'use client';

declare global {
  interface Window {
    google: any;
    googleSignInCallback: (response: any) => void;
  }
}

export interface GoogleUser {
  id: string;
  email: string;
  name: string;
  given_name: string;
  family_name: string;
  picture: string;
}

export class GoogleAuth {
  private static instance: GoogleAuth;
  private clientId: string = '';
  private isInitialized: boolean = false;

  private constructor() {}

  static getInstance(): GoogleAuth {
    if (!GoogleAuth.instance) {
      GoogleAuth.instance = new GoogleAuth();
    }
    return GoogleAuth.instance;
  }

  async initialize(clientId: string): Promise<void> {
    if (this.isInitialized && this.clientId === clientId) {
      return;
    }

    this.clientId = clientId;

    return new Promise((resolve, reject) => {
      if (typeof window === 'undefined') {
        reject(new Error('Google Auth can only be initialized in browser'));
        return;
      }

      // Load Google Identity Services script
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      
      script.onload = () => {
        if (window.google && window.google.accounts) {
          window.google.accounts.id.initialize({
            client_id: this.clientId,
            callback: this.handleCredentialResponse.bind(this),
            auto_select: false,
            cancel_on_tap_outside: true,
          });
          this.isInitialized = true;
          resolve();
        } else {
          reject(new Error('Google Identity Services failed to load'));
        }
      };

      script.onerror = () => {
        reject(new Error('Failed to load Google Identity Services script'));
      };

      document.head.appendChild(script);
    });
  }

  private handleCredentialResponse(response: any) {
    if (window.googleSignInCallback) {
      window.googleSignInCallback(response);
    }
  }

  async signIn(): Promise<GoogleUser> {
    return new Promise((resolve, reject) => {
      if (!this.isInitialized || !window.google) {
        reject(new Error('Google Auth not initialized'));
        return;
      }

      window.googleSignInCallback = (response: any) => {
        try {
          const payload = this.parseJWT(response.credential);
          const user: GoogleUser = {
            id: payload.sub,
            email: payload.email,
            name: payload.name,
            given_name: payload.given_name,
            family_name: payload.family_name,
            picture: payload.picture || ''
          };
          resolve(user);
        } catch (error) {
          reject(error);
        }
      };

      // Trigger the sign-in popup
      window.google.accounts.id.prompt((notification: any) => {
        if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
          // Fallback to popup if prompt is not displayed
          this.showPopup().then(resolve).catch(reject);
        }
      });
    });
  }

  private async showPopup(): Promise<GoogleUser> {
    return new Promise((resolve, reject) => {
      if (!window.google) {
        reject(new Error('Google Auth not initialized'));
        return;
      }

      window.google.accounts.oauth2.initTokenClient({
        client_id: this.clientId,
        scope: 'email profile',
        callback: async (response: any) => {
          if (response.error) {
            reject(new Error(response.error));
            return;
          }

          try {
            // Get user info using the access token
            const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
              headers: {
                'Authorization': `Bearer ${response.access_token}`
              }
            });
            
            if (!userResponse.ok) {
              throw new Error('Failed to fetch user info');
            }
            
            const userData = await userResponse.json();
            const user: GoogleUser = {
              id: userData.id,
              email: userData.email,
              name: userData.name,
              given_name: userData.given_name,
              family_name: userData.family_name,
              picture: userData.picture || ''
            };
            
            resolve(user);
          } catch (error) {
            reject(error);
          }
        }
      }).requestAccessToken();
    });
  }

  private parseJWT(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      return JSON.parse(jsonPayload);
    } catch (error) {
      throw new Error('Invalid JWT token');
    }
  }

  signOut(): void {
    if (window.google && window.google.accounts) {
      window.google.accounts.id.disableAutoSelect();
    }
    // Clear any stored auth data
    localStorage.removeItem('googleAuthToken');
  }
}

export default GoogleAuth;