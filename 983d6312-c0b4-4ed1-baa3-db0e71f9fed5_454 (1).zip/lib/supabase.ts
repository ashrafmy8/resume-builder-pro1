
import { createClient } from '@supabase/supabase-js'
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config'

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

export interface UserProfile {
  id: string
  email: string
  first_name?: string
  last_name?: string
  phone?: string
  company?: string
  job_title?: string
  bio?: string
  avatar_url?: string
  location?: string
  website?: string
  linkedin?: string
  twitter?: string
  role: 'admin' | 'premium' | 'user'
  email_verified: boolean
  email_notifications: boolean
  marketing_emails: boolean
  resume_tips?: boolean
  job_alerts?: boolean
  login_method: 'email' | 'google'
  last_login_at?: string
  created_at: string
  updated_at: string
}

export interface UserPermission {
  id: string
  user_id: string
  permission: string
  granted_at: string
  granted_by?: string
}

export interface EmailNotification {
  id: string
  user_id: string
  email_type: string
  subject?: string
  content?: string
  status: 'pending' | 'sent' | 'failed'
  sent_at?: string
  error_message?: string
  created_at: string
}

// Safe database operations with error handling
const safeDbOperation = async <T>(
  operation: () => Promise<{ data: T | null; error: any }>,
  fallback: T | null = null
): Promise<T | null> => {
  try {
    const result = await operation();
    if (result.error) {
      console.warn('Database operation failed:', result.error);
      return fallback;
    }
    return result.data;
  } catch (error) {
    console.warn('Database operation error:', error);
    return fallback;
  }
};

// User Management Functions
export const userService = {
  async getProfile(userId: string): Promise<UserProfile | null> {
    return safeDbOperation(
      () => supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single(),
      null
    );
  },

  async updateProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile | null> {
    return safeDbOperation(
      () => supabase
        .from('users')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', userId)
        .select()
        .single(),
      null
    );
  },

  async getUserPermissions(userId: string): Promise<UserPermission[]> {
    const result = await safeDbOperation(
      () => supabase
        .from('user_permissions')
        .select('*')
        .eq('user_id', userId),
      []
    );
    return result || [];
  },

  async hasPermission(userId: string, permission: string): Promise<boolean> {
    try {
      const result = await safeDbOperation(
        () => supabase
          .from('user_permissions')
          .select('id')
          .eq('user_id', userId)
          .eq('permission', permission)
          .single(),
        null
      );
      return !!result;
    } catch (error) {
      console.warn('Permission check failed:', error);
      return false;
    }
  },

  async grantPermission(userId: string, permission: string, grantedBy: string): Promise<boolean> {
    const result = await safeDbOperation(
      () => supabase
        .from('user_permissions')
        .insert({
          user_id: userId,
          permission,
          granted_by: grantedBy
        })
        .select()
        .single(),
      null
    );
    return !!result;
  },

  async revokePermission(userId: string, permission: string): Promise<boolean> {
    const result = await safeDbOperation(
      () => supabase
        .from('user_permissions')
        .delete()
        .eq('user_id', userId)
        .eq('permission', permission)
        .select(),
      null
    );
    return !!result;
  }
}

// Email Notification Functions
export const emailService = {
  async sendWelcomeEmail(userId: string, userEmail: string, userName: string): Promise<boolean> {
    try {
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          userId,
          emailType: 'welcome',
          to: userEmail,
          subject: 'Welcome to Resume Teacher! 🎉',
          templateData: { userName }
        })
      });
      
      return response.ok;
    } catch (error) {
      console.warn('Welcome email failed:', error);
      return false;
    }
  },

  async sendNotificationEmail(
    userId: string, 
    emailType: string, 
    to: string, 
    subject: string, 
    content: string
  ): Promise<boolean> {
    try {
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          userId,
          emailType,
          to,
          subject,
          content
        })
      });
      
      return response.ok;
    } catch (error) {
      console.warn('Notification email failed:', error);
      return false;
    }
  },

  async getNotificationHistory(userId: string): Promise<EmailNotification[]> {
    const result = await safeDbOperation(
      () => supabase
        .from('email_notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false }),
      []
    );
    return result || [];
  }
}

// Resume operations with error handling
export const resumeService = {
  async getResumes(userId: string) {
    return safeDbOperation(
      () => supabase
        .from('resumes')
        .select('*')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false }),
      []
    );
  },

  async createResume(userId: string, resumeData: any) {
    return safeDbOperation(
      () => supabase
        .from('resumes')
        .insert([{
          user_id: userId,
          ...resumeData
        }])
        .select()
        .single(),
      null
    );
  },

  async updateResume(resumeId: string, userId: string, updates: any) {
    return safeDbOperation(
      () => supabase
        .from('resumes')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', resumeId)
        .eq('user_id', userId)
        .select()
        .single(),
      null
    );
  },

  async deleteResume(resumeId: string, userId: string) {
    return safeDbOperation(
      () => supabase
        .from('resumes')
        .delete()
        .eq('id', resumeId)
        .eq('user_id', userId)
        .select(),
      null
    );
  }
}

// Affiliate tracking functions
export const affiliateService = {
  async generateAffiliateCode(userId: string): Promise<{code: string, link: string} | null> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const response = await fetch('/api/supabase/functions/affiliate-system', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'generate_affiliate_code' })
      });

      const result = await response.json();
      if (result.success) {
        return {
          code: result.affiliateCode,
          link: result.referralLink
        };
      }
      return null;
    } catch (error) {
      console.warn('Affiliate code generation failed:', error);
      return null;
    }
  },

  async getAffiliateStats(userId: string): Promise<any> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const response = await fetch('/api/supabase/functions/affiliate-system', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'get_affiliate_stats' })
      });

      const result = await response.json();
      return result.success ? result : null;
    } catch (error) {
      console.warn('Affiliate stats loading failed:', error);
      return null;
    }
  },

  async trackReferral(referredUserId: string, affiliateCode: string): Promise<boolean> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return false;

      const response = await fetch('/api/supabase/functions/affiliate-system', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          action: 'track_referral',
          referredUserId,
          affiliateCode
        })
      });

      const result = await response.json();
      return result.success;
    } catch (error) {
      console.warn('Referral tracking failed:', error);
      return false;
    }
  }
}
