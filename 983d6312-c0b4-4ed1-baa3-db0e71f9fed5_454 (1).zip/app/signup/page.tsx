
'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import GoogleAuth, { GoogleUser } from '../../lib/google-auth';
import { GOOGLE_CLIENT_ID } from '../../lib/config';

export default function SignupPage() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    agreeToTerms: false
  });
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [isLoading, setIsLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [googleAuth, setGoogleAuth] = useState<GoogleAuth | null>(null);
  const [emailSent, setEmailSent] = useState(false);
  const [verificationStep, setVerificationStep] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [verifyingCode, setVerifyingCode] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const supabase = createClientComponentClient();
  const router = useRouter();
  
  // Add refs to track component mount status
  const isMountedRef = useRef(true);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  // Check if user is already logged in
  useEffect(() => {
    const checkUser = async () => {
      if (!isMountedRef.current) return;
      
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user && user.email_confirmed_at && isMountedRef.current) {
          router.push('/dashboard');
        }
      } catch (error) {
        console.error('Auth check error:', error);
      }
    };
    checkUser();
  }, [router, supabase.auth]);

  // Initialize Google Auth
  useEffect(() => {
    const initGoogleAuth = async () => {
      if (!GOOGLE_CLIENT_ID || !isMountedRef.current) return;
      
      try {
        const auth = GoogleAuth.getInstance();
        await auth.initialize(GOOGLE_CLIENT_ID);
        if (isMountedRef.current) {
          setGoogleAuth(auth);
        }
      } catch (error) {
        console.error('Failed to initialize Google Auth:', error);
      }
    };

    initGoogleAuth();
  }, []);

  // Safe state setter function
  const safeSetState = (setter: Function) => {
    return (...args: any[]) => {
      if (isMountedRef.current) {
        setter(...args);
      }
    };
  };

  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isMountedRef.current) return;
    
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear specific error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    } else if (formData.firstName.trim().length < 2) {
      newErrors.firstName = 'First name must be at least 2 characters';
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    } else if (formData.lastName.trim().length < 2) {
      newErrors.lastName = 'Last name must be at least 2 characters';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
      newErrors.password = 'Password must contain at least one uppercase letter, one lowercase letter, and one number';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = 'You must agree to the terms and conditions';
    }

    if (isMountedRef.current) {
      setErrors(newErrors);
    }
    return Object.keys(newErrors).length === 0;
  };

  // Create user profile in profiles table
  const createUserProfile = async (userId: string, userData: {
    email: string;
    firstName: string;
    lastName: string;
    loginMethod: 'email' | 'google';
    avatarUrl?: string;
  }) => {
    try {
      console.log('Creating profile for userId:', userId);
      console.log('Profile data:', userData);

      // Check if profile already exists
      const { data: existingProfile, error: checkError } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', userId)
        .maybeSingle();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('Error checking existing profile:', checkError);
        throw checkError;
      }

      if (existingProfile) {
        console.log('User profile already exists');
        return true;
      }

      // Insert new user profile with only the fields that exist in the table
      const profileData = {
        id: userId,
        email: userData.email,
        first_name: userData.firstName,
        last_name: userData.lastName,
        full_name: `${userData.firstName} ${userData.lastName}`,
        avatar_url: userData.avatarUrl || null,
        // Use default values for other fields
        resume_tips: true,
        job_alerts: true,
        product_updates: true,
        newsletter: true,
        email_notifications: true,
        marketing_emails: false
      };

      console.log('Inserting profile data:', profileData);

      const { data, error } = await supabase
        .from('profiles')
        .insert(profileData)
        .select();

      if (error) {
        console.error('Database error creating user profile:', error);
        console.error('Error details:', {
          message: error.message,
          details: error.details,
          hint: error.hint,
          code: error.code
        });
        throw error;
      }
      
      console.log('User profile created successfully:', data);
      return true;
    } catch (error: any) {
      console.error('Unexpected error creating user profile:', error);
      return false;
    }
  };

  // Handle Google signup
  const handleGoogleSignup = async () => {
    if (!googleAuth || !isMountedRef.current) {
      if (isMountedRef.current) {
        setErrors({ google: 'Google authentication not available' });
      }
      return;
    }

    safeSetState(setGoogleLoading)(true);
    safeSetState(setErrors)({});

    try {
      const googleUser: GoogleUser = await googleAuth.signIn();

      if (!googleUser || !googleUser.email) {
        throw new Error('Failed to get user information from Google');
      }

      if (!isMountedRef.current) return;

      // Check if user already exists in Supabase
      const { data: existingUser, error: checkError } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', googleUser.email)
        .maybeSingle();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('Error checking existing user:', checkError);
        throw new Error('Database error during user check');
      }

      if (existingUser && isMountedRef.current) {
        setErrors({ google: 'Account already exists with this email. Please sign in instead.' });
        return;
      }

      if (!isMountedRef.current) return;

      // Create user with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email: googleUser.email,
        password: crypto.randomUUID(), // Random password for Google users
        options: {
          emailRedirectTo: undefined,
          data: {
            first_name: googleUser.given_name || googleUser.name?.split(' ')[0] || 'User',
            last_name: googleUser.family_name || googleUser.name?.split(' ').slice(1).join(' ') || '',
            full_name: googleUser.name || `${googleUser.given_name} ${googleUser.family_name}`,
            avatar_url: googleUser.picture || null,
            provider: 'google',
            custom_verification: true
          }
        }
      });

      if (error) {
        console.error('Supabase auth error:', error);
        throw new Error(error.message);
      }

      if (!data.user || !isMountedRef.current) {
        if (isMountedRef.current) {
          throw new Error('Failed to create user account');
        }
        return;
      }

      // Create user profile
      const firstName = googleUser.given_name || googleUser.name?.split(' ')[0] || 'User';
      const lastName = googleUser.family_name || googleUser.name?.split(' ').slice(1).join(' ') || '';

      const profileCreated = await createUserProfile(data.user.id, {
        email: googleUser.email,
        firstName,
        lastName,
        loginMethod: 'google',
        avatarUrl: googleUser.picture
      });

      if (!profileCreated) {
        console.warn('User profile creation failed, but continuing with signup');
      }

      if (!isMountedRef.current) return;

      // Send custom verification email for Google users too
      try {
        const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
        
        // Create abort controller for this request
        abortControllerRef.current = new AbortController();
        
        const response = await fetch(`${supabaseUrl}/functions/v1/send-verification-email`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({
            userId: data.user.id,
            email: googleUser.email,
            firstName: firstName
          }),
          signal: abortControllerRef.current.signal
        });

        if (!isMountedRef.current) return;

        if (response.ok) {
          // Set form data for verification step
          safeSetState(setFormData)(prev => ({
            ...prev,
            email: googleUser.email,
            firstName: firstName,
            lastName: lastName
          }));
          safeSetState(setCurrentUserId)(data.user.id);
          safeSetState(setVerificationStep)(true);
          safeSetState(setEmailSent)(true);
        } else {
          // If email fails, still allow user to continue
          const userData = {
            id: data.user.id,
            firstName: firstName,
            lastName: lastName,
            email: googleUser.email,
            name: googleUser.name || `${firstName} ${lastName}`,
            loginMethod: 'google',
            emailVerified: true,
            picture: googleUser.picture,
            createdAt: new Date().toISOString()
          };

          if (typeof window !== 'undefined' && isMountedRef.current) {
            localStorage.setItem('user', JSON.stringify(userData));
            localStorage.setItem('isAuthenticated', 'true');
            router.push('/dashboard');
          }
        }
      } catch (emailError: any) {
        if (emailError.name === 'AbortError') {
          return; // Request was aborted, component unmounted
        }
        
        console.error('Email error:', emailError);
        
        if (!isMountedRef.current) return;
        
        // Continue to dashboard even if email fails
        const userData = {
          id: data.user.id,
          firstName: firstName,
          lastName: lastName,
          email: googleUser.email,
          name: googleUser.name || `${firstName} ${lastName}`,
          loginMethod: 'google',
          emailVerified: true,
          picture: googleUser.picture,
          createdAt: new Date().toISOString()
        };

        if (typeof window !== 'undefined') {
          localStorage.setItem('user', JSON.stringify(userData));
          localStorage.setItem('isAuthenticated', 'true');
        }

        router.push('/dashboard');
      }

    } catch (error: any) {
      if (!isMountedRef.current) return;
      
      console.error('Google signup error:', error);
      if (error.message?.includes('popup_closed_by_user')) {
        safeSetState(setErrors)({ google: 'Sign-up was cancelled. Please try again.' });
      } else if (error.message?.includes('already exists')) {
        safeSetState(setErrors)({ google: 'Account already exists with this email. Please sign in instead.' });
      } else {
        safeSetState(setErrors)({ google: error.message || 'Google sign-up failed. Please try again.' });
      }
    } finally {
      if (isMountedRef.current) {
        setGoogleLoading(false);
      }
    }
  };

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !isMountedRef.current) {
      return;
    }

    safeSetState(setIsLoading)(true);
    safeSetState(setErrors)({});

    try {
      // Validate environment variables first
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
      const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseKey) {
        throw new Error('Application configuration error. Please try again later.');
      }

      // Check if user already exists in profiles table first
      const { data: profileCheck, error: profileError } = await supabase
        .from('profiles')
        .select('email')
        .eq('email', formData.email)
        .maybeSingle();

      // Handle errors properly - PGRST116 means no rows found (which is good)
      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Profile check error:', profileError);
        throw new Error('Unable to verify account status. Please try again.');
      }

      if (profileCheck && isMountedRef.current) {
        setErrors({ email: 'An account with this email already exists. Please try logging in instead.' });
        return;
      }

      if (!isMountedRef.current) return;

      // Create new user with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: undefined, // Disable Supabase redirect
          data: {
            first_name: formData.firstName,
            last_name: formData.lastName,
            full_name: `${formData.firstName} ${formData.lastName}`,
            custom_verification: true // Flag to indicate we handle verification
          }
        }
      });

      if (authError) {
        console.error('Auth signup error:', authError);
        
        if (!isMountedRef.current) return;
        
        // Handle specific error cases
        if (authError.message.includes('User already registered')) {
          setErrors({ email: 'An account with this email already exists. Please try logging in instead.' });
        } else if (authError.message.includes('Invalid email')) {
          setErrors({ email: 'Please enter a valid email address' });
        } else if (authError.message.includes('Password')) {
          setErrors({ password: authError.message });
        } else if (authError.message.includes('Signup is disabled')) {
          setErrors({ general: 'Account registration is temporarily disabled. Please try again later.' });
        } else {
          setErrors({ general: `Account creation failed: ${authError.message}` });
        }
        return;
      }

      if (!authData.user || !isMountedRef.current) {
        if (isMountedRef.current) {
          setErrors({ general: 'Failed to create user account. Please try again.' });
        }
        return;
      }

      console.log('Auth user created successfully:', authData.user.id);

      // Create user profile in profiles table
      const profileCreated = await createUserProfile(authData.user.id, {
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        loginMethod: 'email'
      });

      if (!profileCreated) {
        console.warn('User profile creation failed, but continuing with signup process');
      }

      if (!isMountedRef.current) return;

      // Send our custom verification email
      console.log('Sending verification email to:', formData.email);
      
      // Create abort controller for this request
      abortControllerRef.current = new AbortController();
      
      const emailResponse = await fetch(`${supabaseUrl}/functions/v1/send-verification-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`
        },
        body: JSON.stringify({
          userId: authData.user.id,
          email: formData.email,
          firstName: formData.firstName
        }),
        signal: abortControllerRef.current.signal
      });

      if (!isMountedRef.current) return;

      console.log('Email service response status:', emailResponse.status);

      if (!emailResponse.ok) {
        const errorText = await emailResponse.text();
        console.error('Email service error:', errorText);
        throw new Error(`Unable to send verification email. Please contact support.`);
      }

      let emailResult;
      try {
        const responseText = await emailResponse.text();
        console.log('Email service response:', responseText);
        emailResult = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Failed to parse email response:', parseError);
        throw new Error('Email service returned invalid response. Please contact support.');
      }
      
      if (!emailResult || emailResult.error) {
        throw new Error(emailResult?.error || 'Failed to send verification email');
      }

      if (!isMountedRef.current) return;

      console.log('Custom OTP email sent successfully:', emailResult);
      safeSetState(setCurrentUserId)(authData.user.id);
      safeSetState(setVerificationStep)(true);
      safeSetState(setEmailSent)(true);
        
    } catch (error: any) {
      if (error.name === 'AbortError') {
        return; // Request was aborted, component unmounted
      }
      
      if (!isMountedRef.current) return;
      
      console.error('Signup error:', error);
      setErrors({ 
        general: error.message || 'An unexpected error occurred. Please try again.' 
      });
    } finally {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!verificationCode.trim() || !isMountedRef.current) {
      if (isMountedRef.current) {
        setErrors({ verification: 'Please enter the verification code' });
      }
      return;
    }

    if (verificationCode.trim().length !== 6 || !/^\d{6}$/.test(verificationCode.trim())) {
      if (isMountedRef.current) {
        setErrors({ verification: 'Verification code must be exactly 6 digits' });
      }
      return;
    }

    safeSetState(setVerifyingCode)(true);
    safeSetState(setErrors)({});

    try {
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
      
      // Create abort controller for this request
      abortControllerRef.current = new AbortController();
      
      const response = await fetch(`${supabaseUrl}/functions/v1/verify-email-code`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          userId: currentUserId,
          email: formData.email,
          verificationCode: verificationCode.trim()
        }),
        signal: abortControllerRef.current.signal
      });

      if (!isMountedRef.current) return;

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      
      if (!result.success && isMountedRef.current) {
        if (result.expired) {
          setErrors({ verification: 'Code expired. Click "Resend Code" to get a new one.' });
        } else {
          setErrors({ verification: result.error || 'Invalid verification code' });
        }
        return;
      }

      if (!isMountedRef.current) return;

      console.log('Custom OTP verification successful:', result);

      // Store user authentication data
      const userData = {
        id: currentUserId,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        name: `${formData.firstName} ${formData.lastName}`,
        loginMethod: 'email',
        emailVerified: true,
        verificationMethod: 'custom_otp',
        createdAt: new Date().toISOString()
      };

      // Store authentication data
      if (typeof window !== 'undefined' && isMountedRef.current) {
        localStorage.setItem('user', JSON.stringify(userData));
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('customVerification', 'true');
        router.push('/dashboard');
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        return; // Request was aborted, component unmounted
      }
      
      if (!isMountedRef.current) return;
      
      console.error('Custom verification error:', error);
      setErrors({ verification: 'Verification failed. Please try again or contact support.' });
    } finally {
      if (isMountedRef.current) {
        setVerifyingCode(false);
      }
    }
  };

  const resendVerificationCode = async () => {
    if (!currentUserId || !formData.email || !formData.firstName || !isMountedRef.current) {
      if (isMountedRef.current) {
        setErrors({ verification: 'Missing user information. Please try signing up again.' });
      }
      return;
    }

    try {
      safeSetState(setIsLoading)(true);
      safeSetState(setErrors)({});
      
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
      
      // Create abort controller for this request
      abortControllerRef.current = new AbortController();
      
      const response = await fetch(`${supabaseUrl}/functions/v1/send-verification-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          userId: currentUserId,
          email: formData.email,
          firstName: formData.firstName
        }),
        signal: abortControllerRef.current.signal
      });

      if (!isMountedRef.current) return;

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      
      if (!result || result.error) {
        throw new Error(result?.error || 'Failed to resend verification email');
      }

      if (isMountedRef.current) {
        console.log('Custom OTP resent successfully:', result);
        setErrors({ success: 'New verification code sent to your email. Check your inbox!' });
        setVerificationCode(''); // Clear current code
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        return; // Request was aborted, component unmounted
      }
      
      if (!isMountedRef.current) return;
      
      console.error('Resend error:', error);
      setErrors({ verification: 'Failed to resend code. Please try again.' });
    } finally {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }
  };

  // Verification Step UI - Enhanced for custom OTP
  if (verificationStep) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-50 animate-pulse delay-500"></div>
        </div>

        <div className="relative z-10 min-h-screen flex items-center justify-center px-4 py-12">
          <div className="max-w-md w-full">
            <div className="bg-white/90 backdrop-blur-lg rounded-2xl shadow-xl border border-white/20 p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-mail-check-fill text-2xl text-white"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Enter Your Code</h2>
              <p className="text-gray-600 mb-4">
                We've sent a <strong>6-digit verification code</strong> to:
              </p>
              <p className="font-semibold text-blue-600 mb-6">{formData.email}</p>

              {errors.verification && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-600 flex items-center justify-center">
                    <i className="ri-error-warning-fill mr-2"></i>
                    {errors.verification}
                  </p>
                </div>
              )}
              {errors.success && (
                <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-600 flex items-center justify-center">
                    <i className="ri-check-fill mr-2"></i>
                    {errors.success}
                  </p>
                </div>
              )}

              <form onSubmit={handleVerifyCode} className="space-y-6">
                <div className="bg-gray-50 rounded-xl p-4">
                  <label htmlFor="verificationCode" className="block text-sm font-medium text-gray-700 mb-3">
                    Enter 6-digit code from your email
                  </label>
                  <input
                    id="verificationCode"
                    type="text"
                    value={verificationCode}
                    onChange={(e) => {
                      if (!isMountedRef.current) return;
                      const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                      setVerificationCode(value);
                      if (errors.verification) {
                        setErrors(prev => ({ ...prev, verification: '' }));
                      }
                    }}
                    className="w-full px-4 py-4 text-center text-3xl font-mono border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 tracking-widest bg-white transition-all"
                    placeholder="000000"
                    maxLength={6}
                    autoComplete="one-time-code"
                    inputMode="numeric"
                  />
                </div>

                <button
                  type="submit"
                  disabled={verifyingCode || verificationCode.length !== 6}
                  className="w-full py-4 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all whitespace-nowrap cursor-pointer"
                >
                  {verifyingCode ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Verifying...
                    </div>
                  ) : (
                    'Verify & Continue to Dashboard'
                  )}
                </button>
              </form>

              <div className="mt-6 p-4 bg-blue-50 rounded-xl">
                <p className="text-sm text-blue-800 mb-3">
                  <i className="ri-time-fill mr-1"></i>
                  Code expires in 15 minutes
                </p>
                <p className="text-sm text-gray-600 mb-3">
                  Didn't receive the code? Check your spam folder or:
                </p>
                <button
                  onClick={resendVerificationCode}
                  disabled={isLoading}
                  className="text-blue-600 hover:text-blue-500 font-semibold text-sm disabled:opacity-50 cursor-pointer transition-colors"
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center">
                      <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                      Sending New Code...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      <i className="ri-refresh-line mr-1"></i>
                      Send New Code
                    </span>
                  )}
                </button>
              </div>

              <div className="mt-6">
                <button
                  onClick={() => {
                    if (!isMountedRef.current) return;
                    setVerificationStep(false);
                    setEmailSent(false);
                    setVerificationCode('');
                    setErrors({});
                  }}
                  className="text-gray-500 hover:text-gray-700 text-sm cursor-pointer flex items-center justify-center"
                >
                  <i className="ri-arrow-left-line mr-1"></i>
                  Change Email Address
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Email Sent Confirmation UI
  if (emailSent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-50 animate-pulse delay-500"></div>
        </div>

        <div className="relative z-10 min-h-screen flex items-center justify-center px-4 py-12">
          <div className="max-w-md w-full">
            <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl border border-white/20 p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-mail-check-fill text-2xl text-green-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Check your email</h2>
              <p className="text-gray-600 mb-6">
                We've sent a verification code to <strong>{formData.email}</strong>
              </p>
              <p className="text-sm text-gray-500 mb-6">
                Enter the 6-digit code from your email to complete signup and access your dashboard.
              </p>
              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (isMountedRef.current) {
                      setVerificationStep(true);
                    }
                  }}
                  className="w-full py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 whitespace-nowrap cursor-pointer"
                >
                  Enter Verification Code
                </button>
                <button
                  onClick={() => {
                    if (isMountedRef.current) {
                      setEmailSent(false);
                    }
                  }}
                  className="w-full py-3 px-4 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 whitespace-nowrap cursor-pointer"
                >
                  Try Different Email
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Main Signup Form UI
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-50 animate-pulse delay-500"></div>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <Link href="/" className="text-3xl font-['Pacifico'] text-blue-600 hover:text-blue-700 transition-colors">
              ResumeTeacher
            </Link>
            <h2 className="mt-6 text-3xl font-bold text-gray-900">Create your account</h2>
            <p className="mt-2 text-sm text-gray-600">
              Join thousands of professionals who trust ResumeTeacher
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-xl border border-white/20 p-8">
            {errors.general && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">{errors.general}</p>
              </div>
            )}
            {errors.google && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">{errors.google}</p>
              </div>
            )}

            {/* Google Sign-up Button */}
            {GOOGLE_CLIENT_ID && (
              <>
                <div className="space-y-3 mb-6">
                  <button
                    onClick={handleGoogleSignup}
                    disabled={googleLoading || isLoading}
                    className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
                  >
                    {googleLoading ? (
                      <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-3"></div>
                    ) : (
                      <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-3.15c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.2 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                    )}
                    Continue with Google
                  </button>
                </div>

                <div className="relative mb-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">Or continue with email</span>
                  </div>
                </div>
              </>
            )}

            {/* Email Signup Form */}
            <form onSubmit={handleEmailSignup} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                    First Name *
                  </label>
                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors text-sm ${errors.firstName ? 'border-red-500' : 'border-gray-300'}`}
                    placeholder="John"
                    autoComplete="given-name"
                  />
                  {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>}
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name *
                  </label>
                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors text-sm ${errors.lastName ? 'border-red-500' : 'border-gray-300'}`}
                    placeholder="Doe"
                    autoComplete="family-name"
                  />
                  {errors.lastName && <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>}
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors text-sm ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
                  placeholder="john@example.com"
                  autoComplete="email"
                />
                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password *
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors text-sm ${errors.password ? 'border-red-500' : 'border-gray-300'}`}
                  placeholder="••••••••"
                  autoComplete="new-password"
                />
                {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
                <p className="text-xs text-gray-500 mt-1">
                  Minimum 8 characters with uppercase, lowercase, and number
                </p>
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password *
                </label>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors text-sm ${errors.confirmPassword ? 'border-red-500' : 'border-gray-300'}`}
                  placeholder="••••••••"
                  autoComplete="new-password"
                />
                {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>}
              </div>

              <div className="flex items-start">
                <input
                  id="agreeToTerms"
                  name="agreeToTerms"
                  type="checkbox"
                  checked={formData.agreeToTerms}
                  onChange={handleInputChange}
                  className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer"
                />
                <label htmlFor="agreeToTerms" className="ml-2 block text-sm text-gray-700 cursor-pointer">
                  I agree to the{' '}
                  <Link href="/terms" className="text-blue-600 hover:text-blue-500">
                    Terms of Service
                  </Link>{' '}
                  and{' '}
                  <Link href="/privacy" className="text-blue-600 hover:text-blue-500">
                    Privacy Policy
                  </Link>
                </label>
              </div>
              {errors.agreeToTerms && <p className="text-red-500 text-xs">{errors.agreeToTerms}</p>}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-2 00 whitespace-nowrap cursor-pointer"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  'Create Account'
                )}
              </button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Already have an account?{' '}
                <Link href="/login" className="text-blue-600 hover:text-blue-500 font-medium">
                  Sign in
                </Link>
              </p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <div className="flex items-center justify-center space-x-6 text-sm text-gray-500">
              <div className="flex items-center">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-shield-check-fill text-green-500"></i>
                </div>
                Secure & Private
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-user-3-fill text-blue-500"></i>
                </div>
                500K+ Users
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 flex items-center justify-center mr-2">
                  <i className="ri-star-fill text-yellow-500"></i>
                </div>
                4.9/5 Rating
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
