
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import Link from 'next/link';
import ProfileManager from '@/components/ProfileManager';
import ActivityTracker from '@/components/ActivityTracker';
import LiveActivityMonitor from '@/components/LiveActivityMonitor';

interface Resume {
  id: string;
  title: string;
  status: 'draft' | 'in-progress' | 'completed';
  created_at: string;
  updated_at: string;
  template_id?: string;
  user_id: string;
}

interface DashboardStats {
  totalResumes: number;
  completedResumes: number;
  inProgressResumes: number;
  draftResumes: number;
}

interface UserProfile {
  id: string;
  email: string;
  name?: string;
  first_name?: string;
  last_name?: string;
  avatar_url?: string;
  phone?: string;
  company?: string;
  job_title?: string;
  bio?: string;
  location?: string;
  website?: string;
  linkedin?: string;
  twitter?: string;
  created_at?: string;
}

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalResumes: 0,
    completedResumes: 0,
    inProgressResumes: 0,
    draftResumes: 0
  });
  const [loading, setLoading] = useState(true);
  const [showProfileManager, setShowProfileManager] = useState(false);
  const [isSupabaseConnected, setIsSupabaseConnected] = useState(false);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [liveStats, setLiveStats] = useState({
    sessionTime: 0,
    currentStreak: 0,
    resumesInProgress: 0
  });

  useEffect(() => {
    initializeAuth();
  }, []);

  useEffect(() => {
    if (user && isSupabaseConnected) {
      fetchUserResumes();
    }
  }, [user, isSupabaseConnected]);

  useEffect(() => {
    calculateStats();
  }, [resumes]);

  const handleActivityUpdate = (activity: any) => {
    setRecentActivity(prev => [activity, ...prev.slice(0, 9)]);

    // Update live stats
    if (activity.activity_type === 'resume_edit') {
      setLiveStats(prev => ({
        ...prev,
        resumesInProgress: prev.resumesInProgress + 1
      }));
    }
  };

  // Track session time
  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      setLiveStats(prev => ({
        ...prev,
        sessionTime: Math.floor((Date.now() - startTime) / 1000)
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const initializeAuth = async () => {
    try {
      setLoading(true);

      // Check for active Supabase session
      const { data: { session }, error } = await supabase.auth.getSession();

      if (error) {
        console.warn('Supabase auth error:', error);
        setIsSupabaseConnected(false);
        handleFallbackAuth();
        return;
      }

      if (session?.user) {
        // User is authenticated with Supabase
        setIsSupabaseConnected(true);
        const supabaseUser: UserProfile = {
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.full_name || session.user.user_metadata?.name,
          first_name: session.user.user_metadata?.first_name,
          last_name: session.user.user_metadata?.last_name,
          avatar_url: session.user.user_metadata?.avatar_url,
          created_at: session.user.created_at
        };

        // Load enhanced profile from profiles table
        const enhancedProfile = await loadUserProfile(supabaseUser);
        setUser(enhancedProfile);

        // Sync with profiles table
        await syncUserProfile(enhancedProfile);
      } else {
        // No Supabase session, check localStorage
        setIsSupabaseConnected(false);
        handleFallbackAuth();
      }
    } catch (error) {
      console.warn('Auth initialization failed:', error);
      setIsSupabaseConnected(false);
      handleFallbackAuth();
    } finally {
      setLoading(false);
    }
  };

  const loadUserProfile = async (baseUser: UserProfile): Promise<UserProfile> => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', baseUser.id)
        .single();

      if (profile) {
        return {
          ...baseUser,
          first_name: profile.first_name || baseUser.first_name,
          last_name: profile.last_name || baseUser.last_name,
          phone: profile.phone,
          company: profile.company,
          job_title: profile.job_title,
          bio: profile.bio,
          location: profile.location,
          website: profile.website,
          linkedin: profile.linkedin,
          twitter: profile.twitter,
          avatar_url: profile.avatar_url || baseUser.avatar_url
        };
      }
    } catch (error) {
      console.warn('Failed to load enhanced profile:', error);
    }

    return baseUser;
  };

  const handleFallbackAuth = () => {
    // Fallback to localStorage for demo/development
    const userData = localStorage.getItem('user');
    const isAuth = localStorage.getItem('isAuthenticated');

    if (isAuth === 'true' && userData) {
      try {
        const parsedUser = JSON.parse(userData);
        setUser({
          id: parsedUser.id || 'demo-user-' + Date.now(),
          email: parsedUser.email || 'demo@example.com',
          name: parsedUser.name || parsedUser.firstName || 'Demo User',
          first_name: parsedUser.firstName,
          last_name: parsedUser.lastName,
          avatar_url: parsedUser.picture || parsedUser.avatar_url
        });
      } catch (error) {
        console.warn('Invalid user data in localStorage:', error);
        redirectToLogin();
      }
    } else {
      redirectToLogin();
    }
  };

  const syncUserProfile = async (user: UserProfile) => {
    if (!isSupabaseConnected) return;

    try {
      // Check if profile exists
      const { data: existingProfile } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .single();

      if (!existingProfile) {
        // Create profile
        await supabase
          .from('profiles')
          .insert([{
            id: user.id,
            email: user.email,
            first_name: user.first_name,
            last_name: user.last_name,
            avatar_url: user.avatar_url,
            updated_at: new Date().toISOString()
          }]);
      }
    } catch (error) {
      console.warn('Profile sync failed:', error);
    }
  };

  const fetchUserResumes = async () => {
    if (!user?.id) return;

    try {
      if (isSupabaseConnected) {
        // Fetch from Supabase with RLS protection
        const { data, error } = await supabase
          .from('resumes')
          .select('*')
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false });

        if (error) {
          console.warn('Database query error:', error);
          setFallbackResumes();
        } else {
          setResumes(data || []);
        }
      } else {
        // Use localStorage for demo data
        setFallbackResumes();
      }
    } catch (error) {
      console.warn('Resume fetch failed:', error);
      setFallbackResumes();
    }
  };

  const setFallbackResumes = () => {
    const demoResumes = [
      {
        id: 'demo-1',
        title: 'Software Engineer Resume',
        status: 'completed' as const,
        created_at: '2024-01-15T10:00:00Z',
        updated_at: '2024-01-20T10:00:00Z',
        template_id: 'modern',
        user_id: user?.id || 'demo-user'
      },
      {
        id: 'demo-2',
        title: 'Marketing Manager Resume',
        status: 'in-progress' as const,
        created_at: '2024-01-18T10:00:00Z',
        updated_at: '2024-01-19T10:00:00Z',
        template_id: 'professional',
        user_id: user?.id || 'demo-user'
      },
      {
        id: 'demo-3',
        title: 'Data Analyst Resume',
        status: 'draft' as const,
        created_at: '2024-01-20T10:00:00Z',
        updated_at: '2024-01-20T10:00:00Z',
        template_id: 'creative',
        user_id: user?.id || 'demo-user'
      }
    ];
    setResumes(demoResumes);
  };

  const calculateStats = () => {
    const totalResumes = resumes.length;
    const completedResumes = resumes.filter(r => r.status === 'completed').length;
    const inProgressResumes = resumes.filter(r => r.status === 'in-progress').length;
    const draftResumes = resumes.filter(r => r.status === 'draft').length;

    setStats({
      totalResumes,
      completedResumes,
      inProgressResumes,
      draftResumes
    });
  };

  const createNewResume = async () => {
    if (!user?.id) return;

    const newResumeData = {
      title: 'New Resume',
      status: 'draft' as const,
      template_id: 'modern',
      user_id: user.id,
      content: {}
    };

    try {
      if (isSupabaseConnected) {
        // Create in Supabase
        const { data, error } = await supabase
          .from('resumes')
          .insert([newResumeData])
          .select()
          .single();

        if (error) {
          console.warn('Database insert failed:', error);
          addResumeLocally(newResumeData);
        } else {
          setResumes(prev => [data, ...prev]);
        }
      } else {
        // Add locally
        addResumeLocally(newResumeData);
      }
    } catch (error) {
      console.warn('Resume creation failed:', error);
      addResumeLocally(newResumeData);
    }
  };

  const addResumeLocally = (resumeData: any) => {
    const localResume = {
      ...resumeData,
      id: 'local-' + Date.now(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    setResumes(prev => [localResume, ...prev]);
  };

  const deleteResume = async (resumeId: string) => {
    try {
      if (isSupabaseConnected) {
        const { error } = await supabase
          .from('resumes')
          .delete()
          .eq('id', resumeId)
          .eq('user_id', user?.id);

        if (error) {
          console.warn('Database delete failed:', error);
        }
      }
    } catch (error) {
      console.warn('Resume deletion failed:', error);
    }

    // Always remove from local state
    setResumes(prev => prev.filter(r => r.id !== resumeId));
  };

  const redirectToLogin = () => {
    router.push('/login?redirect=/dashboard');
  };

  const handleLogout = async () => {
    try {
      if (isSupabaseConnected) {
        await supabase.auth.signOut();
      }
    } catch (error) {
      console.warn('Supabase logout failed:', error);
    }

    // Clear localStorage
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('user');
    localStorage.removeItem('googleAuthToken');

    router.push('/');
  };

  const handleProfileUpdate = (updatedProfile: UserProfile) => {
    setUser(updatedProfile);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'in-progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'draft': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getProgressPercentage = () => {
    if (stats.totalResumes === 0) return 0;
    return Math.round((stats.completedResumes / stats.totalResumes) * 100);
  };

  const getDisplayName = () => {
    if (user?.first_name && user?.last_name) {
      return `${user.first_name} ${user.last_name}`;
    }
    if (user?.name) return user.name.split(' ')[0];
    if (user?.first_name) return user.first_name;
    if (user?.email) return user.email.split('@')[0];
    return 'User';
  };

  const getInitials = () => {
    if (user?.first_name && user?.last_name) {
      return `${user.first_name.charAt(0)}${user.last_name.charAt(0)}`.toUpperCase();
    }
    if (user?.name) {
      const names = user.name.split(' ');
      return names.length > 1
        ? `${names[0].charAt(0)}${names[1].charAt(0)}`.toUpperCase()
        : names[0].charAt(0).toUpperCase();
    }
    return 'U';
  };

  return (
    <div className="min-h-screen bg-gray-50" suppressHydrationWarning={true}>
      {/* Activity Tracker - invisible component */}
      {user && (
        <ActivityTracker 
          userId={user.id} 
          onActivityUpdate={handleActivityUpdate}
        />
      )}

      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link href="/" className="font-['Pacifico'] text-2xl text-blue-600">
                Resume Teacher
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              {/* Live Session Indicator */}
              <div className="hidden md:flex items-center space-x-3 bg-green-50 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-green-700">
                  Active {Math.floor(liveStats.sessionTime / 60)}m {liveStats.sessionTime % 60}s
                </span>
              </div>

              {isSupabaseConnected && (
                <div className="w-3 h-3 bg-green-500 rounded-full" title="Connected to Supabase"></div>
              )}
              <button
                onClick={handleLogout}
                className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer rounded-lg"
                title="Logout"
              >
                <i className="ri-logout-circle-line text-xl"></i>
              </button>
              <button
                onClick={() => setShowProfileManager(true)}
                className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 transition-colors cursor-pointer"
                title="Edit Profile"
              >
                <i className="ri-settings-3-line text-xl"></i>
              </button>
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center cursor-pointer" onClick={() => setShowProfileManager(true)}>
                {user?.avatar_url ? (
                  <img src={user.avatar_url} alt={getDisplayName()} className="w-8 h-8 rounded-full object-cover" />
                ) : (
                  <span className="text-blue-600 font-medium text-sm">
                    {getInitials()}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {getDisplayName()}!
          </h1>
          <p className="text-gray-600 flex items-center space-x-4">
            <span>Your personal dashboard - manage your resumes and track your progress</span>
            {isSupabaseConnected && <span className="text-green-600 text-sm">✓ Synced with your account</span>}
            <span className="text-blue-600 text-sm">
              • {liveStats.resumesInProgress} resumes in progress this session
            </span>
          </p>
        </div>

        {/* Enhanced Stats Cards with Live Data */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="ri-file-text-line text-2xl text-blue-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Your Resumes</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalResumes}</p>
                {recentActivity.filter(a => a.activity_type === 'resume_edit').length > 0 && (
                  <p className="text-xs text-green-600">• Active editing</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="ri-check-line text-2xl text-green-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-gray-900">{stats.completedResumes}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-2xl text-yellow-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Session Time</p>
                <p className="text-2xl font-bold text-gray-900">
                  {Math.floor(liveStats.sessionTime / 60)}:{(liveStats.sessionTime % 60).toString().padStart(2, '0')}
                </p>
                <p className="text-xs text-blue-600">• Live tracking</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="ri-trophy-line text-2xl text-purple-600"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-gray-900">{getProgressPercentage()}%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Live Activity Monitor */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            {/* Personal Progress */}
            <div className="bg-white p-6 rounded-xl shadow-sm border mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Your Progress</h3>
                <span className="text-sm text-gray-600">{getProgressPercentage()}% Complete</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${getProgressPercentage()}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600">
                You've completed {stats.completedResumes} out of {stats.totalResumes} resumes. Keep up the great work!
              </p>
            </div>

            {/* Quick Actions */}
            <div className="grid md:grid-cols-2 gap-6">
              <Link
                href="/builder"
                className="group bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl p-8 text-white hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl cursor-pointer"
              >
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <i className="ri-add-line text-2xl"></i>
                  </div>
                  <div className="ml-4 text-left">
                    <h4 className="font-semibold">Create New Resume</h4>
                    <p className="text-sm text-blue-100">Start building your perfect resume</p>
                  </div>
                </div>
              </Link>

              <Link
                href="/templates"
                className="group bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-8 text-white hover:from-emerald-600 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl cursor-pointer"
              >
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <i className="ri-layout-line text-2xl"></i>
                  </div>
                  <div className="ml-4 text-left">
                    <h4 className="font-semibold">Browse Templates</h4>
                    <p className="text-sm text-emerald-100">Choose from 100+ professional designs</p>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          <div className="lg:col-span-1">
            {user && (
              <LiveActivityMonitor userId={user.id} maxActivities={15} />
            )}
          </div>
        </div>

        {/* Personal Resume Collection */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-6 border-b">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Your Resume Collection</h3>
              <Link href="/my-resumes" className="text-blue-600 hover:text-blue-700 text-sm font-medium cursor-pointer">
                View All
              </Link>
            </div>
          </div>

          {resumes.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-file-text-line text-2xl text-gray-400"></i>
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">No resumes yet</h4>
              <p className="text-gray-600 mb-6">Create your first resume to get started on your career journey</p>
              <button
                onClick={createNewResume}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                Create Your First Resume
              </button>
            </div>
          ) : (
            <div className="divide-y">
              {resumes.slice(0, 5).map((resume) => (
                <div key={resume.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className="ri-file-text-line text-xl text-blue-600"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 flex items-center space-x-2">
                          <span>{resume.title}</span>
                          {recentActivity.find(a => a.activity_data?.resume_id === resume.id) && (
                            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" title="Recently active"></div>
                          )}
                        </h4>
                        <p className="text-sm text-gray-600">
                          Updated {new Date(resume.updated_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(resume.status)}`}>
                        {resume.status.charAt(0).toUpperCase() + resume.status.slice(1)}
                      </span>
                      <div className="flex items-center space-x-2">
                        <Link
                          href={`/builder?resume=${resume.id}`}
                          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-blue-600 transition-colors cursor-pointer"
                          title="Edit Resume"
                        >
                          <i className="ri-edit-line"></i>
                        </Link>
                        <button
                          onClick={() => deleteResume(resume.id)}
                          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-600 transition-colors cursor-pointer"
                          title="Delete Resume"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showProfileManager && (
        <ProfileManager
          user={user}
          onClose={() => setShowProfileManager(false)}
          onUpdate={handleProfileUpdate}
        />
      )}
    </div>
  );
}
