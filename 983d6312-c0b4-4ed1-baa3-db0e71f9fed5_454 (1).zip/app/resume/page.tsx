'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function ResumePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/resume" className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-1 whitespace-nowrap">
                Resume
              </Link>
              <Link href="/cv" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                CV
              </Link>
              <Link href="/cover-letter" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Cover Letter
              </Link>
              <Link href="/advice" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Advice
              </Link>
              <Link href="/resources" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Resources
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Professional Resume Builder
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Create stunning resumes that get you hired. Choose from professional templates,
            get AI-powered suggestions, and build your perfect resume in minutes.
          </p>
          <Link href="/builder" className="inline-flex items-center px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-add-line mr-2"></i>
            Start Building
          </Link>
        </div>
      </section>

      {/* Resume Tools Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Everything You Need to Build the Perfect Resume
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Link href="/resume-templates" className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:border-blue-300">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-orange-200 transition-colors">
                <i className="ri-file-copy-line text-orange-600 text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Resume Templates</h3>
              <p className="text-gray-600 mb-4">
                Browse our collection of professional, ATS-friendly resume templates designed by career experts.
              </p>
              <div className="flex items-center text-blue-600 font-semibold">
                Browse Templates
                <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/resume-examples" className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:border-blue-300">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-colors">
                <i className="ri-award-line text-blue-600 text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Resume Examples</h3>
              <p className="text-gray-600 mb-4">
                Get inspired by real resume examples from successful professionals across various industries.
              </p>
              <div className="flex items-center text-blue-600 font-semibold">
                View Examples
                <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/formats" className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:border-blue-300">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-200 transition-colors">
                <i className="ri-layout-line text-green-600 text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Resume Formats</h3>
              <p className="text-gray-600 mb-4">
                Learn about different resume formats and choose the best one for your career situation.
              </p>
              <div className="flex items-center text-blue-600 font-semibold">
                Learn Formats
                <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/ai-resume-skills-generator" className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:border-blue-300">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-colors">
                <i className="ri-settings-3-line text-purple-600 text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">AI Skills Generator</h3>
              <p className="text-gray-600 mb-4">
                Generate relevant skills for your resume using AI based on your job title and industry.
              </p>
              <div className="flex items-center text-blue-600 font-semibold">
                Generate Skills
                <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/ats-resume-checker" className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:border-blue-300">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-yellow-200 transition-colors">
                <i className="ri-shield-check-line text-yellow-600 text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">ATS Resume Checker</h3>
              <p className="text-gray-600 mb-4">
                Ensure your resume passes Applicant Tracking Systems with our comprehensive ATS checker.
              </p>
              <div className="flex items-center text-blue-600 font-semibold">
                Check Resume
                <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/ai-review" className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 hover:border-blue-300">
              <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-teal-200 transition-colors">
                <i className="ri-search-eye-line text-teal-600 text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">AI Resume Review</h3>
              <p className="text-gray-600 mb-4">
                Get instant feedback on your resume with AI-powered analysis and improvement suggestions.
              </p>
              <div className="flex items-center text-blue-600 font-semibold">
                Review Resume
                <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            How to Build Your Resume
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Choose Template</h3>
              <p className="text-gray-600">
                Select from our professional resume templates designed to impress employers and pass ATS systems.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Add Your Info</h3>
              <p className="text-gray-600">
                Fill in your details with AI assistance to create compelling content that highlights your achievements.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Download & Apply</h3>
              <p className="text-gray-600">
                Download your polished resume and start applying to your dream jobs with confidence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Build Your Professional Resume?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Join thousands of job seekers who have successfully landed their dream jobs using our resume builder.
          </p>
          <Link href="/builder" className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-rocket-2-line mr-2"></i>
            Start Building Now
          </Link>
        </div>
      </section>
    </div>
  );
}