
'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import AIContentSuggestions from '../../components/AIContentSuggestions';

// Rich Text Editor Component
interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  rows?: number;
  className?: string;
}

function RichTextEditor({ value, onChange, placeholder, rows = 4, className = '' }: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isToolbarVisible, setIsToolbarVisible] = useState(false);
  const [selectedText, setSelectedText] = useState('');

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = value;
    }
  }, []);

  const handleInput = () => {
    if (editorRef.current) {
      const content = editorRef.current.innerHTML;
      onChange(content);
    }
  };

  const handleSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().length > 0) {
      setSelectedText(selection.toString());
      setIsToolbarVisible(true);
    } else {
      setIsToolbarVisible(false);
    }
  };

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    handleInput();
    if (editorRef.current) {
      editorRef.current.focus();
    }
  };

  const insertList = (type: 'ul' | 'ol') => {
    const selection = window.getSelection();
    if (selection && editorRef.current) {
      const range = selection.getRangeAt(0);
      const listElement = document.createElement(type);
      const listItem = document.createElement('li');

      if (selection.toString().length > 0) {
        listItem.textContent = selection.toString();
        range.deleteContents();
      } else {
        listItem.innerHTML = '&nbsp;';
      }

      listElement.appendChild(listItem);
      range.insertNode(listElement);

      // Position cursor at end of list item
      const newRange = document.createRange();
      newRange.setStartAfter(listItem);
      newRange.collapse(true);
      selection.removeAllRanges();
      selection.addRange(newRange);

      handleInput();
    }
  };

  const formatButtons = [
    { command: 'bold', icon: 'ri-bold', title: 'Bold' },
    { command: 'italic', icon: 'ri-italic', title: 'Italic' },
    { command: 'underline', icon: 'ri-underline', title: 'Underline' },
    { command: 'strikeThrough', icon: 'ri-strikethrough', title: 'Strikethrough' }
  ];

  const alignButtons = [
    { command: 'justifyLeft', icon: 'ri-align-left', title: 'Align Left' },
    { command: 'justifyCenter', icon: 'ri-align-center', title: 'Align Center' },
    { command: 'justifyRight', icon: 'ri-align-right', title: 'Align Right' },
    { command: 'justifyFull', icon: 'ri-align-justify', title: 'Justify' }
  ];

  const fontSizes = ['12px', '14px', '16px', '18px', '20px', '24px', '28px', '32px'];
  const colors = ['#000000', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080', '#008000'];

  return (
    <div className={`border border-gray-200 rounded-lg overflow-hidden ${className}`}>
      {/* Toolbar */}
      <div className="bg-gray-50 border-b border-gray-200 p-2 flex items-center gap-1 flex-wrap">
        {/* Text Formatting */}
        <div className="flex items-center gap-1 border-r border-gray-300 pr-2 mr-2">
          {formatButtons.map((btn) => (
            <button
              key={btn.command}
              type="button"
              onClick={() => execCommand(btn.command)}
              className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
              title={btn.title}
            >
              <i className={`${btn.icon} text-sm`}></i>
            </button>
          ))}
        </div>

        {/* Font Size */}
        <div className="flex items-center gap-1 border-r border-gray-300 pr-2 mr-2">
          <select
            onChange={(e) => execCommand('fontSize', e.target.value)}
            className="text-xs border border-gray-300 rounded px-2 py-1 bg-white"
            defaultValue="3"
          >
            <option value="1">8px</option>
            <option value="2">10px</option>
            <option value="3">12px</option>
            <option value="4">14px</option>
            <option value="5">18px</option>
            <option value="6">24px</option>
            <option value="7">36px</option>
          </select>
        </div>

        {/* Text Color */}
        <div className="flex items-center gap-1 border-r border-gray-300 pr-2 mr-2">
          <input
            type="color"
            onChange={(e) => execCommand('foreColor', e.target.value)}
            className="w-8 h-8 border border-gray-300 rounded cursor-pointer"
            title="Text Color"
          />
          <input
            type="color"
            onChange={(e) => execCommand('backColor', e.target.value)}
            className="w-8 h-8 border border-gray-300 rounded cursor-pointer"
            title="Background Color"
          />
        </div>

        {/* Alignment */}
        <div className="flex items-center gap-1 border-r border-gray-300 pr-2 mr-2">
          {alignButtons.map((btn) => (
            <button
              key={btn.command}
              type="button"
              onClick={() => execCommand(btn.command)}
              className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
              title={btn.title}
            >
              <i className={`${btn.icon} text-sm`}></i>
            </button>
          ))}
        </div>

        {/* Lists */}
        <div className="flex items-center gap-1 border-r border-gray-300 pr-2 mr-2">
          <button
            type="button"
            onClick={() => insertList('ul')}
            className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
            title="Bullet List"
          >
            <i className="ri-list-unordered text-sm"></i>
          </button>
          <button
            type="button"
            onClick={() => insertList('ol')}
            className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
            title="Numbered List"
          >
            <i className="ri-list-ordered text-sm"></i>
          </button>
        </div>

        {/* Additional Actions */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => execCommand('removeFormat')}
            className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
            title="Clear Formatting"
          >
            <i className="ri-format-clear text-sm"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('undo')}
            className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
            title="Undo"
          >
            <i className="ri-arrow-go-back-line text-sm"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('redo')}
            className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-200 transition-colors"
            title="Redo"
          >
            <i className="ri-arrow-go-forward-line text-sm"></i>
          </button>
        </div>
      </div>

      {/* Editor */}
      <div
        ref={editorRef}
        contentEditable
        onInput={handleInput}
        onMouseUp={handleSelection}
        onKeyUp={handleSelection}
        className={`w-full px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-inset min-h-[${rows * 24}px] bg-white`}
        style={{ minHeight: `${rows * 24}px` }}
        suppressContentEditableWarning={true}
        dangerouslySetInnerHTML={value ? { __html: value } : undefined}
        data-placeholder={placeholder}
      />

      <style jsx>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: #9CA3AF;
          pointer-events: none;
        }
      `}</style>
    </div>
  );
}

// ---------------------------------------------------------------
// Templates data (moved to top-level so it can be accessed by
// both the main component and the PaymentModal component)
// ---------------------------------------------------------------
const templates = [
  // Professional Templates (15)
  { id: 'professional-1', name: 'Executive Professional', category: 'professional', description: 'Formal corporate design for senior executives', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Professional%20executive%20cover%20letter%20template%20with%20clean%20corporate%20design%2C%20navy%20blue%20color0&height=400&seq=prof-exec-cl-1&orientation=portrait' },
  { id: 'professional-2', name: 'Corporate Classic', category: 'professional', description: 'Traditional business format for finance and consulting', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Corporate%20classic%20cover%20letter%20template%20with%20traditional%20business%20formatting%2C%20dark%20blue%20headers%2C%20structured%20layout%20for%20professional%20correspondence%2C%20conservative%20design%20suitable%20for%20finance%20and%20consulting&width=320&height=400&seq=prof-corp-cl-2&orientation=portrait' },
  { id: 'professional-3', name: 'Business Elite', category: 'professional', description: 'Premium template for C-suite positions', color: 'indigo', preview: 'https://readdy.ai/api/search-image?query=Business%20elite%20cover%20letter%20template%20with%20premium%20design%20for%20C-suite%20executives%2C%20indigo%20color%20accents%2C%20sophisticated%20letterhead%20with%20executive%20summary%2C%20strategic%20positioning&width=320&height=400&seq=prof-elite-cl-3&orientation=portrait' },
  { id: 'professional-4', name: 'Legal Professional', category: 'professional', description: 'Formal design for legal practitioners', color: 'gray', preview: 'https://readdy.ai/api/search-image?query=Legal%20professional%20cover%20letter%20template%20with%20formal%20conservative%20design%2C%20gray%20color%20scheme%2C%20structured%20layout%20for%20law%20firms%20and%20legal0&height=400&seq=prof-legal-cl-4&orientation=portrait' },
  { id: 'professional-5', name: 'Banking Specialist', category: 'professional', description: 'Conservative template for banking professionals', color: 'slate', preview: 'https://readdy.ai/api/search-image?query=Banking%20specialist%20cover%20letter0&height=400&seq=prof-bank-cl-5&orientation=portrait' },
  { id: 'professional-6', name: 'Management Consultant', category: 'professional', description: 'Strategic template for consulting roles', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Management%20consultant%20cover%20letter%20template%20with%20strategic%20professional%20design%2C%20consulting0&height=400&seq=prof-consult-cl-6&orientation=portrait' },
  { id: 'professional-7', name: 'HR Director', category: 'professional', description: 'People-focused design for HR professionals', color: 'emerald', preview: 'https://readdy.ai/api/search-image?query=HR%20director%20cover%20letter%20template%20with%20people-focused%20professional%20design%20emerald%20green%20accents%2C%20human%20resources%20layout&width=320&height=400&seq=prof-hr-cl-7&orientation=portrait' },
  { id: 'professional-8', name: 'Operations Manager', category: 'professional', description: 'Results-driven template for operations roles', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Operations%20manager%20cover%20letter%20template%20with%20results-driven%20design%2C%20orange%20accents%2C%20operations%20focused%20layout&width=320&height=400&seq=prof-ops-cl-8&orientation=portrait' },
  { id: 'professional-9', name: 'Sales Executive', category: 'professional', description: 'Achievement-focused template for sales professionals', color: 'red', preview: 'https://readdy.ai/api/search-image?query=Sales%20executive%20cover%20letter%20template%20with%20achievement-focused%20design%2C%20sales%20professional%20layout&width=320&height=400&seq=prof-sales-cl-9&orientation=portrait' },
  { id: 'professional-10', name: 'Project Manager', category: 'professional', description: 'Organized template for project management roles', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Project%20manager%20cover%20letter%20template%20with%20organized%20professional%20design%2C%20project%20management%20focused%20layout&width=320&height=400&seq=prof-pm-cl-10&orientation=portrait' },
  { id: 'professional-11', name: 'Financial Analyst', category: 'professional', description: 'Data-driven template for financial roles', color: 'teal', preview: 'https://readdy.ai/api/search-image?query=Financial%20analyst%20cover%20letter%20template%20with%20data-driven%20design%2C%20teal%20color%20accents%2C%20financial%20analysis%20focused%20layout&width=320&height=400&seq=prof-fin-cl-11&orientation=portrait' },
  { id: 'professional-12', name: 'Marketing Director', category: 'professional', description: 'Brand-focused template for marketing leaders', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Marketing%20director%20cover%20letter%20template%20with%20brand-focused%20professional%20design%2C%20pink%20color%20accents%2C%20marketing%20leadership%20emphasis&width=320&height=400&seq=prof-mkt-cl-12&orientation=portrait' },
  { id: 'professional-13', name: 'Business Analyst', category: 'professional', description: 'Analytical template for business analyst roles', color: 'indigo', preview: 'https://readdy.ai/api/search-image?query=Business%20analyst%20cover%20letter%20template%20with%20analytical%20professional%20design%2C%20indigo%20color%20accents%2C%20business%20analysis%20focused%20layout&width=320&height=400&seq=prof-ba-cl-13&orientation=portrait' },
  { id: 'professional-14', name: 'Account Manager', category: 'professional', description: 'Relationship-focused template for account management', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Account%20manager%20cover%20letter%20template%20with%20relationship-focused%20design%2C%20orange%20color%20accents%2C%20client%20relationship%20emphasis&width=320&height=400&seq=prof-account-cl-14&orientation=portrait' },
  { id: 'professional-15', name: 'Compliance Officer', category: 'professional', description: 'Regulatory template for compliance professionals', color: 'gray', preview: 'https://readdy.ai/api/search-image?query=Compliance%20officer%20cover%20letter%20template%20with%20regulatory%20professional%20design%2C%20compliance%20focused%20layout&width=320&height=400&seq=prof-comp-cl-15&orientation=portrait' },

  // Creative Templates (10)
  { id: 'creative-1', name: 'Graphic Designer Pro', category: 'creative', description: 'Visual template for graphic designers', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Graphic%20designer%20cover%20letter%20template%20with%20visual%20creative%20design%2C%20purple%20and%20pink%20color%20scheme%2C%20artistic%20layout%20with%20design%20elements%20and%20creative%20formatting&width=320&height=400&seq=creative-gd-cl-1&orientation=portrait' },
  { id: 'creative-2', name: 'UI/UX Designer', category: 'creative', description: 'Modern template for digital designers', color: 'indigo', preview: 'https://readdy.ai/api/search-image?query=UI%20UX%20designer%20cover%20letter%20template%20with%20modern%20digital%20design%20indigo%20and%20blue%20colors%2C%20user%20experience%20focused%20layout%20with%20design%20thinking%20emphasis&width=320&height=400&seq=creative-ux-cl-2&orientation=portrait' },
  { id: 'creative-3', name: 'Content Creator', category: 'creative', description: 'Engaging template for content creators', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Content%20creator%20cover%20letter%20template%20with%20engaging%20creative%20design%2C%20pink%20and%20orange%20colors%2C%20content%20creation%20focused%20layout%20with%20creative%20storytelling%20emphasis&width=320&height=400&seq=creative-cc-cl-3&orientation=portrait' },
  { id: 'creative-4', name: 'Marketing Creative', category: 'creative', description: 'Brand-focused template for marketing creatives', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Marketing%20creative%20cover%20letter%20template%20with%20brand-focused%20design%2C%20orange%20and%20yellow%20colors%2C%20creative%20marketing%20emphasis%20with%20campaign%20focus&width=320&height=400&seq=creative-mc-cl-4&orientation=portrait' },
  { id: 'creative-5', name: 'Art Director', category: 'creative', description: 'Leadership template for creative directors', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Art%20director%20cover%20letter%20template%20with%20creative%20leadership%20design%2C%20purple%20and%20gold%20colors%2C%20artistic%20direction%20emphasis%20with%20creative%20vision%20focus&width=320&height=400&seq=creative-ad-cl-5&orientation=portrait' },
  { id: 'creative-6', name: 'Copywriter', category: 'creative', description: 'Word-focused template for copywriters', color: 'teal', preview: 'https://readdy.ai/api/search-image?query=Copywriter%20cover%20letter%20template%20with%20word-focused%20creative%20design%2C%20teal%20and%20green%20colors%2C%20writing%20storytelling%20emphasis&width=320&height=400&seq=creative-cw-cl-6&orientation=portrait' },
  { id: 'creative-7', name: 'Social Media Manager', category: 'creative', description: 'Trendy template for social media professionals', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Social%20media%20manager%20cover%20letter%20template%20with%20trendy%20design%2C%20social%20media%20focused%20layout&width=320&height=400&seq=creative-sm-cl-7&orientation=portrait' },
  { id: 'creative-8', name: 'Web Designer', category: 'creative', description: 'Digital template for web designers', color: 'cyan', preview: 'https://readdy.ai/api/search-image?query=Web%20designer%20cover%20letter%20template%20with%20digital%20creative%20design%2C%20web%20development%20focused%20layout&width=320&height=400&seq=creative-wd-cl-8&orientation=portrait' },
  { id: 'creative-9', name: 'Brand Designer', category: 'creative', description: 'Identity-focused template for brand designers', color: 'amber', preview: 'https://readdy.ai/api/search-image?query=Brand%20designer%20cover%20letter%20template%20with%20identity-focused%20design%2C%20amber%20and%20orange%20colors%2C%20brand%20design%20emphasis%20with%20visual%20identity%20focus&width=320&height=400&seq=creative-bd-cl-9&orientation=portrait' },
  { id: 'creative-10', name: 'Event Planner', category: 'creative', description: 'Celebration template for event planners', color: 'fuchsia', preview: 'https://readdy.ai/api/search-image?query=Event%20planner%20cover%20letter%20template%20with%20celebration-themed%20design%2C%20fuchsia%20and%20gold%20colors%2C%20event%20planning%20focused%20layout%20with%20creative%20event%20emphasis&width=320&height=400&seq=creative-ep-cl-10&orientation=portrait' },

  // Modern Templates (8)
  { id: 'modern-1', name: 'Tech Startup', category: 'modern', description: 'Innovative template for startup professionals', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Tech%20startup%20cover%20letter%20template%20with%20innovative%20modern%20design%2C%20bright%20blue%20and%20white%20colors%2C%20clean%20minimalist%20layout%20with%20technology%20focus%20and%20innovation%20emphasis&width=320&height=400&seq=modern-startup-cl-1&orientation=portrait' },
  { id: 'modern-2', name: 'Software Engineer', category: 'modern', description: 'Code-focused template for developers', color: 'green', preview: 'https://readdy.ai/api/search-image?query=Software%20engineer%20cover%20letter%20template%20with%20code-focused%20modern%20design%2C%20software%20development%20layout&width=320&height=400&seq=modern-se-cl-2&orientation=portrait' },
  { id: 'modern-3', name: 'Data Scientist', category: 'modern', description: 'Analytics-driven template for data professionals', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Data%20scientist%20cover%20letter%20template%20with%20analytics-driven%20modern%20design%2C%20purple%20and%20blue%20colors%2C%20data%20science%20focused%20layout%20with%20analytical%20emphasis&width=320&height=400&seq=modern-ds-cl-3&orientation=portrait' },
  { id: 'modern-4', name: 'Product Manager', category: 'modern', description: 'Strategy-focused template for product managers', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Product%20manager%20cover%20letter%20template%20with%20strategy-focused%20modern%20design%2C%20product%20management%20layout&width=320&height=400&seq=modern-pm-cl-4&orientation=portrait' },
  { id: 'modern-5', name: 'Digital Marketer', category: 'modern', description: 'Growth-focused template for digital marketers', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Digital%20marketer%20cover%20letter%20template%20with%20growth-focused%20modern%20design%2C%20digital%20marketing%20layout&width=320&height=400&seq=modern-dm-cl-5&orientation=portrait' },
  { id: 'modern-6', name: 'UX Researcher', category: 'modern', description: 'Research-focused template for UX researchers', color: 'violet', preview: 'https://readdy.ai/api/search-image?query=UX%20researcher%20cover%20letter%20template%20with%20research-focused%20modern%20design%2C%20violet%20and%20gray%20colors%2C%20user%20research%20focused%20layout%20with%20methodology%20emphasis&width=320&height=400&seq=modern-uxr-cl-6&orientation=portrait' },
  { id: 'modern-7', name: 'Growth Hacker', category: 'modern', description: 'Experiment-driven template for growth professionals', color: 'lime', preview: 'https://readdy.ai/api/search-image?query=Growth%20hacker%20cover%20letter%20template%20with%20experiment-driven%20modern%20design%2C%20lime%20and%20dark%20colors%2C%20growth%20hacking%20focused%20layout&width=320&height=400&seq=modern-growth-cl-7&orientation=portrait' },
  { id: 'modern-8', name: 'E-commerce Manager', category: 'modern', description: 'Sales-focused template for e-commerce professionals', color: 'rose', preview: 'https://readdy.ai/api/search-image?query=E-commerce%20manager%20cover%20letter%20template%20with%20sales-focused%20modern%20design%2C%20e-commerce%20layout&width=320&height=400&seq=modern-ecom-cl-8&orientation=portrait' }
];

// ---------------------------------------------------------------
// PaymentModal component (used for the download flow)
// ---------------------------------------------------------------
interface PaymentModalProps {
  action: string;
  onClose: () => void;
  coverLetterData: any;
}

function PaymentModal({ action, onClose, coverLetterData }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState('');
  const [subscriptionType, setSubscriptionType] = useState('one-time');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: ''
  });
  const [processing, setProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [downloadFormat, setDownloadFormat] = useState('pdf');
  const [emailAddress, setEmailAddress] = useState('');

  // -----------------------------------------------------------------
  // Helper: get template HTML based on the selected template
  // -----------------------------------------------------------------
  const getFormattedTemplate = () => {
    const { personalInfo, jobInfo, content, template } = coverLetterData;
    const selectedTemplateData = templates.find(t => t.id === template);

    if (!selectedTemplateData) return generateBasicTemplate();

    // For simplicity, the demo uses only the professional template generator.
    // In a full implementation you would switch on selectedTemplateData.category
    // and call the appropriate generator (generateCreativeTemplate, generateModernTemplate, etc.)
    return generateProfessionalTemplate();
  };

  // -----------------------------------------------------------------
  // Professional template generator (the rest of the generators are omitted
  // for brevity – they could be added similarly if needed)
  // -----------------------------------------------------------------
  const generateProfessionalTemplate = () => {
    const { personalInfo, jobInfo, content } = coverLetterData;
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cover Letter - ${personalInfo?.name || 'Cover Letter'}</title>
    <style>
        body { 
          font-family: 'Times New Roman', serif; 
          margin: 40px; 
          color: #000; 
          line-height: 1.6;
          background-color: #ffffff;
        }
        .header { 
          text-align: center;
          margin-bottom: 30px; 
          border-bottom: 2px solid #2563EB;
          padding-bottom: 20px;
        }
        .name { 
          font-size: 24px; 
          font-weight: bold; 
          margin-bottom: 10px; 
          color: #2563EB;
          letter-spacing: 1px;
        }
        .contact { 
          font-size: 12px; 
          color: #374151; 
          line-height: 1.4;
        }
        .date { 
          margin: 20px 0; 
          color: #374151; 
          text-align: right;
        }
        .company-info { 
          margin-bottom: 25px; 
          color: #000;
          font-weight: 500;
        }
        .content { 
          margin-bottom: 18px; 
          text-align: justify;
          color: #000;
        }
        .signature { 
          margin-top: 40px; 
        }
        .signature-name { 
          font-weight: bold; 
          color: #2563EB;
          margin-top: 20px;
        }
        .template-badge {
          position: absolute;
          top: 20px;
          right: 20px;
          background: #2563EB;
          color: white;
          padding: 5px 10px;
          border-radius: 15px;
          font-size: 10px;
          text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="template-badge">Professional Template</div>
    
    <div class="header">
        <div class="name">${personalInfo?.name || 'Your Name'}</div>
        <div class="contact">
            ${personalInfo?.email || ''} | ${personalInfo?.phone || ''}<br>
            ${personalInfo?.address || ''}
        </div>
    </div>
    
    <div class="date">
        ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
    </div>
    
    <div class="company-info">
        ${jobInfo?.hiringManager ? `${jobInfo.hiringManager}<br>` : ''}
        ${jobInfo?.company || ''}
    </div>
    
    <p>Dear ${jobInfo?.hiringManager || 'Hiring Manager'},</p>
    
    ${content?.opening ? `<div class="content">${content.opening}</div>` : ''}
    ${content?.body ? `<div class="content">${content.body}</div>` : ''}
    ${content?.closing ? `<div class="content">${content.closing}</div>` : ''}
    
    <div class="signature">
        <div>Sincerely,</div>
        <div class="signature-name">${personalInfo?.name || 'Your Name'}</div>
    </div>
</body>
</html>
    `;
  };

  // -----------------------------------------------------------------
  // Simple download helpers
  // -----------------------------------------------------------------
  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadAsHTML = (content: string, filename: string) => {
    const htmlContent = `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Cover Letter - ${coverLetterData.personalInfo?.name || 'Professional'}</title>
          <style>
            body { font-family: 'Times New Roman', serif; line-height: 1.6; margin: 40px; background: #ffffff; color: #000000; }
            .container { max-width: 800px; margin: 0 auto; }
            @media print { body { margin: 1in; } }
          </style>
        </head>
        <body>
          <div class="container">
            ${content}
          </div>
        </body>
      </html>
    `;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.html`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Updated downloadAsPDF implementation
  const downloadAsPDF = async (content: string, filename: string) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Cover Letter</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
              .letter-content { max-width: 600px; }
              h1 { color: #333; margin-bottom: 20px; }
              p { margin-bottom: 15px; }
              .signature { margin-top: 30px; }
            </style>
          </head>
          <body>
            <div class="letter-content">
              ${content}
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const downloadAsWord = (content: string, filename: string) => {
    const cleanContent = content
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/class="[^"]*"/g, '')
      .replace(/style="[^"]*"/g, '')
      .replace(/<div class="template-badge"[^>]*>[\s\S]*?<\/div>/gi, '');

    const htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' 
            xmlns:w='urn:schemas-microsoft-com:office:word' 
            xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta charset='utf-8'>
          <title>Cover Letter</title>
          <style>
            body { font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 1.6; margin: 1in; color: #000000; }
            .header { text-align: center; margin-bottom: 24pt; }
            .name { font-size: 16pt; font-weight: bold; margin-bottom: 12pt; }
            .contact { font-size: 11pt; margin-bottom: 12pt; }
            .date { margin-bottom: 12pt; }
            .content { margin-bottom: 12pt; text-align: justify; }
            .signature { margin-top: 24pt; }
          </style>
        </head>
        <body>
          ${cleanContent}
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.docx`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadAsText = (content: string, filename: string) => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(content, 'text/html');
    const textContent = doc.body.textContent || doc.body.innerText || '';
    const cleanText = textContent
      .replace(/\s+/g, ' ')
      .replace(/\n\s*\n/g, '\n\n')
      .replace(/([.!?])\s*(\w)/g, '$1\n\n$2')
      .trim();

    const formattedText = `
${coverLetterData.personalInfo?.name || 'Your Name'}
${coverLetterData.personalInfo?.email || ''} | ${coverLetterData.personalInfo?.phone || ''} | ${coverLetterData.personalInfo?.address || ''}

${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}

${coverLetterData.jobInfo?.hiringManager ? coverLetterData.jobInfo.hiringManager + '\n' : ''}${coverLetterData.jobInfo?.company || ''}

Dear ${coverLetterData.jobInfo?.hiringManager || 'Hiring Manager'},

${coverLetterData.content?.opening || ''}

${coverLetterData.content?.body || ''}

${coverLetterData.content?.closing || ''}

Sincerely,
${coverLetterData.personalInfo?.name || 'Your Name'}
    `.trim();

    const blob = new Blob([formattedText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.txt`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const convertToFormat = async (format: string) => {
    const content = getFormattedTemplate();
    const fileName = `cover-letter-${coverLetterData.personalInfo?.name?.replace(/\s+/g, '-').toLowerCase() || 'document'}-${Date.now()}`;

    switch (format) {
      case 'pdf':
        await downloadAsPDF(content, fileName);
        break;
      case 'html':
        downloadAsHTML(content, fileName);
        break;
      case 'txt':
        downloadAsText(content, fileName);
        break;
      case 'docx':
        downloadAsWord(content, fileName);
        break;
      default:
        downloadAsHTML(content, fileName);
    }
  };

  // -----------------------------------------------------------------
  // Payment handling (simulated)
  // -----------------------------------------------------------------
  const handlePayment = async () => {
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      setPaymentSuccess(true);
    }, 3000);
  };

  // -----------------------------------------------------------------
  // Download format click handling
  // -----------------------------------------------------------------
  const handleFormatDownload = async (format: string) => {
    try {
      const button = document.querySelector(`[data-format="${format}"]`);
      if (button) {
        const originalContent = button.innerHTML;
        button.innerHTML = `
          <div class="w-6 h-6 flex items-center justify-center mx-auto mb-2">
            <div class="animate-spin rounded-full h-4 w-4 border-2 border-${format === 'pdf' ? 'red' : format === 'docx' ? 'blue' : format === 'html' ? 'orange' : 'gray'}-600 border-t-transparent"></div>
          </div>
          <div class="font-medium text-gray-800 text-sm">Downloading...</div>
        `;

        await convertToFormat(format);

        setTimeout(() => {
          button.innerHTML = originalContent;
        }, 2000);
      }
    } catch (error) {
      console.error('Download error:', error);
      // Reset button UI on error
      const button = document.querySelector(`[data-format="${format}"]`);
      if (button) {
        const formatData = [
          { id: 'pdf', name: 'PDF', icon: 'ri-file-pdf-line', color: 'red' },
          { id: 'docx', name: 'Word', icon: 'ri-file-word-line', color: 'blue' },
          { id: 'html', name: 'HTML', icon: 'ri-html5-line', color: 'orange' },
          { id: 'txt', name: 'Text', icon: 'ri-file-text-line', color: 'gray' }
        ].find(f => f.id === format);

        if (formatData) {
          button.innerHTML = `
            <div class="w-6 h-6 flex items-center justify-center mx-auto mb-2">
              <i class="${formatData.icon} text-xl text-${formatData.color}-600 group-hover:scale-110 transition-transform"></i>
            </div>
            <div class="font-medium text-gray-800 text-sm">${formatData.name}</div>
          `;
        }
      }
    }
  };

  // -----------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------
  if (paymentSuccess) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white/95 backdrop-blur-lg rounded-3xl max-w-lg w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-white/20">
          <div className="p-8 text-center">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center animate-bounce">
              <i className="ri-check-line text-white text-3xl"></i>
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-3">Payment Successful! 🎉</h2>
            <p className="text-gray-600 mb-6">Click any format to download immediately:</p>

            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 mb-3">Download Formats:</h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'pdf', name: 'PDF', icon: 'ri-file-pdf-line', color: 'red' },
                  { id: 'docx', name: 'Word', icon: 'ri-file-word-line', color: 'blue' },
                  { id: 'html', name: 'HTML', icon: 'ri-html5-line', color: 'orange' },
                  { id: 'txt', name: 'Text', icon: 'ri-file-text-line', color: 'gray' }
                ].map((format) => (
                  <button
                    key={format.id}
                    onClick={async () => {
                      const button = document.querySelector(`[data-format="${format.id}"]`);
                      if (button) {
                        button.classList.add('animate-pulse');
                        button.innerHTML = `<div class="w-6 h-6 flex items-center justify-center mx-auto mb-2">
                          <div class="animate-spin rounded-full h-4 w-4 border-2 border-${format.color}-600 border-t-transparent"></div>
                        </div>
                        <div class="font-medium text-gray-800 text-sm">Downloading...</div>`;
                      }

                      await handleFormatDownload(format.id);

                      setTimeout(() => {
                        if (button) {
                          button.classList.remove('animate-pulse');
                          button.innerHTML = `<div class="w-6 h-6 flex items-center justify-center mx-auto mb-2">
                            <i class="${format.icon} text-xl text-${format.color}-600 group-hover:scale-110 transition-transform"></i>
                          </div>
                          <div class="font-medium text-gray-800 text-sm">${format.name}</div>`;
                        }
                      }, 2000);
                    }}
                    data-format={format.id}
                    className={`p-4 border-2 rounded-xl transition-all duration-300 hover:scale-105 group border-${format.color}-400 bg-${format.color}-50 hover:bg-${format.color}-100 cursor-pointer flex items-center gap-2`}
                  >
                    <div className={`w-6 h-6 flex items-center justify-center mx-auto mb-2`}>
                      <i className={`${format.icon} text-xl text-${format.color}-600 group-hover:scale-110 transition-transform`}></i>
                    </div>
                    <div className="font-medium text-gray-800 text-sm">{format.name}</div>
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-3">✨ Downloads start instantly when you click</p>
            </div>

            <button
              onClick={onClose}
              className="w-full px-4 py-3 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700 transition-all duration-300 font-medium whitespace-nowrap text-sm"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -----------------------------------------------------------------
  // Main Payment Modal UI - Full Display
  // -----------------------------------------------------------------
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/95 backdrop-blur-lg rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/20">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center">
                <i className="ri-download-line text-white text-lg"></i>
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Download Cover Letter</h2>
                <p className="text-xs text-gray-600">Unlock premium download features</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center text-gray-500 hover:text-gray-700 transition-all duration-300"
            >
              <i className="ri-close-line text-lg"></i>
            </button>
          </div>

          {/* Subscription Options */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-800 mb-3">Choose Your Plan</h3>
            <div className="space-y-3">
              <div 
                onClick={() => setSubscriptionType('one-time')}
                className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${subscriptionType === 'one-time' 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-200 hover:border-gray-300'}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-gray-900">One-Time Download</div>
                    <div className="text-sm text-gray-600">Download this cover letter once</div>
                  </div>
                  <div className="text-xl font-bold text-blue-600">$4.99</div>
                </div>
              </div>
              
              <div 
                onClick={() => setSubscriptionType('monthly')}
                className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${subscriptionType === 'monthly' 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-200 hover:border-gray-300'}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-gray-900">Monthly Pro</div>
                    <div className="text-sm text-gray-600">Unlimited downloads + AI features</div>
                  </div>
                  <div className="text-xl font-bold text-blue-600">$19.99/mo</div>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-800 mb-3">Payment Method</h3>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'card', name: 'Credit Card', icon: 'ri-bank-card-line' },
                { id: 'paypal', name: 'PayPal', icon: 'ri-paypal-line' },
                { id: 'apple', name: 'Apple Pay', icon: 'ri-apple-line' }
              ].map((method) => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id)}
                  className={`p-3 border-2 rounded-xl flex flex-col items-center transition-all ${paymentMethod === method.id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'}`}
                >
                  <i className={`${method.icon} text-2xl mb-1 ${paymentMethod === method.id ? 'text-blue-600' : 'text-gray-400'}`}></i>
                  <span className={`text-xs font-medium ${paymentMethod === method.id ? 'text-blue-600' : 'text-gray-600'}`}>
                    {method.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Card Details Form (if card selected) */}
          {paymentMethod === 'card' && (
            <div className="mb-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name</label>
                <input
                  type="text"
                  value={cardDetails.name}
                  onChange={(e) => setCardDetails(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Card Number</label>
                <input
                  type="text"
                  value={cardDetails.number}
                  onChange={(e) => setCardDetails(prev => ({ ...prev, number: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  placeholder="1234 5678 9012 3456"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Date</label>
                  <input
                    type="text"
                    value={cardDetails.expiry}
                    onChange={(e) => setCardDetails(prev => ({ ...prev, expiry: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="MM/YY"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CVV</label>
                  <input
                    type="text"
                    value={cardDetails.cvv}
                    onChange={(e) => setCardDetails(prev => ({ ...prev, cvv: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    placeholder="123"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Phone Number for SMS receipt */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number (Optional)</label>
            <input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              placeholder="+1 (555) 123-4567"
            />
            <p className="text-xs text-gray-500 mt-1">Receive download link via SMS</p>
          </div>

          {/* Security Notice */}
          <div className="mb-6 bg-green-50 border border-green-200 rounded-xl p-3">
            <div className="flex items-center space-x-2">
              <i className="ri-shield-check-line text-green-600 text-lg"></i>
              <div>
                <div className="font-medium text-green-800">Secure Payment</div>
                <div className="text-xs text-green-700">256-bit SSL encryption protects your data</div>
              </div>
            </div>
          </div>

          {/* Payment Button */}
          <button
            onClick={handlePayment}
            disabled={processing || !paymentMethod}
            className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 font-medium whitespace-nowrap text-sm flex items-center justify-center space-x-2"
          >
            {processing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                <span>Processing Payment...</span>
              </>
            ) : (
              <>
                <i className="ri-secure-payment-line"></i>
                <span>Complete Payment {subscriptionType === 'one-time' ? '$4.99' : '$19.99/mo'}</span>
              </>
            )}
          </button>

          {/* Terms */}
          <p className="text-xs text-gray-500 text-center mt-4">
            By proceeding, you agree to our <a href="/terms" className="text-blue-600 hover:underline">Terms of Service</a> and <a href="/privacy" className="text-blue-600 hover:underline">Privacy Policy</a>
          </p>
        </div>
      </div>
    </div>
  );
}

// Main CoverLetterBuilderPage component
function CoverLetterBuilderPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showAISuggestions, setShowAISuggestions] = useState(false);
  const [aiSuggestionType, setAISuggestionType] = useState<'opening' | 'body' | 'closing'>('opening');

  const [coverLetterData, setCoverLetterData] = useState({
    personalInfo: {
      name: '',
      email: '',
      phone: '',
      address: '',
      reference: ''
    },
    jobInfo: {
      position: '',
      company: '',
      hiringManager: ''
    },
    content: {
      opening: '',
      body: '',
      closing: ''
    },
    template: ''
  });

  // Filter templates
  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { id: 'all', name: 'All Templates', count: templates.length },
    { id: 'professional', name: 'Professional', count: templates.filter(t => t.category === 'professional').length },
    { id: 'creative', name: 'Creative', count: templates.filter(t => t.category === 'creative').length },
    { id: 'modern', name: 'Modern', count: templates.filter(t => t.category === 'modern').length }
  ];

  const steps = [
    { id: 1, title: 'Choose Template', icon: 'ri-layout-line', completed: selectedTemplate !== '' },
    { id: 2, title: 'Personal Info', icon: 'ri-user-line', completed: coverLetterData.personalInfo.name !== '' },
    { id: 3, title: 'Job Details', icon: 'ri-briefcase-line', completed: coverLetterData.jobInfo.position !== '' },
    { id: 4, title: 'Write Content', icon: 'ri-edit-line', completed: coverLetterData.content.opening !== '' },
    { id: 5, title: 'Preview & Download', icon: 'ri-download-line', completed: false }
  ];

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    setCoverLetterData(prev => ({ ...prev, template: templateId }));
    setCurrentStep(2);
  };

  const handlePersonalInfoChange = (field: string, value: string) => {
    setCoverLetterData(prev => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, [field]: value }
    }));
  };

  const handleJobInfoChange = (field: string, value: string) => {
    setCoverLetterData(prev => ({
      ...prev,
      jobInfo: { ...prev.jobInfo, [field]: value }
    }));
  };

  const handleContentChange = (field: string, value: string) => {
    setCoverLetterData(prev => ({
      ...prev,
      content: { ...prev.content, [field]: value }
    }));
  };

  const handleAIAssist = (contentType: 'opening' | 'body' | 'closing') => {
    setAISuggestionType(contentType);
    setShowAISuggestions(true);
  };

  const handleApplyAISuggestion = (content: string) => {
    handleContentChange(aiSuggestionType, content);
    setShowAISuggestions(false);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Cover Letter Template</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Select from our professionally designed templates to create a cover letter that stands out.
              </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                <input
                  type="text"
                  placeholder="Search templates..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                />
              </div>

              <div className="flex space-x-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${selectedCategory === category.id 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                  >
                    {category.name} ({category.count})
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTemplates.map((template) => (
                <div
                  key={template.id}
                  onClick={() => handleTemplateSelect(template.id)}
                  className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer group hover:scale-105"
                >
                  <div className="aspect-[3/4] relative overflow-hidden">
                    <img
                      src={template.preview}
                      alt={template.name}
                      className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
                      <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <span className="text-sm font-medium text-gray-800">Select Template</span>
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-1">{template.name}</h3>
                    <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-1 rounded text-xs font-medium bg-${template.color}-100 text-${template.color}-700`}>
                        {template.category}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Personal Information</h2>
              <p className="text-gray-600">Enter your contact details</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                <input
                  type="text"
                  value={coverLetterData.personalInfo.name}
                  onChange={(e) => handlePersonalInfoChange('name', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                <input
                  type="email"
                  value={coverLetterData.personalInfo.email}
                  onChange={(e) => handlePersonalInfoChange('email', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="your.email@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={coverLetterData.personalInfo.phone}
                  onChange={(e) => handlePersonalInfoChange('phone', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
                <input
                  type="text"
                  value={coverLetterData.personalInfo.address}
                  onChange={(e) => handlePersonalInfoChange('address', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="City, State, ZIP"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reference (Optional)
                  <span className="text-gray-500 font-normal ml-1">- Professional reference or contact</span>
                </label>
                <input
                  type="text"
                  value={coverLetterData.personalInfo.reference}
                  onChange={(e) => handlePersonalInfoChange('reference', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., John Smith, Former Manager at XYZ Corp - (555) 123-4567"
                />
                <p className="text-sm text-gray-500 mt-1">Include name, title, company, and contact information if available</p>
              </div>
            </div>

            <div className="flex justify-between pt-6">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-6 py-3 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap"
              >
                Back to Templates
              </button>
              <button
                onClick={() => setCurrentStep(3)}
                disabled={!coverLetterData.personalInfo.name || !coverLetterData.personalInfo.email}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
              >
                Continue to Job Details
              </button>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Job Information</h2>
              <p className="text-gray-600">Tell us about the position you're applying for</p>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Job Position *</label>
                <input
                  type="text"
                  value={coverLetterData.jobInfo.position}
                  onChange={(e) => handleJobInfoChange('position', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Marketing Manager"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Company Name *</label>
                <input
                  type="text"
                  value={coverLetterData.jobInfo.company}
                  onChange={(e) => handleJobInfoChange('company', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., ABC Corporation"
                />
              </div>

              <div className="block text-sm font-medium text-gray-700 mb-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Hiring Manager Name</label>
                <input
                  type="text"
                  value={coverLetterData.jobInfo.hiringManager}
                  onChange={(e) => handleJobInfoChange('hiringManager', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Sarah Johnson (optional)"
                />
                <p className="text-sm text-gray-500 mt-1">Leave blank if unknown - we'll use "Hiring Manager"</p>
              </div>
            </div>

            <div className="flex justify-between pt-6">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-6 py-3 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap"
              >
                Back to Personal Info
              </button>
              <button
                onClick={() => setCurrentStep(4)}
                disabled={!coverLetterData.jobInfo.position || !coverLetterData.jobInfo.company}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
              >
                Continue to Content
              </button>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Write Your Cover Letter</h2>
              <p className="text-gray-600">Create compelling content with rich formatting options</p>
              <div className="mt-4 inline-flex items-center space-x-2 bg-gradient-to-r from-purple-100 to-pink-100 px-4 py-2 rounded-full">
                <i className="ri-magic-line text-purple-600"></i>
                <span className="text-sm font-medium text-purple-700">Rich text editor with formatting tools</span>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">Opening Paragraph *</label>
                  <button
                    onClick={() => handleAIAssist('opening')}
                    disabled={!coverLetterData.jobInfo.position || !coverLetterData.jobInfo.company}
                    className="inline-flex items-center space-x-2 px-3 py-1.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 text-sm whitespace-nowrap"
                  >
                    <i className="ri-magic-line text-sm"></i>
                    <span>AI Assist</span>
                  </button>
                </div>
                <RichTextEditor
                  value={coverLetterData.content.opening}
                  onChange={(value) => handleContentChange('opening', value)}
                  placeholder="Introduce yourself and explain why you're interested in this position..."
                  rows={4}
                />
                <p className="text-sm text-gray-500 mt-1">Grab their attention with a strong opening</p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">Body Paragraph *</label>
                  <button
                    onClick={() => handleAIAssist('body')}
                    disabled={!coverLetterData.jobInfo.position || !coverLetterData.jobInfo.company}
                    className="inline-flex items-center space-x-2 px-3 py-1.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 text-sm whitespace-nowrap"
                  >
                    <i className="ri-magic-line text-sm"></i>
                    <span>AI Assist</span>
                  </button>
                </div>
                <RichTextEditor
                  value={coverLetterData.content.body}
                  onChange={(value) => handleContentChange('body', value)}
                  placeholder="Highlight your relevant experience, skills, and achievements that make you perfect for this role..."
                  rows={6}
                />
                <p className="text-sm text-gray-500 mt-1">Show how your background aligns with their needs</p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">Closing Paragraph *</label>
                  <button
                    onClick={() => handleAIAssist('closing')}
                    disabled={!coverLetterData.jobInfo.position || !coverLetterData.jobInfo.company}
                    className="inline-flex items-center space-x-2 px-3 py-1.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 text-sm whitespace-nowrap"
                  >
                    <i className="ri-magic-line text-sm"></i>
                    <span>AI Assist</span>
                  </button>
                </div>
                <RichTextEditor
                  value={coverLetterData.content.closing}
                  onChange={(value) => handleContentChange('closing', value)}
                  placeholder="Express enthusiasm for the opportunity and mention next steps..."
                  rows={3}
                />
                <p className="text-sm text-gray-500 mt-1">End with a call to action and professional closing</p>
              </div>

              {(!coverLetterData.jobInfo.position || !coverLetterData.jobInfo.company) && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <div className="flex items-center space-x-3">
                    <i className="ri-information-line text-amber-600 text-lg"></i>
                    <div>
                      <h4 className="font-medium text-amber-800">AI Assistance Requires Job Details</h4>
                      <p className="text-sm text-amber-700 mt-1">
                        Complete the job position and company fields in step 3 to unlock AI-powered content suggestions.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Formatting Tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div className="flex items-start space-x-3">
                  <i className="ri-lightbulb-line text-blue-600 text-lg mt-0.5"></i>
                  <div>
                    <h4 className="font-medium text-blue-800 mb-2">Formatting Tips</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Use <strong>bold</strong> text to highlight key achievements and skills</li>
                      <li>• Create <em>emphasis</em> with italic text for important points</li>
                      <li>• Use bullet points to list your accomplishments clearly</li>
                      <li>• Apply consistent formatting throughout your cover letter</li>
                      <li>• Choose appropriate colors to match your professional brand</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-6">
              <button
                onClick={() => setCurrentStep(3)}
                className="px-6 py-3 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap"
              >
                Back to Job Details
              </button>
              <button
                onClick={() => setCurrentStep(5)}
                disabled={!coverLetterData.content.opening || !coverLetterData.content.body || !coverLetterData.content.closing}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
              >
                Preview &amp; Download
              </button>
            </div>
          </div>
        );

      case 5:
        const selectedTemplateData = templates.find(t => t.id === selectedTemplate);
        return (
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Preview Your Cover Letter</h2>
              <p className="text-gray-600">Review your formatted cover letter before downloading</p>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-8 shadow-sm">
              <div className="max-w-2xl mx-auto">
                <div className="text-center mb-6 pb-4 border-b-2 border-blue-600">
                  <h3 className="text-2xl font-bold text-blue-600 mb-2">{coverLetterData.personalInfo.name}</h3>
                  <div className="text-sm text-gray-600">
                    {coverLetterData.personalInfo.email} | {coverLetterData.personalInfo.phone}<br/>
                    {coverLetterData.personalInfo.address}
                    {coverLetterData.personalInfo.reference && (
                      <><br/>Reference: {coverLetterData.personalInfo.reference}</>
                    )}
                  </div>
                </div>

                <div className="text-right mb-4 text-gray-600">
                  {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </div>

                <div className="mb-4 font-medium">
                  {coverLetterData.jobInfo.hiringManager && <div>{coverLetterData.jobInfo.hiringManager}</div>}
                  <div>{coverLetterData.jobInfo.company}</div>
                </div>

                <div className="mb-4">
                  Dear {coverLetterData.jobInfo.hiringManager || 'Hiring Manager'},
                </div>

                {coverLetterData.personalInfo.reference && (
                  <div className="mb-4">
                    <strong>REF: {coverLetterData.personalInfo.reference}</strong>
                  </div>
                )}

                <div className="space-y-4 text-justify">
                  <div dangerouslySetInnerHTML={{ __html: coverLetterData.content.opening }} />
                  <div dangerouslySetInnerHTML={{ __html: coverLetterData.content.body }} />
                  <div dangerouslySetInnerHTML={{ __html: coverLetterData.content.closing }} />
                </div>

                <div className="mt-6">
                  <div>Sincerely,</div>
                  <div className="font-bold text-blue-600 mt-2">{coverLetterData.personalInfo.name}</div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4 justify-center">
              <button
                onClick={() => setShowPaymentModal(true)}
                className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-download-line"></i>
                Download Cover Letter
              </button>
              <button
                onClick={() => setShowPaymentModal(true)}
                className="px-8 py-3 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-lg hover:from-green-700 hover:to-teal-700 transition-all shadow-lg whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-mail-send-line"></i>
                Email To
              </button>
              <button
                onClick={() => setShowPaymentModal(true)}
                className="px-8 py-3 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-lg hover:from-orange-700 hover:to-red-700 transition-all shadow-lg whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-printer-line"></i>
                Print
              </button>
            </div>

          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Progress Steps */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div 
                  className={`w-12 h-12 rounded-full flex items-center justify-center cursor-pointer transition-all ${currentStep === step.id 
                      ? 'bg-blue-600 text-white' 
                      : step.completed 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-200 text-gray-500'}`}
                  onClick={() => {
                    if (step.completed || step.id <= currentStep) {
                      setCurrentStep(step.id);
                    }
                  }}
                >
                  {step.completed ? (
                    <i className="ri-check-line text-lg"></i>
                  ) : (
                    <i className={`${step.icon} text-lg`}></i>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-0.5 mx-2 ${step.completed ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2">
            {steps.map((step) => (
              <div key={step.id} className="text-center">
                <p className={`text-xs font-medium ${currentStep === step.id ? 'text-blue-600' : 'text-gray-500'}`}>
                  {step.title}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        {renderStepContent()}

        {/* AI Suggestions Modal */}
        {showAISuggestions && (
          <AIContentSuggestions
            jobPosition={coverLetterData.jobInfo.position}
            company={coverLetterData.jobInfo.company}
            currentContent={coverLetterData.content[aiSuggestionType]}
            contentType={aiSuggestionType}
            onApplySuggestion={handleApplyAISuggestion}
            onClose={() => setShowAISuggestions(false)}
          />
        )}

        {/* Payment Modal */}
        {showPaymentModal && (
          <PaymentModal
            action="download"
            onClose={() => setShowPaymentModal(false)}
            coverLetterData={coverLetterData}
          />
        )}
      </div>
    </div>
  );
}

export default CoverLetterBuilderPage;
