
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function ATSResumeCheckerPage() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [jobDescription, setJobDescription] = useState('');
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleFileUpload = (file: File) => {
    if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
      setUploadedFile(file);
    } else {
      alert('Please upload a PDF file');
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const analyzeResume = async () => {
    if (!uploadedFile) {
      alert('Please upload a resume PDF file');
      return;
    }

    setIsAnalyzing(true);
    
    // Simulate ATS analysis with or without job description
    setTimeout(() => {
      const mockResult = {
        score: jobDescription.trim() ? 78 : 72,
        strengths: [
          'Resume is in PDF format (ATS-friendly)',
          'Contact information is clearly formatted',
          'Uses standard section headings',
          jobDescription.trim() ? 'Contains relevant keywords for the position' : 'Professional formatting maintained',
          'Professional font and spacing'
        ],
        improvements: [
          'Add more industry-specific keywords',
          'Quantify achievements with numbers',
          'Include skills section with technical competencies',
          'Use more action verbs in experience descriptions',
          ...(jobDescription.trim() ? [] : ['Add a job description for keyword matching analysis'])
        ],
        keywords: jobDescription.trim() ? {
          found: ['project management', 'leadership', 'team collaboration', 'data analysis'],
          missing: ['agile methodology', 'stakeholder management', 'risk assessment', 'process improvement']
        } : {
          found: ['leadership', 'management', 'analysis', 'communication'],
          missing: ['Add job description to see specific keyword recommendations']
        },
        sections: {
          contact: { score: 95, status: 'excellent' },
          summary: { score: jobDescription.trim() ? 72 : 68, status: 'good' },
          experience: { score: 80, status: 'good' },
          education: { score: 85, status: 'excellent' },
          skills: { score: jobDescription.trim() ? 65 : 60, status: 'needs improvement' }
        },
        formatting: {
          font: 'Standard and readable',
          spacing: 'Appropriate',
          bullets: 'Consistent',
          length: '2 pages (optimal)'
        }
      };
      
      setAnalysisResult(mockResult);
      setIsAnalyzing(false);
    }, 3000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-emerald-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-emerald-600 bg-emerald-50';
      case 'good': return 'text-blue-600 bg-blue-50';
      case 'needs improvement': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg shadow-lg border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center group">
              <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-file-text-line text-white text-xl"></i>
              </div>
              <h1 className="ml-3 text-2xl font-['Pacifico'] bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Resume Teacher</h1>
            </Link>
            <Link href="/builder" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all duration-300 whitespace-nowrap">
              Resume Builder
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative py-16 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://readdy.ai/api/search-image?query=ATS%20applicant%20tracking%20system%20resume%20scanning%20technology%2C%20automated%20resume%20screening%20software%20interface%2C%20HR%20technology%20with%20document%20analysis%2C%20professional%20recruitment%20technology%2C%20modern%20office%20with%20digital%20screening%20process%2C%20clean%20corporate%20environment&width=1200&height=400&seq=ats-hero&orientation=landscape"
            alt="ATS Resume Checker"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-cyan-900/80"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            ATS Resume Checker
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Test your resume against Applicant Tracking Systems (ATS) to ensure it passes automated screening. 
            Get detailed analysis and improvement recommendations.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-search-eye-line text-3xl text-blue-300 mb-2"></i>
              <div className="font-semibold">ATS Scanning</div>
              <div className="text-sm">Real-time analysis</div>
            </div>
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-key-2-line text-3xl text-cyan-300 mb-2"></i>
              <div className="font-semibold">Keyword Matching</div>
              <div className="text-sm">Job-specific optimization</div>
            </div>
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-file-check-line text-3xl text-teal-300 mb-2"></i>
              <div className="font-semibold">Format Check</div>
              <div className="text-sm">ATS-friendly formatting</div>
            </div>
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-bar-chart-line text-3xl text-indigo-300 mb-2"></i>
              <div className="font-semibold">Score & Tips</div>
              <div className="text-sm">Actionable insights</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!analysisResult ? (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* File Upload */}
            <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-upload-line text-indigo-600 mr-3"></i>
                Upload Your Resume
              </h2>
              
              <div
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
                  dragActive 
                    ? 'border-indigo-500 bg-indigo-50' 
                    : 'border-gray-300 hover:border-indigo-400 hover:bg-indigo-50/50'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                {uploadedFile ? (
                  <div className="space-y-4">
                    <i className="ri-file-pdf-line text-5xl text-red-500"></i>
                    <div>
                      <h3 className="font-semibold text-gray-900">{uploadedFile.name}</h3>
                      <p className="text-sm text-gray-600">
                        {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                    <button
                      onClick={() => setUploadedFile(null)}
                      className="text-red-600 hover:text-red-800 transition-colors duration-300"
                    >
                      <i className="ri-delete-bin-line mr-1"></i>
                      Remove file
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <i className="ri-cloud-line text-5xl text-gray-400"></i>
                    <div>
                      <h3 className="font-semibold text-gray-900">Drop your resume here</h3>
                      <p className="text-sm text-gray-600">or click to browse files</p>
                    </div>
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={(e) => e.target.files && handleFileUpload(e.target.files[0])}
                      className="hidden"
                      id="resume-upload"
                    />
                    <label
                      htmlFor="resume-upload"
                      className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-xl hover:bg-indigo-700 transition-colors duration-300 cursor-pointer whitespace-nowrap"
                    >
                      Choose PDF File
                    </label>
                    <p className="text-xs text-gray-500">Only PDF files are supported</p>
                  </div>
                )}
              </div>
            </div>

            {/* Job Description */}
            <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-file-list-line text-emerald-600 mr-3"></i>
                Job Description
              </h2>
              
              <div className="space-y-4">
                <textarea
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  placeholder="Paste the job description here to get personalized ATS analysis and keyword matching..."
                  className="w-full h-64 px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm resize-none"
                />
                <div className="text-xs text-gray-500">
                  {jobDescription.length} characters
                </div>
              </div>
            </div>
          </div>
        ) : (
          // Analysis Results
          <div className="space-y-8">
            {/* Overall Score */}
            <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20 text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">ATS Compatibility Score</h2>
              <div className="relative w-32 h-32 mx-auto mb-6">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="3"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeDasharray={`${analysisResult.score}, 100`}
                    className={getScoreColor(analysisResult.score)}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className={`text-3xl font-bold ${getScoreColor(analysisResult.score)}`}>
                      {analysisResult.score}%
                    </div>
                    <div className="text-sm text-gray-600">ATS Score</div>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                {analysisResult.score >= 80 ? 'Excellent! Your resume is highly ATS-compatible.' :
                 analysisResult.score >= 60 ? 'Good! Some improvements will boost your ATS score.' :
                 'Needs work. Follow our recommendations to improve ATS compatibility.'}
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Strengths */}
              <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
                <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                  <i className="ri-check-line text-emerald-600 mr-3"></i>
                  Strengths
                </h3>
                <div className="space-y-3">
                  {analysisResult.strengths.map((strength: string, index: number) => (
                    <div key={index} className="flex items-start">
                      <i className="ri-checkbox-circle-fill text-emerald-600 mr-3 mt-0.5 flex-shrink-0"></i>
                      <span className="text-gray-700 text-sm">{strength}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Improvements */}
              <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
                <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                  <i className="ri-alert-line text-amber-600 mr-3"></i>
                  Improvements
                </h3>
                <div className="space-y-3">
                  {analysisResult.improvements.map((improvement: string, index: number) => (
                    <div key={index} className="flex items-start">
                      <i className="ri-information-line text-amber-600 mr-3 mt-0.5 flex-shrink-0"></i>
                      <span className="text-gray-700 text-sm">{improvement}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Keywords Analysis */}
            <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-key-2-line text-blue-600 mr-3"></i>
                Keyword Analysis
              </h3>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-emerald-700 mb-3">Found Keywords</h4>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.keywords.found.map((keyword: string, index: number) => (
                      <span key={index} className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-red-700 mb-3">Missing Keywords</h4>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.keywords.missing.map((keyword: string, index: number) => (
                      <span key={index} className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Section Scores */}
            <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-bar-chart-line text-purple-600 mr-3"></i>
                Section Analysis
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
                {Object.entries(analysisResult.sections).map(([section, data]: [string, any]) => (
                  <div key={section} className="text-center p-4 bg-gray-50/80 rounded-xl">
                    <h4 className="font-semibold text-gray-900 capitalize mb-2">{section}</h4>
                    <div className={`text-2xl font-bold mb-2 ${getScoreColor(data.score)}`}>
                      {data.score}%
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(data.status)}`}>
                      {data.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="text-center space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => {
                    setAnalysisResult(null);
                    setUploadedFile(null);
                    setJobDescription('');
                  }}
                  className="bg-gray-600 text-white px-6 py-3 rounded-xl hover:bg-gray-700 transition-colors duration-300 whitespace-nowrap"
                >
                  <i className="ri-refresh-line mr-2"></i>
                  Check Another Resume
                </button>
                <Link href="/builder" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:shadow-lg transition-all duration-300 whitespace-nowrap">
                  <i className="ri-edit-line mr-2"></i>
                  Improve with Builder
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Analyze Button */}
        {!analysisResult && (
          <div className="text-center mt-8">
            <button
              onClick={analyzeResume}
              disabled={!uploadedFile || isAnalyzing}
              className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
            >
              {isAnalyzing ? (
                <span className="flex items-center">
                  <i className="ri-loader-4-line animate-spin mr-3"></i>
                  Analyzing Resume...
                </span>
              ) : (
                <span className="flex items-center">
                  <i className="ri-search-eye-line mr-3"></i>
                  Analyze ATS Compatibility
                </span>
              )}
            </button>
            {!uploadedFile && (
              <p className="text-sm text-gray-500 mt-2">
                Upload a PDF resume to enable analysis
              </p>
            )}
          </div>
        )}
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-cyan-600 py-16 mt-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-6">
            Build an ATS-Optimized Resume
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Use our resume builder with ATS-friendly templates and keyword optimization
          </p>
          <Link href="/builder" className="inline-flex items-center bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:bg-blue-50 transition-all duration-300 whitespace-nowrap">
            <i className="ri-shield-check-line mr-3 text-xl"></i>
            Build ATS-Ready Resume
          </Link>
        </div>
      </div>
    </div>
  );
}
