
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function CoverLetterTemplatesPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'all', name: 'All Templates', count: 33 },
    { id: 'professional', name: 'Professional', count: 15 },
    { id: 'creative', name: 'Creative', count: 10 },
    { id: 'modern', name: 'Modern', count: 8 }
  ];

  // Templates from cover letter builder
  const templates = [
    // Professional Templates (15)
    { id: 'professional-1', name: 'Executive Professional', category: 'professional', description: 'Formal corporate design for senior executives', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Professional%20executive%20cover%20letter%20template%20with%20clean%20corporate%20design%2C%20navy%20blue%20color%20scheme%2C%20formal%20business%20formatting%20for%20senior%20level%20positions%2C%20executive%20letterhead%20with%20company%20branding&width=320&height=400&seq=prof-exec-cl-1&orientation=portrait' },
    { id: 'professional-2', name: 'Corporate Classic', category: 'professional', description: 'Traditional business format for finance and consulting', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Corporate%20classic%20cover%20letter%20template%20with%20traditional%20business%20formatting%2C%20dark%20blue%20headers%2C%20structured%20layout%20for%20professional%20correspondence%2C%20conservative%20design%20suitable%20for%20finance%20and%20consulting&width=320&height=400&seq=prof-corp-cl-2&orientation=portrait' },
    { id: 'professional-3', name: 'Business Elite', category: 'professional', description: 'Premium template for C-suite positions', color: 'indigo', preview: 'https://readdy.ai/api/search-image?query=Business%20elite%20cover%20letter%20template%20with%20premium%20design%20for%20C-suite%20executives%2C%20indigo%20color%20accents%2C%20sophisticated%20letterhead%20with%20executive%20summary%2C%20strategic%20positioning&width=320&height=400&seq=prof-elite-cl-3&orientation=portrait' },
    { id: 'professional-4', name: 'Legal Professional', category: 'professional', description: 'Formal design for legal practitioners', color: 'gray', preview: 'https://readdy.ai/api/search-image?query=Legal%20professional%20cover%20letter%20template%20with%20formal%20conservative%20design%2C%20gray%20color%20scheme%2C%20structured%20layout%20for%20law%20firms%20and%20legal%20practitioners%2C%20traditional%20formatting&width=320&height=400&seq=prof-legal-cl-4&orientation=portrait' },
    { id: 'professional-5', name: 'Banking Specialist', category: 'professional', description: 'Conservative template for banking professionals', color: 'slate', preview: 'https://readdy.ai/api/search-image?query=Banking%20specialist%20cover%20letter%20template%20with%20conservative%20professional%20design%2C%20slate%20gray%20colors%2C%20financial%20services%20focused%20layout%20with%20trust%20and%20reliability%20emphasis&width=320&height=400&seq=prof-bank-cl-5&orientation=portrait' },
    { id: 'professional-6', name: 'Management Consultant', category: 'professional', description: 'Strategic template for consulting roles', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Management%20consultant%20cover%20letter%20template%20with%20strategic%20professional%20design%2C%20consulting%20industry%20focused%20layout%20with%20problem-solving%20emphasis&width=320&height=400&seq=prof-consult-cl-6&orientation=portrait' },
    { id: 'professional-7', name: 'HR Director', category: 'professional', description: 'People-focused design for HR professionals', color: 'emerald', preview: 'https://readdy.ai/api/search-image?query=HR%20director%20cover%20letter%20template%20with%20people-focused%20professional%20design%20emerald%20green%20accents%2C%20human%20resources%20layout%20with%20employee%20development%20emphasis&width=320&height=400&seq=prof-hr-cl-7&orientation=portrait' },
    { id: 'professional-8', name: 'Operations Manager', category: 'professional', description: 'Results-driven template for operations roles', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Operations%20manager%20cover%20letter%20template%20with%20results-driven%20design%2C%20orange%20accents%2C%20operations%20focused%20layout%20with%20efficiency%20and%20process%20improvement%20emphasis&width=320&height=400&seq=prof-ops-cl-8&orientation=portrait' },
    { id: 'professional-9', name: 'Sales Executive', category: 'professional', description: 'Achievement-focused template for sales professionals', color: 'red', preview: 'https://readdy.ai/api/search-image?query=Sales%20executive%20cover%20letter%20template%20with%20achievement-focused%20design%2C%20red%20color%20accents%2C%20sales%20professional%20layout%20with%20results%20and%20performance%20emphasis&width=320&height=400&seq=prof-sales-cl-9&orientation=portrait' },
    { id: 'professional-10', name: 'Project Manager', category: 'professional', description: 'Organized template for project management roles', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Project%20manager%20cover%20letter%20template%20with%20organized%20professional%20design%2C%20purple%20color%20accents%2C%20project%20management%20focused%20layout%20with%20leadership%20and%20coordination%20emphasis&width=320&height=400&seq=prof-pm-cl-10&orientation=portrait' },
    { id: 'professional-11', name: 'Financial Analyst', category: 'professional', description: 'Data-driven template for financial roles', color: 'teal', preview: 'https://readdy.ai/api/search-image?query=Financial%20analyst%20cover%20letter%20template%20with%20data-driven%20design%2C%20teal%20color%20accents%2C%20financial%20analysis%20focused%20layout%20with%20analytical%20and%20quantitative%20emphasis&width=320&height=400&seq=prof-fin-cl-11&orientation=portrait' },
    { id: 'professional-12', name: 'Marketing Director', category: 'professional', description: 'Brand-focused template for marketing leaders', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Marketing%20director%20cover%20letter%20template%20with%20brand-focused%20professional%20design%2C%20pink%20color%20accents%2C%20marketing%20leadership%20emphasis%20with%20strategic%20brand%20management%20focus&width=320&height=400&seq=prof-mkt-cl-12&orientation=portrait' },
    { id: 'professional-13', name: 'Business Analyst', category: 'professional', description: 'Analytical template for business analyst roles', color: 'indigo', preview: 'https://readdy.ai/api/search-image?query=Business%20analyst%20cover%20letter%20template%20with%20analytical%20professional%20design%2C%20indigo%20color%20accents%2C%20business%20analysis%20focused%20layout%20with%20process%20improvement%20emphasis&width=320&height=400&seq=prof-ba-cl-13&orientation=portrait' },
    { id: 'professional-14', name: 'Account Manager', category: 'professional', description: 'Relationship-focused template for account management', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Account%20manager%20cover%20letter%20template%20with%20relationship-focused%20design%2C%20orange%20color%20accents%2C%20client%20relationship%20emphasis%20with%20customer%20success%20focus&width=320&height=400&seq=prof-account-cl-14&orientation=portrait' },
    { id: 'professional-15', name: 'Compliance Officer', category: 'professional', description: 'Regulatory template for compliance professionals', color: 'gray', preview: 'https://readdy.ai/api/search-image?query=Compliance%20officer%20cover%20letter%20template%20with%20regulatory%20professional%20design%2C%20gray%20color%20scheme%2C%20compliance%20focused%20layout%20with%20regulatory%20expertise%20emphasis&width=320&height=400&seq=prof-comp-cl-15&orientation=portrait' },

    // Creative Templates (10)
    { id: 'creative-1', name: 'Graphic Designer Pro', category: 'creative', description: 'Visual template for graphic designers', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Graphic%20designer%20cover%20letter%20template%20with%20visual%20creative%20design%2C%20purple%20and%20pink%20color%20scheme%2C%20artistic%20layout%20with%20design%20elements%20and%20creative%20formatting&width=320&height=400&seq=creative-gd-cl-1&orientation=portrait' },
    { id: 'creative-2', name: 'UI/UX Designer', category: 'creative', description: 'Modern template for digital designers', color: 'indigo', preview: 'https://readdy.ai/api/search-image?query=UI%20UX%20designer%20cover%20letter%20template%20with%20modern%20digital%20design%20indigo%20and%20blue%20colors%2C%20user%20experience%20focused%20layout%20with%20design%20thinking%20emphasis&width=320&height=400&seq=creative-ux-cl-2&orientation=portrait' },
    { id: 'creative-3', name: 'Content Creator', category: 'creative', description: 'Engaging template for content creators', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Content%20creator%20cover%20letter%20template%20with%20engaging%20creative%20design%2C%20pink%20and%20orange%20colors%2C%20content%20creation%20focused%20layout%20with%20creative%20storytelling%20emphasis&width=320&height=400&seq=creative-cc-cl-3&orientation=portrait' },
    { id: 'creative-4', name: 'Marketing Creative', category: 'creative', description: 'Brand-focused template for marketing creatives', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Marketing%20creative%20cover%20letter%20template%20with%20brand-focused%20design%2C%20orange%20and%20yellow%20colors%2C%20creative%20marketing%20emphasis%20with%20campaign%20focus&width=320&height=400&seq=creative-mc-cl-4&orientation=portrait' },
    { id: 'creative-5', name: 'Art Director', category: 'creative', description: 'Leadership template for creative directors', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Art%20director%20cover%20letter%20template%20with%20creative%20leadership%20design%2C%20purple%20and%20gold%20colors%2C%20artistic%20direction%20emphasis%20with%20creative%20vision%20focus&width=320&height=400&seq=creative-ad-cl-5&orientation=portrait' },
    { id: 'creative-6', name: 'Copywriter', category: 'creative', description: 'Word-focused template for copywriters', color: 'teal', preview: 'https://readdy.ai/api/search-image?query=Copywriter%20cover%20letter%20template%20with%20word-focused%20creative%20design%2C%20teal%20and%20green%20colors%2C%20writing%20and%20storytelling%20emphasis%20with%20creative%20content%20focus&width=320&height=400&seq=creative-cw-cl-6&orientation=portrait' },
    { id: 'creative-7', name: 'Social Media Manager', category: 'creative', description: 'Trendy template for social media professionals', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Social%20media%20manager%20cover%20letter%20template%20with%20trendy%20creative%20design%2C%20vibrant%20pink%20and%20blue%20colors%2C%20social%20media%20focused%20layout%20with%20digital%20engagement%20emphasis&width=320&height=400&seq=creative-sm-cl-7&orientation=portrait' },
    { id: 'creative-8', name: 'Web Designer', category: 'creative', description: 'Digital template for web designers', color: 'cyan', preview: 'https://readdy.ai/api/search-image?query=Web%20designer%20cover%20letter%20template%20with%20digital%20creative%20design%2C%20cyan%20and%20blue%20colors%2C%20web%20development%20focused%20layout%20with%20digital%20innovation%20emphasis&width=320&height=400&seq=creative-wd-cl-8&orientation=portrait' },
    { id: 'creative-9', name: 'Brand Designer', category: 'creative', description: 'Identity-focused template for brand designers', color: 'amber', preview: 'https://readdy.ai/api/search-image?query=Brand%20designer%20cover%20letter%20template%20with%20identity-focused%20design%2C%20amber%20and%20orange%20colors%2C%20brand%20design%20emphasis%20with%20visual%20identity%20focus&width=320&height=400&seq=creative-bd-cl-9&orientation=portrait' },
    { id: 'creative-10', name: 'Event Planner', category: 'creative', description: 'Celebration template for event planners', color: 'fuchsia', preview: 'https://readdy.ai/api/search-image?query=Event%20planner%20cover%20letter%20template%20with%20celebration-themed%20design%2C%20fuchsia%20and%20gold%20colors%2C%20event%20planning%20focused%20layout%20with%20creative%20event%20emphasis&width=320&height=400&seq=creative-ep-cl-10&orientation=portrait' },

    // Modern Templates (8)
    { id: 'modern-1', name: 'Tech Startup', category: 'modern', description: 'Innovative template for startup professionals', color: 'blue', preview: 'https://readdy.ai/api/search-image?query=Tech%20startup%20cover%20letter%20template%20with%20innovative%20modern%20design%2C%20bright%20blue%20and%20white%20colors%2C%20clean%20minimalist%20layout%20with%20technology%20focus%20and%20innovation%20emphasis&width=320&height=400&seq=modern-startup-cl-1&orientation=portrait' },
    { id: 'modern-2', name: 'Software Engineer', category: 'modern', description: 'Code-focused template for developers', color: 'green', preview: 'https://readdy.ai/api/search-image?query=Software%20engineer%20cover%20letter%20template%20with%20code-focused%20modern%20design%2C%20green%20and%20dark%20colors%2C%20software%20development%20layout%20with%20programming%20emphasis&width=320&height=400&seq=modern-se-cl-2&orientation=portrait' },
    { id: 'modern-3', name: 'Data Scientist', category: 'modern', description: 'Analytics-driven template for data professionals', color: 'purple', preview: 'https://readdy.ai/api/search-image?query=Data%20scientist%20cover%20letter%20template%20with%20analytics-driven%20modern%20design%2C%20purple%20and%20blue%20colors%2C%20data%20science%20focused%20layout%20with%20analytical%20emphasis&width=320&height=400&seq=modern-ds-cl-3&orientation=portrait' },
    { id: 'modern-4', name: 'Product Manager', category: 'modern', description: 'Strategy-focused template for product managers', color: 'orange', preview: 'https://readdy.ai/api/search-image?query=Product%20manager%20cover%20letter%20template%20with%20strategy-focused%20modern%20design%2C%20orange%20and%20gray%20colors%2C%20product%20management%20layout%20with%20strategic%20planning%20emphasis&width=320&height=400&seq=modern-pm-cl-4&orientation=portrait' },
    { id: 'modern-5', name: 'Digital Marketer', category: 'modern', description: 'Growth-focused template for digital marketers', color: 'pink', preview: 'https://readdy.ai/api/search-image?query=Digital%20marketer%20cover%20letter%20template%20with%20growth-focused%20modern%20design%2C%20pink%20and%20purple%20colors%2C%20digital%20marketing%20layout%20with%20growth%20hacking%20emphasis&width=320&height=400&seq=modern-dm-cl-5&orientation=portrait' },
    { id: 'modern-6', name: 'UX Researcher', category: 'modern', description: 'Research-focused template for UX researchers', color: 'violet', preview: 'https://readdy.ai/api/search-image?query=UX%20researcher%20cover%20letter%20template%20with%20research-focused%20modern%20design%2C%20violet%20and%20gray%20colors%2C%20user%20research%20focused%20layout%20with%20methodology%20emphasis&width=320&height=400&seq=modern-uxr-cl-6&orientation=portrait' },
    { id: 'modern-7', name: 'Growth Hacker', category: 'modern', description: 'Experiment-driven template for growth professionals', color: 'lime', preview: 'https://readdy.ai/api/search-image?query=Growth%20hacker%20cover%20letter%20template%20with%20experiment-driven%20modern%20design%2C%20lime%20and%20dark%20colors%2C%20growth%20hacking%20focused%20layout%20with%20data-driven%20experimentation%20emphasis&width=320&height=400&seq=modern-growth-cl-7&orientation=portrait' },
    { id: 'modern-8', name: 'E-commerce Manager', category: 'modern', description: 'Sales-focused template for e-commerce professionals', color: 'rose', preview: 'https://readdy.ai/api/search-image?query=E-commerce%20manager%20cover%20letter%20template%20with%20sales-focused%20modern%20design%2C%20rose%20and%20white%20colors%2C%20e-commerce%20layout%20with%20online%20retail%20emphasis&width=320&height=400&seq=modern-ecom-cl-8&orientation=portrait' }
  ];

  // Filter templates
  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-layout-2-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-['Pacifico'] text-blue-600">ResumeTeacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Resume Builder
              </Link>
              <Link href="/cover-letter" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Cover Letter Guide
              </Link>
              <Link href="/cover-letter-templates" className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-1 whitespace-nowrap">
                Cover Letter Templates
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h1 className="text-5xl font-bold text-white mb-6">
            Professional Cover Letter Templates
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Choose from 33 professionally designed templates across professional, creative, and modern categories. 
            Each template is optimized for different industries and career levels.
          </p>
          <div className="flex justify-center space-x-4">
            <Link href="/cover-letter-builder" className="inline-flex items-center px-6 py-3 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold">
              <i className="ri-add-line mr-2"></i>
              Create Cover Letter
            </Link>
            <Link href="/cover-letter-examples" className="inline-flex items-center px-6 py-3 border-2 border-white text-white rounded-lg hover:bg-white hover:text-blue-600 transition-colors font-semibold">
              <i className="ri-eye-line mr-2"></i>
              View Examples
            </Link>
          </div>
        </div>
      </section>

      {/* Search and Category Filters */}
      <section className="py-8 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
              <input
                type="text"
                placeholder="Search templates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${selectedCategory === category.id 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                  {category.name} ({category.count})
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Templates Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer group hover:scale-105"
              >
                <div className="aspect-[3/4] relative overflow-hidden">
                  <img
                    src={template.preview}
                    alt={template.name}
                    className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
                    <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <span className="text-sm font-medium text-gray-800">Select Template</span>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-1">{template.name}</h3>
                  <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                  <div className="flex items-center justify-between">
                    <span className={`px-2 py-1 rounded text-xs font-medium bg-${template.color}-100 text-${template.color}-700`}>
                      {template.category}
                    </span>
                    <Link
                      href={`/cover-letter-builder?template=${template.id}`}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium whitespace-nowrap"
                    >
                      Use Template
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Create Your Perfect Cover Letter?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Choose from 33 professional templates designed for different industries and career levels. 
            Get started with our advanced cover letter builder today.
          </p>
          <Link href="/cover-letter-builder" className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold">
            <i className="ri-rocket-2-line mr-2"></i>
            Start Building Now
          </Link>
        </div>
      </section>
    </div>
  );
}
