'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function HomePage() {
  const [isAnimated, setIsAnimated] = useState(false);
  const [showResumeDropdown, setShowResumeDropdown] = useState(false);
  const [showCVDropdown, setShowCVDropdown] = useState(false);
  const [showCoverLetterDropdown, setShowCoverLetterDropdown] = useState(false);
  const [showAdviceDropdown, setShowAdviceDropdown] = useState(false);
  const [showResourcesDropdown, setShowResourcesDropdown] = useState(false);
  const [showWhatsApp, setShowWhatsApp] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [typewriterText, setTypewriterText] = useState('');
  const [showCursor, setShowCursor] = useState(true);
  const [scrollY, setScrollY] = useState(0);
  const [showFloatingButton, setShowFloatingButton] = useState(false);
  const [windowHeight, setWindowHeight] = useState(600); // Default value for SSR

  // FAQ Data
  const faqData = [
    {
      question: "Is the resume builder really free to use?",
      answer:
        "Yes! You can create and download your resume completely free. We also offer premium features for advanced customization and additional templates."
    },
    {
      question: "Are the templates ATS-friendly?",
      answer:
        "Absolutely! All our templates are designed to be ATS (Applicant Tracking System) compliant, ensuring your resume gets past automated screening systems and reaches human recruiters."
    },
    {
      question: "How does the AI writing assistant work?",
      answer:
        "Our AI analyzes your job title, experience, and industry to suggest powerful bullet points, keywords, and phrases that make your resume more compelling and relevant to employers."
    },
    {
      question: "Can I edit my resume after downloading?",
      answer:
        "Yes! You can save your resume to your account and make unlimited edits. Your resume is stored securely and can be accessed anytime to make updates or create new versions."
    },
    {
      question: "What file formats can I download my resume in?",
      answer:
        "You can download your resume in PDF, Word (DOCX), and plain text formats. PDF is recommended for job applications as it preserves formatting across all devices."
    },
    {
      question: "Do you offer cover letter templates too?",
      answer: "Yes! We provide matching cover letter templates that complement your resume design. You can create both documents with consistent formatting and styling."
    },
    {
      question: "Is my personal information secure?",
      answer:
        "Absolutely. We use enterprise-grade security measures to protect your data. Your information is encrypted and we never share your personal details with third parties."
    },
    {
      question: "Can I use the resume builder on my mobile phone?",
      answer:
        "Yes! Our resume builder is fully responsive and works perfectly on all devices - desktop, tablet, and mobile phones. Build your resume anywhere, anytime."
    }
  ];

  // Typewriter effect
  const fullText = "A Powerful AI-Powered Resume Builder";

  useEffect(() => {
    setIsAnimated(true);

    // Set window height on client side only
    if (typeof window !== "undefined") {
      setWindowHeight(window.innerHeight);

      const handleResize = () => {
        setWindowHeight(window.innerHeight);
      };

      window.addEventListener("resize", handleResize);

      // Clean up resize listener
      return () => window.removeEventListener("resize", handleResize);
    }
  }, []);

  useEffect(() => {
    // Typewriter effect for main title
    let index = 0;
    const typeWriter = () => {
      if (index < fullText.length) {
        setTypewriterText(fullText.slice(0, index + 1));
        index++;
        setTimeout(typeWriter, 100);
      } else {
        // Start blinking cursor after typing is complete
        setInterval(() => {
          setShowCursor(prev => !prev);
        }, 500);
      }
    };

    // Start typewriter after a short delay
    setTimeout(typeWriter, 500);

    // Show WhatsApp button after a delay
    setTimeout(() => setShowWhatsApp(true), 2000);

    // Handle scroll for floating button
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setScrollY(currentScrollY);

      // Show floating button after scrolling past hero section (approximately 600px)
      setShowFloatingButton(currentScrollY > 600);
    };

    if (typeof window !== "undefined") {
      window.addEventListener("scroll", handleScroll, { passive: true });

      return () => window.removeEventListener("scroll", handleScroll);
    }
  }, []);

  const handleAIAssistantClick = () => {
    setShowAIModal(true);
  };

  const closeAIModal = () => {
    setShowAIModal(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Add CSS animations for scrolling logos */}
      <style jsx>{`
        @keyframes scrollLeft {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        @keyframes scrollLeftSlow {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        @keyframes fadeInUp {
          0% {
            opacity: 0;
            transform: translateY(30px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slideInLeft {
          0% {
            opacity: 0;
            transform: translateX(-30px);
          }
          100% {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes bounce {
          0%,
          20%,
          53%,
          80%,
          100% {
            transform: translateY(0);
          }
          40%,
          43% {
            transform: translateY(-15px);
          }
          70% {
            transform: translateY(-7px);
          }
          90% {
            transform: translateY(-3px);
          }
        }

        @keyframes pulse {
          0% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
          100% {
            transform: scale(1);
          }
        }

        @keyframes typewriter {
          from {
            width: 0;
          }
          to {
            width: 100%;
          }
        }

        @keyframes blink {
          0%,
          50% {
            opacity: 1;
          }
          51%,
          100% {
            opacity: 0;
          }
        }

        @keyframes smoothSlideIn {
          0% {
            opacity: 0;
            transform: translateY(50px) scale(0.95);
          }
          100% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @keyframes gradientShift {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }

        @keyframes glow {
          0% {
            box-shadow: 0 0 5px rgba(59, 130, 246, 0.3);
          }
          50% {
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.6),
              0 0 30px rgba(59, 130, 246, 0.4);
          }
          100% {
            box-shadow: 0 0 5px rgba(59, 130, 246, 0.3);
          }
        }

        @keyframes floatUpDown {
          0%,
          100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-8px);
          }
        }

        @keyframes shimmer {
          0% {
            background-position: -200% 0;
          }
          100% {
            background-position: 200% 0;
          }
        }

        @keyframes magicalFloat {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
          }
          25% {
            transform: translateY(-12px) rotate(5deg);
          }
          50% {
            transform: translateY(-8px) rotate(-3deg);
          }
          75% {
            transform: translateY(-15px) rotate(7deg);
          }
        }

        @keyframes sparkleRotate {
          0% {
            transform: rotate(0deg) scale(1);
            opacity: 0.7;
          }
          50% {
            transform: rotate(180deg) scale(1.3);
            opacity: 1;
          }
          100% {
            transform: rotate(360deg) scale(1);
            opacity: 0.7;
          }
        }

        @keyframes twinkle {
          0%, 100% {
            opacity: 0.4;
            transform: scale(0.8);
          }
          50% {
            opacity: 1;
            transform: scale(1.2);
          }
        }

        .animate-scroll-left-continuous {
          animation: scrollLeft 25s linear infinite;
          will-change: transform;
        }

        .animate-scroll-left-slow {
          animation: scrollLeftSlow 35s linear infinite;
          will-change: transform;
        }

        .animate-scroll-left-continuous:hover,
        .animate-scroll-left-slow:hover {
          animation-play-state: paused;
        }

        .animate-fade-in-up {
          animation: fadeInUp 1s ease-out forwards;
        }

        .animate-slide-in-left {
          animation: slideInLeft 0.8s ease-out forwards;
        }

        .animate-bounce-custom {
          animation: bounce 2s infinite;
        }

        .animate-pulse-custom {
          animation: pulse 3s ease-in-out infinite;
        }

        .animate-delay-300 {
          animation-delay: 0.3s;
        }

        .animate-delay-600 {
          animation-delay: 0.6s;
        }

        .animate-smooth-slide-in {
          animation: smoothSlideIn 1.2s ease-out forwards;
        }

        .animate-gradient-shift {
          background-size: 200% 200%;
          animation: gradientShift 3s ease-in-out infinite;
        }

        .animate-glow {
          animation: glow 2s ease-in-out infinite;
        }

        .animate-delay-500 {
          animation-delay: 0.5s;
        }

        .animate-delay-1000 {
          animation-delay: 1s;
        }

        .animate-gradient-x {
          background-size: 200% 200%;
          animation: gradient-x 3s ease infinite;
        }

        .animate-slide-in-up {
          animation: slide-in-up 0.8s ease-out forwards;
          opacity: 0;
          transform: translateY(30px);
        }

        .animate-slide-in-left {
          animation: slide-in-left 0.8s ease-out forwards;
          opacity: 0;
          transform: translateX(-30px);
        }

        .animate-typewriter-subtitle {
          overflow: hidden;
          border-right: 2px solid #2563eb;
          white-space: nowrap;
          width: 0;
          animation: typewriter 2s steps(26, end) 3s forwards,
            blink 1s infinite 5s;
        }

        .typewriter-cursor {
          animation: blink 1s infinite;
        }

        .animate-float {
          animation: floatUpDown 3s ease-in-out infinite;
        }

        .animate-shimmer {
          background: linear-gradient(
            90deg,
            transparent,
            rgba(255, 255, 255, 0.4),
            transparent
          );
          background-size: 200% 100%;
          animation: shimmer 2s infinite;
        }

        .animate-magical-float {
          animation: magicalFloat 4s ease-in-out infinite;
        }

        .animate-sparkle-rotate {
          animation: sparkleRotate 3s linear infinite;
        }

        .animate-twinkle {
          animation: twinkle 2s ease-in-out infinite;
        }

        @keyframes gradient-x {
          0%,
          100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }

        @keyframes slide-in-up {
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slide-in-left {
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes glow {
          from {
            text-shadow: 0 0 10px rgba(37, 99, 235, 0.5);
          }
          to {
            text-shadow: 0 0 20px rgba(37, 99, 235, 0.8);
          }
        }
      `}</style>

      {/* Floating AI Assistant Button */}
      <div
        className={`fixed left-6 z-50 transition-all duration-700 ease-out ${
          showFloatingButton
            ? "opacity-100 translate-y-0 scale-100"
            : "opacity-0 translate-y-10 scale-0 pointer-events-none"
        }`}
        style={{
          top: `${Math.min(200 + scrollY * 0.1, windowHeight - 200)}px`
        }}
        suppressHydrationWarning={true}
      >
        <Link
          href="/builder"
          className="group relative bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-110 animate-float block"
        >
          <div className="px-6 py-4 flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
              <i className="ri-magic-line text-xl"></i>
            </div>
            <div className="hidden lg:block">
              <div className="text-sm font-bold">Start with AI</div>
              <div className="text-xs opacity-90">Build Resume Now</div>
            </div>
          </div>

          {/* Shimmer effect */}
          <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-shimmer"></div>

          {/* Pulse ring */}
          <div className="absolute inset-0 bg-blue-400 rounded-2xl animate-ping opacity-20 group-hover:opacity-0 transition-opacity duration-300"></div>

          {/* Tooltip */}
          <div className="absolute left-full ml-4 top-1/2 -translate-y-1/2 bg-gray-900 text-white text-sm px-4 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 whitespace-nowrap pointer-events-none lg:hidden">
            Build your resume with AI assistance
            <div className="absolute left-full top-1/2 -translate-y-1/2 border-4 border-transparent border-l-gray-900"></div>
          </div>
        </Link>
      </div>

      {/* WhatsApp Floating Button - Mobile Optimized - MOVED TO LEFT */}
      <div
        className={`fixed bottom-4 left-4 md:bottom-6 md:left-6 z-50 transition-all duration-1000 ${
          showWhatsApp
            ? "opacity-100 translate-y-0 scale-100"
            : "opacity-0 translate-y-10 scale-0"
        }`}
      >
        <a
          href="https://wa.me/256750625684"
          target="_blank"
          rel="noopener noreferrer"
          className="group relative bg-green-500 hover:bg-green-600 text-white w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 animate-pulse hover:animate-none"
        >
          <i className="ri-whatsapp-line text-lg md:text-2xl"></i>

          {/* Tooltip - Hidden on mobile, positioned for left side */}
          <div className="hidden md:block absolute left-full ml-4 top-1/2 -translate-y-1/2 bg-gray-900 text-white text-sm px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
            Need Help? Chat with us!
            <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-gray-900"></div>
          </div>

          {/* Ripple Effect */}
          <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-20"></div>
        </a>
      </div>

      {/* Modern Header - Mobile Responsive */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-file-text-line text-white text-xl"></i>
              </div>
              <span className="ml-3 text-2xl font-['Pacifico'] bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                ResumeTeacher
              </span>
            </Link>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2 rounded-lg text-gray-600 hover:text-blue-600 hover:bg-gray-100 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <i
                className={`ri-${mobileMenuOpen ? "close" : "menu"}-line text-xl`}
              ></i>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-4 lg:space-x-8">
              <Link
                href="/builder"
                className="px-3 lg:px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap text-sm lg:text-base"
              >
                Builder
              </Link>

              {/* Resume Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setShowResumeDropdown(true)}
                onMouseLeave={() => setShowResumeDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors px-2 lg:px-3 py-2 border-2 border-blue-600 text-blue-600 rounded-lg whitespace-nowrap text-sm lg:text-base">
                  Resume
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>

                {showResumeDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-80 z-50">
                    <div className="grid grid-cols-1 gap-4">
                      <Link
                        href="/resume-templates"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-file-copy-line text-orange-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Resume Templates
                          </h3>
                          <p className="text-sm text-gray-600">
                            Browse customizable templates to create a resume quickly
                            and easily.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/formats"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-layout-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Resume Formats
                          </h3>
                          <p className="text-sm text-gray-600">
                            Learn different formats and choose the best one for you
                            based on your background.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/resume-examples"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-award-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Resume Examples
                          </h3>
                          <p className="text-sm text-gray-600">
                            Use examples for various job titles and industries as a
                            source of inspiration.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/ai-resume-skills-generator"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-settings-3-line text-purple-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            AI Resume Skills Generator
                          </h3>
                          <p className="text-sm text-gray-600">
                            Use our resume skills generator for a quick solution to a
                            job-winning skills section.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/how-to-make-resume"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-question-line text-indigo-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            How to Make a Resume
                          </h3>
                          <p className="text-sm text-gray-600">
                            Learn step-by-step tips for writing a resume that gets
                            noticed.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/ats-resume-checker"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-shield-check-line text-yellow-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            ATS Resume Checker
                          </h3>
                          <p className="text-sm text-gray-600">
                            Ensure your resume can be easily read by Applicant
                            Tracking Systems (ATS).
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/summary-generator"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-magic-line text-red-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            AI Summary Generator
                          </h3>
                          <p className="text-sm text-gray-600">
                            Create a professional resume summary that highlights your
                            essential qualifications and career goals.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/ai-review"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-search-eye-line text-teal-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            AI Resume Review
                          </h3>
                          <p className="text-sm text-gray-600">
                            Get instant expert feedback with clear steps for
                            improvement.
                          </p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* CV Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setShowCVDropdown(true)}
                onMouseLeave={() => setShowCVDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                  CV
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>

                {showCVDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link
                        href="/cv-templates"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-file-list-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            CV Templates
                          </h3>
                          <p className="text-sm text-gray-600">
                            Professional CV templates for academic and research
                            positions.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/cv-examples"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-bookmark-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            CV Examples
                          </h3>
                          <p className="text-sm text-gray-600">
                            Browse CV examples across different industries and
                            experience levels.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/how-to-write-cv"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-edit-line text-purple-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            How to Write a CV
                          </h3>
                          <p className="text-sm text-gray-600">
                            Complete guide to writing a compelling CV that stands
                            out.
                          </p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Cover Letter Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setShowCoverLetterDropdown(true)}
                onMouseLeave={() => setShowCoverLetterDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                  Cover Letter
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>

                {showCoverLetterDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link
                        href="/cover-letter-builder"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-file-text-line text-indigo-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Cover Letter Builder
                          </h3>
                          <p className="text-sm text-gray-600">
                            Create professional cover letters with our easy-to-use
                            builder.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/cover-letter-templates"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-layout-2-line text-orange-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Cover Letter Templates
                          </h3>
                          <p className="text-sm text-gray-600">
                            Choose from professionally designed cover letter
                            templates.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/cover-letter-examples"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-newspaper-line text-teal-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Cover Letter Examples
                          </h3>
                          <p className="text-sm text-gray-600">
                            Get inspired by cover letter examples for various job
                            roles.
                          </p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Advice Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setShowAdviceDropdown(true)}
                onMouseLeave={() => setShowAdviceDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                  Advice
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>

                {showAdviceDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link
                        href="/career-advice"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-lightbulb-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Career Advice
                          </h3>
                          <p className="text-sm text-gray-600">
                            Expert tips for advancing your career and landing your
                            dream job.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/interview-tips"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-discuss-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Interview Tips
                          </h3>
                          <p className="text-sm text-gray-600">
                            Prepare for interviews with our comprehensive guides and
                            tips.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/job-search-tips"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-search-line text-purple-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Job Search Tips
                          </h3>
                          <p className="text-sm text-gray-600">
                            Strategies and tips for finding and applying to the right
                            jobs.
                          </p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Resources Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setShowResourcesDropdown(true)}
                onMouseLeave={() => setShowResourcesDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                  Resources
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>

                {showResourcesDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link
                        href="/blog"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-article-line text-orange-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Blog</h3>
                          <p className="text-sm text-gray-600">
                            Latest articles on career development and job search
                            strategies.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/guides"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-book-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Career Guides
                          </h3>
                          <p className="text-sm text-gray-600">
                            Comprehensive guides for different career paths and
                            industries.
                          </p>
                        </div>
                      </Link>

                      <Link
                        href="/tools"
                        className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-tools-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Career Tools
                          </h3>
                          <p className="text-sm text-gray-600">
                            Useful tools and calculators for career planning and
                            development.
                          </p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Auth Buttons */}
            <div className="hidden md:flex items-center space-x-2 lg:space-x-3">
              <Link
                href="/login"
                className="px-3 lg:px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap text-sm lg:text-base"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="px-3 lg:px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap text-sm lg:text-base"
              >
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20 overflow-hidden">
        {/* Resume Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-15"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=professional%20resume%20template%20with%20clean%20layout%2C%20organized%20sections%2C%20modern%20typography%2C%20CV%20document%20with%20contact%20information%2C%20work%20experience%2C%20education%20sections%2C%20skills%20area%2C%20white%20background%2C%20business%20document%20format%2C%20hiring%20template&width=1200&height=800&seq=resume-bg-001&orientation=landscape')`
          }}
        />

        {/* Overlay for better text readability */}
        <div className="absolute inset-0 bg-white/30" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div
              className={`text-center lg:text-left transition-all duration-1000 ${
                isAnimated ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              <div className="flex-1">
                <h1 className="text-4xl md:text-6xl font-bold mb-6">
                  <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                    {typewriterText}
                    {showCursor && (
                      <span className="typewriter-cursor text-blue-600">|</span>
                    )}
                  </span>
                  <br />
                  <span className="block text-2xl md:text-3xl font-semibold mb-6 transform transition-all duration-1000 hover:scale-105">
                    <span className="text-black animate-bounce">
                      (Affordable &amp; Easy to Use)
                    </span>
                  </span>
                </h1>
                <p className="text-xl text-gray-600 mb-8 animate-slide-in-up animate-delay-500">
                  Create professional resumes in minutes with our AI-powered
                  builder. Stand out from the competition with ATS-optimized
                  templates.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 animate-slide-in-up animate-delay-1000">
                  <Link
                    href="/builder"
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors text-center whitespace-nowrap cursor-pointer text-sm"
                  >
                    Start Building Now
                  </Link>
                  <Link
                    href="/import"
                    className="border-2 border-green-600 text-green-600 px-6 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors text-center whitespace-nowrap cursor-pointer flex items-center justify-center text-sm"
                  >
                    <i className="ri-upload-cloud-line mr-2 text-lg"></i>
                    Upload Your Resume
                  </Link>
                  <Link
                    href="/ats-resume-checker"
                    className="border-2 border-purple-600 text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors text-center whitespace-nowrap cursor-pointer flex items-center justify-center text-sm"
                  >
                    <i className="ri-brain-line mr-2 text-lg"></i>
                    AI Analyse
                  </Link>
                </div>
              </div>
            </div>

            <div
              className={`mt-8 lg:mt-0 transition-all duration-1000 delay-300 ${
                isAnimated
                  ? "opacity-100 translate-x-0"
                  : "opacity-0 translate-x-10"
              }`}
            >
              <div className="relative">
                <img
                  src="https://readdy.ai/api/search-image?query=Professional%20resume%20builder%20software%20interface%20showing%20modern%20resume%20template%20with%20filled%20sections%20including%20professional%20summary%2C%20work%20experience%2C%20education%20and%20skills%2C%20laptop%20screen%20displaying%20resume%20creation%20process%2C%20clean%20workspace%20with%20coffee%20cup%2C%20notebook%20and%20pen%2C%20modern%20office%20setting%20with%20natural%20lightlight%2Cinspiring%20productive%20atmosphere%20showing%20career%20success&width=600&height=400&seq=hero-resume-builder&orientation=landscape"
                  alt="AI Resume Builder Preview"
                  className="w-full h-auto rounded-xl md:rounded-2xl shadow-xl md:shadow-2xl"
                />

                {/* Interactive AI Writing Assistant Button - Mobile Optimized */}
                <button
                  onClick={handleAIAssistantClick}
                  className="absolute -top-2 -right-2 md:-top-4 md:-right-4 bg-white rounded-lg md:rounded-xl shadow-lg p-2 md:p-4 border border-gray-100 animate-bounce hover:animate-none hover:scale-105 transition-all duration-300 cursor-pointer group"
                >
                  <div className="flex items-center space-x-1 md:space-x-2">
                    <i className="ri-magic-line text-blue-600 group-hover:text-blue-700 text-sm md:text-base"></i>
                    <span className="text-xs md:text-sm font-semibold text-gray-800 group-hover:blue-600 hidden sm:inline">
                      AI Writing Assistant
                    </span>
                  </div>
                </button>

                <div className="absolute -bottom-2 -left-2 md:-bottom-4 md:-left-4 bg-white rounded-lg md:rounded-xl shadow-lg p-2 md:p-4 border border-gray-100 animate-pulse">
                  <div className="flex items-center space-x-1 md:space-x-2">
                    <i className="ri-check-line text-green-600 text-sm md:text-base"></i>
                    <span className="text-xs md:text-sm font-semibold text-gray-800">
                      ATS Optimized
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Assistant Section - Mobile Responsive */}
      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            Let AI do the work!
          </h2>
          <p className="text-lg md:text-xl text-gray-600 mb-6 md:mb-8 max-w-3xl mx-auto">
            Our intelligent resume builder
            analyzes your experience and suggests the best content to make your resume more compelling and relevant to employers.
          </p>
          <Link
            href="/builder"
            className="inline-flex items-center px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-colors text-base md:text-lg font-semibold whitespace-nowrap"
          >
            <i className="ri-magic-line mr-2"></i>
            Start with AI Assistant
          </Link>
        </div>
      </section>

      {/* Companies Section - Mobile Responsive */}
      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-8 md:mb-12">
            Our users get hired by
          </h2>

          {/* First Row - Scrolling */}
          <div className="overflow-hidden mb-6 md:mb-8 relative">
            <div className="flex items-center space-x-8 md:space-x-16 animate-scroll-left-continuous whitespace-nowrap">
              <img
                src="https://readdy.ai/api/search-image?query=BBC%20logo%20simple%20white%20letters%20on%20black%20squares%20background%2C%20British%20broadcasting%20corporation%20brand%20identity%20clean%20design&width=120&height=60&seq=bbc-logo&orientation=landscape"
                alt="BBC"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Wall%20Street%20JournalWSJ%20logo%20elegant%20serif%20font%20black%20text%20on%20white%20background%2C%20financial%20newspaper%20brand&width=120&height=60&seq=wsj-logo&orientation=landscape"
                alt="WSJ"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=New%20York%20Post%20logo%20bold%20italic%20white%20text%20on%20dark%20background%2C%20newspaper%20masthead%20design&width=140&height=60&seq=nypost-logo&orientation=landscape"
                alt="New York Post"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=MSNBC%20logo%20colorful%20peacock%20with%20text%20news%20networkbrand%20identity%20clean%20design&width=140&height=60&seq=msnbc-logo&orientation=landscape"
                alt="MSNBC"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=FOX%20logo%20bold%20blue%20letters%20media%20company%20brand%20identity%20clean%20corporate%20design&width=120&height=60&seq=fox-logo&orientation=landscape"
                alt="FOX"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              {/* duplicate logos for seamless loop */}
              <img
                src="https://readdy.ai/api/search-image?query=BBC%20logo%20simple%20white%20letters%20on%20black%20squares%20background%2C%20British%20broadcasting%20corporation%20brand%20identity%20clean%20design&width=120&height=60&seq=bbc-logo-2&orientation=landscape"
                alt="BBC"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Wall%20Street%20JournalWSJ%20logo%20elegant%20serif%20font%20black%20text%20on%20white%20background%2C%20financial%20newspaper%20brand&width=120&height=60&seq=wsj-logo-2&orientation=landscape"
                alt="WSJ"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=New%20York%20Post%20logo%20bold%20italic%20white%20text%20on%20dark%20background%2C%20newspaper%20masthead%20design&width=140&height=60&seq=nypost-logo-2&orientation=landscape"
                alt="New York Post"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=MSNBC%20logo%20colorful%20peacock%20with%20text%20news%20networkbrand%20identity%20clean%20design&width=140&height=60&seq=msnbc-logo-2&orientation=landscape"
                alt="MSNBC"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-30"
              />
              <img
                src="https://readdy.ai/api/search-image?query=FOX%20logo%20bold%20blue%20letters%20media%20company%20brand%20identity%20clean%20corporate%20design&width=120&height=60&seq=fox-logo-2&orientation=landscape"
                alt="FOX"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
            </div>
          </div>

          {/* Second Row - Scrolling */}
          <div className="overflow-hidden relative">
            <div className="flex items-center space-x-8 md:space-x-16 animate-scroll-left-slow whitespace-nowrap">
              <img
                src="https://readdy.ai/api/search-image?query=NBC%20peacock%20logo%20colorful%20feathers%20with%20text%20television%20networkbrand%20identity&width=120&height=60&seq=nbc-logo&orientation=landscape"
                alt="NBC"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Newsweek%20%20magazine%20logo%20red%20text%20on%20white%20background%20news%20publication%20brand&width=140&height=60&seq=newsweek-logo&orientation=landscape"
                alt="Newsweek"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Fortune%20%20magazine%20logo%20elegant%20serif%20font%20business%20publication%20brand%20identity&width=140&height=60&seq=fortune-logo&orientation=landscape"
                alt="Fortune"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Business%20Insider%20logo%20modern%20sans%20serif%20text%20business%20news%20publication%20brand&width=160&height=60&seq=business-insider-logo&orientation=landscape"
                alt="Business Insider"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=HuffPost%20logo%20green%20text%20modern%20digital%20news%20publication%20brand%20identity&width=140&height=60&seq=huffpost-logo&orientation=landscape"
                alt="HuffPost"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Forbes%20logo%20elegant%20serif%20font%20business%20magazine%20publication&width=120&height=60&seq=forbes-logo-2&orientation=landscape"
                alt="Forbes"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              {/* duplicate row for seamless loop */}
              <img
                src="https://readdy.ai/api/search-image?query=NBC%20peacock%20logo%20colorful%20feathers%20with%20text%20television%20networkbrand%20identity&width=120&height=60&seq=nbc-logo-2&orientation=landscape"
                alt="NBC"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Newsweek%20%20magazine%20logo%20red%20text%20on%20white%20background%20news%20publication%20brand&width=140&height=60&seq=newsweek-logo-2&orientation=landscape"
                alt="Newsweek"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Fortune%20%20magazine%20logo%20elegant%20serif%20font%20business%20publication%20brand%20identity&width=140&height=60&seq=fortune-logo-2&orientation=landscape"
                alt="Fortune"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Business%20Insider%20logo%20modern%20sans%20serif%20text%20business%20news%20publication%20brand&width=160&height=60&seq=business-insider-logo-2&orientation=landscape"
                alt="Business Insider"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=HuffPost%20logo%20green%20text%20modern%20digital%20news%20publication%20brand%20identity&width=140&height=60&seq=huffpost-logo-2&orientation=landscape"
                alt="HuffPost"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
              <img
                src="https://readdy.ai/api/search-image?query=Forbes%20logo%20elegant%20serif%20font%20business%20magazine%20publication&width=120&height=60&seq=forbes-logo-2&orientation=landscape"
                alt="Forbes"
                className="h-8 md:h-12 opacity-60 hover:opacity-100 transition-opacity duration-300 flex-shrink-0"
              />
            </div>
          </div>

          <p className="text-xs md:text-sm text-gray-500 mt-8 md:mt-12">
            Join thousands of professionals who've landed their dream jobs with
            our resume builder
          </p>
        </div>
      </section>

      {/* Why Choose Section - Mobile Responsive */}
      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Resume Builder?
            </h2>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              Create professional resumes that get you hired with our powerful AI-driven
              features
            </p>
          </div>

          {/* Visual process section */}
          <div className="mb-12 md:mb-16">
            <div className="relative">
              <img
                src="https://readdy.ai/api/search-image?query=Step%20by%20step%20resume%20creation%20process%20showing%20three%20stages%20-%20person%20typing%20on%20laptop%20with%20resume%20template%2C%20AI%20suggestions%20appearing%20on%20screen%2C%20and%20final%20professional%20resume%20document%2C%20modern%20workspace%20with%20organized%20desk%2C%20bright%20natural%20lighting%20professional%20career%20development%20theme&width=1000&height=300&seq=resume-process-steps&orientation=landscape"
                alt="Resume Creation Process"
                className="w-full h-48 md:h-64 object-cover rounded-xl md:rounded-2xl shadow-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-purple-900/80 rounded-xl md:rounded-2xl flex items-center justify-center">
                <div className="text-center text-white px-4">
                  <h3 className="text-lg md:text-2xl font-bold mb-2">
                    Build Your Resume in 3 Easy Steps
                  </h3>
                  <p className="text-sm md:text-lg opacity-90">
                    Choose Template → Add Content → Download &amp; Apply
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-6 md:p-8 rounded-xl md:rounded-2xl text-center">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-blue-600 rounded-xl md:rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6">
                <i className="ri-magic-line text-white text-xl md:text-2xl"></i>
              </div>
              <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-3 md:mb-4">
                AI-Powered Writing
              </h3>
              <p className="text-sm md:text-base text-gray-600">
                Get intelligent suggestions for every section of your resume. Our
                AI helps you write compelling content that stands out.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-100 p-6 md:p-8 rounded-xl md:rounded-2xl text-center">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-purple-600 rounded-xl md:rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6">
                <i className="ri-palette-line text-white text-xl md:text-2xl"></i>
              </div>
              <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-3 md:mb-4">
                Beautiful Templates
              </h3>
              <p className="text-sm md:text-base text-gray-600">
                Choose from dozens of professionally designed templates that are
                ATS-friendly and recruiter-approved.
              </p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-6 md:p-8 rounded-xl md:rounded-2xl text-center md:col-span-2 lg:col-span-1">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-green-600 rounded-xl md:rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6">
                <i className="ri-smartphone-line text-white text-xl md:text-2xl"></i>
              </div>
              <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-3 md:mb-4">
                Mobile-Friendly
              </h3>
              <p className="text-sm md:text-base text-gray-600">
                Build and edit your resume on any device. Our responsive design
                works perfectly on desktop, tablet, and mobile.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Resume Photos Showcase Section */}
      <section className="py-16 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
              Professional Resume Templates
            </h2>
            <p className="text-gray-600 mb-8">
              Choose from our collection of ATS-friendly, modern resume designs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Template 1 */}
            <div className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src="https://readdy.ai/api/search-image?query=modern%20professional%20resume%20template%20with%20clean%20typography%2C%20minimalist%20design%2C%20corporate%20layout%20with%20sections%20for%20experience%20education%20skills%2C%20white%20background%20with%20blue%20accents%2C%20high%20quality%20business%20document&width=400&height=533&seq=resume1&orientation=portrait"
                  alt="Modern Professional Resume Template"
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <h3 className="font-semibold text-gray-900">
                    Modern Professional
                  </h3>
                  <p className="text-sm text-gray-600">Clean &amp; ATS-friendly</p>
                </div>
              </div>
            </div>

            {/* Template 2 */}
            <div className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src="https://readdy.ai/api/search-image?query=creative%20resume%20template%20with%20elegant%20typography%2C%20sophisticated%20design%20with%20sidebar%20layout%2C%20professional%20business%20document%20with%20modern%20styling%2C%20clean%20white%20background%20with%20green%20accents%2C%20premium%20quality&width=400&height=533&seq=resume2&orientation=portrait"
                  alt="Creative Professional Resume Template"
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <h3 className="font-semibold text-gray-900">
                    Creative Professional
                  </h3>
                  <p className="text-sm text-gray-600">Elegant &amp; distinctive</p>
                </div>
              </div>
            </div>

            {/* Template 3 */}
            <div className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src="https://readdy.ai/api/search-image?query=executive%20resume%20template%20with%20premium%20design%2C%20luxury%20business%20document%20layout%2C%20sophisticated%20typography%20with%20gold%20accents%2C%20professional%20corporate%20style%2C%20high-end%20quality%20with%20clean%20white%20background&width=400&height=533&seq=resume3&orientation=portrait"
                  alt="Executive Resume Template"
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <h3 className="font-semibold text-gray-900">
                    Executive Premium
                  </h3>
                  <p className="text-sm text-gray-600">Luxury &amp; impactful</p>
                </div>
              </div>
            </div>

            {/* Template 4 */}
            <div className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src="https://readdy.ai/api/search-image?query=tech%20industry%20resume%20template%20with%20modern%20design%2C%20software%20engineer%20CV%20layout%2C%20contemporary%20typography%20with%20purple%20accents%2C%20clean%20professional%20document%2C%20technology%20sector%20styling%20with%20white%20background&width=400&height=533&seq=resume4&orientation=portrait"
                  alt="Tech Industry Resume Template"
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <h3 className="font-semibold text-gray-900">
                    Tech Specialist
                  </h3>
                  <p className="text-sm text-gray-600">Modern &amp; innovative</p>
                </div>
              </div>
            </div>

            {/* Template 5 */}
            <div className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src="https://readdy.ai/api/search-image?query=healthcare%20resume%20template%20with%20professional%20medical%20design%2C%20clean%20healthcare%20CV%20layout%2C%20trustworthy%20typography%20with%20teal%20accents%2C%20medical%20industry%20document%20styling%2C%20pristine%20white%20background&width=400&height=533&seq=resume5&orientation=portrait"
                  alt="Healthcare Resume Template"
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <h3 className="font-semibold text-gray-900">
                    Healthcare Pro
                  </h3>
                  <p className="text-sm text-gray-600">Trusted &amp; reliable</p>
                </div>
              </div>
            </div>

            {/* Template 6 */}
            <div className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src="https://readdy.ai/api/search-image?query=marketing%20resume%20template%20with%20creative%20design%2C%20advertising%20industry%20CV%20layout%2C%20dynamic%20typography%20with%20orange%20accents%2C%20marketing%20professional%20document%2C%20energetic%20styling%20with%20clean%20white%20background%20and%20modern%20sections&width=400&height=533&seq=resume6&orientation=portrait"
                  alt="Marketing Resume Template"
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <h3 className="font-semibold text-gray-900">
                    Marketing Creative
                  </h3>
                  <p className="text-sm text-gray-600">Dynamic &amp; engaging</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white hover:shadow-2xl transition-all duration-500 hover:scale-105">
              <h3 className="text-xl md:text-2xl font-bold mb-4">
                Choose Your Perfect Template
              </h3>
              <p className="text-blue-100 mb-6">
                All templates are ATS optimized and professionally designed to help
                you stand out
              </p>
              <Link
                href="/builder"
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-center whitespace-nowrap hover:scale-110 hover:shadow-lg"
              >
                Browse All Templates
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - Mobile Responsive */}
      <section className="py-12 md:py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-r from-green-500 to-blue-600 rounded-2xl p-8 text-white hover:shadow-2xl transition-all duration-500 hover:scale-105 animate-gradient-shift">
            <h3 className="text-xl md:text-2xl font-bold mb-4 animate-pulse">
              Join thousands of successful job seekers
            </h3>
            <p className="text-green-100 mb-6">
              Start building your professional resume today and land your dream
              job faster
            </p>
            <Link
              href="/builder"
              className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-300 whitespace-nowrap hover:scale-110 hover:shadow-lg"
            >
              Start Building Now
            </Link>
          </div>

          {/* Live Counter Script */}
          <script dangerouslySetInnerHTML={{
            __html: `
              // Wait for DOM to be fully loaded
              document.addEventListener('DOMContentLoaded', function() {
                let resumeCount = 1266;
                let activeUsers = 892;
                let downloads = 645;
                let templatesUsed = 105;
                let lastUpdateTime = Date.now();

                function updateCounters() {
                  // Check if elements exist before updating
                  const resumeCounter = document.getElementById('resume-counter');
                  const activeUsersEl = document.getElementById('active-users');
                  const downloadsEl = document.getElementById('downloads-today');
                  const templatesEl = document.getElementById('templates-used');
                  
                  if (resumeCounter) {
                    resumeCount += Math.floor(Math.random() * 3) + 1;
                    resumeCounter.textContent = resumeCount.toLocaleString();
                  }
                  
                  // Update other stats occasionally
                  if (Math.random() < 0.4 && activeUsersEl) {
                    activeUsers += Math.floor(Math.random() * 2);
                    activeUsersEl.textContent = activeUsers.toLocaleString();
                  }
                  
                  if (Math.random() < 0.3 && downloadsEl) {
                    downloads += Math.floor(Math.random() * 2) + 1;
                    downloadsEl.textContent = downloads.toLocaleString();
                  }
                  
                  if (Math.random() < 0.3 && templatesEl) {
                    templatesUsed += Math.floor(Math.random() * 2);
                    templatesEl.textContent = templatesUsed.toLocaleString();
                  }
                  
                  // Update timestamp
                  updateTimestamp();
                }

                function updateTimestamp() {
                  const updateElement = document.getElementById('last-update');
                  if (!updateElement) return;
                  
                  const now = Date.now();
                  const diff = Math.floor((now - lastUpdateTime) / 1000);
                  
                  if (diff < 60) {
                    updateElement.textContent = 'Last updated: just now';
                  } else if (diff < 3600) {
                    const minutes = Math.floor(diff / 60);
                    updateElement.textContent = \`Last updated: \${minutes} minute\${minutes > 1 ? 's' : ''} ago\`;
                  } else {
                    const hours = Math.floor(diff / 3600);
                    updateElement.textContent = \`Last updated: \${hours} hour\${hours > 1 ? 's' : ''} ago\`;
                  }
                }

                // Update counters every 15-45 seconds
                function scheduleNextUpdate() {
                  const delay = Math.floor(Math.random() * 30000) + 15000; // 15-45 seconds
                  setTimeout(() => {
                    updateCounters();
                    lastUpdateTime = Date.now();
                    scheduleNextUpdate();
                  }, delay);
                }

                // Start the counter updates after a short delay
                setTimeout(() => {
                  scheduleNextUpdate();
                }, 1000);

                // Update timestamp every 10 seconds
                setInterval(updateTimestamp, 10000);
              });
            `
          }} />

          {/* Live Counter Visuals */}
          <div className="mt-8 relative">
            <div className="bg-gradient-to-br from-blue-50 via-white to-purple-50 backdrop-blur-xl border border-white/20 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
              {/* Background decoration */}
              <div className="absolute inset-4 bg-gradient-to-r from-blue-600/3 via-purple-600/3 to-pink-600/3 rounded-xl"></div>
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full blur-xl"></div>
              <div className="absolute -bottom-10 -left-10 w-28 h-28 bg-gradient-to-br from-purple-400/10 to-pink-400/10 rounded-full blur-xl"></div>
              
              <div className="relative z-10">
                {/* Live indicator */}
                <div className="flex items-center justify-center space-x-3 mb-6">
                  <div className="relative">
                    <div className="w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse shadow-lg"></div>
                    <div className="absolute inset-0 w-4 h-4 bg-green-400 rounded-full animate-ping opacity-30"></div>
                  </div>
                  <span className="text-gray-700 font-semibold tracking-wide text-lg">LIVE ACTIVITY</span>
                  <div className="relative">
                    <div className="w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse shadow-lg"></div>
                    <div className="absolute inset-0 w-4 h-4 bg-green-400 rounded-full animate-ping opacity-30"></div>
                  </div>
                </div>

                {/* Main counter */}
                <div className="mb-6">
                  <div className="text-6xl md:text-7xl font-black bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2 tracking-tight">
                    <span id="resume-counter" className="tabular-nums">1,266</span>
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-gray-800 mb-2">resumes created today</div>
                  <div className="h-1 w-32 mx-auto bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full"></div>
                </div>

                {/* Stats grid */}
                <div className="grid grid-cols-3 gap-6 mb-8">
                  <div className="text-center">
                    <div className="text-2xl md:text-3xl font-bold text-blue-600 mb-1">
                      <span id="active-users">892</span>
                    </div>
                    <div className="text-sm text-gray-600 font-medium">Active Users</div>
                  </div>
                  <div className="text-center border-x border-gray-200">
                    <div className="text-2xl md:text-3xl font-bold text-purple-600 mb-1">
                      <span id="downloads-today">645</span>
                    </div>
                    <div className="text-sm text-gray-600 font-medium">Downloads</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl md:text-3xl font-bold text-pink-600 mb-1">
                      <span id="templates-used">105</span>
                    </div>
                    <div className="text-sm text-gray-600 font-medium">Templates</div>
                  </div>
                </div>

                {/* Last update */}
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <div className="flex items-center justify-center w-5 h-5">
                    <i className="ri-refresh-line text-lg"></i>
                  </div>
                  <span id="last-update">Last updated: just now</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 animate-fade-in">
              Success Stories from Our Users
            </h2>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto animate-fade-in animate-delay-200">
              Join thousands of professionals who've transformed their careers with ResumeTeacher
            </p>
          </div>
            
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-300 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "The AI suggestions were incredibly helpful. I landed my dream job within 2 weeks of using ResumeTeacher! The templates are modern and professional."
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Sarah Johnson
                  </p>
                  <p className="text-gray-600 text-sm">Marketing Manager</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:gray-700 transition-colors duration-300">2 days ago</span>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-400 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "Amazing ATS checker saved me! My resume was getting rejected until I used ResumeTeacher. Now I'm getting interviews every week. Best investment ever!"
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Michael Chen
                  </p>
                  <p className="text-gray-600 text-sm">Software Engineer</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">5 days ago</span>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-500 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "Career transition made easy! From finance to tech in 6 months. The industry-specific templates and guidance were exactly what I needed."
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Emily Rodriguez
                  </p>
                  <p className="text-gray-600 text-sm">Product Manager</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">1 week ago</span>
              </div>
            </div>

            {/* Testimonial 4 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-600 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "The cover letter builder is phenomenal! Got 3 job offers in one month. The AI suggestions helped me express my skills perfectly. Highly recommend!"
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    David Thompson
                  </p>
                  <p className="text-gray-600 text-sm">Data Analyst</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">3 days ago</span>
              </div>
            </div>

            {/* Testimonial 5 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-700 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-30"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "Executive-level templates are outstanding! Helped me secure a VP position with 40% salary increase. The strategic formatting made all the difference."
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Jessica Martinez
                  </p>
                  <p className="text-gray-600 text-sm">VP of Operations</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">1 week ago</span>
              </div>
            </div>

            {/* Testimonial 6 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-800 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "Recent graduate here - the entry-level guidance was perfect! Landed my first job at Google thanks to the tech-specific resume format. Thank you ResumeTeacher!"
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Alex Kim
                  </p>
                  <p className="text-gray-600 text-sm">Junior Developer</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">4 days ago</span>
              </div>
            </div>

            {/* Testimonial 7 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-900 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-30"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "International job search made simple! The global format templates helped me get offers from 3 different countries. Professional quality is unmatched."
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Priya Sharma
                  </p>
                  <p className="text-gray-600 text-sm">Business Consultant</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:group-hover:text-gray-700 transition-colors duration-300">6 days ago</span>
              </div>
            </div>

            {/* Testimonial 8 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-1000 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "Healthcare professionals need this! The medical resume templates perfectly showcase clinical experience. Got my dream hospital position within 3 weeks."
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Dr. Robert Wilson
                  </p>
                  <p className="text-gray-600 text-sm">Emergency Physician</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">2 weeks ago</span>
              </div>
            </div>

            {/* Testimonial 9 */}
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 animate-smooth-slide-in animate-delay-1100 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex text-yellow-400 group-hover:animate-pulse">
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                  <i className="ri-star-fill hover:animate-spin transition-transform duration-300"></i>
                </div>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium group-hover:bg-green-200 transition-colors duration-300">✓ Verified</span>
              </div>
              <p className="text-gray-700 mb-4 italic leading-relaxed group-hover:text-gray-900 transition-colors duration-300">
                "Small business owner to corporate executive! The career pivot templates and interview prep got me a C-suite position. ROI was incredible - 10x value!"
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                    Lisa Anderson
                  </p>
                  <p className="text-gray-600 text-sm">Chief Marketing Officer</p>
                </div>
                <span className="text-gray-500 text-sm group-hover:text-gray-700 transition-colors duration-300">1 day ago</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer - Mobile Responsive */}
      <footer className="bg-gray-900 text-white py-12 md:py-16 relative overflow-hidden">
        {/* Enhanced Magic Wand Sticker in Footer */}
        <div className="absolute top-8 right-8 md:top-12 md:right-16 z-20">
          <div className="relative group cursor-pointer">
            {/* Main Magic Wand */}
            <img
              src="https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/c60b31656d7a61f006c5aa48c9e8a889.png"
              alt="AI Magic Wand"
              className="w-20 h-20 md:w-28 md:h-28 lg:w-32 lg:h-32 opacity-90 hover:opacity-100 group-hover:scale-125 transition-all duration-500 animate-magical-float"
              style={{
                filter: 'drop-shadow(0 8px 16px rgba(139, 92, 246, 0.4)) drop-shadow(0 4px 8px rgba(59, 130, 246, 0.3))'
              }}
            />
            
            {/* Enhanced Sparkle Effects */}
            <div className="absolute -top-3 -left-3 w-4 h-4 bg-gradient-to-r from-yellow-300 to-amber-400 rounded-full animate-sparkle-rotate opacity-80 group-hover:opacity-100"></div>
            <div className="absolute -bottom-2 -right-2 w-3 h-3 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full animate-twinkle opacity-70 group-hover:opacity-100"></div>
            <div className="absolute top-1/2 -left-4 w-2 h-2 bg-gradient-to-r from-blue-400 to-cyan-4 ounded-full animate-bounce opacity-60 group-hover:opacity-100"></div>
            <div className="absolute -top-2 right-2 w-2.5 h-2.5 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full animate-pulse opacity-65 group-hover:opacity-100"></div>
            <div className="absolute bottom-4 -left-2 w-1.5 h-1.5 bg-gradient-to-r from-rose-400 to-red-400 rounded-full animate-ping opacity-50 group-hover:opacity-100"></div>
            
            {/* Magical Glow Ring */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-500/20 via-blue-500/20 to-pink-500/20 animate-spin opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            
            {/* Tooltip */}
            <div className="absolute bottom-full mb-4 left-1/2 -translate-x-1/2 bg-gray-800/90 backdrop-blur-sm text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 whitespace-nowrap pointer-events-none">
              ✨ Made with AI Magic ✨
              <div className="absolute left-full top-1/2 -translate-y-1/2 border-4 border-transparent border-l-gray-900/90"></div>
            </div>
          </div>
        </div>

        {/* Magical particles background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-1 h-1 bg-purple-400 rounded-full animate-twinkle opacity-40"></div>
          <div className="absolute top-32 right-24 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse opacity-30"></div>
          <div className="absolute bottom-40 left-20 w-1 h-1 bg-pink-400 rounded-full animate-bounce opacity-35"></div>
          <div className="absolute bottom-20 right-32 w-1 h-1 bg-yellow-400 rounded-full animate-ping opacity-25"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            <div className="sm:col-span-2 lg:col-span-1">
              <img
                src="https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/7c7a026c903443183a4060f537c81563.png"
                alt="ResumeTeacher Logo"
                className="h-8 md:h-10 w-auto object-contain hover:scale-110 transition-transform duration-300 mb-4 mix-blend-screen bg-transparent"
                onError={e => {
                  console.error("Logo failed to load:", e);
                }}
              />
              <p className="text-gray-400 mb-4 text-sm md:text-base">
                Build professional resumes with AI assistance and land your dream
                job faster.
              </p>
              <div className="flex space-x-4">
                <a
                  href="https://www.facebook.com/share/17AoP7R2VB/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <i className="ri-facebook-line text-lg md:text-xl"></i>
                </a>
                <a
                  href="https://x.com/Resumeteacher1?t=5IhMQBx2gPe1aXmh3DR6eQ&s=09"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <i className="ri-twitter-x-line text-lg md:text-xl"></i>
                </a>
                <a
                  href="https://www.instagram.com/resumeteacher1?igsh=a2VnbTl6eHZ6ZWxi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <i className="ri-instagram-line text-lg md:text-xl"></i>
                </a>
                <a
                  href="https://www.tiktok.com/@resumeteacher?_t=ZM-8zXEg5dBYa0&_r=1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <i className="ri-tiktok-line text-lg md:text-xl"></i>
                </a>
              </div>
            </div>

            <div>
              <h3 className="text-base md:text-lg font-semibold mb-4">Resume Builder</h3>
              <ul className="space-y-2 text-sm md:text-base">
                <li>
                  <Link href="/templates" className="text-gray-400 hover:text-white transition-colors">
                    Resume Templates
                  </Link>
                </li>
                <li>
                  <Link href="/examples" className="text-gray-400 hover:text-white transition-colors">
                    Resume Examples
                  </Link>
                </li>
                <li>
                  <Link href="/formats" className="text-gray-400 hover:text-white transition-colors">
                    Resume Formats
                  </Link>
                </li>
                <li>
                  <Link href="/builder" className="text-gray-400 hover:text-white transition-colors">
                    Create Resume
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-base md:text-lg font-semibold mb-4">Career Resources</h3>
              <ul className="space-y-2 text-sm md:text-base">
                <li>
                  <Link href="/career-advice" className="text-gray-400 hover:text-white transition-colors">
                    Career Advice
                  </Link>
                </li>
                <li>
                  <Link href="/interview-tips" className="text-gray-400 hover:text-white transition-colors">
                    Interview Tips
                  </Link>
                </li>
                <li>
                  <Link href="/job-search-tips" className="text-gray-400 hover:text-white transition-colors">
                    Job Search Tips
                  </Link>
                </li>
                <li>
                  <Link href="/affiliates" className="text-gray-400 hover:text-white transition-colors">
                    Affiliate Program
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="text-gray-400 hover:text-white transition-colors">
                    Blog
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-base md:text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-sm md:text-base">
                <li>
                  <Link href="/help-center" className="text-gray-400 hover:text-white transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-400 hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-gray-400 hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="text-gray-400 hover:text-white transition-colors">
                    Pricing
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 md:mt-12 pt-6 md:pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <p className="text-gray-400 text-sm md:text-base text-center md:text-left">
                © 2025 ResumeTeacher. All rights reserved. Build your career with
                confidence.
              </p>
              <div className="flex items-center space-x-4">
                <Link 
                  href="https://readdy.ai/?origin=logo" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors text-sm group"
                >
                  <span className="group-hover:scale-110 transition-transform duration-300">✨</span>
                  <span>Made with Readdy</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
