'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function CVExamplesPage() {
  const [selectedField, setSelectedField] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const fields = [
    { id: 'all', name: 'All Fields' },
    { id: 'academic', name: 'Academic' },
    { id: 'medical', name: 'Medical' },
    { id: 'research', name: 'Research' },
    { id: 'legal', name: 'Legal' },
    { id: 'engineering', name: 'Engineering' }
  ];

  const levels = [
    { id: 'all', name: 'All Levels' },
    { id: 'early', name: 'Early Career' },
    { id: 'mid', name: 'Mid Career' },
    { id: 'senior', name: 'Senior Level' },
    { id: 'executive', name: 'Executive' }
  ];

  const examples = [
    {
      id: 1,
      name: 'Dr. Sarah Chen',
      position: 'Professor of Biomedical Engineering',
      institution: 'Stanford University',
      field: 'academic',
      level: 'senior',
      experience: '15 years',
      publications: 47,
      citations: '2,840',
      hIndex: 24,
      image: 'Professional headshot of Dr. Sarah Chen, confident Asian woman professor in biomedical engineering, modern university laboratory background with research equipment, academic professional portrait',
      highlights: [
        'NIH R01 Grant Recipient ($2.3M)',
        'Nature Biomedical Engineering Publications',
        'IEEE Fellow Recognition',
        'Keynote Speaker at 12+ International Conferences'
      ],
      achievements: [
        'Led breakthrough research in neural interfaces',
        'Mentored 25+ PhD students to completion',
        'Founded university spin-off company',
        'Editorial board member of 3 top-tier journals'
      ],
      education: 'PhD Biomedical Engineering, MIT',
      currentRole: 'Department Chair & Endowed Professor'
    },
    {
      id: 2,
      name: 'Prof. Michael Rodriguez',
      position: 'Associate Professor of Computer Science',
      institution: 'MIT',
      field: 'academic',
      level: 'mid',
      experience: '12 years',
      publications: 32,
      citations: '1,956',
      hIndex: 18,
      image: 'Professional headshot of Prof. Michael Rodriguez, confident Hispanic man computer science professor, modern tech laboratory with computers and equipment, academic technology environment',
      highlights: [
        'ACM Distinguished Scientist Award',
        'Best Paper Awards at Top Conferences',
        'Industry Partnerships with Google & Microsoft',
        'Open Source Contributions (50K+ GitHub stars)'
      ],
      achievements: [
        'Developed machine learning algorithms used by millions',
        'Published in ICML, NeurIPS, and ICLR',
        'Co-founded AI research lab',
        'Supervised 15+ successful PhD graduates'
      ],
      education: 'PhD Computer Science, Carnegie Mellon',
      currentRole: 'Associate Professor & Lab Director'
    },
    {
      id: 3,
      name: 'Dr. Emily Watson',
      position: 'Chief of Cardiology',
      institution: 'Johns Hopkins Hospital',
      field: 'medical',
      level: 'executive',
      experience: '18 years',
      procedures: '2,500+',
      publications: 89,
      certifications: 8,
      image: 'Professional headshot of Dr. Emily Watson, confident white woman cardiologist chief, modern hospital setting with medical equipment, healthcare leadership professional portrait',
      highlights: [
        'Board Certified in Cardiology & Interventional Cardiology',
        'Pioneer in Minimally Invasive Cardiac Procedures',
        'American Heart Association Fellow',
        'Medical Innovation Award Recipient'
      ],
      achievements: [
        'Reduced cardiac surgery mortality by 35%',
        'Established heart transplant program',
        'Published 89 peer-reviewed articles',
        'Trained 40+ cardiology fellows'
      ],
      education: 'MD Harvard Medical School, Residency Mayo Clinic',
      currentRole: 'Department Chief & Clinical Professor'
    },
    {
      id: 4,
      name: 'Dr. James Foster',
      position: 'Senior Research Scientist',
      institution: 'Google DeepMind',
      field: 'research',
      level: 'senior',
      experience: '11 years',
      publications: 28,
      citations: '3,125',
      patents: 12,
      image: 'Professional headshot of Dr. James Foster, confident white man research scientist, modern AI research laboratory with advanced computing equipment, technology innovation environment',
      highlights: [
        'Lead Scientist on AlphaFold Project',
        '12 Filed Patents in AI/ML',
        'Nature & Science Co-author',
        'Royal Society Research Fellow'
      ],
      achievements: [
        'Breakthrough contributions to protein folding',
        'Developed novel deep learning architectures',
        'Collaborated with Nobel Prize winners',
        'Technology transferred to 5+ pharmaceutical companies'
      ],
      education: 'PhD Machine Learning, Oxford University',
      currentRole: 'Principal Research Scientist'
    },
    {
      id: 5,
      name: 'Professor Lisa Wang',
      position: 'Professor of Law',
      institution: 'Harvard Law School',
      field: 'legal',
      level: 'senior',
      experience: '16 years',
      cases: '150+',
      publications: 45,
      clerkship: 'Supreme Court',
      image: 'Professional headshot of Professor Lisa Wang, confident Asian woman law professor, prestigious law school library background with legal books, academic legal professional portrait',
      highlights: [
        'Former Supreme Court Clerk',
        'Constitutional Law Expert',
        'Argued 15+ Cases Before Federal Courts',
        'Legal Scholar of the Year Award'
      ],
      achievements: [
        'Published definitive constitutional law textbook',
        'Advised on landmark civil rights cases',
        'Testified before Congressional committees',
        'Founded law school human rights clinic'
      ],
      education: 'JD Harvard Law School, BA Yale University',
      currentRole: 'Endowed Chair Professor & Clinic Director'
    },
    {
      id: 6,
      name: 'Dr. Robert Martinez',
      position: 'Senior Staff Engineer',
      institution: 'Tesla',
      field: 'engineering',
      level: 'senior',
      experience: '14 years',
      patents: 18,
      publications: 15,
      projects: '25+',
      image: 'Professional headshot of Dr. Robert Martinez, confident Hispanic man senior engineer, modern automotive engineering facility with Tesla vehicles and technology, engineering innovation environment',
      highlights: [
        '18 Patents in Electric Vehicle Technology',
        'Led Model S Battery System Design',
        'IEEE Senior Member',
        'Automotive Innovation Award Winner'
      ],
      achievements: [
        'Designed battery systems for 500K+ vehicles',
        'Reduced charging time by 40%',
        'Led cross-functional team of 50+ engineers',
        'Published in top automotive engineering journals'
      ],
      education: 'PhD Electrical Engineering, UC Berkeley',
      currentRole: 'Senior Staff Engineer & Technical Lead'
    },
    {
      id: 7,
      name: 'Dr. Amanda Foster',
      position: 'Postdoctoral Research Fellow',
      institution: 'NIH',
      field: 'research',
      level: 'early',
      experience: '3 years',
      publications: 12,
      citations: '185',
      grants: 2,
      image: 'Professional headshot of Dr. Amanda Foster, confident young white woman postdoc researcher, modern biomedical research laboratory with scientific equipment, early career researcher portrait',
      highlights: [
        'NIH F32 Fellowship Recipient',
        'First Author in Cell & Nature Communications',
        'Young Investigator Award',
        'International Conference Best Poster'
      ],
      achievements: [
        'Discovered novel cancer metabolism pathway',
        'Collaborated with 3 international research groups',
        'Mentored 5 undergraduate researchers',
        'Presented at 8 international conferences'
      ],
      education: 'PhD Molecular Biology, UCSF',
      currentRole: 'Postdoctoral Research Fellow'
    },
    {
      id: 8,
      name: 'Dr. Thomas Kim',
      position: 'Assistant Professor',
      institution: 'University of Chicago',
      field: 'academic',
      level: 'early',
      experience: '5 years',
      publications: 18,
      citations: '425',
      courses: 4,
      image: 'Professional headshot of Dr. Thomas Kim, confident young Asian man assistant professor, modern university office with books and research materials, early career academic portrait',
      highlights: [
        'NSF CAREER Award Finalist',
        'Rising Star Faculty Award',
        'Outstanding Teaching Recognition',
        'Sloan Research Fellowship Nominee'
      ],
      achievements: [
        'Established independent research program',
        'Secured $850K in research funding',
        'Published in top economics journals',
        'Developed innovative course curricula'
      ],
      education: 'PhD Economics, Princeton University',
      currentRole: 'Assistant Professor of Economics'
    }
  ];

  const filteredExamples = examples.filter(example => {
    const matchesField = selectedField === 'all' || example.field === selectedField;
    const matchesLevel = selectedLevel === 'all' || example.level === selectedLevel;
    return matchesField && matchesLevel;
  });

  const successMetrics = [
    {
      title: 'Average Citations',
      value: '1,847',
      icon: 'ri-line-chart-line',
      color: 'blue'
    },
    {
      title: 'Publications Range',
      value: '12-89',
      icon: 'ri-article-line',
      color: 'green'
    },
    {
      title: 'Years Experience',
      value: '3-18',
      icon: 'ri-time-line',
      color: 'purple'
    },
    {
      title: 'Success Rate',
      value: '95%+',
      icon: 'ri-trophy-line',
      color: 'orange'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-list-3-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap">
                CV Builder
              </Link>
              <Link href="/cv" className="text-gray-700 hover:text-teal-600 transition-colors whitespace-nowrap">
                CV Guide
              </Link>
              <Link href="/cv-templates" className="text-gray-700 hover:text-teal-600 transition-colors whitespace-nowrap">
                CV Templates
              </Link>
              <Link href="/how-to-write-cv" className="text-gray-700 hover:text-teal-600 transition-colors whitespace-nowrap">
                Writing Guide
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-teal-600 transition-colors border border-gray-300 rounded-lg hover:border-teal-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-teal-600 to-cyan-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Real CV Examples from Successful Professionals
            </h1>
            <p className="text-xl text-teal-100 mb-8 max-w-3xl mx-auto">
              Learn from the CVs of accomplished academics, medical professionals, researchers, and industry leaders. 
              See what made them successful and apply these insights to your own CV.
            </p>
            <div className="flex items-center justify-center space-x-8 text-teal-100">
              <div className="flex items-center">
                <i className="ri-user-star-line mr-2"></i>
                <span>Real Professionals</span>
              </div>
              <div className="flex items-center">
                <i className="ri-award-line mr-2"></i>
                <span>Proven Success</span>
              </div>
              <div className="flex items-center">
                <i className="ri-global-line mr-2"></i>
                <span>Top Institutions</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Success Metrics */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-6">
            {successMetrics.map((metric, index) => (
              <div key={index} className="text-center">
                <div className={`w-16 h-16 bg-${metric.color}-100 rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                  <i className={`${metric.icon} text-${metric.color}-600 text-2xl`}></i>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{metric.value}</div>
                <div className="text-gray-600">{metric.title}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-gray-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Field</label>
              <select
                value={selectedField}
                onChange={(e) => setSelectedField(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 pr-8"
              >
                {fields.map((field) => (
                  <option key={field.id} value={field.id}>
                    {field.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Career Level</label>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 pr-8"
              >
                {levels.map((level) => (
                  <option key={level.id} value={level.id}>
                    {level.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setSelectedField('all');
                  setSelectedLevel('all');
                }}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Examples Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-gray-900">
              Professional CV Examples
            </h2>
            <div className="text-gray-600">
              {filteredExamples.length} example{filteredExamples.length !== 1 ? 's' : ''}
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {filteredExamples.map((example, index) => (
              <div
                key={example.id}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-1 ${
                  isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="p-8">
                  {/* Profile Header */}
                  <div className="flex items-start space-x-6 mb-6">
                    <div className="relative">
                      <img
                        src={`https://readdy.ai/api/search-image?query=$%7Bexample.image%7D&width=120&height=120&seq=cv-example-${example.id}&orientation=squarish`}
                        alt={example.name}
                        className="w-24 h-24 rounded-full object-cover border-4 border-teal-100"
                      />
                      <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
                        <i className="ri-verified-badge-line text-white text-sm"></i>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900 mb-1">{example.name}</h3>
                      <p className="text-lg text-teal-600 font-semibold mb-2">{example.position}</p>
                      <div className="flex items-center text-gray-600 mb-3">
                        <i className="ri-building-line mr-2"></i>
                        <span className="font-medium">{example.institution}</span>
                      </div>
                      <div className="text-gray-600 mb-2">{example.currentRole}</div>
                      <div className="text-sm text-gray-500">{example.education}</div>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-xl">
                    <div className="text-center">
                      <div className="text-xl font-bold text-gray-900">{example.experience}</div>
                      <div className="text-xs text-gray-500">Experience</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-gray-900">{example.publications || example.procedures || example.patents || example.cases || example.projects || example.courses}</div>
                      <div className="text-xs text-gray-500">{example.publications ? 'Publications' : example.procedures ? 'Procedures' : example.patents ? 'Patents' : example.cases ? 'Cases' : example.projects ? 'Projects' : 'Courses'}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-gray-900">{example.citations || example.certifications || example.hIndex || example.clerkship || example.grants}</div>
                      <div className="text-xs text-gray-500">{example.citations ? 'Citations' : example.certifications ? 'Certifications' : example.hIndex ? 'H-Index' : example.clerkship ? 'Clerkship' : 'Grants'}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-teal-600">{example.level === 'early' ? 'Rising' : example.level === 'mid' ? 'Established' : example.level === 'senior' ? 'Senior' : 'Executive'}</div>
                      <div className="text-xs text-gray-500">Level</div>
                    </div>
                  </div>

                  {/* Key Highlights */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <i className="ri-star-line text-teal-600 mr-2"></i>
                      Key Highlights
                    </h4>
                    <div className="space-y-2">
                      {example.highlights.map((highlight, idx) => (
                        <div key={idx} className="flex items-start">
                          <i className="ri-arrow-right-s-line text-teal-600 mr-2 mt-0.5 flex-shrink-0"></i>
                          <span className="text-gray-700 text-sm">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Major Achievements */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <i className="ri-trophy-line text-teal-600 mr-2"></i>
                      Major Achievements
                    </h4>
                    <div className="space-y-2">
                      {example.achievements.map((achievement, idx) => (
                        <div key={idx} className="flex items-start">
                          <i className="ri-check-line text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                          <span className="text-gray-700 text-sm">{achievement}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-3">
                    <Link
                      href={`/builder?example=${example.id}&type=cv`}
                      className="flex-1 bg-gradient-to-r from-teal-600 to-cyan-600 text-white py-3 rounded-lg hover:from-teal-700 hover:to-cyan-700 transition-colors text-center font-semibold whitespace-nowrap"
                    >
                      Use This Style
                    </Link>
                    <button className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium whitespace-nowrap">
                      View Full CV
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredExamples.length === 0 && (
            <div className="text-center py-20">
              <i className="ri-user-line text-6xl text-gray-400 mb-4"></i>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No examples found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your filter criteria</p>
              <button
                onClick={() => {
                  setSelectedField('all');
                  setSelectedLevel('all');
                }}
                className="bg-teal-600 text-white px-6 py-3 rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap"
              >
                Show All Examples
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Success Factors */}
      <section className="py-16 bg-teal-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">What Makes These CVs Successful?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Common patterns and strategies used by successful professionals across different fields
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-target-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Quantified Impact</h3>
              <p className="text-gray-600 mb-4">
                Every achievement includes specific numbers, metrics, and measurable outcomes that demonstrate real-world impact.
              </p>
              <div className="text-sm text-gray-500">
                Examples: Publications count, citation metrics, grant amounts, team sizes
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-award-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Recognition & Awards</h3>
              <p className="text-gray-600 mb-4">
                Consistent recognition from peers, institutions, and professional organizations validates expertise and contributions.
              </p>
              <div className="text-sm text-gray-500">
                Examples: Fellowships, grants, awards, editorial positions, keynote invitations
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-team-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Leadership & Mentorship</h3>
              <p className="text-gray-600 mb-4">
                Evidence of leading teams, mentoring others, and contributing to the broader professional community.
              </p>
              <div className="text-sm text-gray-500">
                Examples: PhD supervision, team leadership, committee service, community involvement
              </div>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-lightbulb-line text-orange-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Innovation & Impact</h3>
              <p className="text-gray-600 mb-4">
                Clear demonstration of novel contributions, breakthrough discoveries, or innovative solutions to important problems.
              </p>
              <div className="text-sm text-gray-500">
                Examples: Patents, breakthrough research, novel methodologies, technology transfer
              </div>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-global-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">International Reach</h3>
              <p className="text-gray-600 mb-4">
                Global collaborations, international recognition, and contributions that transcend geographic boundaries.
              </p>
              <div className="text-sm text-gray-500">
                Examples: International collaborations, global conferences, cross-border projects
              </div>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="w-14 h-14 bg-indigo-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-graduation-cap-line text-indigo-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Continuous Learning</h3>
              <p className="text-gray-600 mb-4">
                Ongoing professional development, additional certifications, and adaptation to evolving field requirements.
              </p>
              <div className="text-sm text-gray-500">
                Examples: Additional certifications, continued education, skill development, cross-training
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-teal-600 to-cyan-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Create Your Success Story?</h2>
          <p className="text-xl text-teal-100 mb-8 max-w-2xl mx-auto">
            Use these examples as inspiration to craft your own compelling CV that showcases your unique achievements and expertise
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/builder?type=cv"
              className="inline-block bg-white text-teal-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap"
            >
              Start Building My CV
            </Link>
            <Link
              href="/cv-templates"
              className="inline-block bg-teal-500 text-white px-8 py-4 rounded-lg hover:bg-teal-400 transition-colors text-lg font-semibold whitespace-nowrap"
            >
              Browse CV Templates
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}