'use client';

import { useState } from 'react';
import Header from '../../components/Header';

export default function HelpCenterPage() {
  const [activeCategory, setActiveCategory] = useState('Getting Started');
  const [openArticles, setOpenArticles] = useState<string[]>([]);

  const categories = [
    { name: 'Getting Started', icon: 'ri-play-circle-line' },
    { name: 'Resume Builder', icon: 'ri-file-text-line' },
    { name: 'Templates', icon: 'ri-layout-line' },
    { name: 'Account & Billing', icon: 'ri-user-line' },
    { name: 'Troubleshooting', icon: 'ri-tools-line' },
    { name: 'Tips & Best Practices', icon: 'ri-lightbulb-line' }
  ];

  const articles = {
    'Getting Started': [
      { title: 'How to create your first resume', content: 'Step-by-step guide to building your resume...' },
      { title: 'Choosing the right template', content: 'Tips for selecting the perfect template...' },
      { title: 'Understanding ATS optimization', content: 'Learn how to make your resume ATS-friendly...' }
    ],
    'Resume Builder': [
      { title: 'Adding work experience', content: 'How to effectively showcase your work history...' },
      { title: 'Writing compelling summaries', content: 'Craft summaries that grab attention...' },
      { title: 'Skills section best practices', content: 'Optimize your skills for maximum impact...' }
    ],
    'Templates': [
      { title: 'Template customization options', content: 'Learn how to personalize your chosen template...' },
      { title: 'Industry-specific templates', content: 'Find templates tailored to your industry...' },
      { title: 'Color and font adjustments', content: 'Customize the visual appearance...' }
    ],
    'Account & Billing': [
      { title: 'Managing your subscription', content: 'How to upgrade, downgrade, or cancel...' },
      { title: 'Payment methods', content: 'Accepted payment options and billing cycles...' },
      { title: 'Account settings', content: 'Update your profile and preferences...' }
    ],
    'Troubleshooting': [
      { title: 'Download issues', content: 'Solutions for resume download problems...' },
      { title: 'Browser compatibility', content: 'Supported browsers and requirements...' },
      { title: 'Performance optimization', content: 'Tips for better app performance...' }
    ],
    'Tips & Best Practices': [
      { title: 'Resume writing tips', content: 'Professional advice for better resumes...' },
      { title: 'Interview preparation', content: 'Get ready for your next interview...' },
      { title: 'Job search strategies', content: 'Effective approaches to finding jobs...' }
    ]
  };

  const toggleArticle = (title: string) => {
    setOpenArticles(prev => 
      prev.includes(title) 
        ? prev.filter(t => t !== title)
        : [...prev, title]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="pt-20">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Help Center</h1>
            <p className="text-xl text-gray-600">Find answers to common questions and get support</p>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-1/4">
              <div className="bg-gray-100 rounded-lg p-2 mb-6">
                <div className="flex flex-wrap lg:flex-col gap-1">
                  {categories.map((category) => (
                    <button
                      key={category.name}
                      onClick={() => setActiveCategory(category.name)}
                      className={`flex items-center px-4 py-3 rounded-lg text-left transition-all whitespace-nowrap ${
                        activeCategory === category.name
                          ? 'bg-white text-blue-600 shadow-sm'
                          : 'text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <i className={`${category.icon} mr-2`}></i>
                      <span className="font-medium">{category.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Need More Help?</h3>
                <div className="space-y-3">
                  <a 
                    href="/contact" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-mail-line mr-2"></i>
                    <span className="group-hover:underline">Contact Support</span>
                  </a>
                  <a 
                    href="#" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-chat-3-line mr-2"></i>
                    <span className="group-hover:underline">Live Chat</span>
                  </a>
                  <a 
                    href="/faq" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-question-line mr-2"></i>
                    <span className="group-hover:underline">View FAQ</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="lg:w-3/4">
              <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">{activeCategory}</h2>
                  <div className="flex items-center bg-gray-100 rounded-lg px-4 py-2">
                    <i className="ri-search-line text-gray-500 mr-2"></i>
                    <input
                      type="text"
                      placeholder="Search articles..."
                      className="bg-transparent border-none outline-none text-gray-700 placeholder-gray-500"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  {articles[activeCategory as keyof typeof articles]?.map((article, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg">
                      <button
                        onClick={() => toggleArticle(article.title)}
                        className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition-colors"
                      >
                        <span className="font-medium text-gray-900">{article.title}</span>
                        <i className={`ri-arrow-${openArticles.includes(article.title) ? 'up' : 'down'}-s-line text-gray-500`}></i>
                      </button>
                      {openArticles.includes(article.title) && (
                        <div className="px-4 pb-4 border-t border-gray-200">
                          <p className="text-gray-600 mt-4">{article.content}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border mt-6 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Articles</h3>
                <div className="space-y-3">
                  <a 
                    href="/guides/professional-resume-10-minutes" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-star-line mr-2"></i>
                    <span className="group-hover:underline">How to create a professional resume in 10 minutes</span>
                  </a>
                  <a 
                    href="/guides/best-resume-templates-2025" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-star-line mr-2"></i>
                    <span className="group-hover:underline">Best resume templates for 2025</span>
                  </a>
                  <a 
                    href="/guides/ats-resume-formatting" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-star-line mr-2"></i>
                    <span className="group-hover:underline">ATS-friendly resume formatting tips</span>
                  </a>
                  <a 
                    href="/guides/cover-letter-best-practices" 
                    className="flex items-center text-blue-600 hover:text-blue-700 group"
                  >
                    <i className="ri-star-line mr-2"></i>
                    <span className="group-hover:underline">Cover letter writing best practices</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}