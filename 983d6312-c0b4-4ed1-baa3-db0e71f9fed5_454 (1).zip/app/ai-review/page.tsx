'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function AIReviewPage() {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [reviewResults, setReviewResults] = useState<any>(null);
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      setFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const analyzeResume = () => {
    if (!file) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      setReviewResults({
        overallScore: 78,
        sections: {
          formatting: { score: 85, feedback: 'Good formatting with clear sections and professional layout' },
          content: { score: 72, feedback: 'Content is solid but could be more specific with achievements' },
          keywords: { score: 68, feedback: 'Missing some key industry terms and skills' },
          length: { score: 90, feedback: 'Appropriate length for your experience level' },
          contact: { score: 95, feedback: 'Complete contact information provided' }
        },
        strengths: [
          'Clear professional summary that highlights key qualifications',
          'Well-organized work experience with proper chronological order',
          'Good use of action verbs throughout job descriptions',
          'Consistent formatting and professional appearance'
        ],
        improvements: [
          'Add more quantifiable achievements and metrics to demonstrate impact',
          'Include more industry-specific keywords to improve ATS compatibility',
          'Expand skills section with both technical and soft skills',
          'Consider adding relevant certifications or professional development'
        ],
        suggestions: [
          'Replace generic phrases with specific accomplishments',
          'Use bullet points consistently throughout all sections',
          'Ensure all dates and formatting are consistent',
          'Proofread for any grammatical errors or typos'
        ]
      });
      setIsAnalyzing(false);
    }, 3000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-green-600';
    if (score >= 60) return 'bg-yellow-600';
    return 'bg-red-600';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>
            <Link href="/builder" className="px-6 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap">
              Build Resume
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-teal-600 to-cyan-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              AI Resume Review
            </h1>
            <p className="text-xl text-teal-100 mb-8 max-w-3xl mx-auto">
              Get instant expert feedback on your resume with our AI-powered analysis. 
              Receive actionable insights to improve your resume and increase your chances of getting hired.
            </p>
            <div className="flex items-center justify-center space-x-8 text-teal-100">
              <div className="flex items-center">
                <i className="ri-search-eye-line mr-2"></i>
                <span>Detailed Analysis</span>
              </div>
              <div className="flex items-center">
                <i className="ri-lightbulb-line mr-2"></i>
                <span>Actionable Tips</span>
              </div>
              <div className="flex items-center">
                <i className="ri-time-line mr-2"></i>
                <span>Instant Results</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Upload Section */}
      {!reviewResults && (
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className={`transition-all duration-1000 delay-300 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="text-center mb-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="ri-upload-2-line text-white text-3xl"></i>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Upload Your Resume</h2>
                  <p className="text-gray-600">Upload your resume to get detailed AI-powered feedback and improvement suggestions</p>
                </div>

                <div
                  className={`border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
                    isDragging 
                      ? 'border-teal-500 bg-teal-50' 
                      : file 
                        ? 'border-green-500 bg-green-50' 
                        : 'border-gray-300 hover:border-teal-400 hover:bg-teal-50'
                  }`}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  {file ? (
                    <div>
                      <i className="ri-file-text-line text-6xl text-green-600 mb-4"></i>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{file.name}</h3>
                      <p className="text-gray-600 mb-4">File ready for analysis</p>
                      <button
                        onClick={() => setFile(null)}
                        className="text-red-600 hover:text-red-700 font-medium"
                      >
                        Remove file
                      </button>
                    </div>
                  ) : (
                    <div>
                      <i className="ri-upload-cloud-2-line text-6xl text-gray-400 mb-4"></i>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        Drag and drop your resume here
                      </h3>
                      <p className="text-gray-600 mb-4">or click to browse files</p>
                      <input
                        type="file"
                        accept=".pdf,.doc,.docx"
                        onChange={handleFileSelect}
                        className="hidden"
                        id="resume-upload"
                      />
                      <label
                        htmlFor="resume-upload"
                        className="inline-block bg-teal-600 text-white px-6 py-3 rounded-lg hover:bg-teal-700 transition-colors cursor-pointer font-semibold whitespace-nowrap"
                      >
                        Choose File
                      </label>
                      <p className="text-sm text-gray-500 mt-3">
                        Supported formats: PDF, DOC, DOCX (Max 5MB)
                      </p>
                    </div>
                  )}
                </div>

                {file && (
                  <div className="mt-8 text-center">
                    <button
                      onClick={analyzeResume}
                      disabled={isAnalyzing}
                      className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white px-8 py-4 rounded-lg hover:from-teal-700 hover:to-cyan-700 transition-colors text-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                    >
                      {isAnalyzing ? (
                        <div className="flex items-center">
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                          Analyzing Resume...
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <i className="ri-search-eye-line mr-2"></i>
                          Analyze My Resume
                        </div>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Results Section */}
      {reviewResults && (
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Overall Score */}
            <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-r from-teal-500 to-cyan-600 text-white text-3xl font-bold mb-4">
                  {reviewResults.overallScore}
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Overall Resume Score</h2>
                <p className="text-gray-600 text-lg">Your resume has been analyzed across multiple criteria</p>
              </div>
            </div>

            {/* Section Scores */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {Object.entries(reviewResults.sections).map(([key, section]: [string, any]) => (
                <div key={key} className="bg-white rounded-2xl shadow-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 capitalize">{key}</h3>
                    <span className={`text-2xl font-bold ${getScoreColor(section.score)}`}>
                      {section.score}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 mb-3">
                    <div
                      className={`h-3 rounded-full ${getScoreBg(section.score)}`}
                      style={{ width: `${section.score}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600">{section.feedback}</p>
                </div>
              ))}
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Strengths */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-thumb-up-line text-green-600"></i>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Strengths</h3>
                </div>
                <ul className="space-y-3">
                  {reviewResults.strengths.map((strength: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-check-line text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                      <span className="text-gray-700 text-sm">{strength}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Areas for Improvement */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-arrow-up-line text-orange-600"></i>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Improvements</h3>
                </div>
                <ul className="space-y-3">
                  {reviewResults.improvements.map((improvement: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-arrow-right-line text-orange-600 mr-2 mt-0.5 flex-shrink-0"></i>
                      <span className="text-gray-700 text-sm">{improvement}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Suggestions */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-lightbulb-line text-blue-600"></i>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Suggestions</h3>
                </div>
                <ul className="space-y-3">
                  {reviewResults.suggestions.map((suggestion: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-star-line text-blue-600 mr-2 mt-0.5 flex-shrink-0"></i>
                      <span className="text-gray-700 text-sm">{suggestion}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="text-center mt-12 space-y-4">
              <Link
                href="/builder"
                className="inline-block bg-gradient-to-r from-teal-600 to-cyan-600 text-white px-8 py-4 rounded-lg hover:from-teal-700 hover:to-cyan-700 transition-colors text-lg font-semibold mr-4 whitespace-nowrap"
              >
                Improve My Resume
              </Link>
              <button
                onClick={() => {
                  setFile(null);
                  setReviewResults(null);
                }}
                className="inline-block bg-gray-600 text-white px-8 py-4 rounded-lg hover:bg-gray-700 transition-colors text-lg font-semibold whitespace-nowrap"
              >
                Analyze Another Resume
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">What Our AI Reviews</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-layout-line text-teal-600 text-3xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Formatting</h3>
              <p className="text-gray-600 text-sm">
                Professional layout, consistent styling, and visual appeal
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-file-text-line text-teal-600 text-3xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Content Quality</h3>
              <p className="text-gray-600 text-sm">
                Relevance, achievements, and professional language usage
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-key-line text-teal-600 text-3xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Keywords</h3>
              <p className="text-gray-600 text-sm">
                Industry-specific terms and ATS optimization
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-ruler-line text-teal-600 text-3xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Structure</h3>
              <p className="text-gray-600 text-sm">
                Proper sections, length, and information organization
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-cyan-600 to-teal-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Create a Perfect Resume?</h2>
          <p className="text-xl text-cyan-100 mb-8 max-w-2xl mx-auto">
            Use our insights to build a resume that stands out and gets you hired
          </p>
          <Link
            href="/builder"
            className="inline-block bg-white text-cyan-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap"
          >
            Start Building Your Resume
          </Link>
        </div>
      </section>
    </div>
  );
}