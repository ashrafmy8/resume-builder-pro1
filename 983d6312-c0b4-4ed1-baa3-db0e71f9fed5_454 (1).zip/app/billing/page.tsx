'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface BillingInfo {
  plan: 'free' | 'premium' | 'pro';
  planName: string;
  price: number;
  billingCycle: 'monthly' | 'yearly';
  nextBilling?: string;
  features: string[];
  usage: {
    resumesCreated: number;
    resumeLimit: number;
    templatesUsed: number;
    templateLimit: number;
  };
}

const plans = {
  free: {
    name: 'Free Plan',
    price: 0,
    features: [
      'Create up to 3 resumes',
      'Basic templates',
      'PDF export',
      'Basic support'
    ]
  },
  premium: {
    name: 'Premium Plan',
    price: 9.99,
    features: [
      'Unlimited resumes',
      'Premium templates',
      'AI-powered suggestions',
      'ATS optimization',
      'Priority support',
      'Cover letter builder'
    ]
  },
  pro: {
    name: 'Pro Plan',
    price: 19.99,
    features: [
      'Everything in Premium',
      'Advanced AI features',
      'Custom branding',
      'Team collaboration',
      'Analytics dashboard',
      'White-label solution'
    ]
  }
};

export default function BillingPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [billingInfo, setBillingInfo] = useState<BillingInfo>({
    plan: 'free',
    planName: 'Free Plan',
    price: 0,
    billingCycle: 'monthly',
    features: plans.free.features,
    usage: {
      resumesCreated: 2,
      resumeLimit: 3,
      templatesUsed: 1,
      templateLimit: 5
    }
  });

  useEffect(() => {
    const checkAuth = () => {
      const authStatus = localStorage.getItem('isAuthenticated');
      const userData = localStorage.getItem('user');
      
      if (authStatus === 'true' && userData) {
        setUser(JSON.parse(userData));
      } else {
        router.push('/login');
      }
      setLoading(false);
    };

    checkAuth();
  }, [router]);

  const handleUpgrade = (planType: 'premium' | 'pro') => {
    // In a real app, this would redirect to payment processing
    alert(`Upgrading to ${plans[planType].name}. Payment integration would go here.`);
  };

  const handleCancelSubscription = () => {
    const confirmed = window.confirm('Are you sure you want to cancel your subscription? Your plan will remain active until the end of the current billing period.');
    if (confirmed) {
      alert('Subscription cancelled. You will receive a confirmation email shortly.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading billing information...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Billing & Subscription</h1>
              <p className="text-gray-600 mt-2">Manage your subscription and billing information</p>
            </div>
            <Link 
              href="/dashboard"
              className="flex items-center px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Back to Dashboard
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Current Plan */}
          <div className="lg:col-span-2 space-y-8">
            {/* Plan Overview */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Current Plan</h2>
              
              <div className="flex items-center justify-between p-6 bg-blue-50 rounded-lg">
                <div>
                  <h3 className="text-lg font-semibold text-blue-900">{billingInfo.planName}</h3>
                  <p className="text-blue-700">
                    {billingInfo.price === 0 ? 'Free forever' : `$${billingInfo.price}/${billingInfo.billingCycle}`}
                  </p>
                  {billingInfo.nextBilling && (
                    <p className="text-sm text-blue-600 mt-1">
                      Next billing: {new Date(billingInfo.nextBilling).toLocaleDateString()}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  {billingInfo.plan === 'free' ? (
                    <button 
                      onClick={() => router.push('/pricing')}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
                    >
                      Upgrade Plan
                    </button>
                  ) : (
                    <button 
                      onClick={handleCancelSubscription}
                      className="px-4 py-2 text-red-600 border border-red-200 rounded-lg hover:bg-red-50 transition-colors whitespace-nowrap"
                    >
                      Cancel Subscription
                    </button>
                  )}
                </div>
              </div>

              {/* Features */}
              <div className="mt-6">
                <h4 className="font-semibold text-gray-900 mb-3">Plan Features</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {billingInfo.features.map((feature, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-600">
                      <i className="ri-check-line text-green-600 mr-2"></i>
                      {feature}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Usage Stats */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Usage This Month</h2>
              
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Resumes Created</span>
                    <span className="text-sm text-gray-500">
                      {billingInfo.usage.resumesCreated} / {billingInfo.usage.resumeLimit === -1 ? '∞' : billingInfo.usage.resumeLimit}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ 
                        width: billingInfo.usage.resumeLimit === -1 
                          ? '20%' 
                          : `${Math.min((billingInfo.usage.resumesCreated / billingInfo.usage.resumeLimit) * 100, 100)}%` 
                      }}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Templates Used</span>
                    <span className="text-sm text-gray-500">
                      {billingInfo.usage.templatesUsed} / {billingInfo.usage.templateLimit === -1 ? '∞' : billingInfo.usage.templateLimit}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{ 
                        width: billingInfo.usage.templateLimit === -1 
                          ? '10%' 
                          : `${Math.min((billingInfo.usage.templatesUsed / billingInfo.usage.templateLimit) * 100, 100)}%` 
                      }}
                    ></div>
                  </div>
                </div>
              </div>

              {billingInfo.plan === 'free' && (
                <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="flex items-center">
                    <i className="ri-warning-line text-orange-600 mr-2"></i>
                    <span className="text-orange-800 text-sm">
                      You're approaching your free plan limits. Upgrade to get unlimited access.
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Billing History */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Billing History</h2>
              
              {billingInfo.plan === 'free' ? (
                <div className="text-center py-8">
                  <i className="ri-file-list-line text-4xl text-gray-300 mb-4"></i>
                  <p className="text-gray-500">No billing history for free accounts</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Sample billing entries */}
                  <div className="flex items-center justify-between py-3 border-b border-gray-100">
                    <div>
                      <p className="font-medium text-gray-900">Premium Plan - Monthly</p>
                      <p className="text-sm text-gray-500">January 15, 2024</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">$9.99</p>
                      <button className="text-sm text-blue-600 hover:text-blue-700">
                        Download Invoice
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-gray-100">
                    <div>
                      <p className="font-medium text-gray-900">Premium Plan - Monthly</p>
                      <p className="text-sm text-gray-500">December 15, 2023</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">$9.99</p>
                      <button className="text-sm text-blue-600 hover:text-blue-700">
                        Download Invoice
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Upgrade Options */}
          <div className="space-y-6">
            {billingInfo.plan !== 'premium' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="text-center mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Premium Plan</h3>
                  <p className="text-3xl font-bold text-blue-600 mt-2">$9.99<span className="text-sm text-gray-500">/month</span></p>
                </div>
                <ul className="space-y-2 mb-6">
                  {plans.premium.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <i className="ri-check-line text-green-600 mr-2"></i>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => handleUpgrade('premium')}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
                >
                  Upgrade to Premium
                </button>
              </div>
            )}

            {billingInfo.plan !== 'pro' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="text-center mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Pro Plan</h3>
                  <p className="text-3xl font-bold text-purple-600 mt-2">$19.99<span className="text-sm text-gray-500">/month</span></p>
                </div>
                <ul className="space-y-2 mb-6">
                  {plans.pro.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <i className="ri-check-line text-green-600 mr-2"></i>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => handleUpgrade('pro')}
                  className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap"
                >
                  Upgrade to Pro
                </button>
              </div>
            )}

            {/* Support */}
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="font-semibold text-gray-900 mb-3">Need Help?</h3>
              <p className="text-sm text-gray-600 mb-4">
                Have questions about billing or need to make changes to your subscription?
              </p>
              <Link 
                href="/support"
                className="inline-flex items-center text-sm text-blue-600 hover:text-blue-700"
              >
                <i className="ri-customer-service-line mr-2"></i>
                Contact Support
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}