
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function CVTemplatesPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'all', name: 'All Templates' },
    { id: 'modern', name: 'Modern' },
    { id: 'creative', name: 'Creative' },
    { id: 'professional', name: 'Professional' },
    { id: 'executive', name: 'Executive' },
    { id: 'minimalist', name: 'Minimalist' },
    { id: 'entry-level', name: 'Entry Level' }
  ];

  const templates = [
    // Modern Templates (6)
    {
      id: 'galaxy-modern',
      name: 'Galaxy Modern',
      category: 'modern',
      description: 'Dark space theme with gradient headers and glassmorphism effects for tech professionals',
      premium: false,
      rating: 4.9,
      downloads: '52.3K',
      preview: 'https://readdy.ai/api/search-image?query=Modern%20professional%20CV%20template%20with%20dark%20galaxy%20theme%2C%20gradient%20purple%20to%20blue%20header%20section%2C%20glassmorphism%20white%20cards%20with%20backdrop%20blur%20effects%2C%20professional%20photo%20placeholder%2C%20space-inspired%20design%20elements%2C%20contemporary%20typography%2C%20technical%20skills%20visualization%20with%20progress%20bars&width=400&height=500&seq=galaxy-modern&orientation=portrait'
    },
    {
      id: 'quantum-tech',
      name: 'Quantum Tech',
      category: 'modern',
      description: 'Emerald/cyan gradients perfect for AI/tech professionals with futuristic design elements',
      premium: false,
      rating: 4.8,
      downloads: '48.7K',
      preview: 'https://readdy.ai/api/search-image?query=Futuristic%20tech%20CV%20template%20with%20emerald%20to%20cyan%20gradient%20elements%2C%20quantum-inspired%20design%2C%20glassmorphism%20cards%2C%20AI%20and%20machine%20learning%20focus%2C%20modern%20technical%20typography%2C%20circuit%20board%20subtle%20patterns%2C%20tech%20professional%20formatting&width=400&height=500&seq=quantum-tech&orientation=portrait'
    },
    {
      id: 'velocity-modern',
      name: 'Velocity Modern',
      category: 'modern',
      description: 'Blue/purple gradients with contemporary card layouts and dynamic visual elements',
      premium: false,
      rating: 4.9,
      downloads: '45.2K',
      preview: 'https://readdy.ai/api/search-image?query=Contemporary%20modern%20CV%20template%20with%20blue%20to%20purple%20gradient%20background%2C%20velocity-inspired%20dynamic%20elements%2C%20floating%20cards%20design%2C%20contemporary%20typography%2C%20professional%20photo%20treatment%2C%20modern%20skill%20visualization%2C%20speed%20and%20motion%20visual%20metaphors&width=400&height=500&seq=velocity-modern&orientation=portrait'
    },
    {
      id: 'matrix-tech',
      name: 'Matrix Tech',
      category: 'modern',
      description: 'Cyberpunk-inspired design with green terminal aesthetics for developers',
      premium: true,
      rating: 5.0,
      downloads: '28.9K',
      preview: 'https://readdy.ai/api/search-image?query=Cyberpunk%20matrix%20CV%20template%20with%20dark%20background%2C%20green%20terminal-inspired%20accents%2C%20code-like%20typography%2C%20developer%20and%20hacker%20aesthetic%2C%20digital%20rain%20effects%2C%20futuristic%20professional%20formatting%2C%20cybersecurity%20focus&width=400&height=500&seq=matrix-tech&orientation=portrait'
    },
    {
      id: 'flux-modern',
      name: 'Flux Modern',
      category: 'modern',
      description: 'Cyan/blue gradients with floating elements and modern typography',
      premium: false,
      rating: 4.8,
      downloads: '41.6K',
      preview: 'https://readdy.ai/api/search-image?query=Modern%20flux%20CV%20template%20with%20cyan%20to%20blue%20gradient%20elements%2C%20floating%20geometric%20shapes%2C%20contemporary%20card-based%20layout%2C%20modern%20sans-serif%20typography%2C%20professional%20photo%20with%20gradient%20border%2C%20dynamic%20visual%20flow&width=400&height=500&seq=flux-modern&orientation=portrait'
    },
    {
      id: 'echo-modern',
      name: 'Echo Modern',
      category: 'modern',
      description: 'Orange/red gradients with dynamic visual elements and contemporary design',
      premium: false,
      rating: 4.7,
      downloads: '35.8K',
      preview: 'https://readdy.ai/api/search-image?query=Echo%20modern%20CV%20template%20with%20orange%20to%20red%20gradient%20background%2C%20sound%20wave%20visual%20elements%2C%20dynamic%20typography%2C%20contemporary%20professional%20design%2C%20creative%20visual%20metaphors%2C%20modern%20card%20layouts&width=400&height=500&seq=echo-modern&orientation=portrait'
    },

    // Creative Templates (4)
    {
      id: 'nexus-creative',
      name: 'Nexus Creative',
      category: 'creative',
      description: 'Purple/violet gradients with artistic flair and creative visual elements',
      premium: false,
      rating: 4.8,
      downloads: '32.4K',
      preview: 'https://readdy.ai/api/search-image?query=Creative%20nexus%20CV%20template%20with%20purple%20to%20violet%20gradient%20background%2C%20artistic%20connection%20points%20and%20network%20visuals%2C%20creative%20typography%2C%20portfolio%20project%20showcase%2C%20artistic%20photo%20treatment%2C%20creative%20industry%20formatting&width=400&height=500&seq=nexus-creative&orientation=portrait'
    },
    {
      id: 'spectrum-creative',
      name: 'Spectrum Creative',
      category: 'creative',
      description: 'Yellow/orange/red gradients for motion graphics and visual artists',
      premium: false,
      rating: 4.7,
      downloads: '28.2K',
      preview: 'https://readdy.ai/api/search-image?query=Spectrum%20creative%20CV%20template%20with%20rainbow%20gradient%20from%20yellow%20through%20orange%20to%20red%2C%20color%20spectrum%20visual%20elements%2C%20motion%20graphics%20inspired%20design%2C%20creative%20skills%20visualization%2C%20artistic%20typography%2C%20visual%20arts%20professional%20formatting&width=400&height=500&seq=spectrum-creative&orientation=portrait'
    },
    {
      id: 'aurora-creative',
      name: 'Aurora Creative',
      category: 'creative',
      description: 'Pink/purple/indigo gradients with artistic photo treatments',
      premium: false,
      rating: 4.9,
      downloads: '26.5K',
      preview: 'https://readdy.ai/api/search-image?query=Aurora%20creative%20CV%20template%20with%20pink%20to%20purple%20to%20indigo%20gradient%20background%2C%20northern%20lights%20inspired%20design%2C%20artistic%20photo%20treatment%20with%20creative%20borders%2C%20ethereal%20visual%20elements%2C%20creative%20portfolio%20showcase&width=400&height=500&seq=aurora-creative&orientation=portrait'
    },
    {
      id: 'neon-creative',
      name: 'Neon Creative',
      category: 'creative',
      description: 'Dark theme with neon accents perfect for digital artists and NFT creators',
      premium: true,
      rating: 4.9,
      downloads: '19.7K',
      preview: 'https://readdy.ai/api/search-image?query=Neon%20creative%20CV%20template%20with%20dark%20black%20background%2C%20bright%20neon%20purple%20and%20cyan%20accents%2C%20digital%20art%20aesthetic%2C%20NFT%20and%20crypto%20art%20focus%2C%20glowing%20text%20effects%2C%20futuristic%20creative%20professional%20formatting&width=400&height=500&seq=neon-creative&orientation=portrait'
    },

    // Professional Templates (4)
    {
      id: 'astral-professional',
      name: 'Astral Professional',
      category: 'professional',
      description: 'Rose/orange gradients with structured business formatting',
      premium: false,
      rating: 4.8,
      downloads: '38.9K',
      preview: 'https://readdy.ai/api/search-image?query=Astral%20professional%20CV%20template%20with%20rose%20to%20orange%20gradient%20elements%2C%20space-inspired%20professional%20design%2C%20structured%20business%20formatting%2C%20clean%20typography%2C%20professional%20photo%20placement%2C%20corporate%20consulting%20style&width=400&height=500&seq=astral-professional&orientation=portrait'
    },
    {
      id: 'horizon-professional',
      name: 'Horizon Professional',
      category: 'professional',
      description: 'Clean white background with teal accents and professional layout',
      premium: false,
      rating: 4.7,
      downloads: '44.2K',
      preview: 'https://readdy.ai/api/search-image?query=Horizon%20professional%20CV%20template%20with%20clean%20white%20background%2C%20teal%20accent%20colors%2C%20horizon%20line%20design%20elements%2C%20professional%20business%20formatting%2C%20structured%20sections%20with%20clean%20borders%2C%20corporate%20typography&width=400&height=500&seq=horizon-professional&orientation=portrait'
    },
    {
      id: 'cosmos-professional',
      name: 'Cosmos Professional',
      category: 'professional',
      description: 'Traditional design with indigo accents and centered photo',
      premium: false,
      rating: 4.6,
      downloads: '36.8K',
      preview: 'https://readdy.ai/api/search-image?query=Cosmos%20professional%20CV%20template%20with%20traditional%20business%20layout%2C%20indigo%20accent%20colors%2C%20centered%20professional%20photo%2C%20cosmic%20subtle%20elements%2C%20structured%20professional%20formatting%2C%20business%20consulting%20style&width=400&height=500&seq=cosmos-professional&orientation=portrait'
    },
    {
      id: 'vertex-professional',
      name: 'Vertex Professional',
      category: 'professional',
      description: 'Green theme with project management focus and structured layout',
      premium: false,
      rating: 4.7,
      downloads: '31.5K',
      preview: 'https://readdy.ai/api/search-image?query=Vertex%20professional%20CV%20template%20with%20green%20accent%20colors%2C%20geometric%20vertex%20design%20elements%2C%20project%20management%20focus%2C%20structured%20professional%20layout%2C%20clean%20business%20typography%2C%20management%20consulting%20formatting&width=400&height=500&seq=vertex-professional&orientation=portrait'
    },

    // Executive Templates (2)
    {
      id: 'prism-executive',
      name: 'Prism Executive',
      category: 'executive',
      description: 'Sophisticated slate colors with premium gradient headers',
      premium: true,
      rating: 4.9,
      downloads: '15.3K',
      preview: 'https://readdy.ai/api/search-image?query=Prism%20executive%20CV%20template%20with%20sophisticated%20slate%20color%20scheme%2C%20premium%20gradient%20header%2C%20prism%20light%20refraction%20design%20elements%2C%20executive%20photo%20treatment%2C%20luxury%20business%20formatting%2C%20C-suite%20professional%20style&width=400&height=500&seq=prism-executive&orientation=portrait'
    },
    {
      id: 'platinum-executive',
      name: 'Platinum Executive',
      category: 'executive',
      description: 'Luxury gray/white design for C-suite professionals',
      premium: true,
      rating: 5.0,
      downloads: '12.8K',
      preview: 'https://readdy.ai/api/search-image?query=Platinum%20executive%20CV%20template%20with%20luxury%20platinum%20and%20white%20color%20scheme%2C%20premium%20executive%20formatting%2C%20sophisticated%20design%20elements%2C%20C-suite%20professional%20layout%2C%20high-end%20business%20typography%2C%20luxury%20corporate%20style&width=400&height=500&seq=platinum-executive&orientation=portrait'
    },

    // Minimalist Templates (2)
    {
      id: 'zenith-minimalist',
      name: 'Zenith Minimalist',
      category: 'minimalist',
      description: 'Ultra-clean white design with indigo accents and minimal elements',
      premium: false,
      rating: 4.8,
      downloads: '29.7K',
      preview: 'https://readdy.ai/api/search-image?query=Zenith%20minimalist%20CV%20template%20with%20ultra-clean%20white%20background%2C%20minimal%20indigo%20accents%2C%20maximum%20white%20space%2C%20clean%20sans-serif%20typography%2C%20minimal%20design%20elements%2C%20Scandinavian-inspired%20professional%20formatting&width=400&height=500&seq=zenith-minimalist&orientation=portrait'
    },
    {
      id: 'zen-minimalist',
      name: 'Zen Minimalist',
      category: 'minimalist',
      description: 'Scandinavian-inspired layout with maximum white space',
      premium: false,
      rating: 4.7,
      downloads: '25.4K',
      preview: 'https://readdy.ai/api/search-image?query=Zen%20minimalist%20CV%20template%20with%20Scandinavian%20design%20principles%2C%20maximum%20white%20space%2C%20subtle%20blue%20accents%2C%20zen-inspired%20minimal%20elements%2C%20clean%20typography%2C%20Nordic%20professional%20formatting&width=400&height=500&seq=zen-minimalist&orientation=portrait'
    },

    // Entry Level Templates (2)
    {
      id: 'nova-entry-level',
      name: 'Nova Entry Level',
      category: 'entry-level',
      description: 'Bright colors for students and new graduates',
      premium: false,
      rating: 4.6,
      downloads: '42.8K',
      preview: 'https://readdy.ai/api/search-image?query=Nova%20entry%20level%20CV%20template%20with%20bright%20orange%20and%20yellow%20colors%2C%20student-friendly%20design%2C%20fresh%20graduate%20formatting%2C%20education%20section%20emphasis%2C%20internship%20experience%20highlight%2C%20energetic%20typography&width=400&height=500&seq=nova-entry-level&orientation=portrait'
    },
    {
      id: 'spark-entry-level',
      name: 'Spark Entry Level',
      category: 'entry-level',
      description: 'Energetic design for fresh professionals',
      premium: false,
      rating: 4.5,
      downloads: '38.1K',
      preview: 'https://readdy.ai/api/search-image?query=Spark%20entry%20level%20CV%20template%20with%20energetic%20red%20and%20orange%20colors%2C%20spark-inspired%20design%20elements%2C%20fresh%20professional%20formatting%2C%20entry-level%20focus%2C%20dynamic%20typography%2C%20new%20graduate%20style&width=400&height=500&seq=spark-entry-level&orientation=portrait'
    }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Professional CV Templates</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Create stunning academic and professional CVs with our collection of modern, creative, and executive templates. 
            Each template features comprehensive content and ATS-optimized formatting for maximum impact.
          </p>
          <div className="flex justify-center items-center space-x-8 text-lg">
            <div className="flex items-center">
              <i className="ri-check-line text-green-400 mr-2"></i>
              <span>A4 Format</span>
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-green-400 mr-2"></i>
              <span>ATS Optimized</span>
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-green-400 mr-2"></i>
              <span>Professional Content</span>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <div className="relative max-w-md mx-auto">
              <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
              <input
                type="text"
                placeholder="Search templates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
              />
            </div>
          </div>

          <div className="flex justify-center">
            <div className="flex flex-wrap gap-4">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-6 py-3 rounded-full font-medium transition-all whitespace-nowrap ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Templates Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
              >
                <div className="relative">
                  <img
                    src={template.preview}
                    alt={`${template.name} CV Template`}
                    className="w-full h-96 object-cover object-top"
                  />
                  
                  {template.premium && (
                    <div className="absolute top-4 left-4 px-3 py-1 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-xs rounded-full font-bold">
                      <i className="ri-vip-crown-line mr-1"></i>
                      Premium
                    </div>
                  )}

                  <div className="absolute top-4 right-4 flex items-center space-x-1 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                    <i className="ri-star-fill text-amber-500 text-sm"></i>
                    <span className="text-sm font-medium">{template.rating}</span>
                  </div>
                  
                  <div className="absolute inset-0 bg-black/0 hover:bg-black/10 transition-colors duration-300 flex items-center justify-center opacity-0 hover:opacity-100">
                    <Link
                      href={`/builder?template=${template.id}&type=cv`}
                      className="bg-white text-gray-900 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors transform scale-90 hover:scale-100 duration-300 whitespace-nowrap shadow-lg"
                    >
                      Use This Template
                    </Link>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-bold text-gray-900">{template.name}</h3>
                    <div className="flex items-center space-x-1 text-sm text-gray-500">
                      <i className="ri-download-line"></i>
                      <span>{template.downloads}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed">{template.description}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <span className={`px-3 py-1 text-xs rounded-full font-medium ${
                      template.category === 'modern' ? 'bg-blue-100 text-blue-700' :
                      template.category === 'professional' ? 'bg-emerald-100 text-emerald-700' :
                      template.category === 'creative' ? 'bg-purple-100 text-purple-700' :
                      template.category === 'executive' ? 'bg-slate-100 text-slate-700' :
                      template.category === 'minimalist' ? 'bg-indigo-100 text-indigo-700' :
                      'bg-orange-100 text-orange-700'
                    }`}>
                      {template.category.charAt(0).toUpperCase() + template.category.slice(1).replace('-', ' ')}
                    </span>
                  </div>
                  
                  <Link
                    href={`/builder?template=${template.id}&type=cv`}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors text-center block font-semibold whitespace-nowrap"
                  >
                    Select Template
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {filteredTemplates.length === 0 && (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <i className="ri-search-line text-gray-400 text-3xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">No templates found</h3>
              <p className="text-gray-600">Try adjusting your search or filter criteria to find the perfect template</p>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Our CV Templates?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">Professional designs with comprehensive content for every career stage</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-palette-line text-white text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Modern Design</h3>
              <p className="text-gray-600 text-sm">Contemporary layouts with professional aesthetics</p>
            </div>
            
            <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-robot-line text-white text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">ATS Optimized</h3>
              <p className="text-gray-600 text-sm">Formatted to pass applicant tracking systems</p>
            </div>
            
            <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-file-text-line text-white text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Complete Content</h3>
              <p className="text-gray-600 text-sm">Comprehensive sections with professional examples</p>
            </div>

            <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-download-cloud-line text-white text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Export Ready</h3>
              <p className="text-gray-600 text-sm">Download as PDF or Word with preserved formatting</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Build Your Professional CV?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Choose from our collection of modern, creative, and professional CV templates to create your perfect curriculum vitae.
          </p>
          <Link
            href="/builder?type=cv"
            className="inline-flex items-center bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap"
          >
            <i className="ri-file-edit-line mr-2"></i>
            Start Building Now
          </Link>
        </div>
      </section>
    </div>
  );
}
