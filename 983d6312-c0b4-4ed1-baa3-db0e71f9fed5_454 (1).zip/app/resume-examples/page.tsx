'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function ResumeExamplesPage() {
  const [selectedIndustry, setSelectedIndustry] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const industries = [
    { id: 'all', name: 'All Industries' },
    { id: 'tech', name: 'Technology' },
    { id: 'marketing', name: 'Marketing' },
    { id: 'finance', name: 'Finance' },
    { id: 'healthcare', name: 'Healthcare' },
    { id: 'education', name: 'Education' },
    { id: 'sales', name: 'Sales' }
  ];

  const levels = [
    { id: 'all', name: 'All Levels' },
    { id: 'entry', name: 'Entry Level' },
    { id: 'mid', name: 'Mid Level' },
    { id: 'senior', name: 'Senior Level' },
    { id: 'executive', name: 'Executive' }
  ];

  const examples = [
    {
      id: 1,
      name: 'Sarah Chen',
      position: 'Senior Software Engineer',
      company: 'Google',
      industry: 'tech',
      level: 'senior',
      salary: '$180,000 - $220,000',
      experience: '8 years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Asian%20woman%20software%20engineer%20headshot%20photo%2C%20confident%20expression%2C%20modern%20tech%20office%20background%2C%20professional%20business%20attire%2C%20high-quality%20professional%20portrait&width=150&height=150&seq=sarah-chen&orientation=squarish',
      skills: ['Python', 'Java', 'System Design', 'Machine Learning', 'AWS'],
      achievements: [
        'Led team of 12 engineers on critical infrastructure project',
        'Reduced system latency by 40% through optimization',
        'Mentored 15+ junior developers'
      ],
      description: 'Experienced software engineer with expertise in distributed systems and machine learning. Led multiple high-impact projects at Google.'
    },
    {
      id: 2,
      name: 'Michael Rodriguez',
      position: 'Marketing Director',
      company: 'Nike',
      industry: 'marketing',
      level: 'senior',
      salary: '$140,000 - $170,000',
      experience: '10 years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Hispanic%20man%20marketing%20director%20headshot%20photo%2C%20confident%20smile%2C%20creative%20office%20background%2C%20business%20casual%20attire%2C%20professional%20corporate%20portrait&width=150&height=150&seq=michael-rodriguez&orientation=squarish',
      skills: ['Digital Marketing', 'Brand Strategy', 'Analytics', 'Team Leadership', 'Campaign Management'],
      achievements: [
        'Increased brand engagement by 150% across digital channels',
        'Managed $50M+ annual marketing budget',
        'Launched 20+ successful product campaigns'
      ],
      description: 'Creative marketing leader with proven track record of driving brand growth and customer engagement through innovative campaigns.'
    },
    {
      id: 3,
      name: 'Emily Johnson',
      position: 'Financial Analyst',
      company: 'Goldman Sachs',
      industry: 'finance',
      level: 'mid',
      salary: '$95,000 - $120,000',
      experience: '4 years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20blonde%20woman%20financial%20analyst%20headshot%20photo%2C%20confident%20professional%20expression%2C%20corporate%20finance%20office%20background%2C%20business%20suit%20attire%2C%20executive%20portrait&width=150&height=150&seq=emily-johnson&orientation=squarish',
      skills: ['Financial Modeling', 'Excel', 'Python', 'Risk Analysis', 'Investment Research'],
      achievements: [
        'Generated $2M+ in revenue through strategic recommendations',
        'Improved forecasting accuracy by 25%',
        'Led analysis on 50+ investment opportunities'
      ],
      description: 'Detail-oriented financial analyst with expertise in investment research and risk assessment. Strong analytical and communication skills.'
    },
    {
      id: 4,
      name: 'David Kim',
      position: 'Product Manager',
      company: 'Apple',
      industry: 'tech',
      level: 'senior',
      salary: '$160,000 - $200,000',
      experience: '7 years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Asian%20man%20product%20manager%20headshot%20photo%2C%20confident%20expression%2C%20modern%20tech%20company%20office%20background%2C%20business%20casual%20attire%2C%20professional%20portrait&width=150&height=150&seq=david-kim&orientation=squarish',
      skills: ['Product Strategy', 'User Research', 'Data Analysis', 'Agile', 'Cross-functional Leadership'],
      achievements: [
        'Launched 3 products with 10M+ active users',
        'Increased user retention by 35%',
        'Led cross-functional teams of 25+ people'
      ],
      description: 'Strategic product manager with experience launching consumer products at scale. Passionate about user experience and data-driven decisions.'
    },
    {
      id: 5,
      name: 'Lisa Wang',
      position: 'UX Designer',
      company: 'Airbnb',
      industry: 'tech',
      level: 'mid',
      salary: '$110,000 - $140,000',
      experience: '5 years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Asian%20woman%20UX%20designer%20headshot%20photo%2C%20creative%20expression%2C%20modern%20design%20studio%20background%2C%20stylish%20professional%20attire%2C%20artistic%20portrait&width=150&height=150&seq=lisa-wang&orientation=squarish',
      skills: ['UI/UX Design', 'Figma', 'User Research', 'Prototyping', 'Design Systems'],
      achievements: [
        'Redesigned booking flow, increasing conversion by 20%',
        'Led design system adoption across 15+ teams',
        'Conducted 100+ user interviews and usability tests'
      ],
      description: 'Creative UX designer focused on creating intuitive and delightful user experiences. Expertise in design systems and user research.'
    },
    {
      id: 6,
      name: 'James Thompson',
      position: 'Sales Executive',
      company: 'Salesforce',
      industry: 'sales',
      level: 'senior',
      salary: '$130,000 - $180,000',
      experience: '9 years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20white%20man%20sales%20executive%20headshot%20photo%2C%20confident%20smile%2C%20modern%20corporate%20office%20background%2C%20business%20suit%20attire%2C%20executive%20professional%20portrait&width=150&height=150&seq=james-thompson&orientation=squarish',
      skills: ['Enterprise Sales', 'CRM', 'Negotiation', 'Account Management', 'Team Leadership'],
      achievements: [
        'Exceeded quota by 150% for 3 consecutive years',
        'Closed $10M+ in new business annually',
        'Built and managed team of 8 sales reps'
      ],
      description: 'Results-driven sales executive with proven track record in enterprise software sales. Expert in building relationships and closing complex deals.'
    }
  ];

  const filteredExamples = examples.filter(example => {
    const matchesIndustry = selectedIndustry === 'all' || example.industry === selectedIndustry;
    const matchesLevel = selectedLevel === 'all' || example.level === selectedLevel;
    return matchesIndustry && matchesLevel;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>
            <Link href="/builder" className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap">
              Build Resume
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Real Resume Examples
            </h1>
            <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
              Get inspired by real resumes from professionals who landed jobs at top companies. 
              See what works and apply it to your own resume.
            </p>
            <div className="flex items-center justify-center space-x-8 text-purple-100">
              <div className="flex items-center">
                <i className="ri-user-line mr-2"></i>
                <span>Real Examples</span>
              </div>
              <div className="flex items-center">
                <i className="ri-star-line mr-2"></i>
                <span>Top Companies</span>
              </div>
              <div className="flex items-center">
                <i className="ri-briefcase-line mr-2"></i>
                <span>All Industries</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
              <select
                value={selectedIndustry}
                onChange={(e) => setSelectedIndustry(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 pr-8"
              >
                {industries.map((industry) => (
                  <option key={industry.id} value={industry.id}>
                    {industry.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Experience Level</label>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 pr-8"
              >
                {levels.map((level) => (
                  <option key={level.id} value={level.id}>
                    {level.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setSelectedIndustry('all');
                  setSelectedLevel('all');
                }}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Examples Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {filteredExamples.map((example, index) => (
              <div
                key={example.id}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-1 ${
                  isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="p-8">
                  {/* Profile Header */}
                  <div className="flex items-start space-x-6 mb-6">
                    <img
                      src={example.image}
                      alt={example.name}
                      className="w-20 h-20 rounded-full object-cover border-4 border-purple-100"
                    />
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900 mb-1">{example.name}</h3>
                      <p className="text-lg text-purple-600 font-semibold mb-2">{example.position}</p>
                      <div className="flex items-center text-gray-600 mb-2">
                        <i className="ri-building-line mr-2"></i>
                        <span className="font-medium">{example.company}</span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <i className="ri-time-line mr-1"></i>
                          {example.experience}
                        </span>
                        <span className="flex items-center">
                          <i className="ri-money-dollar-circle-line mr-1"></i>
                          {example.salary}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-700 mb-6 leading-relaxed">{example.description}</p>

                  {/* Skills */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Key Skills</h4>
                    <div className="flex flex-wrap gap-2">
                      {example.skills.map((skill, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Achievements */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Key Achievements</h4>
                    <ul className="space-y-2">
                      {example.achievements.map((achievement, idx) => (
                        <li key={idx} className="flex items-start">
                          <i className="ri-check-line text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                          <span className="text-gray-700 text-sm">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Action Button */}
                  <Link
                    href="/builder"
                    className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-colors text-center block font-semibold whitespace-nowrap"
                  >
                    Use This Style
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {filteredExamples.length === 0 && (
            <div className="text-center py-20">
              <i className="ri-user-line text-6xl text-gray-400 mb-4"></i>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No examples found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your filter criteria</p>
              <button
                onClick={() => {
                  setSelectedIndustry('all');
                  setSelectedLevel('all');
                }}
                className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap"
              >
                Show All Examples
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Tips Section */}
      <section className="py-16 bg-gradient-to-r from-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-6">What Makes These Resumes Successful?</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-target-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">Quantified Results</h3>
              <p className="text-indigo-100">
                Every achievement includes specific numbers and metrics that demonstrate real impact and value.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-star-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">Relevant Skills</h3>
              <p className="text-indigo-100">
                Skills are carefully selected to match job requirements and industry standards.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-trophy-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">Clear Impact</h3>
              <p className="text-indigo-100">
                Each role clearly communicates the value delivered to the organization and business outcomes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Ready to Create Your Success Story?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Use these examples as inspiration to craft your own compelling resume that gets results
          </p>
          <Link
            href="/builder"
            className="inline-block bg-purple-600 text-white px-8 py-4 rounded-lg hover:bg-purple-700 transition-colors text-lg font-semibold whitespace-nowrap"
          >
            Start Building Your Resume
          </Link>
        </div>
      </section>
    </div>
  );
}