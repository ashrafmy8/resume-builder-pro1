
'use client';

import { useState } from 'react';
import { Check } from 'lucide-react';

export default function PricingPage() {
  const [selectedPlan, setSelectedPlan] = useState('one-time');

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Choose the plan that works best for you. No hidden fees, no surprises.
          </p>
        </div>
      </div>

      {/* Pricing Plans */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 gap-8">
          {/* One-Time Payment Plan */}
          <div className={`relative rounded-2xl border-2 p-8 ${
            selectedPlan === 'one-time' 
              ? 'border-green-500 bg-green-50' 
              : 'border-gray-200 bg-white hover:border-green-300'
          } transition-all duration-200 cursor-pointer`}
          onClick={() => setSelectedPlan('one-time')}>
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-green-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                POPULAR
              </span>
            </div>
            
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-gray-900">One-Time Access</h3>
                <p className="text-gray-600 mt-2">Perfect for immediate use, download resume right now.</p>
              </div>
              <div className="text-right">
                <div className="text-4xl font-bold text-green-600">$2</div>
              </div>
            </div>

            <div className="flex items-center mb-6">
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                selectedPlan === 'one-time' 
                  ? 'border-green-500 bg-green-500' 
                  : 'border-gray-300'
              }`}>
                {selectedPlan === 'one-time' && (
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                )}
              </div>
            </div>

            <ul className="space-y-3">
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                All formats • Instant access • No recurring charges
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                Professional templates
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                AI-powered resume builder
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                ATS optimization
              </li>
            </ul>
          </div>

          {/* Monthly Subscription Plan */}
          <div className={`relative rounded-2xl border-2 p-8 ${
            selectedPlan === 'monthly' 
              ? 'border-blue-500 bg-blue-50' 
              : 'border-gray-200 bg-white hover:border-blue-300'
          } transition-all duration-200 cursor-pointer`}
          onClick={() => setSelectedPlan('monthly')}>
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                UNLIMITED
              </span>
            </div>
            
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-gray-900">Monthly Subscription</h3>
                <p className="text-gray-600 mt-2">Unlimited access to all features. Cancel anytime.</p>
              </div>
              <div className="text-right">
                <div className="text-4xl font-bold text-blue-600">$5</div>
                <div className="text-gray-500">/month</div>
              </div>
            </div>

            <div className="flex items-center mb-6">
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                selectedPlan === 'monthly' 
                  ? 'border-blue-500 bg-blue-500' 
                  : 'border-gray-300'
              }`}>
                {selectedPlan === 'monthly' && (
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                )}
              </div>
            </div>

            <ul className="space-y-3">
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-blue-500 mr-3" />
                Unlimited downloads in all formats
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-blue-500 mr-3" />
                Premium templates & AI features
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-blue-500 mr-3" />
                Priority support
              </li>
              <li className="flex items-center text-gray-700">
                <Check className="w-5 h-5 text-blue-500 mr-3" />
                Regular updates & new features
              </li>
            </ul>
          </div>
        </div>

        {/* CTA Button */}
        <div className="text-center mt-12">
          <button className="bg-blue-600 text-white px-12 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors duration-200">
            Get Started with {selectedPlan === 'one-time' ? '$2 One-Time' : '$5/Month'}
          </button>
          <p className="text-gray-500 mt-4">
            {selectedPlan === 'one-time' 
              ? 'One-time payment, lifetime access to core features'
              : 'Cancel anytime, no commitment required'
            }
          </p>
        </div>
      </div>

      {/* Value Proposition */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Pricing?
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-green-600">$2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Perfect for Job Seekers</h3>
              <p className="text-gray-600">
                Get instant access to professional resume templates and AI tools for just $2. 
                Perfect if you need a resume now and want lifetime access to core features.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-blue-600">$5</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">For Career Growth</h3>
              <p className="text-gray-600">
                Unlimited access to all features, premium templates, and ongoing updates. 
                Ideal for professionals who frequently update their resumes and want the latest features.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Frequently Asked Questions
        </h2>
        
        <div className="space-y-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              What's the difference between the $2 and $5 plans?
            </h3>
            <p className="text-gray-600">
              The $2 one-time payment gives you lifetime access to core features and templates. 
              The $5 monthly plan includes unlimited downloads, premium templates, priority support, 
              and regular feature updates.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Can I upgrade from the $2 plan to the $5 plan later?
            </h3>
            <p className="text-gray-600">
              Yes! You can upgrade to the monthly plan anytime to get access to unlimited downloads 
              and premium features.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Is the $2 payment really one-time?
            </h3>
            <p className="text-gray-600">
              Absolutely! Pay once and keep access to the core features forever. No recurring charges, 
              no hidden fees.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Can I cancel the monthly plan anytime?
            </h3>
            <p className="text-gray-600">
              Yes, you can cancel your monthly subscription at any time. You'll continue to have 
              access until the end of your current billing period.
            </p>
          </div>
        </div>
      </div>

      {/* Money Back Guarantee */}
      <div className="bg-blue-600 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">
            30-Day Money-Back Guarantee
          </h2>
          <p className="text-blue-100 text-lg">
            Not satisfied? Get a full refund within 30 days, no questions asked.
          </p>
        </div>
      </div>
    </div>
  );
}
