import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";
import TawkToWidget from "../components/TawkToWidget";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ResumeTeacher - Professional Resume Builder",
  description: "Create professional resumes with AI assistance. Build, customize, and download your perfect resume in minutes.",
  icons: {
    icon: "https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/0b7e043db5415b70adb1fb91d39565a5.png",
    shortcut: "https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/0b7e043db5415b70adb1fb91d39565a5.png",
    apple: "https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/0b7e043db5415b70adb1fb91d39565a5.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
        <TawkToWidget />
      </body>
    </html>
  );
}
