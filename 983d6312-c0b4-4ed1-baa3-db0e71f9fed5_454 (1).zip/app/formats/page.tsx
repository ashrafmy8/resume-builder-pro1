'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function ResumeFormatsPage() {
  const [selectedFormat, setSelectedFormat] = useState('chronological');
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const formats = [
    {
      id: 'chronological',
      name: 'Chronological Resume',
      description: 'Lists work experience in reverse chronological order, starting with your most recent job.',
      bestFor: ['Professionals with consistent work history', 'Career advancement in same field', 'Traditional industries'],
      pros: ['Easy to follow work progression', 'Preferred by most recruiters', 'Shows career growth clearly'],
      cons: ['Highlights employment gaps', 'Not ideal for career changers', 'May emphasize age'],
      image: 'https://readdy.ai/api/search-image?query=Chronological%20resume%20format%20example%20with%20clear%20timeline%20of%20work%20experience%2C%20professional%20layout%20showing%20career%20progression%2C%20clean%20structured%20design%20with%20dates%20and%20job%20titles%20in%20order&width=400&height=300&seq=chronological-format&orientation=landscape'
    },
    {
      id: 'functional',
      name: 'Functional Resume',
      description: 'Focuses on skills and qualifications rather than work history chronology.',
      bestFor: ['Career changers', 'People with employment gaps', 'Recent graduates', 'Freelancers'],
      pros: ['Highlights relevant skills', 'Downplays employment gaps', 'Good for career transitions'],
      cons: ['Some recruiters suspicious of format', 'Difficult to see career progression', 'Not ATS-friendly'],
      image: 'https://readdy.ai/api/search-image?query=Functional%20resume%20format%20example%20with%20skills-based%20sections%2C%20competency-focused%20layout%2C%20professional%20design%20emphasizing%20abilities%20over%20chronological%20work%20history&width=400&height=300&seq=functional-format&orientation=landscape'
    },
    {
      id: 'combination',
      name: 'Combination Resume',
      description: 'Combines elements of both chronological and functional formats.',
      bestFor: ['Experienced professionals', 'Career changers with relevant skills', 'People changing industries'],
      pros: ['Shows both skills and experience', 'Flexible format', 'Highlights achievements'],
      cons: ['Can be longer than other formats', 'More complex to write', 'May seem repetitive'],
      image: 'https://readdy.ai/api/search-image?query=Combination%20resume%20format%20example%20blending%20skills%20section%20with%20chronological%20work%20history%2C%20hybrid%20layout%20showing%20both%20competencies%20and%20career%20timeline&width=400&height=300&seq=combination-format&orientation=landscape'
    },
    {
      id: 'targeted',
      name: 'Targeted Resume',
      description: 'Customized specifically for a particular job or company.',
      bestFor: ['Specific job applications', 'Competitive positions', 'Career-focused professionals'],
      pros: ['Highly relevant to job', 'Shows genuine interest', 'Better ATS matching'],
      cons: ['Time-consuming to create', 'Need multiple versions', 'Requires research'],
      image: 'https://readdy.ai/api/search-image?query=Targeted%20resume%20format%20example%20customized%20for%20specific%20job%20role%2C%20tailored%20content%20highlighting%20relevant%20experience%20and%20skills%20matching%20job%20requirements&width=400&height=300&seq=targeted-format&orientation=landscape'
    }
  ];

  const currentFormat = formats.find(f => f.id === selectedFormat) || formats[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>
            <Link href="/builder" className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap">
              Build Resume
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-green-600 to-emerald-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Resume Formats Guide
            </h1>
            <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
              Choose the right resume format for your career situation. Learn about different formats 
              and find the one that best showcases your experience and skills.
            </p>
          </div>
        </div>
      </section>

      {/* Format Selector */}
      <section className="py-8 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-4 justify-center">
            {formats.map((format) => (
              <button
                key={format.id}
                onClick={() => setSelectedFormat(format.id)}
                className={`px-6 py-3 rounded-lg font-medium transition-colors whitespace-nowrap ${
                  selectedFormat === format.id
                    ? 'bg-green-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {format.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Format Details */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Format Image */}
            <div className={`transition-all duration-500 ${isAnimated ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
                <img
                  src={currentFormat.image}
                  alt={currentFormat.name}
                  className="w-full h-80 object-cover object-top"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{currentFormat.name}</h3>
                  <p className="text-gray-600">{currentFormat.description}</p>
                </div>
              </div>
            </div>

            {/* Format Information */}
            <div className={`transition-all duration-500 delay-300 ${isAnimated ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <div className="space-y-8">
                {/* Best For */}
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                  <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <i className="ri-user-star-line text-green-600 mr-3"></i>
                    Best For
                  </h3>
                  <ul className="space-y-2">
                    {currentFormat.bestFor.map((item, index) => (
                      <li key={index} className="flex items-start">
                        <i className="ri-check-line text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                        <span className="text-gray-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Pros and Cons */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Pros */}
                  <div className="bg-green-50 rounded-2xl p-6 border border-green-200">
                    <h4 className="text-lg font-bold text-green-900 mb-4 flex items-center">
                      <i className="ri-thumb-up-line text-green-600 mr-2"></i>
                      Advantages
                    </h4>
                    <ul className="space-y-2">
                      {currentFormat.pros.map((pro, index) => (
                        <li key={index} className="flex items-start">
                          <i className="ri-check-line text-green-600 mr-2 mt-0.5 flex-shrink-0"></i>
                          <span className="text-green-800 text-sm">{pro}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Cons */}
                  <div className="bg-red-50 rounded-2xl p-6 border border-red-200">
                    <h4 className="text-lg font-bold text-red-900 mb-4 flex items-center">
                      <i className="ri-thumb-down-line text-red-600 mr-2"></i>
                      Disadvantages
                    </h4>
                    <ul className="space-y-2">
                      {currentFormat.cons.map((con, index) => (
                        <li key={index} className="flex items-start">
                          <i className="ri-close-line text-red-600 mr-2 mt-0.5 flex-shrink-0"></i>
                          <span className="text-red-800 text-sm">{con}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Action Button */}
                <div className="text-center">
                  <Link
                    href="/builder"
                    className="inline-block bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 rounded-lg hover:from-green-700 hover:to-emerald-700 transition-colors text-lg font-semibold whitespace-nowrap"
                  >
                    Use This Format
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Format Comparison */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Format Comparison</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Compare different resume formats to choose the one that best fits your career situation
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-2xl shadow-lg overflow-hidden">
              <thead className="bg-green-600 text-white">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold">Format</th>
                  <th className="px-6 py-4 text-left font-semibold">Work History Focus</th>
                  <th className="px-6 py-4 text-left font-semibold">Skills Emphasis</th>
                  <th className="px-6 py-4 text-left font-semibold">ATS Friendly</th>
                  <th className="px-6 py-4 text-left font-semibold">Best For</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">Chronological</td>
                  <td className="px-6 py-4 text-green-600">High</td>
                  <td className="px-6 py-4 text-yellow-600">Medium</td>
                  <td className="px-6 py-4 text-green-600">Excellent</td>
                  <td className="px-6 py-4 text-gray-700">Traditional careers</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">Functional</td>
                  <td className="px-6 py-4 text-red-600">Low</td>
                  <td className="px-6 py-4 text-green-600">High</td>
                  <td className="px-6 py-4 text-red-600">Poor</td>
                  <td className="px-6 py-4 text-gray-700">Career changers</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">Combination</td>
                  <td className="px-6 py-4 text-yellow-600">Medium</td>
                  <td className="px-6 py-4 text-green-600">High</td>
                  <td className="px-6 py-4 text-yellow-600">Good</td>
                  <td className="px-6 py-4 text-gray-700">Experienced pros</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">Targeted</td>
                  <td className="px-6 py-4 text-green-600">High</td>
                  <td className="px-6 py-4 text-green-600">High</td>
                  <td className="px-6 py-4 text-green-600">Excellent</td>
                  <td className="px-6 py-4 text-gray-700">Specific roles</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Tips Section */}
      <section className="py-16 bg-gradient-to-r from-emerald-600 to-green-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-6">Resume Format Tips</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-eye-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">Consider Your Audience</h3>
              <p className="text-emerald-100">
                Research the company culture and industry norms to choose the most appropriate format.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-focus-3-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">Highlight Your Strengths</h3>
              <p className="text-emerald-100">
                Choose a format that emphasizes your strongest qualifications and achievements.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-refresh-line text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">Stay Flexible</h3>
              <p className="text-emerald-100">
                Be prepared to adjust your format based on specific job requirements and feedback.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Ready to Choose Your Format?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Start building your resume with the format that best showcases your unique background
          </p>
          <Link
            href="/builder"
            className="inline-block bg-green-600 text-white px-8 py-4 rounded-lg hover:bg-green-700 transition-colors text-lg font-semibold whitespace-nowrap"
          >
            Start Building Your Resume
          </Link>
        </div>
      </section>
    </div>
  );
}