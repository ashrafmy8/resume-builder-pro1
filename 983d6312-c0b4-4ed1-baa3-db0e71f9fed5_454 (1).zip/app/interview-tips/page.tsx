'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function InterviewTipsPage() {
  const [activeTab, setActiveTab] = useState('preparation');

  const tabs = [
    { id: 'preparation', name: 'Preparation', icon: 'ri-book-open-line' },
    { id: 'questions', name: 'Common Questions', icon: 'ri-question-line' },
    { id: 'techniques', name: 'Techniques', icon: 'ri-lightbulb-line' },
    { id: 'follow-up', name: 'Follow-up', icon: 'ri-mail-send-line' }
  ];

  const commonQuestions = [
    {
      question: "Tell me about yourself",
      category: "Introduction",
      difficulty: "Easy",
      tips: "Focus on your professional journey, key achievements, and what brings you to this role.",
      example: "I'm a software engineer with 5 years of experience building scalable web applications. I started at a startup where I wore many hats, then moved to a larger company to specialize in frontend development. I'm passionate about creating user-friendly interfaces and have led several successful product launches."
    },
    {
      question: "Why do you want to work here?",
      category: "Company Interest",
      difficulty: "Medium",
      tips: "Research the company thoroughly and connect their mission to your career goals.",
      example: "I'm excited about your company's commitment to sustainability and innovation. Your recent launch of the eco-friendly product line aligns perfectly with my values, and I see this as an opportunity to contribute to meaningful work while growing my skills in product development."
    },
    {
      question: "What are your strengths and weaknesses?",
      category: "Self-Assessment",
      difficulty: "Medium",
      tips: "Choose real strengths relevant to the role, and share a genuine weakness you're actively working to improve.",
      example: "My strength is problem-solving - I enjoy breaking down complex issues into manageable parts. As for weaknesses, I used to struggle with delegation, but I've been working with a mentor to develop my leadership skills and trust my team more."
    },
    {
      question: "Describe a challenging situation you overcame",
      category: "Behavioral",
      difficulty: "Hard",
      tips: "Use the STAR method: Situation, Task, Action, Result. Focus on your role and the positive outcome.",
      example: "When our main server crashed during peak hours, I immediately assessed the situation, coordinated with the infrastructure team, implemented our backup plan, and communicated updates to stakeholders. We restored service within 2 hours and prevented similar issues with improved monitoring."
    }
  ];

  const interviewTypes = [
    {
      type: "Phone/Video Interview",
      icon: "ri-phone-line",
      color: "blue",
      tips: [
        "Test your technology beforehand",
        "Choose a quiet, well-lit location",
        "Have your resume and notes ready",
        "Maintain eye contact with the camera",
        "Dress professionally from head to toe"
      ]
    },
    {
      type: "Panel Interview",
      icon: "ri-team-line",
      color: "green",
      tips: [
        "Address all panel members when answering",
        "Make eye contact with everyone",
        "Ask for names and roles at the start",
        "Prepare questions for different perspectives",
        "Send thank you notes to each member"
      ]
    },
    {
      type: "Technical Interview",
      icon: "ri-code-line",
      color: "purple",
      tips: [
        "Practice coding problems beforehand",
        "Think out loud during problem-solving",
        "Ask clarifying questions",
        "Test your solution thoroughly",
        "Explain your approach clearly"
      ]
    },
    {
      type: "Behavioral Interview",
      icon: "ri-user-heart-line",
      color: "orange",
      tips: [
        "Prepare STAR method examples",
        "Focus on specific situations",
        "Highlight your role and actions",
        "Quantify results when possible",
        "Show growth and learning"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-discuss-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-['Pacifico'] text-blue-600">ResumeTeacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/advice" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Advice
              </Link>
              <Link href="/interview-tips" className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-1 whitespace-nowrap">
                Interview Tips
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700 relative">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://readdy.ai/api/search-image?query=Professional%20job%20interview%20coaching%20session%20with%20confident%20candidate%20practicing%20answers%2C%20modern%20office%20boardroom%20setting%20with%20interviewer%20and%20notes%2C%20positive%20and%20encouraging%20atmosphere%2C%20career%20preparation%20and%20success&width=1200&height=600&seq=interview-tips-hero&orientation=landscape"
            alt="Interview Tips"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h1 className="text-5xl font-bold text-white mb-6">
            Master Your Next Interview
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Get expert interview tips and strategies that will help you stand out from the competition 
            and land your dream job with confidence.
          </p>
          <div className="flex justify-center space-x-4">
            <Link href="#preparation" className="inline-flex items-center px-6 py-3 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold">
              <i className="ri-book-open-line mr-2"></i>
              Start Preparing
            </Link>
            <Link href="/job-search-tips" className="inline-flex items-center px-6 py-3 border-2 border-white text-white rounded-lg hover:bg-white hover:text-blue-600 transition-colors font-semibold">
              <i className="ri-search-line mr-2"></i>
              Job Search Tips
            </Link>
          </div>
        </div>
      </section>

      {/* Tabs Navigation */}
      <section className="py-8 bg-white border-b border-gray-100" id="preparation">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-6 py-3 rounded-lg border-2 transition-all duration-300 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-white text-gray-700 border-gray-200 hover:border-blue-300 hover:text-blue-600'
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Preparation Tab */}
      {activeTab === 'preparation' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Interview Preparation Guide</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Proper preparation is the key to interview success. Follow this comprehensive guide to ace your next interview.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {interviewTypes.map((type, index) => (
                <div key={index} className={`bg-gradient-to-br from-${type.color}-50 to-${type.color}-100 border border-${type.color}-200 rounded-xl p-6`}>
                  <div className={`w-12 h-12 bg-${type.color}-600 rounded-lg flex items-center justify-center mb-4`}>
                    <i className={`${type.icon} text-white text-xl`}></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">{type.type}</h3>
                  <ul className="space-y-2">
                    {type.tips.map((tip, tipIndex) => (
                      <li key={tipIndex} className="flex items-start space-x-2">
                        <i className={`ri-check-line text-${type.color}-600 text-sm mt-1 flex-shrink-0`}></i>
                        <span className="text-gray-600 text-sm">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Research Checklist */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Pre-Interview Research Checklist</h3>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Company Research</h4>
                  <div className="space-y-3">
                    {[
                      'Company mission, values, and culture',
                      'Recent news and achievements',
                      'Products, services, and competitors',
                      'Financial performance and growth',
                      'Leadership team and key employees'
                    ].map((item, index) => (
                      <label key={index} className="flex items-center space-x-3 cursor-pointer">
                        <input type="checkbox" className="w-4 h-4 text-blue-600 bg-white border-2 border-gray-300 rounded focus:ring-blue-500" />
                        <span className="text-gray-700">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Role Preparation</h4>
                  <div className="space-y-3">
                    {[
                      'Job description and requirements',
                      'Team structure and reporting',
                      'Growth opportunities and career path',
                      'Salary range and benefits',
                      'Questions to ask the interviewer'
                    ].map((item, index) => (
                      <label key={index} className="flex items-center space-x-3 cursor-pointer">
                        <input type="checkbox" className="w-4 h-4 text-blue-600 bg-white border-2 border-gray-300 rounded focus:ring-blue-500" />
                        <span className="text-gray-700">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Common Questions Tab */}
      {activeTab === 'questions' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Common Interview Questions</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Practice these frequently asked questions with proven answer frameworks and examples.
              </p>
            </div>

            <div className="space-y-8">
              {commonQuestions.map((q, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-xl p-8 hover:shadow-lg transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">"{q.question}"</h3>
                    <div className="flex items-center space-x-3">
                      <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                        {q.category}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        q.difficulty === 'Easy' ? 'bg-green-100 text-green-700' :
                        q.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {q.difficulty}
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid lg:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">💡 How to Answer:</h4>
                      <p className="text-gray-600 mb-4">{q.tips}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">📝 Example Answer:</h4>
                      <p className="text-gray-600 italic">{q.example}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Success Stories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Interview Success Stories</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real stories from professionals who landed their dream jobs using our interview tips.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Jennifer Kim",
                role: "Product Manager at Meta",
                image: "Professional headshot of Jennifer Kim, product manager at Meta, confident and successful in modern tech office environment",
                story: "The STAR method helped me structure my answers perfectly. I got the offer after a 6-round interview process!"
              },
              {
                name: "Carlos Rodriguez",
                role: "Senior Developer at Netflix",
                image: "Professional headshot of Carlos Rodriguez, senior developer at Netflix, confident tech professional in modern development workspace",
                story: "Practicing technical questions and behavioral scenarios gave me the confidence to excel in both rounds."
              },
              {
                name: "Dr. Sarah Chen",
                role: "Medical Director at Kaiser",
                image: "Professional headshot of Dr. Sarah Chen, medical director at Kaiser, confident healthcare professional in medical facility",
                story: "The preparation checklist was invaluable. I knew everything about the organization and impressed the panel."
              }
            ].map((story, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="w-20 h-20 bg-gray-100 rounded-full mx-auto mb-4 overflow-hidden">
                  <img
                    src={`https://readdy.ai/api/search-image?query=$%7Bstory.image%7D&width=150&height=150&seq=success-story-${index}&orientation=squarish`}
                    alt={story.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 text-center mb-2">{story.name}</h3>
                <p className="text-blue-600 font-medium text-center mb-4">{story.role}</p>
                <p className="text-gray-600 italic text-center">"{story.story}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Ace Your Interview?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Start with a strong resume that gets you the interview, then use our tips to land the job.
          </p>
          <Link href="/builder" className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold">
            <i className="ri-rocket-2-line mr-2"></i>
            Build My Resume
          </Link>
        </div>
      </section>
    </div>
  );
}