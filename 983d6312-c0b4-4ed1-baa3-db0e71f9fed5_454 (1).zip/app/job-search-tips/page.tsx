'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function JobSearchTipsPage() {
  const [activeStrategy, setActiveStrategy] = useState('networking');

  const strategies = [
    { id: 'networking', name: 'Networking', icon: 'ri-team-line' },
    { id: 'online', name: 'Online Platforms', icon: 'ri-computer-line' },
    { id: 'direct', name: 'Direct Applications', icon: 'ri-send-plane-line' },
    { id: 'recruiters', name: 'Recruiters', icon: 'ri-user-search-line' }
  ];

  const jobBoards = [
    {
      name: "LinkedIn",
      type: "Professional Network",
      strengths: ["Professional networking", "Industry insights", "Company research"],
      tips: ["Optimize your profile", "Engage with content", "Connect strategically"],
      color: "blue"
    },
    {
      name: "Indeed",
      type: "Job Aggregator",
      strengths: ["Vast job database", "Easy application", "Salary insights"],
      tips: ["Set up job alerts", "Research companies", "Apply quickly"],
      color: "green"
    },
    {
      name: "Glassdoor",
      type: "Company Reviews",
      strengths: ["Company reviews", "Salary data", "Interview insights"],
      tips: ["Read reviews", "Research salaries", "Prepare for interviews"],
      color: "purple"
    },
    {
      name: "AngelList",
      type: "Startup Jobs",
      strengths: ["Startup ecosystem", "Equity information", "Direct founder contact"],
      tips: ["Show startup interest", "Highlight adaptability", "Research funding"],
      color: "orange"
    }
  ];

  const networkingTips = [
    {
      strategy: "Professional Events",
      description: "Attend industry conferences, meetups, and workshops",
      actions: [
        "Research upcoming events in your field",
        "Prepare your elevator pitch",
        "Bring business cards or digital contact info",
        "Follow up within 48 hours"
      ]
    },
    {
      strategy: "LinkedIn Networking",
      description: "Build meaningful professional relationships online",
      actions: [
        "Send personalized connection requests",
        "Engage with others' content regularly",
        "Share valuable industry insights",
        "Offer help before asking for favors"
      ]
    },
    {
      strategy: "Informational Interviews",
      description: "Learn from professionals in your target roles",
      actions: [
        "Identify professionals in your desired field",
        "Request 15-20 minute conversations",
        "Prepare thoughtful questions",
        "Send thank you notes and updates"
      ]
    },
    {
      strategy: "Alumni Networks",
      description: "Leverage your educational connections",
      actions: [
        "Join alumni associations and groups",
        "Attend alumni networking events",
        "Reach out to alumni in target companies",
        "Offer to help current students"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-search-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-['Pacifico'] text-green-600">ResumeTeacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/advice" className="text-gray-700 hover:text-green-600 transition-colors whitespace-nowrap">
                Advice
              </Link>
              <Link href="/job-search-tips" className="text-green-600 font-semibold border-b-2 border-green-600 pb-1 whitespace-nowrap">
                Job Search Tips
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-green-600 transition-colors border border-gray-300 rounded-lg hover:border-green-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-emerald-700 relative">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://readdy.ai/api/search-image?query=Professional%20job%20seeker%20researching%20opportunities%20on%20laptop%20at%20modern%20coworking%20space%2C%20surrounded%20by%20career%20planning%20materials%20and%20notes%2C%20focused%20and%20determined%20expression%2C%20inspiring%20career%20search%20atmosphere%20with%20plants%20and%20natural%20lighting&width=1200&height=600&seq=job-search-hero&orientation=landscape"
            alt="Job Search Tips"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h1 className="text-5xl font-bold text-white mb-6">
            Strategic Job Search Guide
          </h1>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Master proven job search strategies that go beyond job boards. Learn how to find hidden opportunities 
            and accelerate your path to your dream job.
          </p>
          <div className="flex justify-center space-x-4">
            <Link href="#strategies" className="inline-flex items-center px-6 py-3 bg-white text-green-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold">
              <i className="ri-lightbulb-line mr-2"></i>
              Explore Strategies
            </Link>
            <Link href="/interview-tips" className="inline-flex items-center px-6 py-3 border-2 border-white text-white rounded-lg hover:bg-white hover:text-green-600 transition-colors font-semibold">
              <i className="ri-discuss-line mr-2"></i>
              Interview Tips
            </Link>
          </div>
        </div>
      </section>

      {/* Job Search Statistics */}
      <section className="py-16 bg-white" id="strategies">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">The Hidden Job Market</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Understanding where jobs actually come from will revolutionize your search strategy.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">80%</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Hidden Jobs</h3>
              <p className="text-gray-600">Never advertised publicly</p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">70%</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Through Networking</h3>
              <p className="text-gray-600">Found via professional connections</p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-purple-600">15%</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Online Job Boards</h3>
              <p className="text-gray-600">Found through traditional applications</p>
            </div>
            <div className="text-center">
              <div className="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">15%</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Recruiters</h3>
              <p className="text-gray-600">Through recruitment agencies</p>
            </div>
          </div>

          {/* Strategy Selector */}
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Choose Your Strategy</h3>
              <p className="text-gray-600">Select a job search approach to learn more</p>
            </div>
            
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              {strategies.map((strategy) => (
                <button
                  key={strategy.id}
                  onClick={() => setActiveStrategy(strategy.id)}
                  className={`flex items-center px-6 py-3 rounded-lg border-2 transition-all ${
                    activeStrategy === strategy.id
                      ? 'bg-green-600 text-white border-green-600'
                      : 'bg-white text-gray-700 border-gray-200 hover:border-green-300 hover:text-green-600'
                  }`}
                >
                  <i className={`${strategy.icon} mr-2`}></i>
                  {strategy.name}
                </button>
              ))}
            </div>

            {/* Networking Strategy */}
            {activeStrategy === 'networking' && (
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-xl font-semibold text-gray-900 mb-6">Networking Strategies</h4>
                  <div className="space-y-6">
                    {networkingTips.map((tip, index) => (
                      <div key={index} className="bg-white rounded-lg p-6 border border-gray-200">
                        <h5 className="font-semibold text-gray-900 mb-2">{tip.strategy}</h5>
                        <p className="text-gray-600 mb-4">{tip.description}</p>
                        <ul className="space-y-2">
                          {tip.actions.map((action, actionIndex) => (
                            <li key={actionIndex} className="flex items-start space-x-2">
                              <i className="ri-check-line text-green-600 text-sm mt-1 flex-shrink-0"></i>
                              <span className="text-gray-600 text-sm">{action}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <img
                    src="https://readdy.ai/api/search-image?query=Professional%20networking%20event%20with%20diverse%20business%20people%20exchanging%20business%20cards%20and%20having%20meaningful%20conversations%2C%20modern%20conference%20center%20setting%20with%20laptops%20and%20presentations%2C%20collaborative%20and%20engaging%20atmosphere&width=500&height=600&seq=networking-strategy&orientation=portrait"
                    alt="Professional Networking"
                    className="w-full h-auto rounded-xl shadow-lg"
                  />
                </div>
              </div>
            )}

            {/* Online Platforms Strategy */}
            {activeStrategy === 'online' && (
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-6 text-center">Top Job Search Platforms</h4>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {jobBoards.map((board, index) => (
                    <div key={index} className={`bg-white rounded-xl p-6 border-2 border-${board.color}-200`}>
                      <div className={`w-12 h-12 bg-${board.color}-600 rounded-lg flex items-center justify-center mb-4`}>
                        <i className="ri-global-line text-white text-xl"></i>
                      </div>
                      <h5 className="font-semibold text-gray-900 mb-2">{board.name}</h5>
                      <p className={`text-${board.color}-600 text-sm mb-4`}>{board.type}</p>
                      
                      <div className="mb-4">
                        <h6 className="font-medium text-gray-900 mb-2">Strengths:</h6>
                        <ul className="space-y-1">
                          {board.strengths.map((strength, sIndex) => (
                            <li key={sIndex} className="text-gray-600 text-sm flex items-center">
                              <i className={`ri-star-line text-${board.color}-500 mr-2 text-xs`}></i>
                              {strength}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h6 className="font-medium text-gray-900 mb-2">Tips:</h6>
                        <ul className="space-y-1">
                          {board.tips.map((tip, tIndex) => (
                            <li key={tIndex} className="text-gray-600 text-sm flex items-start">
                              <i className={`ri-check-line text-${board.color}-500 mr-2 text-xs mt-1 flex-shrink-0`}></i>
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Job Search Timeline */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">30-Day Job Search Plan</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A structured approach to maximize your job search effectiveness in one month.
            </p>
          </div>

          <div className="space-y-8">
            {[
              {
                week: "Week 1",
                title: "Foundation & Setup",
                color: "blue",
                tasks: [
                  "Update and optimize your resume",
                  "Enhance your LinkedIn profile",
                  "Define your target roles and companies",
                  "Set up job alerts on major platforms"
                ]
              },
              {
                week: "Week 2",
                title: "Research & Network",
                color: "green",
                tasks: [
                  "Research 20 target companies thoroughly",
                  "Identify key contacts in target companies",
                  "Attend 2-3 networking events or webinars",
                  "Reach out to 10 professional connections"
                ]
              },
              {
                week: "Week 3",
                title: "Apply & Connect",
                color: "purple",
                tasks: [
                  "Submit 15-20 quality applications",
                  "Schedule 3-5 informational interviews",
                  "Follow up on previous applications",
                  "Engage actively on LinkedIn"
                ]
              },
              {
                week: "Week 4",
                title: "Interview & Follow-up",
                color: "orange",
                tasks: [
                  "Prepare for scheduled interviews",
                  "Send thank you notes promptly",
                  "Continue networking and applying",
                  "Evaluate and adjust your strategy"
                ]
              }
            ].map((week, index) => (
              <div key={index} className="flex items-start space-x-6">
                <div className={`w-16 h-16 bg-${week.color}-600 rounded-full flex items-center justify-center flex-shrink-0`}>
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                <div className="flex-1 bg-white rounded-xl p-6 shadow-lg">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">{week.week}: {week.title}</h3>
                    <span className={`bg-${week.color}-100 text-${week.color}-700 px-3 py-1 rounded-full text-sm font-medium`}>
                      {week.week}
                    </span>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    {week.tasks.map((task, taskIndex) => (
                      <div key={taskIndex} className="flex items-center space-x-3">
                        <i className={`ri-check-line text-${week.color}-600`}></i>
                        <span className="text-gray-700">{task}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Metrics */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Track Your Success</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Monitor these key metrics to optimize your job search strategy.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { metric: "Application Rate", target: "15-20 per week", icon: "ri-send-plane-line", color: "blue" },
              { metric: "Response Rate", target: "15-20%", icon: "ri-mail-check-line", color: "green" },
              { metric: "Interview Rate", target: "5-10%", icon: "ri-discuss-line", color: "purple" },
              { metric: "Offer Rate", target: "20-30%", icon: "ri-award-line", color: "orange" }
            ].map((item, index) => (
              <div key={index} className={`bg-gradient-to-br from-${item.color}-50 to-${item.color}-100 rounded-xl p-6 text-center`}>
                <div className={`w-16 h-16 bg-${item.color}-600 rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <i className={`${item.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.metric}</h3>
                <p className={`text-${item.color}-600 font-medium`}>{item.target}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-emerald-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Start Your Strategic Job Search
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Begin with a compelling resume that opens doors, then apply these proven strategies to accelerate your search.
          </p>
          <Link href="/builder" className="inline-flex items-center px-8 py-4 bg-white text-green-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold">
            <i className="ri-rocket-2-line mr-2"></i>
            Build My Resume
          </Link>
        </div>
      </section>
    </div>
  );
}