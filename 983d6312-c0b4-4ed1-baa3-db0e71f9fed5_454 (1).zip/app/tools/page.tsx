'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../../components/Header';

export default function ToolsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Resume Tools', 'Career Planning', 'Job Search', 'Interview Prep', 'Calculators'];

  const tools = [
    {
      id: 1,
      name: "AI Resume Builder",
      description: "Create professional resumes with AI-powered content suggestions and ATS optimization.",
      category: "Resume Tools",
      icon: "ri-magic-line",
      color: "from-blue-500 to-indigo-600",
      href: "/builder",
      features: ["AI Writing Assistant", "ATS Optimization", "Professional Templates", "Real-time Preview"],
      popular: true
    },
    {
      id: 2,
      name: "ATS Resume Checker",
      description: "Analyze your resume's compatibility with Applicant Tracking Systems and get improvement suggestions.",
      category: "Resume Tools",
      icon: "ri-shield-check-line",
      color: "from-green-500 to-emerald-600",
      href: "/ats-resume-checker",
      features: ["ATS Compatibility Score", "Keyword Analysis", "Format Optimization", "Detailed Feedback"]
    },
    {
      id: 3,
      name: "Cover Letter Builder",
      description: "Build compelling cover letters that complement your resume and grab employer attention.",
      category: "Resume Tools",
      icon: "ri-file-text-line",
      color: "from-purple-500 to-pink-600",
      href: "/cover-letter-builder",
      features: ["Template Selection", "Personalization Tools", "Industry Examples", "Expert Tips"]
    },
    {
      id: 4,
      name: "Salary Calculator",
      description: "Research salary ranges for your role and location to negotiate with confidence.",
      category: "Calculators",
      icon: "ri-money-dollar-circle-line",
      color: "from-yellow-500 to-orange-600",
      href: "/tools/salary-calculator",
      features: ["Location Adjustment", "Experience Level", "Industry Comparison", "Benefits Analysis"]
    },
    {
      id: 5,
      name: "Career Path Planner",
      description: "Map out your career trajectory and identify the skills needed for your dream role.",
      category: "Career Planning",
      icon: "ri-route-line",
      color: "from-teal-500 to-cyan-600",
      href: "/tools/career-planner",
      features: ["Goal Setting", "Skill Gap Analysis", "Timeline Planning", "Milestone Tracking"]
    },
    {
      id: 6,
      name: "Job Application Tracker",
      description: "Keep track of all your job applications, interviews, and follow-ups in one organized place.",
      category: "Job Search",
      icon: "ri-table-line",
      color: "from-indigo-500 to-purple-600",
      href: "/tools/application-tracker",
      features: ["Application Status", "Interview Scheduling", "Follow-up Reminders", "Analytics Dashboard"]
    },
    {
      id: 7,
      name: "LinkedIn Profile Optimizer",
      description: "Optimize your LinkedIn profile for maximum visibility and professional impact.",
      category: "Job Search",
      icon: "ri-linkedin-fill",
      color: "from-blue-600 to-blue-700",
      href: "/tools/linkedin-optimizer",
      features: ["Headline Optimization", "Summary Enhancement", "Keyword Strategy", "Profile Score"]
    },
    {
      id: 8,
      name: "Interview Question Generator",
      description: "Practice with AI-generated interview questions tailored to your industry and role.",
      category: "Interview Prep",
      icon: "ri-question-answer-line",
      color: "from-red-500 to-pink-600",
      href: "/tools/interview-questions",
      features: ["Role-Specific Questions", "STAR Method Practice", "Answer Evaluation", "Progress Tracking"]
    },
    {
      id: 9,
      name: "Skills Assessment Tool",
      description: "Evaluate your professional skills and get recommendations for improvement areas.",
      category: "Career Planning",
      icon: "ri-bar-chart-line",
      color: "from-emerald-500 to-teal-600",
      href: "/tools/skills-assessment",
      features: ["Skill Evaluation", "Industry Benchmarks", "Learning Recommendations", "Progress Reports"]
    }
  ];

  const filteredTools = selectedCategory === 'All' 
    ? tools 
    : tools.filter(tool => tool.category === selectedCategory);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Career Development Tools
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Powerful tools to accelerate your career growth. From resume building to salary negotiation, 
            we've got everything you need to succeed in your job search and career advancement.
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full transition-colors whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredTools.map((tool) => (
              <div key={tool.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className={`h-2 bg-gradient-to-r ${tool.color}`}></div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-r ${tool.color} rounded-xl flex items-center justify-center`}>
                      <i className={`${tool.icon} text-white text-xl`}></i>
                    </div>
                    {tool.popular && (
                      <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full text-xs font-medium">
                        Popular
                      </span>
                    )}
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {tool.name}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {tool.description}
                  </p>
                  
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Key Features:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {tool.features.map((feature, index) => (
                        <li key={index} className="flex items-center">
                          <i className="ri-check-line text-green-500 mr-2"></i>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Link 
                    href={tool.href} 
                    className={`w-full bg-gradient-to-r ${tool.color} text-white px-4 py-3 rounded-lg hover:opacity-90 transition-opacity font-semibold text-center block whitespace-nowrap`}
                  >
                    Use Tool
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trustpilot Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <img 
              src="https://readdy.ai/api/search-image?query=Trustpilot%20logo%20with%20green%20star%20rating%2C%20professional%20clean%20design%20on%20white%20background%2C%20high%20quality%20brand%20logo%20with%20trustpilot%20text%20and%20green%20star%20symbol&width=140&height=50&seq=trustpilot-brand-logo&orientation=landscape"
              alt="Trustpilot"
              className="h-10"
            />
            <div className="flex items-center space-x-1">
              <div className="flex text-green-500">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-lg"></i>
                ))}
              </div>
              <span className="text-gray-700 font-bold ml-2">4.8/5 Excellent</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Tools That Deliver Results</h2>
          <p className="text-gray-600 mb-8">Based on 28,847 reviews • Trusted by job seekers worldwide</p>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex text-green-500 justify-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill"></i>
                ))}
              </div>
              <p className="text-gray-700 italic mb-4">
                "The Resume Builder and ATS Checker combo is incredible! Fixed my resume issues and landed 3 interviews in one week."
              </p>
              <div className="flex items-center justify-center space-x-2">
                <span className="font-semibold text-gray-900">Kevin Park</span>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">✓ Verified</span>
              </div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex text-green-500 justify-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill"></i>
                ))}
              </div>
              <p className="text-gray-700 italic mb-4">
                "The Career Path Planner helped me map out my next 5 years. Now I have a clear strategy for my career growth!"
              </p>
              <div className="flex items-center justify-center space-x-2">
                <span className="font-semibold text-gray-900">Amanda Chen</span>
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">✓ Verified</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Start Building Your Career Today</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands who've accelerated their careers with our powerful tools. Start with our most popular AI Resume Builder.
          </p>
          <Link href="/builder" className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg inline-flex items-center whitespace-nowrap">
            Build My Resume
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-file-text-line text-white text-lg"></i>
                </div>
                <span className="text-xl font-['Pacifico']">ResumeTeacher</span>
              </div>
              <p className="text-gray-400 mb-4">
                Build professional resumes with AI assistance and land your dream job faster.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Popular Tools</h3>
              <ul className="space-y-2">
                <li><Link href="/builder" className="text-gray-400 hover:text-white transition-colors">Resume Builder</Link></li>
                <li><Link href="/ats-resume-checker" className="text-gray-400 hover:text-white transition-colors">ATS Checker</Link></li>
                <li><Link href="/cover-letter-builder" className="text-gray-400 hover:text-white transition-colors">Cover Letter Builder</Link></li>
                <li><Link href="/tools/salary-calculator" className="text-gray-400 hover:text-white transition-colors">Salary Calculator</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Career Resources</h3>
              <ul className="space-y-2">
                <li><Link href="/guides" className="text-gray-400 hover:text-white transition-colors">Career Guides</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</Link></li>
                <li><Link href="/advice" className="text-gray-400 hover:text-white transition-colors">Career Advice</Link></li>
                <li><Link href="/interview-tips" className="text-gray-400 hover:text-white transition-colors">Interview Tips</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2">
                <li><Link href="/help" className="text-gray-400 hover:text-white transition-colors">Help Center</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link></li>
                <li><Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2025 ResumeTeacher. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}