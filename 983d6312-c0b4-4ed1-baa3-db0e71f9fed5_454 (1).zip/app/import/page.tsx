'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function ImportResume() {
  const [isAnimated, setIsAnimated] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [extractedData, setExtractedData] = useState<any>(null);
  const [extractionError, setExtractionError] = useState('');

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (file: File) => {
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    
    if (!allowedTypes.includes(file.type)) {
      alert('Please upload a PDF, Word document, or text file');
      return;
    }

    setSelectedFile(file);
    setExtractionError('');
    await extractResumeData(file);
  };

  const extractResumeData = async (file: File) => {
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Simulate progress during upload
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + Math.random() * 20;
        });
      }, 200);

      // Call the AI extraction function
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/extract-resume-data`, {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`,
        },
      });

      clearInterval(progressInterval);
      
      if (!response.ok) {
        throw new Error('Failed to extract resume data');
      }

      const result = await response.json();
      
      if (result.success) {
        setExtractedData(result.data);
        setUploadProgress(100);
        setUploadComplete(true);
        
        // Store extracted data in localStorage for the builder
        localStorage.setItem('extractedResumeData', JSON.stringify(result.data));
      } else {
        throw new Error(result.error || 'Extraction failed');
      }
      
    } catch (error) {
      console.error('Extraction error:', error);
      setExtractionError('Failed to extract resume data. Please try again or use the manual entry option.');
      setUploadProgress(0);
    } finally {
      setIsUploading(false);
    }
  };

  const resetUpload = () => {
    setSelectedFile(null);
    setUploadProgress(0);
    setIsUploading(false);
    setUploadComplete(false);
    setExtractedData(null);
    setExtractionError('');
    localStorage.removeItem('extractedResumeData');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-r from-blue-400/20 to-indigo-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-r from-purple-400/20 to-pink-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-gradient-to-r from-cyan-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Header */}
      <header className="relative bg-white/80 backdrop-blur-lg shadow-lg border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center group">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-file-text-line text-white text-xl"></i>
              </div>
              <span className="ml-3 text-2xl font-['Pacifico'] bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">ResumeTeacher</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`text-center transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="flex justify-center mb-8">
              <div className="relative">
                <img
                  src="https://readdy.ai/api/search-image?query=Professional%20business%20woman%20uploading%20resume%20document%20to%20computer%2C%20modern%20office%20workspace%20with%20laptop%20and%20documents%2C%20confident%20expression%2C%20clean%20contemporary%20design%2C%20bright%20natural%20lighting%2C%20digital%20technology%20concept%2C%20inspiring%20professional%20atmosphere&width=400&height=250&seq=import-hero&orientation=landscape"
                  alt="Import Resume"
                  className="w-96 h-60 object-cover object-top rounded-2xl shadow-2xl hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute -top-4 -right-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-3 rounded-xl shadow-lg animate-bounce">
                  <i className="ri-upload-cloud-line text-xl"></i>
                </div>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent mb-6">
              Import Your Existing Resume
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Upload your current resume and let our AI automatically extract and organize your information into editable fields for easy enhancement
            </p>
          </div>

          {/* Upload Section */}
          <div className={`transition-all duration-1000 delay-300 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-2xl border border-white/30 p-8 hover:shadow-3xl transition-all duration-500">
              
              {!uploadComplete ? (
                <div>
                  {/* Drag & Drop Area */}
                  <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    className={`border-3 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
                      dragActive 
                        ? 'border-blue-500 bg-blue-50/50 scale-105' 
                        : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50/30'
                    }`}
                  >
                    <div className="space-y-6">
                      <div className="flex justify-center">
                        <div className={`w-24 h-24 rounded-2xl flex items-center justify-center transition-all duration-300 ${
                          dragActive 
                            ? 'bg-gradient-to-r from-blue-500 to-indigo-600 scale-110' 
                            : 'bg-gradient-to-r from-gray-400 to-gray-500 hover:from-blue-500 hover:to-indigo-600'
                        }`}>
                          <i className={`text-white text-4xl transition-transform duration-300 ${
                            dragActive ? 'ri-download-cloud-line animate-bounce' : 'ri-upload-cloud-line'
                          }`}></i>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-3">
                          {dragActive ? 'Drop your resume here!' : 'Upload Your Resume'}
                        </h3>
                        <p className="text-gray-600 mb-6">
                          Drag and drop your resume file here, or click to browse. Our AI will automatically extract all your information.
                        </p>
                        
                        <input
                          type="file"
                          id="fileInput"
                          className="hidden"
                          accept=".pdf,.doc,.docx,.txt"
                          onChange={handleFileInput}
                        />
                        
                        <label
                          htmlFor="fileInput"
                          className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-blue-200/50 hover:-translate-y-1 whitespace-nowrap"
                        >
                          <i className="ri-folder-open-line mr-2 text-xl"></i>
                          Choose File
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-center space-x-6 text-sm text-gray-500">
                        <div className="flex items-center space-x-2">
                          <i className="ri-file-pdf-line text-red-500 text-lg"></i>
                          <span>PDF</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <i className="ri-file-word-line text-blue-500 text-lg"></i>
                          <span>DOC</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <i className="ri-file-word-line text-blue-600 text-lg"></i>
                          <span>DOCX</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <i className="ri-file-text-line text-gray-500 text-lg"></i>
                          <span>TXT</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Upload Progress */}
                  {isUploading && (
                    <div className="mt-8 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <i className="ri-file-text-line text-blue-600 text-xl"></i>
                          <span className="font-medium text-gray-900">{selectedFile?.name}</span>
                        </div>
                        <span className="text-blue-600 font-semibold">{Math.round(uploadProgress)}%</span>
                      </div>
                      
                      <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-300 ease-out"
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      
                      <div className="flex items-center justify-center space-x-2 text-blue-600">
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-100"></div>
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-200"></div>
                        <span className="ml-3 font-medium">AI is extracting your data...</span>
                      </div>
                    </div>
                  )}

                  {/* Error Display */}
                  {extractionError && (
                    <div className="mt-8 p-4 bg-red-50/80 backdrop-blur-sm border border-red-200/50 rounded-xl">
                      <div className="flex items-start space-x-3">
                        <i className="ri-error-warning-line text-red-500 text-xl flex-shrink-0 mt-0.5"></i>
                        <div>
                          <h4 className="font-semibold text-red-800 mb-1">Extraction Failed</h4>
                          <p className="text-red-700 text-sm">{extractionError}</p>
                          <button
                            onClick={resetUpload}
                            className="mt-3 text-red-600 hover:text-red-700 underline text-sm"
                          >
                            Try again
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* Upload Success */
                <div className="text-center space-y-6">
                  <div className="flex justify-center">
                    <div className="w-24 h-24 bg-gradient-to-r from-emerald-500 to-green-600 rounded-2xl flex items-center justify-center animate-pulse">
                      <i className="ri-check-line text-white text-4xl"></i>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">Data Extracted Successfully!</h3>
                    <p className="text-gray-600 mb-6">
                      Our AI has successfully analyzed your resume and extracted your information. 
                      All data will be automatically filled into the editable form fields.
                    </p>
                  </div>

                  {/* Extracted Data Preview */}
                  {extractedData && (
                    <div className="bg-gradient-to-r from-emerald-50/80 to-green-50/80 backdrop-blur-sm border border-emerald-200/50 rounded-xl p-6 mb-6">
                      <h4 className="font-semibold text-emerald-800 mb-4 text-left">Extracted Information Preview:</h4>
                      <div className="grid md:grid-cols-2 gap-4 text-left text-sm">
                        {extractedData.personalInfo?.fullName && (
                          <div className="flex items-center space-x-2">
                            <i className="ri-user-line text-emerald-600"></i>
                            <span className="text-emerald-700">{extractedData.personalInfo.fullName}</span>
                          </div>
                        )}
                        {extractedData.personalInfo?.email && (
                          <div className="flex items-center space-x-2">
                            <i className="ri-mail-line text-emerald-600"></i>
                            <span className="text-emerald-700">{extractedData.personalInfo.email}</span>
                          </div>
                        )}
                        {extractedData.experience?.length > 0 && (
                          <div className="flex items-center space-x-2">
                            <i className="ri-briefcase-line text-emerald-600"></i>
                            <span className="text-emerald-700">{extractedData.experience.length} work experiences</span>
                          </div>
                        )}
                        {extractedData.skills?.length > 0 && (
                          <div className="flex items-center space-x-2">
                            <i className="ri-star-line text-emerald-600"></i>
                            <span className="text-emerald-700">{extractedData.skills.length} skills identified</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Link 
                      href="/builder"
                      className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-blue-200/50 hover:-translate-y-1 whitespace-nowrap"
                    >
                      <i className="ri-edit-line mr-2 text-xl"></i>
                      Edit & Enhance
                    </Link>
                    <button
                      onClick={resetUpload}
                      className="inline-flex items-center px-8 py-4 bg-white text-gray-700 border-2 border-gray-300 rounded-xl hover:border-gray-400 hover:bg-gray-50 transition-all duration-300 whitespace-nowrap"
                    >
                      <i className="ri-upload-line mr-2 text-xl"></i>
                      Upload Another
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Features Section */}
          <div className={`mt-16 transition-all duration-1000 delay-500 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">What Happens After Upload?</h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="group bg-white/70 backdrop-blur-lg p-8 rounded-2xl shadow-xl border border-white/20 hover:shadow-2xl hover:-translate-y-2 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <i className="ri-scan-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">Smart Analysis</h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Our AI analyzes your resume structure, extracts key information, and identifies areas for improvement
                </p>
              </div>

              <div className="group bg-white/70 backdrop-blur-lg p-8 rounded-2xl shadow-xl border border-white/20 hover:shadow-2xl hover:-translate-y-2 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <i className="ri-magic-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">AI Enhancement</h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Get intelligent suggestions for better wording, formatting, and content optimization
                </p>
              </div>

              <div className="group bg-white/70 backdrop-blur-lg p-8 rounded-2xl shadow-xl border border-white/20 hover:shadow-2xl hover:-translate-y-2 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <i className="ri-palette-line text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">Beautiful Templates</h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Apply professional templates while preserving your content and improving visual appeal
                </p>
              </div>
            </div>
          </div>

          {/* Alternative Options */}
          <div className={`mt-16 transition-all duration-1000 delay-700 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10 backdrop-blur-lg rounded-2xl p-8 border border-indigo-200/30">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Don't have a resume yet?</h3>
                <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
                  No problem! Start from scratch with our AI-powered resume builder and create a professional resume in minutes
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link 
                    href="/builder"
                    className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-indigo-200/50 hover:-translate-y-1 whitespace-nowrap"
                  >
                    <i className="ri-add-line mr-2 text-xl"></i>
                    Create New Resume
                  </Link>
                  <Link 
                    href="/resume-templates"
                    className="inline-flex items-center px-8 py-4 bg-white text-indigo-600 border-2 border-indigo-600 rounded-xl hover:bg-indigo-50 transition-all duration-300 whitespace-nowrap"
                  >
                    <i className="ri-layout-line mr-2 text-xl"></i>
                    Browse Templates
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-8 right-8 space-y-4">
        <div className="group">
          <div className="w-14 h-14 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full shadow-lg flex items-center justify-center cursor-pointer hover:scale-110 transition-all duration-300 hover:shadow-blue-200/50">
            <i className="ri-question-line text-white text-xl group-hover:animate-bounce"></i>
          </div>
          <div className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-black/80 text-white px-3 py-1 rounded-lg text-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
            Need Help?
          </div>
        </div>
      </div>
    </div>
  );
}