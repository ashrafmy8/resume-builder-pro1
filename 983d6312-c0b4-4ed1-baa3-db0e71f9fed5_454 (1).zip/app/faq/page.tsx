
'use client';
import { useState } from 'react';
import Link from 'next/link';

export default function FAQPage() {
  const [activeCategory, setActiveCategory] = useState('technical');
  const [openFAQ, setOpenFAQ] = useState<string | null>(null);

  const categories = [
    { id: 'technical', name: 'Technical assistance', icon: 'ri-settings-3-line' },
    { id: 'payment', name: 'Payment information', icon: 'ri-bank-card-line' },
    { id: 'data', name: 'Delete or request data', icon: 'ri-shield-user-line' },
    { id: 'cover-letter', name: 'Cover letter FAQs', icon: 'ri-file-text-line' },
    { id: 'resume', name: 'Resume FAQs', icon: 'ri-file-user-line' },
    { id: 'cv', name: 'CV FAQs', icon: 'ri-profile-line' }
  ];

  const faqData = {
    technical: [
      {
        id: 'tech-1',
        question: 'Why can\'t I edit my resume?',
        answer: 'If you\'re having trouble editing your resume, try refreshing your browser or clearing your cache. Make sure you\'re logged into your ResumeTeacher account. If the problem persists, contact our support team.'
      },
      {
        id: 'tech-2',
        question: 'Why isn\'t my resume saving?',
        answer: 'Resume saving issues can occur due to poor internet connection or browser issues. Ensure you have a stable internet connection and try using a different browser. Your progress is automatically saved every few seconds when connected.'
      },
      {
        id: 'tech-3',
        question: 'How do I download my resume?',
        answer: 'Once you\'ve completed your resume, click the "Download" button in the top right corner. You can choose from PDF, Word, or plain text formats. Premium users get access to additional download options.'
      },
      {
        id: 'tech-4',
        question: 'What browsers work best with ResumeTeacher?',
        answer: 'ResumeTeacher works best with modern browsers like Chrome, Firefox, Safari, and Edge. Make sure your browser is updated to the latest version for optimal performance.'
      }
    ],
    payment: [
      {
        id: 'pay-1',
        question: 'How much does ResumeTeacher cost?',
        answer: 'ResumeTeacher offers both free and premium plans. The free plan includes basic resume building features, while premium plans start at $9.95/month and include advanced templates, cover letter tools, and priority support.'
      },
      {
        id: 'pay-2',
        question: 'Can I get a refund?',
        answer: 'Yes, we offer a 30-day money-back guarantee. If you\'re not satisfied with your ResumeTeacher experience, contact our support team within 30 days of purchase for a full refund.'
      },
      {
        id: 'pay-3',
        question: 'What payment methods do you accept?',
        answer: 'We accept all major credit cards (Visa, MasterCard, American Express), PayPal, and other secure payment methods. All transactions are encrypted and secure.'
      },
      {
        id: 'pay-4',
        question: 'Can I cancel my subscription anytime?',
        answer: 'Yes, you can cancel your subscription at any time from your account settings. Your access to premium features will continue until the end of your current billing period.'
      }
    ],
    data: [
      {
        id: 'data-1',
        question: 'How do I delete my account?',
        answer: 'To delete your account, go to Account Settings and click "Delete Account." This will permanently remove all your data from our servers. This action cannot be undone.'
      },
      {
        id: 'data-2',
        question: 'How do I request my data?',
        answer: 'You can request a copy of your personal data by contacting our support team. We\'ll provide you with all the information we have about your account within 30 days.'
      },
      {
        id: 'data-3',
        question: 'Is my data secure?',
        answer: 'Yes, we take data security seriously. All data is encrypted in transit and at rest. We comply with GDPR and other privacy regulations to protect your personal information.'
      },
      {
        id: 'data-4',
        question: 'Who has access to my resume?',
        answer: 'Only you have access to your resume data. ResumeTeacher staff may access your data only for technical support purposes and with your explicit permission.'
      }
    ],
    'cover-letter': [
      {
        id: 'cover-1',
        question: 'How do I create a cover letter?',
        answer: 'Use our Cover Letter Builder to create professional cover letters. Choose from our templates, fill in your information, and customize the content to match your target job.'
      },
      {
        id: 'cover-2',
        question: 'Can I use the same cover letter for multiple jobs?',
        answer: 'While you can use the same template, we recommend customizing each cover letter for the specific job and company you\'re applying to for better results.'
      },
      {
        id: 'cover-3',
        question: 'What should I include in my cover letter?',
        answer: 'A good cover letter should include an engaging opening, specific examples of your achievements, why you\'re interested in the role, and a strong closing with a call to action.'
      },
      {
        id: 'cover-4',
        question: 'How long should my cover letter be?',
        answer: 'Keep your cover letter concise - typically 3-4 paragraphs or about 250-400 words. Focus on your most relevant qualifications and achievements.'
      }
    ],
    resume: [
      {
        id: 'resume-1',
        question: 'What makes a good resume?',
        answer: 'A good resume is clear, concise, and tailored to the job. It should highlight your most relevant skills and achievements, use action verbs, and be free of errors. Our templates and guides help you create professional resumes.'
      },
      {
        id: 'resume-2',
        question: 'How long should my resume be?',
        answer: 'For most professionals, a 1-2 page resume is ideal. Entry-level candidates should aim for one page, while experienced professionals can use up to two pages if the content is relevant.'
      },
      {
        id: 'resume-3',
        question: 'Should I include a photo on my resume?',
        answer: 'In most countries, including the US, it\'s not recommended to include a photo on your resume unless specifically requested by the employer or industry standard (like modeling or acting).'
      },
      {
        id: 'resume-4',
        question: 'How often should I update my resume?',
        answer: 'Update your resume regularly - at least every 6 months or whenever you gain new skills, complete projects, or change roles. Keep it current even when you\'re not actively job searching.'
      }
    ],
    cv: [
      {
        id: 'cv-1',
        question: 'What\'s the difference between a CV and resume?',
        answer: 'A CV (Curriculum Vitae) is typically longer and more detailed than a resume, commonly used in academic, research, or international contexts. A resume is shorter and focused on relevant work experience.'
      },
      {
        id: 'cv-2',
        question: 'When should I use a CV instead of a resume?',
        answer: 'Use a CV when applying for academic positions, research roles, medical positions, or when applying for jobs internationally where CVs are the standard format.'
      },
      {
        id: 'cv-3',
        question: 'How long can a CV be?',
        answer: 'Unlike resumes, CVs can be several pages long. Academic CVs often range from 2-15 pages depending on your experience, publications, and achievements.'
      },
      {
        id: 'cv-4',
        question: 'What sections should I include in my CV?',
        answer: 'A comprehensive CV should include personal information, education, work experience, publications, presentations, awards, grants, and professional memberships relevant to your field.'
      }
    ]
  };

  const scrollToSection = (categoryId: string) => {
    setActiveCategory(categoryId);
    const element = document.getElementById(categoryId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Find answers to common questions about ResumeTeacher. Can't find what you're looking for? 
                <Link href="/contact" className="text-blue-600 hover:text-blue-700 ml-1">Contact our support team</Link>.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-white border-b sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center py-4">
            <div className="flex space-x-1 bg-gray-100 p-1 rounded-xl">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => scrollToSection(category.id)}
                  className={`flex items-center space-x-2 px-4 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 whitespace-nowrap ${
                    activeCategory === category.id
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-blue-600 hover:bg-white/50'
                  }`}
                >
                  <i className={`${category.icon} text-lg`}></i>
                  <span>{category.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* FAQ Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {categories.map((category) => (
          <section key={category.id} id={category.id} className="mb-16">
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <i className={`${category.icon} text-xl text-blue-600`}></i>
              </div>
              <h2 className="text-3xl font-bold text-gray-900">{category.name}</h2>
            </div>
            
            <div className="space-y-4">
              {faqData[category.id as keyof typeof faqData]?.map((faq) => (
                <div key={faq.id} className="bg-white rounded-xl border border-gray-200 shadow-sm">
                  <button
                    onClick={() => setOpenFAQ(openFAQ === faq.id ? null : faq.id)}
                    className="w-full px-6 py-5 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
                  >
                    <span className="text-lg font-semibold text-gray-900 pr-4">{faq.question}</span>
                    <div className="flex-shrink-0">
                      <i className={`ri-${openFAQ === faq.id ? 'subtract' : 'add'}-line text-xl text-gray-400`}></i>
                    </div>
                  </button>
                  {openFAQ === faq.id && (
                    <div className="px-6 pb-5 border-t border-gray-100">
                      <p className="text-gray-600 leading-relaxed pt-4">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>

      {/* Contact Support */}
      <div className="bg-blue-50 border-t">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-customer-service-2-line text-2xl text-blue-600"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Still need help?</h3>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Can't find the answer you're looking for? Our friendly support team is here to help you succeed.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center space-x-2 bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200"
            >
              <i className="ri-mail-line text-lg"></i>
              <span>Contact Support</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
