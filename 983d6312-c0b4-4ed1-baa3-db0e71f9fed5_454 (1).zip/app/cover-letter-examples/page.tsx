
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function CoverLetterExamplesPage() {
  const [selectedIndustry, setSelectedIndustry] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [selectedExample, setSelectedExample] = useState<any>(null);

  const industries = [
    { id: 'all', name: 'All Industries' },
    { id: 'technology', name: 'Technology' },
    { id: 'healthcare', name: 'Healthcare' },
    { id: 'finance', name: 'Finance' },
    { id: 'marketing', name: 'Marketing' },
    { id: 'education', name: 'Education' },
    { id: 'consulting', name: 'Consulting' }
  ];

  const levels = [
    { id: 'all', name: 'All Levels' },
    { id: 'entry', name: 'Entry Level' },
    { id: 'mid', name: 'Mid Level' },
    { id: 'senior', name: 'Senior Level' },
    { id: 'executive', name: 'Executive' }
  ];

  const examples = [
    {
      id: 1,
      name: 'Sarah Chen',
      position: 'Software Engineer',
      company: 'Google',
      industry: 'technology',
      level: 'mid',
      experience: '5 years',
      outcome: 'Got the job',
      keyStrengths: ['Technical expertise', 'Open source contributions', 'Team leadership'],
      image: 'Professional Asian female software engineer Sarah Chen in modern tech office workspace, wearing casual business attire, confident smile, computer screens with code in background, Google office environment, natural lighting, high quality portrait',
      preview: 'Dear Hiring Manager, I am excited to apply for the Software Engineer position at Google. With 5 years of experience in full-stack development and a passion for creating scalable solutions...',
      fullLetter: `Dear Hiring Manager,

I am excited to apply for the Software Engineer position at Google. With 5 years of experience in full-stack development and a passion for creating scalable solutions, I am confident that my technical expertise and collaborative approach would make me a valuable addition to your engineering team.

In my current role at TechCorp, I have successfully led the development of three major product features that increased user engagement by 40%. My experience includes:

• Architecting microservices using Node.js and Python that handle 1M+ daily requests
• Contributing to open-source projects with over 500 GitHub stars
• Mentoring junior developers and leading code review processes
• Implementing CI/CD pipelines that reduced deployment time by 60%

What excites me most about Google is your commitment to innovation and the opportunity to work on products that impact billions of users. I am particularly interested in your work on machine learning infrastructure and would love to contribute to projects that push the boundaries of what's possible.

I would welcome the opportunity to discuss how my passion for clean code, system design, and collaborative development can contribute to Google's continued success.

Thank you for your consideration.

Best regards,
Sarah Chen`
    },
    {
      id: 2,
      name: 'Dr. Michael Rodriguez',
      position: 'Senior Physician',
      company: 'Johns Hopkins',
      industry: 'healthcare',
      level: 'senior',
      experience: '12 years',
      outcome: 'Interview secured',
      keyStrengths: ['Clinical expertise', 'Research publications', 'Patient care'],
      image: 'Professional Hispanic male doctor Michael Rodriguez in white medical coat with stethoscope, Johns Hopkins hospital background, confident healthcare professional, medical facility setting, warm lighting, authoritative medical presence',
      preview: 'Dear Dr. Johnson, I am writing to express my strong interest in the Senior Physician position at Johns Hopkins Hospital. My 12 years of clinical experience and dedication to patient care...',
      fullLetter: `Dear Dr. Johnson,

I am writing to express my strong interest in the Senior Physician position at Johns Hopkins Hospital. My 12 years of clinical experience, combined with a robust research background and unwavering dedication to patient care, align perfectly with your department's mission of excellence in healthcare delivery.

Throughout my career at Massachusetts General Hospital, I have:

• Managed complex medical cases with a 95% patient satisfaction rate
• Published 15 peer-reviewed articles in leading medical journals
• Led a multidisciplinary team of 20+ healthcare professionals
• Implemented evidence-based protocols that reduced readmission rates by 25%
• Mentored 30+ medical residents and contributed to curriculum development

My research in cardiovascular medicine has been recognized nationally, and I am particularly excited about the opportunity to continue this work at Johns Hopkins, where innovation and clinical excellence go hand in hand. Your institution's commitment to advancing medical knowledge while providing compassionate care resonates deeply with my professional values.

I am eager to bring my clinical expertise, research acumen, and passion for teaching to your esteemed institution. I would welcome the opportunity to discuss how I can contribute to Johns Hopkins' continued leadership in healthcare.

Thank you for your consideration.

Sincerely,
Dr. Michael Rodriguez, MD`
    },
    {
      id: 3,
      name: 'Emily Zhang',
      position: 'Investment Analyst',
      company: 'Goldman Sachs',
      industry: 'finance',
      level: 'entry',
      experience: '1 year',
      outcome: 'Got the job',
      keyStrengths: ['Financial modeling', 'Market analysis', 'Academic excellence'],
      image: 'Professional young Asian female finance analyst Emily Zhang in business suit, Goldman Sachs office environment, financial charts and screens in background, confident entry-level professional, modern corporate setting',
      preview: 'Dear Mr. Thompson, As a recent Finance graduate with internship experience at JP Morgan, I am thrilled to apply for the Investment Analyst position at Goldman Sachs...',
      fullLetter: `Dear Mr. Thompson,

As a recent Finance graduate with internship experience at JP Morgan, I am thrilled to apply for the Investment Analyst position at Goldman Sachs. My academic excellence, combined with hands-on experience in financial modeling and market analysis, has prepared me to contribute meaningfully to your investment team from day one.

During my internship at JP Morgan, I:

• Built financial models for M&A transactions worth over $500M
• Conducted industry research that informed investment recommendations
• Collaborated with senior analysts on pitch presentations to clients
• Achieved top 10% performance ranking among 200+ interns
• Developed proficiency in Bloomberg Terminal and advanced Excel modeling

My academic achievements include graduating summa cum laude with a 3.9 GPA, receiving the Dean's Award for Excellence in Finance, and completing the CFA Level I exam. I am particularly drawn to Goldman Sachs' reputation for rigorous analysis and client-focused solutions.

What excites me most about this opportunity is the chance to work alongside industry leaders while contributing to complex financial transactions that shape the global economy. I am committed to excellence and eager to bring my analytical skills, attention to detail, and passion for finance to your team.

I would welcome the opportunity to discuss how my enthusiasm and fresh perspective can contribute to Goldman Sachs' continued success.

Thank you for your consideration.

Best regards,
Emily Zhang`
    },
    {
      id: 4,
      name: 'James Wilson',
      position: 'Marketing Director',
      company: 'Nike',
      industry: 'marketing',
      level: 'senior',
      experience: '8 years',
      outcome: 'Got the job',
      keyStrengths: ['Brand strategy', 'Digital campaigns', 'Team management'],
      image: 'Professional African American male marketing director James Wilson in creative office space, Nike brand elements in background, confident marketing executive, modern agency environment with campaign materials and screens',
      preview: 'Dear Marketing Team, I am excited to submit my application for the Marketing Director position at Nike. My 8 years of experience in brand strategy and digital marketing...',
      fullLetter: `Dear Marketing Team,

I am excited to submit my application for the Marketing Director position at Nike. My 8 years of experience in brand strategy, digital marketing, and team leadership, combined with a passion for athletic excellence, makes me uniquely qualified to drive Nike's continued growth and brand dominance.

In my current role as Senior Marketing Manager at Adidas, I have:

• Led brand campaigns that increased market share by 15% in key demographics
• Managed a $50M annual marketing budget across digital and traditional channels
• Built and mentored a high-performing team of 25+ marketing professionals
• Launched successful influencer partnerships that generated 100M+ impressions
• Implemented data-driven marketing strategies that improved ROI by 35%

What draws me to Nike is your brand's ability to inspire athletes at every level while pushing the boundaries of innovation. Your "Just Do It" philosophy resonates with my approach to marketing – bold, authentic, and results-driven. I am particularly excited about the opportunity to work on global campaigns that celebrate athletic achievement and cultural impact.

My experience spans traditional advertising, digital marketing, social media strategy, and brand partnerships. I thrive in fast-paced environments and excel at translating brand vision into compelling campaigns that drive both engagement and revenue.

I would love the opportunity to discuss how my strategic vision and proven track record can help Nike continue to inspire and innovate in the athletic marketplace.

Thank you for your consideration.

Best regards,
James Wilson`
    },
    {
      id: 5,
      name: 'Professor Lisa Anderson',
      position: 'Department Chair',
      company: 'Stanford University',
      industry: 'education',
      level: 'executive',
      experience: '15 years',
      outcome: 'Interview secured',
      keyStrengths: ['Academic leadership', 'Research excellence', 'Curriculum development'],
      image: 'Professional Caucasian female professor Lisa Anderson in academic office with books and research materials, Stanford University campus setting, confident academic leader, scholarly environment with diplomas and publications',
      preview: 'Dear Search Committee, I am honored to apply for the Department Chair position at Stanford University. With 15 years of academic experience and a track record of research excellence...',
      fullLetter: `Dear Search Committee,

I am honored to apply for the Department Chair position at Stanford University. With 15 years of academic experience, a distinguished research portfolio, and a proven track record of administrative leadership, I am excited about the opportunity to guide your department toward continued excellence and innovation.

My qualifications for this role include:

Academic Leadership:
• Served as Associate Chair at MIT for 4 years, overseeing curriculum reform initiatives
• Led faculty search committees that recruited 12 top-tier researchers
• Managed departmental budgets exceeding $5M annually
• Established interdisciplinary programs that increased enrollment by 30%

Research Excellence:
• Published 45+ peer-reviewed articles in top-tier journals
• Secured $8M in federal research funding over the past decade
• Mentored 25+ PhD students, with 90% achieving academic or industry leadership roles
• Recognized with the National Science Foundation CAREER Award

Educational Innovation:
• Developed online learning platforms adopted by 50+ universities
• Created inclusive curriculum that improved student diversity and retention
• Implemented assessment strategies that enhanced learning outcomes by 25%

Stanford's commitment to pushing the boundaries of knowledge while fostering inclusive excellence aligns perfectly with my vision for academic leadership. I am particularly excited about the opportunity to strengthen interdepartmental collaborations and expand the department's global impact.

I would welcome the opportunity to discuss my vision for the department's future and how I can contribute to Stanford's continued leadership in higher education.

Thank you for your consideration.

Sincerely,
Professor Lisa Anderson, PhD`
    },
    {
      id: 6,
      name: 'David Park',
      position: 'Senior Consultant',
      company: 'McKinsey & Company',
      industry: 'consulting',
      level: 'senior',
      experience: '7 years',
      outcome: 'Got the job',
      keyStrengths: ['Strategic thinking', 'Client relations', 'Problem solving'],
      image: 'Professional Korean American male consultant David Park in business suit, McKinsey office environment with strategy frameworks on whiteboards, confident consulting professional, modern corporate meeting room setting',
      preview: 'Dear Hiring Manager, I am writing to express my interest in the Senior Consultant position at McKinsey & Company. My 7 years of consulting experience across various industries...',
      fullLetter: `Dear Hiring Manager,

I am writing to express my interest in the Senior Consultant position at McKinsey & Company. My 7 years of consulting experience across Fortune 500 companies, combined with a proven track record of delivering transformational results, positions me well to contribute to McKinsey's continued excellence in strategic consulting.

In my current role as Principal Consultant at Bain & Company, I have:

• Led cross-functional teams of 10-15 consultants on complex transformation projects
• Generated over $200M in client value through strategic initiatives and operational improvements
• Managed relationships with C-suite executives across technology, healthcare, and financial services
• Developed proprietary frameworks adopted firm-wide for digital transformation engagements
• Mentored 20+ junior consultants, with 85% receiving accelerated promotions

Notable achievements include:

• Redesigned supply chain operations for a $5B retailer, reducing costs by 22%
• Led post-merger integration for a pharmaceutical company, accelerating synergy realization by 6 months
• Developed go-to-market strategy for a fintech startup that resulted in 300% revenue growth
• Implemented agile operating model for a Fortune 100 company, improving time-to-market by 40%

What attracts me to McKinsey is your firm's reputation for intellectual rigor and commitment to helping organizations create lasting positive change. I am particularly drawn to your digital and analytics capabilities and would be excited to contribute to client transformations in an increasingly data-driven world.

My collaborative leadership style, analytical mindset, and passion for solving complex business challenges align well with McKinsey's culture and values. I am eager to bring my experience and fresh perspectives to your team.

I would welcome the opportunity to discuss how I can contribute to McKinsey's mission of helping organizations achieve sustainable performance improvements.

Thank you for your consideration.

Best regards,
David Park`
    }
  ];

  const filteredExamples = examples.filter(example => {
    const industryMatch = selectedIndustry === 'all' || example.industry === selectedIndustry;
    const levelMatch = selectedLevel === 'all' || example.level === selectedLevel;
    return industryMatch && levelMatch;
  });

  const viewCoverLetter = (example: any) => {
    setSelectedExample(example);
  };

  const closeCoverLetter = () => {
    setSelectedExample(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50">
      {/* Cover Letter Modal */}
      {selectedExample && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{selectedExample.name}</h2>
                <p className="text-gray-600">{selectedExample.position} at {selectedExample.company}</p>
              </div>
              <button
                onClick={closeCoverLetter}
                className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
              >
                <i className="ri-close-line text-xl text-gray-500"></i>
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              <div className="bg-gray-50 p-6 rounded-lg mb-6">
                <div className="flex items-center space-x-4 mb-4">
                  <img
                    src={`https://readdy.ai/api/search-image?query=$%7BselectedExample.image%7D&width=100&height=100&seq=modal-${selectedExample.id}&orientation=squarish`}
                    alt={selectedExample.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900">{selectedExample.name}</h3>
                    <p className="text-gray-600">{selectedExample.experience} experience</p>
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mt-1 ${
                      selectedExample.outcome === 'Got the job' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {selectedExample.outcome}
                    </span>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Key Strengths:</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedExample.keyStrengths.map((strength: string, index: number) => (
                        <span key={index} className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                          {strength}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Details:</h4>
                    <p className="text-sm text-gray-600">Industry: {selectedExample.industry}</p>
                    <p className="text-sm text-gray-600">Level: {selectedExample.level}</p>
                    <p className="text-sm text-gray-600">Experience: {selectedExample.experience}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Full Cover Letter</h3>
                <div className="prose prose-gray max-w-none">
                  <pre className="whitespace-pre-wrap font-sans text-gray-700 leading-relaxed">
                    {selectedExample.fullLetter}
                  </pre>
                </div>
              </div>
              
              <div className="mt-6 flex justify-center space-x-4">
                <Link 
                  href="/cover-letter-builder"
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                  <i className="ri-edit-line mr-2"></i>
                  Create Similar Letter
                </Link>
                <button
                  onClick={closeCoverLetter}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-newspaper-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-['Pacifico'] text-green-600">ResumeTeacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/cover-letter" className="text-gray-700 hover:text-green-600 transition-colors whitespace-nowrap">
                Cover Letter
              </Link>
              <Link href="/cover-letter-examples" className="text-green-600 font-semibold border-b-2 border-green-600 pb-1 whitespace-nowrap">
                Examples
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-green-600 transition-colors border border-gray-300 rounded-lg hover:border-green-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-emerald-700 relative">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://readdy.ai/api/search-image?query=Professional%20business%20meeting%20with%20successful%20job%20candidates%20showing%20cover%20letter%20examples%2C%20diverse%20group%20of%20professionals%20in%20modern%20office%20boardroom%2C%20inspiring%20career%20success%20stories%20with%20documents%20and%20laptops&width=1200&height=600&seq=cover-letter-examples-hero&orientation=landscape"
            alt="Cover Letter Examples"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h1 className="text-5xl font-bold text-white mb-6">
            Successful Cover Letter Examples
          </h1>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Learn from real cover letters that landed interviews and job offers at top companies. 
            Get inspired by success stories from professionals across different industries.
          </p>
          <div className="flex justify-center space-x-4">
            <Link href="/cover-letter-builder" className="inline-flex items-center px-6 py-3 bg-white text-green-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold">
              <i className="ri-add-line mr-2"></i>
              Create Your Own
            </Link>
            <Link href="/cover-letter-templates" className="inline-flex items-center px-6 py-3 border-2 border-white text-white rounded-lg hover:bg-white hover:text-green-600 transition-colors font-semibold">
              <i className="ri-layout-line mr-2"></i>
              Browse Templates
            </Link>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Filter Examples</h2>
            <p className="text-gray-600">Find cover letter examples that match your industry and experience level</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Industry</h3>
              <div className="flex flex-wrap gap-2">
                {industries.map((industry) => (
                  <button
                    key={industry.id}
                    onClick={() => setSelectedIndustry(industry.id)}
                    className={`px-4 py-2 rounded-full border-2 transition-all ${
                      selectedIndustry === industry.id
                        ? 'bg-green-600 text-white border-green-600'
                        : 'bg-white text-gray-700 border-gray-200 hover:border-green-300 hover:text-green-600'
                    }`}
                  >
                    {industry.name}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Experience Level</h3>
              <div className="flex flex-wrap gap-2">
                {levels.map((level) => (
                  <button
                    key={level.id}
                    onClick={() => setSelectedLevel(level.id)}
                    className={`px-4 py-2 rounded-full border-2 transition-all ${
                      selectedLevel === level.id
                        ? 'bg-green-600 text-white border-green-600'
                        : 'bg-white text-gray-700 border-gray-200 hover:border-green-300 hover:text-green-600'
                    }`}
                  >
                    {level.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Examples Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {filteredExamples.length} Cover Letter {filteredExamples.length === 1 ? 'Example' : 'Examples'}
            </h2>
            <p className="text-gray-600">Real cover letters from successful job seekers</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredExamples.map((example) => (
              <div key={example.id} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="relative h-48 bg-gradient-to-br from-green-100 to-emerald-200 overflow-hidden">
                  <img
                    src={`https://readdy.ai/api/search-image?query=$%7Bexample.image%7D&width=400&height=250&seq=example-${example.id}&orientation=landscape`}
                    alt={example.name}
                    className="w-full h-full object-cover object-top"
                  />
                  <div className="absolute top-3 right-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      example.outcome === 'Got the job' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {example.outcome}
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900">{example.name}</h3>
                    <span className="text-sm text-gray-500 capitalize">{example.level} Level</span>
                  </div>
                  
                  <p className="text-gray-600 mb-1">{example.position}</p>
                  <p className="text-green-600 font-medium mb-2">{example.company}</p>
                  <p className="text-sm text-gray-500 mb-4">Experience: {example.experience}</p>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Key Strengths:</h4>
                    <div className="flex flex-wrap gap-2">
                      {example.keyStrengths.map((strength, index) => (
                        <span key={index} className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                          {strength}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Preview:</h4>
                    <p className="text-sm text-gray-600 italic">{example.preview}</p>
                  </div>
                  
                  <button 
                    onClick={() => viewCoverLetter(example)}
                    className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
                  >
                    View Full Cover Letter
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Stats */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Statistics</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our cover letter examples come from real success stories
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">92%</div>
              <p className="text-gray-600">Interview Rate</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">78%</div>
              <p className="text-gray-600">Job Offer Rate</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">500+</div>
              <p className="text-gray-600">Companies</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">15+</div>
              <p className="text-gray-600">Industries</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trustpilot Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <img 
              src="https://readdy.ai/api/search-image?query=Trustpilot%20logo%20with%20green%20star%20rating%20badge%2C%20professional%20clean%20design%20on%20white%20background%2C%20high%20quality%20brand%20logo%20with%20trustpilot%20text%20and%20green%20star%20symbol&width=140&height=50&seq=trustpilot-brand-logo&orientation=landscape"
              alt="Trustpilot"
              className="h-10"
            />
            <div className="flex items-center space-x-1">
              <div className="flex text-green-500">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-lg"></i>
                ))}
              </div>
              <span className="text-gray-700 font-bold ml-2">4.8/5 Excellent</span>
            </div>
          </div>
          <p className="text-gray-600 mb-8">Based on 28,847 reviews • TrustScore 4.8</p>
          
          <div className="bg-white p-6 rounded-xl shadow-lg max-w-2xl mx-auto">
            <div className="flex text-green-500 justify-center mb-4">
              {[...Array(5)].map((_, i) => (
                <i key={i} className="ri-star-fill"></i>
              ))}
            </div>
            <p className="text-gray-700 italic mb-4">
              "ResumeTeacher's cover letter examples helped me craft the perfect application. Got my dream marketing role within 3 weeks!"
            </p>
            <div className="flex items-center justify-center space-x-2">
              <span className="font-semibold text-gray-900">Jessica Martinez</span>
              <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">✓ Verified</span>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-emerald-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Write Your Success Story?
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Use these examples as inspiration to create your own compelling cover letter that gets results.
          </p>
          <Link href="/cover-letter-builder" className="inline-flex items-center px-8 py-4 bg-white text-green-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold">
            <i className="ri-rocket-2-line mr-2"></i>
            Start Your Cover Letter
          </Link>
        </div>
      </section>
    </div>
  );
}
