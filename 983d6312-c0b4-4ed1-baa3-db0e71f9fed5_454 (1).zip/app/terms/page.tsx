export default function TermsPage() {
  const lastUpdated = "January 15, 2024";
  
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-50 to-purple-50 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Terms of Service</h1>
          <p className="text-xl text-gray-600 mb-2">
            Please read these terms carefully before using ResumeTeacher services.
          </p>
          <p className="text-gray-500">Last updated: {lastUpdated}</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <div className="prose prose-lg max-w-none">
            
            {/* Agreement */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">1. Agreement to Terms</h2>
              
              <div className="bg-blue-50 rounded-2xl p-8 mb-6">
                <p className="text-blue-800 mb-4">
                  By accessing and using ResumeTeacher ("the Service"), you agree to be bound by these Terms of Service 
                  ("Terms"). If you disagree with any part of these terms, you may not access the Service.
                </p>
                <p className="text-blue-700">
                  These Terms apply to all visitors, users, and others who access or use the Service.
                </p>
              </div>
            </div>

            {/* Service Description */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">2. Description of Service</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-indigo-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-indigo-900 mb-3">Resume Builder</h3>
                  <ul className="space-y-2 text-indigo-800 text-sm">
                    <li>• Professional resume templates</li>
                    <li>• AI-powered content suggestions</li>
                    <li>• ATS-friendly formatting</li>
                    <li>• Multiple export formats</li>
                  </ul>
                </div>

                <div className="bg-purple-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-purple-900 mb-3">Career Tools</h3>
                  <ul className="space-y-2 text-purple-800 text-sm">
                    <li>• Cover letter builder</li>
                    <li>• Skills assessment</li>
                    <li>• Interview preparation</li>
                    <li>• Career guidance resources</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* User Accounts */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">3. User Accounts</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Account Creation</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>• You must provide accurate and complete information</li>
                    <li>• You are responsible for maintaining account security</li>
                    <li>• You must be at least 13 years old to create an account</li>
                    <li>• One person may not maintain more than one account</li>
                  </ul>
                </div>

                <div className="bg-red-50 border border-red-200 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-red-900 mb-3">Account Security</h3>
                  <p className="text-red-800">
                    You are responsible for all activities that occur under your account. 
                    Notify us immediately of any unauthorized use of your account.
                  </p>
                </div>
              </div>
            </div>

            {/* User Content */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">4. User Content and Data</h2>
              
              <div className="space-y-6">
                <div className="bg-emerald-50 rounded-2xl p-8">
                  <h3 className="text-xl font-semibold text-emerald-900 mb-4">Your Content Ownership</h3>
                  <p className="text-emerald-800">
                    You retain all rights to the content you create, upload, or submit to our Service, 
                    including your resume information, cover letters, and personal data.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="border border-gray-200 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Content License</h3>
                    <p className="text-gray-700 text-sm">
                      By using our Service, you grant us a limited license to use your content solely 
                      for providing and improving our services.
                    </p>
                  </div>

                  <div className="border border-gray-200 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Content Standards</h3>
                    <p className="text-gray-700 text-sm">
                      You agree not to upload content that is illegal, harmful, threatening, 
                      abusive, or violates others' rights.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Subscription Terms */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">5. Subscription and Billing</h2>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Available Plans</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-white rounded-xl p-6 border border-blue-200">
                      <div className="flex items-center mb-3">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                          <i className="ri-check-line text-green-600"></i>
                        </div>
                        <h4 className="font-semibold text-gray-900">One-Time Access</h4>
                      </div>
                      <div className="mb-4">
                        <span className="text-3xl font-bold text-green-600">$2</span>
                        <span className="text-gray-500 ml-2">per use</span>
                      </div>
                      <ul className="space-y-2 text-gray-700 text-sm">
                        <li>• Instant access to premium features</li>
                        <li>• Single resume save/download/email</li>
                        <li>• All premium templates</li>
                        <li>• AI writing assistance</li>
                        <li>• ATS optimization</li>
                      </ul>
                    </div>
                    <div className="bg-white rounded-xl p-6 border border-indigo-200">
                      <div className="flex items-center mb-3">
                        <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
                          <i className="ri-vip-crown-line text-indigo-600"></i>
                        </div>
                        <h4 className="font-semibold text-gray-900">Monthly Subscription</h4>
                      </div>
                      <div className="mb-4">
                        <span className="text-3xl font-bold text-indigo-600">$5</span>
                        <span className="text-gray-500 ml-2">per month</span>
                      </div>
                      <ul className="space-y-2 text-gray-700 text-sm">
                        <li>• Unlimited saves, downloads & emails</li>
                        <li>• All premium templates</li>
                        <li>• Priority AI suggestions</li>
                        <li>• Cover letter builder access</li>
                        <li>• Advanced ATS optimization</li>
                        <li>• Priority customer support</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-yellow-900 mb-3">Billing Terms</h3>
                    <ul className="space-y-2 text-yellow-800 text-sm">
                      <li>• One-time payments are processed immediately</li>
                      <li>• Monthly subscriptions renew automatically</li>
                      <li>• Payments are non-refundable except as required by law</li>
                      <li>• We may change prices with 30 days notice</li>
                      <li>• Failed payments may result in service suspension</li>
                      <li>• All prices are in USD unless otherwise specified</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-green-900 mb-3">Payment Methods</h3>
                    <ul className="space-y-2 text-green-800 text-sm">
                      <li>• Credit/Debit cards (Visa, Mastercard)</li>
                      <li>• MTN Mobile Money</li>
                      <li>• Airtel Money</li>
                      <li>• PayPal (where available)</li>
                      <li>• Bank transfers (for annual plans)</li>
                    </ul>
                    <div className="mt-4 p-3 bg-green-100 rounded-lg">
                      <p className="text-green-800 text-xs">
                        <i className="ri-shield-check-line mr-1"></i>
                        All payments are secured with 256-bit SSL encryption
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-blue-900 mb-3">Cancellation & Refunds</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-blue-900 mb-2">Monthly Subscriptions</h4>
                      <ul className="space-y-1 text-blue-800 text-sm">
                        <li>• Cancel anytime from account settings</li>
                        <li>• Access continues until period ends</li>
                        <li>• No refunds for partial billing periods</li>
                        <li>• Automatic renewal can be disabled</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-blue-900 mb-2">One-Time Purchases</h4>
                      <ul className="space-y-1 text-blue-800 text-sm">
                        <li>• No automatic renewals</li>
                        <li>• Refunds within 24 hours if unused</li>
                        <li>• Technical issues qualify for refunds</li>
                        <li>• Contact support for refund requests</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Prohibited Uses */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">6. Prohibited Uses</h2>
              
              <div className="bg-red-50 border border-red-200 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-red-900 mb-4">You may not use our Service:</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <ul className="space-y-2 text-red-800">
                    <li>• For any unlawful purpose or activity</li>
                    <li>• To violate any laws or regulations</li>
                    <li>• To transmit harmful or malicious code</li>
                    <li>• To impersonate others or misrepresent identity</li>
                    <li>• To collect others' personal information</li>
                  </ul>
                  <ul className="space-y-2 text-red-800">
                    <li>• To interfere with service operation</li>
                    <li>• To attempt unauthorized access</li>
                    <li>• To use automated tools without permission</li>
                    <li>• To copy or redistribute our content</li>
                    <li>• To create derivative works</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Intellectual Property */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">7. Intellectual Property Rights</h2>
              
              <div className="space-y-6">
                <div className="bg-purple-50 rounded-2xl p-8">
                  <h3 className="text-xl font-semibold text-purple-900 mb-4">Our Property</h3>
                  <p className="text-purple-800 mb-4">
                    The Service and its original content, features, and functionality are owned by ResumeTeacher 
                    and are protected by copyright, trademark, and other intellectual property laws.
                  </p>
                  <ul className="space-y-2 text-purple-700">
                    <li>• Website design and layout</li>
                    <li>• Resume templates and formats</li>
                    <li>• Software and algorithms</li>
                    <li>• Trademarks and logos</li>
                  </ul>
                </div>

                <div className="bg-indigo-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-indigo-900 mb-3">Permitted Use</h3>
                  <p className="text-indigo-800">
                    You may use our templates and tools to create resumes for your personal job search activities. 
                    Commercial use requires separate agreement.
                  </p>
                </div>
              </div>
            </div>

            {/* Disclaimers */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">8. Disclaimers and Warranties</h2>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-yellow-900 mb-4">Service Provided "As Is"</h3>
                <p className="text-yellow-800 mb-4">
                  ResumeTeacher provides the Service on an "as is" and "as available" basis. 
                  We make no representations or warranties of any kind, express or implied.
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-yellow-900 mb-2">We do not warrant:</h4>
                    <ul className="space-y-1 text-yellow-800 text-sm">
                      <li>• Uninterrupted or error-free service</li>
                      <li>• Results from using our Service</li>
                      <li>• Accuracy of content or templates</li>
                      <li>• Compatibility with all systems</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-yellow-900 mb-2">Your responsibility:</h4>
                    <ul className="space-y-1 text-yellow-800 text-sm">
                      <li>• Verify all resume content</li>
                      <li>• Ensure accuracy of information</li>
                      <li>• Comply with employer requirements</li>
                      <li>• Maintain backup copies</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Limitation of Liability */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">9. Limitation of Liability</h2>
              
              <div className="bg-red-50 border border-red-200 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-red-900 mb-4">Liability Limits</h3>
                <p className="text-red-800 mb-4">
                  To the maximum extent permitted by law, ResumeTeacher shall not be liable for any indirect, 
                  incidental, special, consequential, or punitive damages.
                </p>
                <p className="text-red-700">
                  Our total liability to you for all claims shall not exceed the amount you paid us in the 
                  12 months preceding the claim.
                </p>
              </div>
            </div>

            {/* Termination */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">10. Termination</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">By You</h3>
                  <p className="text-gray-700 text-sm mb-3">
                    You may terminate your account at any time by contacting us or using account settings.
                  </p>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• Download your data before termination</li>
                    <li>• Subscription access continues until period ends</li>
                    <li>• Some data may be retained per privacy policy</li>
                  </ul>
                </div>

                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">By Us</h3>
                  <p className="text-gray-700 text-sm mb-3">
                    We may terminate or suspend your account for violations of these Terms.
                  </p>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• Immediate termination for serious violations</li>
                    <li>• Notice provided when possible</li>
                    <li>• Refund policies apply where required</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Changes to Terms */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">11. Changes to Terms</h2>
              
              <div className="bg-blue-50 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-blue-900 mb-4">Updates and Modifications</h3>
                <p className="text-blue-800 mb-4">
                  We reserve the right to modify these Terms at any time. When we make changes:
                </p>
                <ul className="space-y-2 text-blue-700">
                  <li>• We will update the "Last Updated" date</li>
                  <li>• We will notify users of significant changes</li>
                  <li>• Continued use constitutes acceptance of new Terms</li>
                  <li>• You may terminate if you disagree with changes</li>
                </ul>
              </div>
            </div>

            {/* Contact Information */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">12. Contact Information</h2>
              
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Questions About These Terms?</h3>
                <p className="text-gray-700 mb-6">
                  If you have questions about these Terms of Service, please contact us:
                </p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">General Inquiries</h4>
                    <div className="space-y-2 text-gray-700">
                      <p>Email: legal@resumeteacher.com</p>
                      <p>Response time: Within 5 business days</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Support Team</h4>
                    <div className="space-y-2 text-gray-700">
                      <p>Email: support@resumeteacher.com</p>
                      <p>For account and service questions</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}