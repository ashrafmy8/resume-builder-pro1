
'use client';

import React, { useState } from 'react';
import Link from 'next/link';

export default function ResumeTemplatesPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTemplate, setSelectedTemplate] = useState('echo-modern');
  const [showFullPreview, setShowFullPreview] = useState(false);

  const templates = [
    // Modern Templates (12)
    {
      id: 'galaxy-modern',
      name: 'Galaxy Modern',
      category: 'modern',
      rating: 4.9,
      downloads: '15.2k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=modern%20resume%20template%20with%20dark%20gradient%20header%2C%20professional%20layout%20with%20clean%20sections%20for%20experience%20education%20and%20skills%2C%20contemporary%20design%20with%20subtle%20geometric%20elements&width=400&height=500&seq=galaxy1&orientation=portrait',
      previewComponent: (
        <div className="template-preview bg-white rounded-lg shadow-lg overflow-hidden" style={{ width: '595px', height: '842px', fontSize: '11px', lineHeight: '1.4' }}>
          <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white p-6">
            <h1 className="text-2xl font-bold mb-1">Sarah Johnson</h1>
            <p className="text-lg text-gray-300">Senior Product Manager</p>
            <div className="flex gap-4 text-sm text-gray-300 mt-2">
              <span>sarah.johnson@email.com</span>
              <span>+1 (555) 123-4567</span>
              <span>New York, NY</span>
            </div>
          </div>
          <div className="p-6 space-y-4">
            <section>
              <h3 className="text-sm font-bold text-gray-800 mb-2">SUMMARY</h3>
              <p className="text-xs text-slate-700">Results-driven Product Manager with 7+ years of experience leading cross-functional teams to deliver innovative digital products. Proven track record of increasing user engagement by 45% and revenue by $2.3M through strategic product initiatives.</p>
            </section>
            <section>
              <h3 className="text-sm font-bold text-gray-800 mb-2">EXPERIENCE</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800">Senior Product Manager</h4>
                      <p className="text-xs text-slate-600">TechFlow Inc.</p>
                    </div>
                    <span className="text-xs text-slate-500">2021 - Present</span>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800">Product Manager</h4>
                      <p className="text-xs text-slate-600">InnovateCorp</p>
                    </div>
                    <span className="text-xs text-slate-500">2019 - 2021</span>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      )
    },
    {
      id: 'quantum-tech',
      name: 'Quantum Tech',
      category: 'modern',
      rating: 4.8,
      downloads: '12.8k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=tech%20resume%20template%20with%20emerald%20cyan%20gradients%2C%20glassmorphism%20effects%2C%20modern%20card%20layout%20with%20clean%20typography%20and%20professional%20sections&width=400&height=500&seq=quantum1&orientation=portrait',
      previewComponent: (
        <div className="template-preview bg-white rounded-lg shadow-lg overflow-hidden" style={{ width: '595px', height: '842px', fontSize: '11px', lineHeight: '1.4' }}>
          <div className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-white p-6">
            <h1 className="text-2xl font-bold mb-1">Sarah Johnson</h1>
            <p className="text-lg text-emerald-100">Senior Product Manager</p>
            <div className="flex gap-4 text-sm text-emerald-100 mt-2">
              <span>sarah.johnson@email.com</span>
              <span>+1 (555) 123-4567</span>
              <span>New York, NY</span>
            </div>
          </div>
          <div className="p-6 space-y-4">
            <div className="bg-gradient-to-r from-emerald-50 to-cyan-50 p-4 rounded-lg">
              <h3 className="text-sm font-bold text-emerald-800 mb-2">SUMMARY</h3>
              <p className="text-xs text-slate-700">Results-driven Product Manager with 7+ years of experience leading cross-functional teams to deliver innovative digital products. Proven track record of increasing user engagement by 45% and revenue by $2.3M through strategic product initiatives.</p>
            </div>
            <section>
              <h3 className="text-sm font-bold text-emerald-800 mb-2">EXPERIENCE</h3>
              <div className="space-y-3">
                <div className="border-l-4 border-emerald-400 pl-4">
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800">Senior Product Manager</h4>
                      <p className="text-xs text-slate-600">TechFlow Inc.</p>
                    </div>
                    <span className="text-xs text-slate-500">2021 - Present</span>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      )
    },
    {
      id: 'echo-modern',
      name: 'Echo Modern',
      category: 'modern',
      rating: 4.8,
      downloads: '13.1k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=dynamic%20resume%20design%20with%20orange%20red%20gradients%2C%20modern%20visual%20elements%20and%20clean%20sections&width=400&height=500&seq=echo1&orientation=portrait',
      previewComponent: (
        <div className="template-preview bg-white rounded-lg shadow-lg overflow-hidden" style={{ width: '595px', height: '842px', fontSize: '11px', lineHeight: '1.4' }}>
          <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6">
            <h1 className="text-2xl font-bold mb-1">Sarah Johnson</h1>
            <p className="text-lg text-orange-100">Senior Product Manager</p>
            <div className="flex gap-4 text-sm text-orange-100 mt-2">
              <span>sarah.johnson@email.com</span>
              <span>+1 (555) 123-4567</span>
              <span>New York, NY</span>
            </div>
          </div>
          <div className="p-6 space-y-4">
            <section>
              <h3 className="text-sm font-bold text-orange-800 mb-2">SUMMARY</h3>
              <div className="bg-orange-50 p-3 rounded-lg">
                <p className="text-xs text-slate-700">Results-driven Product Manager with 7+ years of experience leading cross-functional teams to deliver innovative digital products. Proven track record of increasing user engagement by 45% and revenue by $2.3M through strategic product initiatives.</p>
              </div>
            </section>
            <section>
              <h3 className="text-sm font-bold text-orange-800 mb-2">EXPERIENCE</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800">Senior Product Manager</h4>
                      <p className="text-xs text-slate-600">TechFlow Inc.</p>
                    </div>
                    <span className="text-xs text-slate-500 bg-orange-100 px-2 py-1 rounded">2021 - Present</span>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800">Product Manager</h4>
                      <p className="text-xs text-slate-600">InnovateCorp</p>
                    </div>
                    <span className="text-xs text-slate-500 bg-orange-100 px-2 py-1 rounded">2019 - 2021</span>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      )
    },
    {
      id: 'velocity-modern',
      name: 'Velocity Modern',
      category: 'modern',
      rating: 4.7,
      downloads: '11.5k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=contemporary%20resume%20template%20with%20blue%20purple%20color%20scheme%2C%20dynamic%20layout%20with%20geometric%20shapes%20and%20modern%20typography%20for%20professional%20presentation&width=400&height=500&seq=velocity1&orientation=portrait'
    },
    {
      id: 'matrix-tech',
      name: 'Matrix Tech',
      category: 'modern',
      rating: 4.9,
      downloads: '14.2k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=cyberpunk%20style%20resume%20template%20with%20green%20terminal%20aesthetic%2C%20dark%20background%20with%20matrix-like%20elements%20and%20futuristic%20typography&width=400&height=500&seq=matrix1&orientation=portrait'
    },
    {
      id: 'flux-modern',
      name: 'Flux Modern',
      category: 'modern',
      rating: 4.6,
      downloads: '10.8k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=fluid%20resume%20design%20with%20cyan%20blue%20gradients%2C%20floating%20elements%20and%20smooth%20curves%20for%20modern%20professional%20presentation&width=400&height=500&seq=flux1&orientation=portrait'
    },
    {
      id: 'nexus-modern',
      name: 'Nexus Modern',
      category: 'modern',
      rating: 4.8,
      downloads: '12.3k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=interconnected%20resume%20template%20with%20network%20patterns%2C%20violet%20purple%20theme%20and%20modern%20geometric%20layout%20for%20tech%20professionals&width=400&height=500&seq=nexus1&orientation=portrait'
    },
    {
      id: 'prism-modern',
      name: 'Prism Modern',
      category: 'modern',
      rating: 4.7,
      downloads: '9.9k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=prismatic%20resume%20design%20with%20rainbow%20light%20effects%2C%20crystal-like%20elements%20and%20modern%20clean%20layout%20for%20creative%20professionals&width=400&height=500&seq=prism1&orientation=portrait'
    },
    {
      id: 'stellar-modern',
      name: 'Stellar Modern',
      category: 'modern',
      rating: 4.9,
      downloads: '16.1k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=stellar%20themed%20resume%20with%20cosmic%20elements%2C%20deep%20space%20colors%20and%20constellation%20patterns%20for%20innovative%20professionals&width=400&height=500&seq=stellar1&orientation=portrait'
    },
    {
      id: 'wave-modern',
      name: 'Wave Modern',
      category: 'modern',
      rating: 4.5,
      downloads: '8.7k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=wave%20pattern%20resume%20with%20flowing%20blue%20teal%20gradients%2C%20organic%20shapes%20and%20contemporary%20typography%20for%20dynamic%20presentation&width=400&height=500&seq=wave1&orientation=portrait'
    },
    {
      id: 'zenith-modern',
      name: 'Zenith Modern',
      category: 'modern',
      rating: 4.8,
      downloads: '13.7k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=peak%20performance%20resume%20template%20with%20mountain%20peak%20elements%2C%20gold%20yellow%20accents%20and%20aspirational%20design%20for%20leadership%20roles&width=400&height=500&seq=zenith1&orientation=portrait'
    },
    {
      id: 'orbit-modern',
      name: 'Orbit Modern',
      category: 'modern',
      rating: 4.6,
      downloads: '10.1k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=orbital%20resume%20design%20with%20circular%20elements%2C%20satellite%20patterns%20and%20space%20age%20typography%20for%20forward-thinking%20professionals&width=400&height=500&seq=orbit1&orientation=portrait'
    },

    // Creative Templates (8)
    {
      id: 'spectrum-creative',
      name: 'Spectrum Creative',
      category: 'creative',
      rating: 4.9,
      downloads: '18.5k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=rainbow%20spectrum%20resume%20with%20vibrant%20gradients%2C%20artistic%20elements%20and%20creative%20typography%20for%20designers%20and%20visual%20artists&width=400&height=500&seq=spectrum1&orientation=portrait'
    },
    {
      id: 'aurora-creative',
      name: 'Aurora Creative',
      category: 'creative',
      rating: 4.7,
      downloads: '14.8k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=aurora%20borealis%20inspired%20resume%20with%20pink%20purple%20indigo%20northern%20lights%20effects%20and%20ethereal%20design%20for%20creative%20professionals&width=400&height=500&seq=aurora1&orientation=portrait'
    },
    {
      id: 'neon-creative',
      name: 'Neon Creative',
      category: 'creative',
      rating: 4.8,
      downloads: '16.2k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=neon%20lights%20resume%20template%20with%20dark%20background%2C%20bright%20electric%20colors%20and%20cyberpunk%20aesthetic%20for%20creative%20digital%20professionals&width=400&height=500&seq=neon1&orientation=portrait'
    },
    {
      id: 'canvas-creative',
      name: 'Canvas Creative',
      category: 'creative',
      rating: 4.6,
      downloads: '12.1k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=artist%20canvas%20resume%20with%20paint%20brush%20strokes%2C%20palette%20colors%20and%20artistic%20textures%20for%20fine%20arts%20and%20design%20professionals&width=400&height=500&seq=canvas1&orientation=portrait'
    },
    {
      id: 'mosaic-creative',
      name: 'Mosaic Creative',
      category: 'creative',
      rating: 4.8,
      downloads: '15.3k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=mosaic%20pattern%20resume%20with%20colorful%20tile%20elements%2C%20geometric%20art%20pieces%20and%20creative%20layout%20for%20multimedia%20artists&width=400&height=500&seq=mosaic1&orientation=portrait'
    },
    {
      id: 'splash-creative',
      name: 'Splash Creative',
      category: 'creative',
      rating: 4.5,
      downloads: '9.8k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=paint%20splash%20resume%20with%20vibrant%20color%20explosions%2C%20artistic%20splatters%20and%20dynamic%20creative%20design%20for%20graphic%20designers&width=400&height=500&seq=splash1&orientation=portrait'
    },
    {
      id: 'pixel-creative',
      name: 'Pixel Creative',
      category: 'creative',
      rating: 4.7,
      downloads: '13.6k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=pixel%20art%20resume%20template%20with%208-bit%20elements%2C%20retro%20gaming%20aesthetic%20and%20colorful%20pixelated%20design%20for%20game%20developers&width=400&height=500&seq=pixel1&orientation=portrait'
    },
    {
      id: 'abstract-creative',
      name: 'Abstract Creative',
      category: 'creative',
      rating: 4.9,
      downloads: '17.4k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=abstract%20art%20resume%20with%20fluid%20shapes%2C%20contemporary%20art%20elements%20and%20sophisticated%20creative%20design%20for%20art%20directors&width=400&height=500&seq=abstract1&orientation=portrait'
    },

    // Professional Templates (8)
    {
      id: 'astral-professional',
      name: 'Astral Professional',
      category: 'professional',
      rating: 4.8,
      downloads: '22.1k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=professional%20resume%20template%20with%20rose%20gold%20orange%20accents%2C%20structured%20formatting%20and%20elegant%20corporate%20design%20for%20business%20executives&width=400&height=500&seq=astral1&orientation=portrait'
    },
    {
      id: 'horizon-professional',
      name: 'Horizon Professional',
      category: 'professional',
      rating: 4.9,
      downloads: '25.3k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=clean%20horizon%20resume%20with%20teal%20blue%20accents%2C%20professional%20white%20background%20and%20structured%20business%20layout%20for%20corporate%20professionals&width=400&height=500&seq=horizon1&orientation=portrait'
    },
    {
      id: 'cosmos-professional',
      name: 'Cosmos Professional',
      category: 'professional',
      rating: 4.7,
      downloads: '19.8k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=cosmic%20professional%20resume%20with%20indigo%20navy%20colors%2C%20centered%20profile%20photo%20and%20traditional%20structured%20format%20for%20senior%20managers&width=400&height=500&seq=cosmos1&orientation=portrait'
    },
    {
      id: 'vertex-professional',
      name: 'Vertex Professional',
      category: 'professional',
      rating: 4.6,
      downloads: '16.7k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=vertex%20design%20resume%20with%20forest%20green%20accents%2C%20angular%20elements%20and%20project%20management%20focused%20layout%20for%20business%20professionals&width=400&height=500&seq=vertex1&orientation=portrait'
    },
    {
      id: 'summit-professional',
      name: 'Summit Professional',
      category: 'professional',
      rating: 4.8,
      downloads: '21.5k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=summit%20peak%20professional%20resume%20with%20mountain%20imagery%2C%20corporate%20blue%20colors%20and%20leadership-focused%20design%20for%20executives&width=400&height=500&seq=summit1&orientation=portrait'
    },
    {
      id: 'sterling-professional',
      name: 'Sterling Professional',
      category: 'professional',
      rating: 4.9,
      downloads: '24.2k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=sterling%20silver%20professional%20resume%20with%20metallic%20accents%2C%20premium%20corporate%20design%20and%20sophisticated%20layout%20for%20senior%20professionals&width=400&height=500&seq=sterling1&orientation=portrait'
    },
    {
      id: 'atlas-professional',
      name: 'Atlas Professional',
      category: 'professional',
      rating: 4.7,
      downloads: '18.9k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=atlas%20world%20map%20professional%20resume%20with%20global%20business%20elements%2C%20navy%20blue%20theme%20and%20international%20corporate%20design&width=400&height=500&seq=atlas1&orientation=portrait'
    },
    {
      id: 'pinnacle-professional',
      name: 'Pinnacle Professional',
      category: 'professional',
      rating: 4.8,
      downloads: '20.7k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=pinnacle%20achievement%20resume%20with%20success%20imagery%2C%20gold%20bronze%20accents%20and%20high-performance%20professional%20layout%20for%20top%20executives&width=400&height=500&seq=pinnacle1&orientation=portrait'
    },

    // Executive Templates (6)
    {
      id: 'platinum-executive',
      name: 'Platinum Executive',
      category: 'executive',
      rating: 4.9,
      downloads: '8.9k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=luxury%20platinum%20executive%20resume%20with%20premium%20gray%20white%20design%2C%20sophisticated%20layout%20and%20C-suite%20professional%20formatting&width=400&height=500&seq=platinum1&orientation=portrait'
    },
    {
      id: 'diamond-executive',
      name: 'Diamond Executive',
      category: 'executive',
      rating: 4.8,
      downloads: '7.2k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=diamond%20luxury%20executive%20resume%20with%20crystal%20clear%20design%2C%20premium%20white%20background%20and%20elite%20professional%20formatting%20for%20CEOs&width=400&height=500&seq=diamond1&orientation=portrait'
    },
    {
      id: 'imperial-executive',
      name: 'Imperial Executive',
      category: 'executive',
      rating: 4.9,
      downloads: '9.4k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=imperial%20executive%20resume%20with%20royal%20purple%20gold%20accents%2C%20regal%20design%20elements%20and%20prestigious%20corporate%20layout%20for%20board%20members&width=400&height=500&seq=imperial1&orientation=portrait'
    },
    {
      id: 'sovereign-executive',
      name: 'Sovereign Executive',
      category: 'executive',
      rating: 4.7,
      downloads: '6.8k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=sovereign%20executive%20resume%20with%20deep%20burgundy%20wine%20colors%2C%20elegant%20serif%20typography%20and%20distinguished%20leadership%20design&width=400&height=500&seq=sovereign1&orientation=portrait'
    },
    {
      id: 'crown-executive',
      name: 'Crown Executive',
      category: 'executive',
      rating: 4.8,
      downloads: '8.1k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=crown%20jewel%20executive%20resume%20with%20emerald%20green%20gold%20accents%2C%20luxury%20design%20elements%20and%20premium%20corporate%20formatting&width=400&height=500&seq=crown1&orientation=portrait'
    },
    {
      id: 'prestige-executive',
      name: 'Prestige Executive',
      category: 'executive',
      rating: 4.9,
      downloads: '9.7k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=prestige%20executive%20resume%20with%20midnight%20blue%20silver%20accents%2C%20distinguished%20professional%20design%20and%20exclusive%20C-level%20formatting&width=400&height=500&seq=prestige1&orientation=portrait'
    },

    // Minimalist Templates (6)
    {
      id: 'zen-minimalist',
      name: 'Zen Minimalist',
      category: 'minimalist',
      rating: 4.8,
      downloads: '19.5k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=zen%20minimalist%20resume%20with%20maximum%20white%20space%2C%20clean%20lines%20and%20scandinavian%20design%20principles%20for%20simple%20elegant%20presentation&width=400&height=500&seq=zen1&orientation=portrait'
    },
    {
      id: 'pure-minimalist',
      name: 'Pure Minimalist',
      category: 'minimalist',
      rating: 4.9,
      downloads: '21.8k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=pure%20white%20minimalist%20resume%20with%20ultra%20clean%20design%2C%20minimal%20typography%20and%20maximum%20simplicity%20for%20professional%20clarity&width=400&height=500&seq=pure1&orientation=portrait'
    },
    {
      id: 'essence-minimalist',
      name: 'Essence Minimalist',
      category: 'minimalist',
      rating: 4.7,
      downloads: '17.3k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=essence%20minimalist%20resume%20with%20subtle%20gray%20accents%2C%20essential%20information%20only%20and%20refined%20simplicity%20for%20focused%20presentation&width=400&height=500&seq=essence1&orientation=portrait'
    },
    {
      id: 'blank-minimalist',
      name: 'Blank Minimalist',
      category: 'minimalist',
      rating: 4.6,
      downloads: '14.9k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=blank%20canvas%20minimalist%20resume%20with%20pure%20white%20background%2C%20minimal%20black%20text%20and%20ultimate%20simplicity%20for%20clean%20professional%20look&width=400&height=500&seq=blank1&orientation=portrait'
    },
    {
      id: 'void-minimalist',
      name: 'Void Minimalist',
      category: 'minimalist',
      rating: 4.8,
      downloads: '16.1k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=void%20space%20minimalist%20resume%20with%20negative%20space%20design%2C%20minimal%20elements%20and%20architectural%20simplicity%20for%20modern%20professionals&width=400&height=500&seq=void1&orientation=portrait'
    },
    {
      id: 'crystal-minimalist',
      name: 'Crystal Minimalist',
      category: 'minimalist',
      rating: 4.7,
      downloads: '15.4k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=crystal%20clear%20minimalist%20resume%20with%20transparent%20elements%2C%20glass-like%20design%20and%20pristine%20simplicity%20for%20elegant%20presentation&width=400&height=500&seq=crystal1&orientation=portrait'
    },

    // Entry Level Templates (6)
    {
      id: 'nova-entry',
      name: 'Nova Entry Level',
      category: 'entry-level',
      rating: 4.7,
      downloads: '28.3k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=bright%20nova%20star%20resume%20with%20vibrant%20colors%2C%20energetic%20design%20and%20student-friendly%20layout%20for%20recent%20graduates%20and%20entry-level%20professionals&width=400&height=500&seq=nova1&orientation=portrait'
    },
    {
      id: 'spark-entry',
      name: 'Spark Entry Level',
      category: 'entry-level',
      rating: 4.6,
      downloads: '25.7k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=spark%20energy%20resume%20with%20dynamic%20elements%2C%20fresh%20colors%20and%20youthful%20design%20for%20new%20professionals%20and%20career%20starters&width=400&height=500&seq=spark1&orientation=portrait'
    },
    {
      id: 'fresh-entry',
      name: 'Fresh Entry Level',
      category: 'entry-level',
      rating: 4.8,
      downloads: '31.2k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=fresh%20green%20resume%20with%20nature%20elements%2C%20clean%20modern%20design%20and%20beginner-friendly%20layout%20for%20students%20and%20interns&width=400&height=500&seq=fresh1&orientation=portrait'
    },
    {
      id: 'bloom-entry',
      name: 'Bloom Entry Level',
      category: 'entry-level',
      rating: 4.7,
      downloads: '26.9k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=blooming%20flower%20resume%20with%20spring%20colors%2C%20growth%20imagery%20and%20optimistic%20design%20for%20young%20professionals%20starting%20careers&width=400&height=500&seq=bloom1&orientation=portrait'
    },
    {
      id: 'dawn-entry',
      name: 'Dawn Entry Level',
      category: 'entry-level',
      rating: 4.5,
      downloads: '22.4k',
      isPremium: false,
      image: 'https://readdy.ai/api/search-image?query=sunrise%20dawn%20resume%20with%20warm%20morning%20colors%2C%20hopeful%20imagery%20and%20beginner-friendly%20professional%20design%20for%20new%20graduates&width=400&height=500&seq=dawn1&orientation=portrait'
    },
    {
      id: 'launch-entry',
      name: 'Launch Entry Level',
      category: 'entry-level',
      rating: 4.8,
      downloads: '29.6k',
      isPremium: true,
      image: 'https://readdy.ai/api/search-image?query=rocket%20launch%20resume%20with%20space%20imagery%2C%20upward%20trajectory%20elements%20and%20ambitious%20design%20for%20career%20launchers%20and%20new%20professionals&width=400&height=500&seq=launch1&orientation=portrait'
    }
  ];

  const categories = [
    { id: 'all', name: 'All Templates', count: templates.length },
    { id: 'modern', name: 'Modern', count: templates.filter(t => t.category === 'modern').length },
    { id: 'creative', name: 'Creative', count: templates.filter(t => t.category === 'creative').length },
    { id: 'professional', name: 'Professional', count: templates.filter(t => t.category === 'professional').length },
    { id: 'executive', name: 'Executive', count: templates.filter(t => t.category === 'executive').length },
    { id: 'minimalist', name: 'Minimalist', count: templates.filter(t => t.category === 'minimalist').length },
    { id: 'entry-level', name: 'Entry Level', count: templates.filter(t => t.category === 'entry-level').length }
  ];

  const filteredTemplates = selectedCategory === 'all' 
    ? templates 
    : templates.filter(template => template.category === selectedCategory);

  const currentTemplate = templates.find(t => t.id === selectedTemplate) || templates[2];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Professional Resume Templates</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">Choose from our collection of modern, ATS-friendly resume templates designed by professionals. Land your dream job with a standout resume.</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
              <h3 className="font-semibold text-gray-900 mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="capitalize">{category.name}</span>
                      <span className="text-sm text-gray-500">{category.count}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Templates Grid */}
          <div className="flex-1">
            <div className="flex gap-8">
              <div className="flex-1">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredTemplates.map((template) => (
                    <div
                      key={template.id}
                      onClick={() => setSelectedTemplate(template.id)}
                      className={`bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer transition-all duration-200 hover:shadow-lg hover:transform hover:scale-102 ${
                        selectedTemplate === template.id ? 'ring-2 ring-blue-500 transform scale-105' : ''
                      }`}
                    >
                      <div className="aspect-[3/4] bg-gray-100 overflow-hidden">
                        <img
                          src={template.image}
                          alt={template.name}
                          className="w-full h-full object-cover object-top"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-gray-900">{template.name}</h3>
                          {template.isPremium && (
                            <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                              Premium
                            </span>
                          )}
                        </div>
                        <div className="flex items-center justify-between text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <div className="flex text-yellow-400">
                              <i className="ri-star-fill"></i>
                              <i className="ri-star-fill"></i>
                              <i className="ri-star-fill"></i>
                              <i className="ri-star-fill"></i>
                              <i className="ri-star-line"></i>
                            </div>
                            <span className="ml-1">{template.rating}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <i className="ri-download-line"></i>
                            <span>{template.downloads}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live Preview */}
              <div className="w-96 sticky top-8">
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-900">Live Preview</h3>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowFullPreview(true)}
                        className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                      >
                        <i className="ri-zoom-in-line w-4 h-4"></i>
                      </button>
                      <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100">
                        <i className="ri-download-line w-4 h-4"></i>
                      </button>
                    </div>
                  </div>
                  
                  <div className="border rounded-lg overflow-hidden bg-gray-50 flex items-center justify-center" style={{ height: '500px' }}>
                    <div className="transform scale-50 origin-top">
                      {currentTemplate.previewComponent || (
                        <div className="template-preview bg-white rounded-lg shadow-lg overflow-hidden" style={{ width: '595px', height: '842px', fontSize: '11px', lineHeight: '1.4' }}>
                          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
                            <h1 className="text-2xl font-bold mb-1">Sarah Johnson</h1>
                            <p className="text-lg text-blue-100">Senior Product Manager</p>
                            <div className="flex gap-4 text-sm text-blue-100 mt-2">
                              <span>sarah.johnson@email.com</span>
                              <span>+1 (555) 123-4567</span>
                              <span>New York, NY</span>
                            </div>
                          </div>
                          <div className="p-6 space-y-4">
                            <section>
                              <h3 className="text-sm font-bold text-blue-800 mb-2">SUMMARY</h3>
                              <p className="text-xs text-slate-700">Results-driven Product Manager with 7+ years of experience leading cross-functional teams to deliver innovative digital products.</p>
                            </section>
                            <section>
                              <h3 className="text-sm font-bold text-blue-800 mb-2">EXPERIENCE</h3>
                              <div className="space-y-3">
                                <div>
                                  <div className="flex justify-between items-start mb-1">
                                    <div>
                                      <h4 className="text-xs font-semibold text-slate-800">Senior Product Manager</h4>
                                      <p className="text-xs text-slate-600">TechFlow Inc.</p>
                                    </div>
                                    <span className="text-xs text-slate-500">2021 - Present</span>
                                  </div>
                                </div>
                              </div>
                            </section>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t">
                    <h4 className="font-semibold text-gray-900 mb-2">{currentTemplate.name}</h4>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                      <div className="flex items-center gap-1">
                        <div className="flex text-yellow-400">
                          <i className="ri-star-fill"></i>
                          <i className="ri-star-fill"></i>
                          <i className="ri-star-fill"></i>
                          <i className="ri-star-fill"></i>
                          <i className="ri-star-line"></i>
                        </div>
                        <span className="ml-1">{currentTemplate.rating}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <i className="ri-download-line"></i>
                        <span>{currentTemplate.downloads} downloads</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Link
                        href={`/builder?template=${currentTemplate.id}`}
                        className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium text-center block whitespace-nowrap"
                      >
                        Use This Template
                      </Link>
                      <button
                        onClick={() => setShowFullPreview(true)}
                        className="w-full border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors font-medium whitespace-nowrap"
                      >
                        Preview Full Size
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Full Size Preview Modal */}
      {showFullPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-4xl max-h-full overflow-auto">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">{currentTemplate.name} - Full Preview</h3>
              <button
                onClick={() => setShowFullPreview(false)}
                className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
              >
                <i className="ri-close-line w-5 h-5"></i>
              </button>
            </div>
            <div className="p-6 flex justify-center">
              <div className="transform scale-75">
                {currentTemplate.previewComponent || (
                  <div className="template-preview bg-white rounded-lg shadow-lg overflow-hidden" style={{ width: '595px', height: '842px', fontSize: '11px', lineHeight: '1.4' }}>
                    <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
                      <h1 className="text-2xl font-bold mb-1">Sarah Johnson</h1>
                      <p className="text-lg text-blue-100">Senior Product Manager</p>
                      <div className="flex gap-4 text-sm text-blue-100 mt-2">
                        <span>sarah.johnson@email.com</span>
                        <span>+1 (555) 123-4567</span>
                        <span>New York, NY</span>
                      </div>
                    </div>
                    <div className="p-6 space-y-4">
                      <section>
                        <h3 className="text-sm font-bold text-blue-800 mb-2">SUMMARY</h3>
                        <p className="text-xs text-slate-700">Results-driven Product Manager with 7+ years of experience leading cross-functional teams to deliver innovative digital products.</p>
                      </section>
                      <section>
                        <h3 className="text-sm font-bold text-blue-800 mb-2">EXPERIENCE</h3>
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between items-start mb-1">
                              <div>
                                <h4 className="text-xs font-semibold text-slate-800">Senior Product Manager</h4>
                                <p className="text-xs text-slate-600">TechFlow Inc.</p>
                              </div>
                              <span className="text-xs text-slate-500">2021 - Present</span>
                            </div>
                          </div>
                        </div>
                      </section>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="p-4 border-t bg-gray-50 flex gap-3 justify-center">
              <Link
                href={`/builder?template=${currentTemplate.id}`}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium whitespace-nowrap"
              >
                Use This Template
              </Link>
              <button
                onClick={() => setShowFullPreview(false)}
                className="border border-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-50 transition-colors font-medium whitespace-nowrap"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
