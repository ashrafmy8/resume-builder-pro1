'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function HowToMakeResumePage() {
  const [activeStep, setActiveStep] = useState(1);

  const steps = [
    {
      id: 1,
      title: 'Choose the Right Format',
      duration: '5 minutes',
      icon: 'ri-layout-line',
      content: {
        overview: 'Select a resume format that best showcases your experience and career goals.',
        tips: [
          'Chronological: Best for steady career progression',
          'Functional: Great for career changers or gaps',
          'Combination: Perfect for experienced professionals',
          'Creative: Ideal for design and creative roles'
        ],
        example: 'For a software engineer with 5+ years experience, use chronological format to highlight career progression.',
        tools: ['Resume templates', 'Format guides', 'Industry examples']
      }
    },
    {
      id: 2,
      title: 'Write a Compelling Header',
      duration: '10 minutes',
      icon: 'ri-user-line',
      content: {
        overview: 'Create a professional header with your contact information and professional title.',
        tips: [
          'Full name in large, readable font',
          'Professional email address',
          'Phone number with area code',
          'LinkedIn profile URL',
          'City, State (no full address needed)'
        ],
        example: 'John Smith | Senior Marketing Manager | john.smith@email.com | (555) 123-4567 | linkedin.com/in/johnsmith',
        tools: ['Email generators', 'LinkedIn optimization', 'Professional headshots']
      }
    },
    {
      id: 3,
      title: 'Craft Your Professional Summary',
      duration: '15 minutes',
      icon: 'ri-file-text-line',
      content: {
        overview: 'Write a 2-3 sentence summary that highlights your key qualifications and career goals.',
        tips: [
          'Start with your years of experience',
          'Mention your key skills and expertise',
          'Include 1-2 quantified achievements',
          'End with your career objective'
        ],
        example: 'Results-driven Marketing Manager with 7+ years of experience in digital marketing and brand management. Increased ROI by 40% and led campaigns generating $2M+ in revenue. Seeking to leverage expertise in data-driven marketing to drive growth at a Fortune 500 company.',
        tools: ['AI writing assistant', 'Summary examples', 'Industry keywords']
      }
    },
    {
      id: 4,
      title: 'Detail Your Work Experience',
      duration: '20 minutes',
      icon: 'ri-briefcase-line',
      content: {
        overview: 'List your work experience in reverse chronological order with quantified achievements.',
        tips: [
          'Use action verbs to start each bullet point',
          'Quantify achievements with numbers and percentages',
          'Focus on results, not just responsibilities',
          'Tailor experience to match job requirements'
        ],
        example: '• Increased website traffic by 65% through SEO optimization and content marketing strategies\n• Managed $500K marketing budget and delivered 25% cost savings\n• Led cross-functional team of 8 to launch 3 successful product campaigns',
        tools: ['Action verb lists', 'Achievement calculators', 'Industry benchmarks']
      }
    },
    {
      id: 5,
      title: 'Highlight Your Education',
      duration: '5 minutes',
      icon: 'ri-graduation-cap-line',
      content: {
        overview: 'Include your educational background with relevant details and achievements.',
        tips: [
          'List degree, major, school name, and graduation year',
          'Include GPA if 3.5 or higher',
          'Add relevant coursework for recent graduates',
          'Include academic honors and achievements'
        ],
        example: 'Bachelor of Science in Marketing | University of California, Los Angeles | 2018\nRelevant Coursework: Digital Marketing, Consumer Behavior, Market Research\nAchievements: Dean\'s List (3 semesters), Marketing Club President',
        tools: ['Education formatters', 'Coursework selectors', 'Achievement trackers']
      }
    },
    {
      id: 6,
      title: 'Showcase Your Skills',
      duration: '10 minutes',
      icon: 'ri-star-line',
      content: {
        overview: 'List your relevant technical and soft skills that match the job requirements.',
        tips: [
          'Separate technical and soft skills',
          'Use skill categories for organization',
          'Include proficiency levels when relevant',
          'Match skills to job descriptions'
        ],
        example: 'Technical Skills: Google Analytics, SEO/SEM, Adobe Creative Suite, HTML/CSS, Salesforce\nSoft Skills: Leadership, Project Management, Public Speaking, Team Collaboration, Problem Solving',
        tools: ['Skill assessments', 'Industry skill lists', 'Proficiency meters']
      }
    },
    {
      id: 7,
      title: 'Add Additional Sections',
      duration: '10 minutes',
      icon: 'ri-add-line',
      content: {
        overview: 'Include additional sections that strengthen your candidacy and show personality.',
        tips: [
          'Certifications and licenses',
          'Professional associations',
          'Volunteer work and community involvement',
          'Languages and proficiency levels',
          'Awards and recognition'
        ],
        example: 'Certifications: Google Ads Certified, HubSpot Content Marketing\nVolunteer: Marketing Committee Chair, Local Food Bank (2020-Present)\nLanguages: English (Native), Spanish (Conversational)',
        tools: ['Certification trackers', 'Volunteer databases', 'Language assessments']
      }
    },
    {
      id: 8,
      title: 'Proofread and Format',
      duration: '15 minutes',
      icon: 'ri-check-line',
      content: {
        overview: 'Review your resume for errors and ensure professional formatting throughout.',
        tips: [
          'Check for spelling and grammar errors',
          'Ensure consistent formatting and fonts',
          'Verify contact information accuracy',
          'Test readability and ATS compatibility',
          'Get feedback from others'
        ],
        example: 'Use tools like Grammarly for grammar checking, and ask 2-3 professionals in your network to review your resume for feedback.',
        tools: ['Grammar checkers', 'ATS scanners', 'Formatting guides', 'Peer review']
      }
    }
  ];

  const currentStep = steps.find(step => step.id === activeStep);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg shadow-lg border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center group">
              <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-file-text-line text-white text-xl"></i>
              </div>
              <h1 className="ml-3 text-2xl font-['Pacifico'] bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Resume Teacher</h1>
            </Link>
            <Link href="/builder" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all duration-300 whitespace-nowrap">
              Start Building
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative py-16 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://readdy.ai/api/search-image?query=Professional%20person%20writing%20resume%20and%20CV%20at%20modern%20workspace%20desk%2C%20step-by-step%20process%20visualization%2C%20organized%20workspace%20with%20laptop%20notebook%20and%20planning%20materials%2C%20focused%20concentration%2C%20bright%20natural%20lighting%2C%20productivity%20and%20career%20development%20concept%2C%20clean%20organized%20environment&width=1200&height=400&seq=howto-hero&orientation=landscape"
            alt="How to Make Resume"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-indigo-900/80"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            How to Make a Professional Resume
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Follow our comprehensive 8-step guide to create a resume that gets you hired. 
            Expert tips, real examples, and proven strategies included.
          </p>
          <div className="flex justify-center space-x-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-300">8</div>
              <div className="text-sm text-blue-100">Easy Steps</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-indigo-300">90</div>
              <div className="text-sm text-blue-100">Minutes Total</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-300">95%</div>
              <div className="text-sm text-blue-100">Success Rate</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Step Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-6 border border-white/20 sticky top-6">
              <h3 className="font-bold text-gray-900 mb-6">Resume Building Steps</h3>
              <div className="space-y-2">
                {steps.map((step) => (
                  <button
                    key={step.id}
                    onClick={() => setActiveStep(step.id)}
                    className={`w-full text-left p-4 rounded-xl transition-all duration-300 ${
                      activeStep === step.id
                        ? 'bg-indigo-600 text-white shadow-lg'
                        : 'bg-white/60 text-gray-700 hover:bg-indigo-50 hover:text-indigo-600'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${
                        activeStep === step.id ? 'bg-white/20' : 'bg-indigo-100'
                      }`}>
                        <i className={`${step.icon} ${activeStep === step.id ? 'text-white' : 'text-indigo-600'}`}></i>
                      </div>
                      <div>
                        <div className="font-semibold text-sm">{step.title}</div>
                        <div className={`text-xs ${activeStep === step.id ? 'text-indigo-100' : 'text-gray-500'}`}>
                          {step.duration}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              
              {/* Progress */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Progress</span>
                  <span className="text-sm text-indigo-600 font-semibold">
                    {Math.round((activeStep / steps.length) * 100)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full transition-all duration-500"
                    style={{ width: `${(activeStep / steps.length) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* Step Content */}
          <div className="lg:col-span-3">
            {currentStep && (
              <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden">
                {/* Step Header */}
                <div className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10 p-8">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mr-4">
                        <i className={`${currentStep.icon} text-white text-xl`}></i>
                      </div>
                      <div>
                        <div className="text-sm text-indigo-600 font-semibold">Step {currentStep.id} of {steps.length}</div>
                        <h2 className="text-2xl font-bold text-gray-900">{currentStep.title}</h2>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-500">Estimated Time</div>
                      <div className="text-lg font-semibold text-indigo-600">{currentStep.duration}</div>
                    </div>
                  </div>
                  <p className="text-gray-700 text-lg">{currentStep.content.overview}</p>
                </div>

                {/* Step Content */}
                <div className="p-8">
                  {/* Tips Section */}
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                      <i className="ri-lightbulb-line text-yellow-500 mr-2"></i>
                      Key Tips
                    </h3>
                    <div className="bg-yellow-50/80 backdrop-blur-sm rounded-xl p-6 border border-yellow-200/50">
                      <ul className="space-y-3">
                        {currentStep.content.tips.map((tip, index) => (
                          <li key={index} className="flex items-start">
                            <i className="ri-check-line text-emerald-600 mr-3 mt-0.5 flex-shrink-0"></i>
                            <span className="text-gray-700">{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Example Section */}
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                      <i className="ri-file-text-line text-blue-500 mr-2"></i>
                      Example
                    </h3>
                    <div className="bg-blue-50/80 backdrop-blur-sm rounded-xl p-6 border border-blue-200/50">
                      <pre className="text-gray-700 whitespace-pre-wrap font-mono text-sm bg-white/60 p-4 rounded-lg border">
{currentStep.content.example}
                      </pre>
                    </div>
                  </div>

                  {/* Tools Section */}
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                      <i className="ri-tools-line text-purple-500 mr-2"></i>
                      Helpful Tools
                    </h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      {currentStep.content.tools.map((tool, index) => (
                        <div key={index} className="bg-purple-50/80 backdrop-blur-sm rounded-xl p-4 border border-purple-200/50 hover:bg-purple-100/80 transition-colors duration-300 cursor-pointer">
                          <div className="flex items-center">
                            <i className="ri-tool-line text-purple-600 mr-3"></i>
                            <span className="text-gray-700 font-medium">{tool}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Navigation */}
                  <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                    <button
                      onClick={() => setActiveStep(Math.max(1, activeStep - 1))}
                      disabled={activeStep === 1}
                      className="flex items-center px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                    >
                      <i className="ri-arrow-left-line mr-2"></i>
                      Previous Step
                    </button>

                    <div className="flex items-center space-x-2">
                      {steps.map((step) => (
                        <div
                          key={step.id}
                          className={`w-3 h-3 rounded-full transition-all duration-300 ${
                            step.id === activeStep
                              ? 'bg-indigo-600 scale-125'
                              : step.id < activeStep
                                ? 'bg-emerald-500'
                                : 'bg-gray-300'
                          }`}
                        ></div>
                      ))}
                    </div>

                    {activeStep < steps.length ? (
                      <button
                        onClick={() => setActiveStep(Math.min(steps.length, activeStep + 1))}
                        className="flex items-center px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all duration-300 whitespace-nowrap"
                      >
                        Next Step
                        <i className="ri-arrow-right-line ml-2"></i>
                      </button>
                    ) : (
                      <Link href="/builder" className="flex items-center px-6 py-3 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-xl hover:shadow-lg transition-all duration-300 whitespace-nowrap">
                        Start Building Now
                        <i className="ri-rocket-line ml-2"></i>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 py-16 mt-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Build Your Resume?
          </h2>
          <p className="text-xl text-indigo-100 mb-8">
            Use our AI-powered builder to create your professional resume in minutes
          </p>
          <Link href="/builder" className="inline-flex items-center bg-white text-indigo-600 px-8 py-4 rounded-xl font-bold hover:bg-indigo-50 transition-all duration-300 whitespace-nowrap">
            <i className="ri-magic-line mr-3 text-xl"></i>
            Build with AI Assistant
          </Link>
        </div>
      </div>
    </div>
  );
}