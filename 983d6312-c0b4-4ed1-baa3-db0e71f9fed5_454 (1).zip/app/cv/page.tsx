
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function CVPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', name: 'CV Overview', icon: 'ri-file-list-3-line' },
    { id: 'templates', name: 'CV Templates', icon: 'ri-layout-2-line' },
    { id: 'examples', name: 'CV Examples', icon: 'ri-newspaper-line' },
    { id: 'builder', name: 'CV Builder', icon: 'ri-edit-2-line' }
  ];

  const cvTemplates = [
    {
      id: 'academic',
      name: 'Academic CV Template',
      category: 'Academic',
      description: 'Comprehensive template for professors, researchers, and PhD candidates',
      features: ['Publications section', 'Research experience', 'Conference presentations', 'Grants & funding'],
      image: 'Academic CV template with detailed sections for research publications, conference presentations, grants and awards, professional academic layout with clear typography and organized formatting'
    },
    {
      id: 'medical',
      name: 'Medical CV Template',
      category: 'Healthcare',
      description: 'Specialized format for physicians, nurses, and healthcare professionals',
      features: ['Medical education', 'Clinical experience', 'Certifications', 'Publications'],
      image: 'Medical CV template design for healthcare professionals, clean layout with sections for medical education, clinical rotations, certifications, and professional experience'
    },
    {
      id: 'research',
      name: 'Research Scientist CV',
      category: 'Science',
      description: 'Perfect for research scientists and laboratory professionals',
      features: ['Research projects', 'Technical skills', 'Publications', 'Lab experience'],
      image: 'Research scientist CV template with comprehensive sections for laboratory experience, research projects, scientific publications, and technical expertise'
    },
    {
      id: 'legal',
      name: 'Legal Professional CV',
      category: 'Legal',
      description: 'Tailored for lawyers, attorneys, and legal professionals',
      features: ['Bar admissions', 'Case experience', 'Legal publications', 'Court appearances'],
      image: 'Legal professional CV template with sections for bar admissions, court experience, legal publications, and professional legal practice history'
    }
  ];

  const cvExamples = [
    {
      id: 1,
      name: 'Dr. Sarah Chen',
      position: 'Research Professor',
      field: 'Biomedical Engineering',
      university: 'Stanford University',
      experience: '15 years',
      publications: 47,
      citations: '2,840',
      highlights: ['NIH Grant Recipient', 'Nature Publications', 'Keynote Speaker'],
      image: 'Professional academic headshot of Dr. Sarah Chen, confident research professor in biomedical engineering, laboratory background with modern research equipment'
    },
    {
      id: 2,
      name: 'Prof. Michael Rodriguez',
      position: 'Associate Professor',
      field: 'Computer Science',
      university: 'MIT',
      experience: '12 years',
      publications: 32,
      citations: '1,956',
      highlights: ['ACM Fellow', 'Best Paper Awards', 'Industry Partnerships'],
      image: 'Professional headshot of Prof. Michael Rodriguez, computer science professor at MIT, modern tech laboratory setting with computers and research equipment'
    },
    {
      id: 3,
      name: 'Dr. Emily Watson',
      position: 'Chief Medical Officer',
      field: 'Cardiology',
      hospital: 'Johns Hopkins',
      experience: '18 years',
      procedures: '2,500+',
      certifications: 8,
      highlights: ['Board Certified', 'Medical Innovations', 'Patient Care Excellence'],
      image: 'Professional medical headshot of Dr. Emily Watson, chief medical officer in cardiology, hospital setting with medical equipment and professional healthcare environment'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/resume" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Resume
              </Link>
              <Link href="/cv" className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-1 whitespace-nowrap">
                CV
              </Link>
              <Link href="/cover-letter" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Cover Letter
              </Link>
              <Link href="/advice" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Advice
              </Link>
              <Link href="/resources" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Resources
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-50 to-emerald-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Professional CV Builder
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Create comprehensive Curriculum Vitae for academic positions, research roles, 
            and professional opportunities that require detailed career documentation.
          </p>
          <Link href="/builder?type=cv" className="inline-flex items-center px-8 py-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-file-list-3-line mr-2"></i>
            Build Your CV
          </Link>
        </div>
      </section>

      {/* Tabs Navigation */}
      <section className="py-8 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-6 py-3 rounded-lg border-2 transition-all duration-300 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-green-600 text-white border-green-600'
                    : 'bg-white text-gray-700 border-gray-200 hover:border-green-300 hover:text-green-600'
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div>
          {/* CV vs Resume Comparison */}
          <section className="py-16 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">CV vs Resume: Understanding the Difference</h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  Choose the right document format for your career goals and target opportunities.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-green-50 border border-green-200 rounded-xl p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                      <i className="ri-file-list-3-line text-white text-xl"></i>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">Curriculum Vitae (CV)</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <i className="ri-check-line text-green-600 text-lg mt-1"></i>
                      <div>
                        <p className="font-semibold text-gray-900">Length: 2+ pages</p>
                        <p className="text-gray-600">Comprehensive document with complete career history</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <i className="ri-check-line text-green-600 text-lg mt-1"></i>
                      <div>
                        <p className="font-semibold text-gray-900">Content: Complete career overview</p>
                        <p className="text-gray-600">Education, research, publications, presentations, awards</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <i className="ri-check-line text-green-600 text-lg mt-1"></i>
                      <div>
                        <p className="font-semibold text-gray-900">Best for: Academic & research positions</p>
                        <p className="text-gray-600">Universities, research institutions, medical roles, international positions</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                      <i className="ri-file-text-line text-white text-xl"></i>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">Resume</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <i className="ri-check-line text-blue-600 text-lg mt-1"></i>
                      <div>
                        <p className="font-semibold text-gray-900">Length: 1-2 pages</p>
                        <p className="text-gray-600">Concise summary of relevant experience</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <i className="ri-check-line text-blue-600 text-lg mt-1"></i>
                      <div>
                        <p className="font-semibold text-gray-900">Content: Targeted information</p>
                        <p className="text-gray-600">Skills and experience relevant to specific job</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <i className="ri-check-line text-blue-600 text-lg mt-1"></i>
                      <div>
                        <p className="font-semibold text-gray-900">Best for: Industry positions</p>
                        <p className="text-gray-600">Corporate jobs, startups, most private sector roles</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Essential CV Sections */}
          <section className="py-16 bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
                Essential CV Sections
              </h2>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-user-line text-blue-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Personal Information</h3>
                  <p className="text-gray-600 text-sm">Contact details, professional title, and brief personal summary</p>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-graduation-cap-line text-green-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Education</h3>
                  <p className="text-gray-600 text-sm">Degrees, institutions, dates, thesis topics, academic achievements</p>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-briefcase-line text-purple-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Professional Experience</h3>
                  <p className="text-gray-600 text-sm">Employment history, research positions, academic appointments</p>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-article-line text-orange-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Publications</h3>
                  <p className="text-gray-600 text-sm">Research papers, articles, books, conference presentations</p>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-award-line text-red-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Awards & Honors</h3>
                  <p className="text-gray-600 text-sm">Scholarships, grants, recognitions, professional achievements</p>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-microscope-line text-teal-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Research Experience</h3>
                  <p className="text-gray-600 text-sm">Research projects, methodologies, findings, collaborations</p>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}

      {/* Templates Tab */}
      {activeTab === 'templates' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Professional CV Templates</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Choose from our collection of CV templates designed for academic and professional fields.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {cvTemplates.map((template) => (
                <div key={template.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 group">
                  <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                    <img
                      src={`https://readdy.ai/api/search-image?query=$%7Btemplate.image%7D&width=400&height=250&seq=cv-template-${template.id}&orientation=landscape`}
                      alt={template.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xl font-semibold text-gray-900">{template.name}</h3>
                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                        {template.category}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-4">{template.description}</p>
                    <div className="mb-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Key Features:</h4>
                      <div className="flex flex-wrap gap-2">
                        {template.features.map((feature, index) => (
                          <span key={index} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                    <Link href={`/builder?template=${template.id}&type=cv`} className="inline-flex items-center text-green-600 font-semibold hover:text-green-700 transition-colors">
                      Use Template
                      <i className="ri-arrow-right-line ml-2"></i>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Examples Tab */}
      {activeTab === 'examples' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Professional CV Examples</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Learn from successful professionals who used these CV formats to advance their careers.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {cvExamples.map((example) => (
                <div key={example.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300">
                  <div className="h-48 bg-gradient-to-br from-green-100 to-emerald-200 flex items-center justify-center">
                    <img
                      src={`https://readdy.ai/api/search-image?query=$%7Bexample.image%7D&width=300&height=200&seq=cv-example-${example.id}&orientation=landscape`}
                      alt={example.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{example.name}</h3>
                    <p className="text-gray-600 mb-1">{example.position}</p>
                    <p className="text-green-600 font-medium mb-4">{example.field} • {example.university || example.hospital}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-gray-500">Experience</p>
                        <p className="font-semibold text-gray-900">{example.experience}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Publications</p>
                        <p className="font-semibold text-gray-900">{example.publications || example.procedures}</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Key Achievements:</h4>
                      <div className="flex flex-wrap gap-2">
                        {example.highlights.map((highlight, index) => (
                          <span key={index} className="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">
                            {highlight}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <button className="w-full px-4 py-2 text-green-600 border border-green-300 rounded-lg hover:bg-green-50 transition-colors">
                      View Full CV
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Builder Tab */}
      {activeTab === 'builder' && (
        <section className="py-16 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">CV Building Process</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Follow our step-by-step process to create a comprehensive CV that showcases your expertise.
              </p>
            </div>

            <div className="space-y-8">
              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">1</span>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Choose Your CV Template</h3>
                  <p className="text-gray-600 mb-4">
                    Select from academic, medical, research, or professional CV templates designed for your field.
                  </p>
                  <div className="flex items-center text-green-600 font-semibold">
                    <i className="ri-layout-2-line mr-2"></i>
                    Browse Templates
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">2</span>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Add Personal Information</h3>
                  <p className="text-gray-600 mb-4">
                    Include comprehensive contact details, professional summary, and career objectives.
                  </p>
                  <div className="flex items-center text-green-600 font-semibold">
                    <i className="ri-user-line mr-2"></i>
                    Personal Details
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">3</span>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Education & Qualifications</h3>
                  <p className="text-gray-600 mb-4">
                    Detail your academic background, degrees, certifications, and ongoing education.
                  </p>
                  <div className="flex items-center text-green-600 font-semibold">
                    <i className="ri-graduation-cap-line mr-2"></i>
                    Academic History
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">4</span>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Professional Experience</h3>
                  <p className="text-gray-600 mb-4">
                    Document your complete career history, research positions, and academic appointments.
                  </p>
                  <div className="flex items-center text-green-600 font-semibold">
                    <i className="ri-briefcase-line mr-2"></i>
                    Work History
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">5</span>
                </div>
                <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Publications & Research</h3>
                  <p className="text-gray-600 mb-4">
                    List publications, research projects, conference presentations, and academic contributions.
                  </p>
                  <div className="flex items-center text-green-600 font-semibold">
                    <i className="ri-article-line mr-2"></i>
                    Academic Work
                  </div>
                </div>
              </div>

              <div className="text-center mt-12">
                <Link href="/builder?type=cv" className="inline-flex items-center px-8 py-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-lg font-semibold whitespace-nowrap">
                  <i className="ri-add-line mr-2"></i>
                  Start Building Your CV
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-emerald-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Create Your Professional CV?
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
            Build a comprehensive CV that showcases your academic achievements and professional expertise.
          </p>
          <Link href="/builder?type=cv" className="inline-flex items-center px-8 py-4 bg-white text-green-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-rocket-2-line mr-2"></i>
            Build CV Now
          </Link>
        </div>
      </section>
    </div>
  );
}
