'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import ProfileSettings from '@/components/ProfileSettings';
import RoleManager from '@/components/RoleManager';
import { supabase, userService, emailService, UserProfile } from '@/lib/supabase';

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('profile');
  const [permissions, setPermissions] = useState<string[]>([]);

  useEffect(() => {
    checkAuthAndLoadData();
  }, []);

  const checkAuthAndLoadData = async () => {
    try {
      const { data: { user: authUser } } = await supabase.auth.getUser();
      
      if (!authUser) {
        router.push('/login');
        return;
      }

      // Load user profile
      const profile = await userService.getProfile(authUser.id);
      if (profile) {
        setUser(profile);
        
        // Load user permissions
        const userPermissions = await userService.getUserPermissions(authUser.id);
        setPermissions(userPermissions.map(p => p.permission));
      }
    } catch (error) {
      console.error('Error loading user data:', error);
      router.push('/login');
    } finally {
      setLoading(false);
    }
  };

  const handleProfileUpdate = async (updatedProfile: UserProfile) => {
    setUser(updatedProfile);
    
    // Send profile update notification email
    try {
      await emailService.sendNotificationEmail(
        updatedProfile.id,
        'profile_updated',
        updatedProfile.email,
        'Profile Updated Successfully',
        ''
      );
    } catch (error) {
      console.error('Error sending profile update email:', error);
    }
  };

  const handleDeleteAccount = async () => {
    const confirmed = window.confirm(
      'Are you sure you want to delete your account? This action cannot be undone and all your data will be permanently removed.'
    );

    if (!confirmed) return;

    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      router.push('/');
    } catch (error) {
      console.error('Error deleting account:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const tabs = [
    { id: 'profile', label: 'Profile Settings', icon: 'ri-user-line' },
    { id: 'permissions', label: 'Role Management', icon: 'ri-shield-user-line', adminOnly: true },
    { id: 'notifications', label: 'Email History', icon: 'ri-mail-line' }
  ];

  const visibleTabs = tabs.filter(tab => !tab.adminOnly || user.role === 'admin');

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Account Settings</h1>
              <p className="text-gray-600 mt-2">Manage your profile, permissions, and preferences</p>
            </div>
            <Link 
              href="/dashboard"
              className="flex items-center px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Back to Dashboard
            </Link>
          </div>
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex items-center space-x-6">
            {user.avatar_url ? (
              <img 
                src={user.avatar_url} 
                alt={`${user.first_name} ${user.last_name}`}
                className="w-20 h-20 rounded-full border-4 border-gray-100 object-cover"
              />
            ) : (
              <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-2xl font-bold">
                  {(user.first_name || user.email[0]).toUpperCase()}
                </span>
              </div>
            )}
            
            <div className="flex-1">
              <h2 className="text-2xl font-semibold text-gray-900">
                {user.first_name || user.last_name 
                  ? `${user.first_name || ''} ${user.last_name || ''}`.trim()
                  : user.email
                }
              </h2>
              <p className="text-gray-600">{user.email}</p>
              <div className="flex items-center space-x-4 mt-2">
                <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                  user.role === 'admin'
                    ? 'bg-red-100 text-red-800'
                    : user.role === 'premium'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {user.role}
                </span>
                
                <div className="flex items-center text-sm text-gray-500">
                  <i className="ri-shield-check-line mr-1"></i>
                  {user.email_verified ? 'Verified' : 'Not Verified'}
                </div>
                
                <div className="flex items-center text-sm text-gray-500">
                  <i className="ri-calendar-line mr-1"></i>
                  Joined {new Date(user.created_at).toLocaleDateString()}
                </div>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-sm text-gray-500">Permissions</p>
              <p className="text-lg font-semibold text-gray-900">{permissions.length}</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              {visibleTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <i className={`${tab.icon} mr-2`}></i>
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div>
          {activeTab === 'profile' && (
            <ProfileSettings 
              userId={user.id} 
              onUpdate={handleProfileUpdate}
            />
          )}
          
          {activeTab === 'permissions' && user.role === 'admin' && (
            <RoleManager 
              currentUserId={user.id}
              currentUserRole={user.role}
            />
          )}
          
          {activeTab === 'notifications' && (
            <EmailNotificationHistory userId={user.id} />
          )}
        </div>

        {/* Danger Zone */}
        {activeTab === 'profile' && (
          <div className="mt-8 bg-white rounded-xl shadow-sm border border-red-200 p-6">
            <h3 className="text-lg font-semibold text-red-900 mb-4">Danger Zone</h3>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">Delete Account</h4>
                <p className="text-sm text-gray-600">Permanently delete your account and all associated data</p>
              </div>
              <button
                onClick={handleDeleteAccount}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors whitespace-nowrap"
              >
                <i className="ri-delete-bin-line mr-2"></i>
                Delete Account
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Email Notification History Component
function EmailNotificationHistory({ userId }: { userId: string }) {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, [userId]);

  const loadNotifications = async () => {
    try {
      const history = await emailService.getNotificationHistory(userId);
      setNotifications(history);
    } catch (error) {
      console.error('Error loading notification history:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-center py-8">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Email Notification History</h3>
          <p className="text-gray-600">View all emails sent to your account</p>
        </div>
        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
          {notifications.length} emails
        </span>
      </div>

      {notifications.length === 0 ? (
        <div className="text-center py-8">
          <i className="ri-mail-line text-6xl text-gray-300 mb-4"></i>
          <h4 className="font-semibold text-gray-900 mb-2">No Email History</h4>
          <p className="text-gray-600">Email notifications will appear here once sent</p>
        </div>
      ) : (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-900">{notification.subject}</h4>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    notification.status === 'sent'
                      ? 'bg-green-100 text-green-800'
                      : notification.status === 'failed'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {notification.status}
                  </span>
                  <span className="text-sm text-gray-500">
                    {new Date(notification.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span className="flex items-center">
                  <i className="ri-mail-line mr-1"></i>
                  {notification.email_type.replace('_', ' ').toUpperCase()}
                </span>
                {notification.sent_at && (
                  <span className="flex items-center">
                    <i className="ri-time-line mr-1"></i>
                    Sent {new Date(notification.sent_at).toLocaleTimeString()}
                  </span>
                )}
              </div>
              
              {notification.error_message && (
                <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-700">
                  <i className="ri-error-warning-line mr-1"></i>
                  {notification.error_message}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}