
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import GoogleAuth, { GoogleUser } from '../../lib/google-auth';
import { GOOGLE_CLIENT_ID } from '../../lib/config';

export default function LoginPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState({ google: false });
  const [errors, setErrors] = useState<string[]>([]);
  const [googleAuth, setGoogleAuth] = useState<GoogleAuth | null>(null);

  // Initialize Google Auth
  useEffect(() => {
    const initGoogleAuth = async () => {
      try {
        const auth = GoogleAuth.getInstance();
        await auth.initialize(GOOGLE_CLIENT_ID);
        setGoogleAuth(auth);
      } catch (error) {
        console.error('Failed to initialize Google Auth:', error);
        setErrors(['Google Sign-In is temporarily unavailable']);
      }
    };

    initGoogleAuth();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    setErrors([]);
  };

  const validateForm = () => {
    const newErrors: string[] = [];
    
    if (!formData.email.trim()) newErrors.push('Email is required');
    if (!formData.email.includes('@')) newErrors.push('Please enter a valid email');
    if (!formData.password.trim()) newErrors.push('Password is required');
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);
    
    try {
      // Store user data in localStorage for demo
      const userData = {
        id: Date.now().toString(),
        firstName: 'John',
        lastName: 'Doe',
        email: formData.email,
        createdAt: new Date().toISOString(),
        loginMethod: 'email'
      };
      
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('isAuthenticated', 'true');
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      router.push('/dashboard');
    } catch (error) {
      setErrors(['Login failed. Please check your credentials.']);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    if (!googleAuth) {
      setErrors(['Google Sign-In not initialized']);
      return;
    }

    setSocialLoading(prev => ({ ...prev, google: true }));
    
    try {
      const googleUser: GoogleUser = await googleAuth.signIn();
      
      // Create user data from Google response
      const userData = {
        id: googleUser.id,
        firstName: googleUser.given_name || googleUser.name.split(' ')[0] || 'Google',
        lastName: googleUser.family_name || googleUser.name.split(' ').slice(1).join(' ') || 'User',
        email: googleUser.email,
        name: googleUser.name,
        picture: googleUser.picture,
        createdAt: new Date().toISOString(),
        loginMethod: 'google'
      };
      
      // Store user data
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('googleAuthToken', 'authenticated');
      
      // Redirect to dashboard
      router.push('/dashboard');
    } catch (error: any) {
      console.error('Google login error:', error);
      if (error.message?.includes('popup_closed_by_user')) {
        setErrors(['Google Sign-In was cancelled']);
      } else if (error.message?.includes('access_denied')) {
        setErrors(['Google Sign-In access denied']);
      } else {
        setErrors(['Google Sign-In failed. Please try again.']);
      }
    } finally {
      setSocialLoading(prev => ({ ...prev, google: false }));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50/80 via-white to-purple-50/80 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-r from-indigo-400/20 to-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-r from-blue-400/20 to-indigo-600/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-purple-400/10 to-pink-600/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      <div className="absolute top-0 left-0 right-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center group">
            <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-700 rounded-xl flex items-center justify-center mr-3 group-hover:scale-110 transition-transform duration-300 shadow-lg">
              <i className="ri-file-text-line text-white text-xl"></i>
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent font-['Pacifico']">ResumeTeacher</span>
          </Link>
        </div>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen py-12 px-4">
        <div className="w-full max-w-md">
          {/* Main Card */}
          <div className="bg-white/80 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/20 p-8 relative overflow-hidden">
            {/* Card Background Pattern */}
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-50/50 to-purple-50/50 rounded-3xl"></div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-indigo-200/30 to-transparent rounded-3xl"></div>
            
            <div className="relative">
              {/* Header */}
              <div className="text-center mb-8">
                <div className="w-20 h-20 bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg hover:scale-105 transition-transform duration-300">
                  <i className="ri-user-line text-white text-3xl"></i>
                </div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent mb-3">
                  Welcome Back
                </h1>
                <p className="text-gray-600 text-lg">
                  Sign in to continue building your resume
                </p>
              </div>

              {/* Error Messages */}
              {errors.length > 0 && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
                  <div className="flex items-center mb-2">
                    <i className="ri-error-warning-line text-red-600 mr-2"></i>
                    <h3 className="text-red-800 font-semibold">Login Failed:</h3>
                  </div>
                  <ul className="text-red-700 text-sm space-y-1">
                    {errors.map((error, index) => (
                      <li key={index}>• {error}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Social Login Buttons */}
              <div className="space-y-4 mb-8">
                <button
                  onClick={handleGoogleLogin}
                  disabled={socialLoading.google || isLoading}
                  className="w-full flex items-center justify-center py-4 px-6 border-2 border-gray-200 rounded-xl shadow-sm bg-white/90 backdrop-blur-sm text-gray-700 hover:bg-gray-50 hover:border-gray-300 hover:shadow-lg transition-all duration-300 group disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {socialLoading.google ? (
                    <div className="w-5 h-5 border-2 border-gray-400 border-t-red-500 rounded-full animate-spin mr-3"></div>
                  ) : (
                    <i className="ri-google-fill text-red-500 text-xl mr-3 group-hover:scale-110 transition-transform duration-300"></i>
                  )}
                  <span className="font-semibold">
                    {socialLoading.google ? 'Signing in...' : 'Continue with Google'}
                  </span>
                </button>
              </div>

              {/* Divider */}
              <div className="relative mb-8">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-white text-gray-500 font-medium">Or sign in with email</span>
                </div>
              </div>

              {/* Email Login Form */}
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    Email address
                  </label>
                  <div className="relative">
                    <i className="ri-mail-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-semibold text-gray-700 mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <i className="ri-lock-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <input
                      id="password"
                      name="password"
                      type="password"
                      autoComplete="current-password"
                      required
                      value={formData.password}
                      onChange={handleInputChange}
                      className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300"
                      placeholder="Enter your password"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember-me"
                      name="rememberMe"
                      type="checkbox"
                      checked={formData.rememberMe}
                      onChange={handleInputChange}
                      className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700">
                      Remember me
                    </label>
                  </div>

                  <div className="text-sm">
                    <Link href="/forgot-password" className="text-indigo-600 hover:text-indigo-500 font-semibold transition-colors duration-300">
                      Forgot your password?
                    </Link>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || socialLoading.google}
                  className="w-full flex justify-center items-center py-4 px-6 border border-transparent rounded-xl shadow-lg text-white bg-gradient-to-r from-indigo-600 to-purple-700 hover:from-indigo-700 hover:to-purple-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 font-semibold transition-all duration-300 hover:scale-105 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 whitespace-nowrap"
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                      Signing In...
                    </>
                  ) : (
                    <>
                      <i className="ri-login-circle-line mr-2"></i>
                      Sign In
                    </>
                  )}
                </button>
              </form>

              <div className="mt-8 text-center">
                <p className="text-sm text-gray-600">
                  Don't have an account?{' '}
                  <Link href="/signup" className="text-indigo-600 hover:text-indigo-500 font-semibold transition-colors duration-300">
                    Sign up for free
                  </Link>
                </p>
              </div>
            </div>
          </div>

          {/* Benefits Card */}
          <div className="mt-8">
            <div className="bg-white/60 backdrop-blur-lg rounded-2xl p-6 shadow-lg border border-white/20">
              <h3 className="text-lg font-bold text-gray-900 mb-4 text-center">
                Why Choose ResumeTeacher?
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700 text-sm font-medium">Save unlimited resumes</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700 text-sm font-medium">Premium templates</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700 text-sm font-medium">AI-powered suggestions</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-600 rounded-lg flex items-center justify-center">
                    <i className="ri-check-line text-white text-sm"></i>
                  </div>
                  <span className="text-gray-700 text-sm font-medium">Track applications</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
