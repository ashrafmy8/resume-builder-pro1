export default function PrivacyPage() {
  const lastUpdated = "January 15, 2024";
  
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-50 to-purple-50 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Privacy Policy</h1>
          <p className="text-xl text-gray-600 mb-2">
            Your privacy is important to us. This policy explains how we collect, use, and protect your information.
          </p>
          <p className="text-gray-500">Last updated: {lastUpdated}</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <div className="prose prose-lg max-w-none">
            
            {/* Information We Collect */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">1. Information We Collect</h2>
              
              <div className="bg-gray-50 rounded-2xl p-8 mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Personal Information</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Name, email address, and contact information</li>
                  <li>• Account credentials and profile information</li>
                  <li>• Resume content and career-related information</li>
                  <li>• Payment information (processed securely by third-party providers)</li>
                  <li>• Communication history with our support team</li>
                </ul>
              </div>

              <div className="bg-gray-50 rounded-2xl p-8 mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Usage Information</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• How you interact with our website and services</li>
                  <li>• Device information, IP address, and browser type</li>
                  <li>• Cookies and similar tracking technologies</li>
                  <li>• Feature usage and preferences</li>
                  <li>• Error logs and performance data</li>
                </ul>
              </div>
            </div>

            {/* How We Use Information */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">2. How We Use Your Information</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-indigo-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-indigo-900 mb-3">Service Provision</h3>
                  <ul className="space-y-2 text-indigo-800 text-sm">
                    <li>• Create and manage your account</li>
                    <li>• Provide resume building tools</li>
                    <li>• Process payments and subscriptions</li>
                    <li>• Deliver customer support</li>
                  </ul>
                </div>

                <div className="bg-purple-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-purple-900 mb-3">Improvement & Analytics</h3>
                  <ul className="space-y-2 text-purple-800 text-sm">
                    <li>• Analyze usage patterns</li>
                    <li>• Improve our services</li>
                    <li>• Develop new features</li>
                    <li>• Ensure security and prevent fraud</li>
                  </ul>
                </div>

                <div className="bg-emerald-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-emerald-900 mb-3">Communication</h3>
                  <ul className="space-y-2 text-emerald-800 text-sm">
                    <li>• Send service updates</li>
                    <li>• Respond to inquiries</li>
                    <li>• Share helpful tips (with consent)</li>
                    <li>• Notify about policy changes</li>
                  </ul>
                </div>

                <div className="bg-orange-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-orange-900 mb-3">Legal Compliance</h3>
                  <ul className="space-y-2 text-orange-800 text-sm">
                    <li>• Comply with legal obligations</li>
                    <li>• Protect our rights and interests</li>
                    <li>• Resolve disputes</li>
                    <li>• Enforce our terms of service</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Information Sharing */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">3. Information Sharing and Disclosure</h2>
              
              <div className="bg-red-50 border border-red-200 rounded-2xl p-8 mb-6">
                <h3 className="text-xl font-semibold text-red-900 mb-4">We Never Sell Your Personal Information</h3>
                <p className="text-red-800">
                  ResumeTeacher does not sell, trade, or rent your personal information to third parties for marketing purposes.
                </p>
              </div>

              <div className="space-y-6">
                <div className="border border-gray-200 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Service Providers</h3>
                  <p className="text-gray-700 mb-3">We may share information with trusted third-party service providers who help us operate our business:</p>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• Payment processors (Stripe, PayPal)</li>
                    <li>• Cloud hosting services (AWS, Google Cloud)</li>
                    <li>• Email service providers</li>
                    <li>• Analytics platforms</li>
                  </ul>
                </div>

                <div className="border border-gray-200 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Legal Requirements</h3>
                  <p className="text-gray-700">
                    We may disclose information when required by law, court order, or to protect our rights, property, or safety of our users.
                  </p>
                </div>

                <div className="border border-gray-200 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Business Transfers</h3>
                  <p className="text-gray-700">
                    In the event of a merger, acquisition, or sale of assets, user information may be transferred as part of the transaction.
                  </p>
                </div>
              </div>
            </div>

            {/* Data Security */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">4. Data Security</h2>
              
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Technical Safeguards</h3>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• SSL/TLS encryption for data transmission</li>
                      <li>• Encrypted data storage</li>
                      <li>• Regular security audits and testing</li>
                      <li>• Secure access controls and authentication</li>
                      <li>• Regular software updates and patches</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Organizational Safeguards</h3>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Employee privacy training</li>
                      <li>• Limited access on need-to-know basis</li>
                      <li>• Incident response procedures</li>
                      <li>• Regular backup and recovery processes</li>
                      <li>• Third-party security assessments</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Your Rights */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">5. Your Privacy Rights</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
                        <i className="ri-eye-line text-indigo-600"></i>
                      </div>
                      <h3 className="font-semibold text-gray-900">Access</h3>
                    </div>
                    <p className="text-gray-600 text-sm">Request a copy of the personal information we have about you</p>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center mr-3">
                        <i className="ri-edit-line text-emerald-600"></i>
                      </div>
                      <h3 className="font-semibold text-gray-900">Correction</h3>
                    </div>
                    <p className="text-gray-600 text-sm">Update or correct inaccurate personal information</p>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-3">
                        <i className="ri-delete-bin-line text-red-600"></i>
                      </div>
                      <h3 className="font-semibold text-gray-900">Deletion</h3>
                    </div>
                    <p className="text-gray-600 text-sm">Request deletion of your personal information</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                        <i className="ri-download-line text-purple-600"></i>
                      </div>
                      <h3 className="font-semibold text-gray-900">Portability</h3>
                    </div>
                    <p className="text-gray-600 text-sm">Export your data in a commonly used format</p>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                        <i className="ri-forbid-line text-orange-600"></i>
                      </div>
                      <h3 className="font-semibold text-gray-900">Opt-out</h3>
                    </div>
                    <p className="text-gray-600 text-sm">Unsubscribe from marketing communications</p>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                        <i className="ri-question-line text-blue-600"></i>
                      </div>
                      <h3 className="font-semibold text-gray-900">Object</h3>
                    </div>
                    <p className="text-gray-600 text-sm">Object to certain uses of your personal information</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 bg-blue-50 rounded-2xl p-6">
                <h3 className="text-lg font-semibold text-blue-900 mb-3">How to Exercise Your Rights</h3>
                <p className="text-blue-800">
                  To exercise any of these rights, please contact us at privacy@resumeteacher.com or through our contact form. 
                  We will respond to your request within 30 days.
                </p>
              </div>
            </div>

            {/* Cookies */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">6. Cookies and Tracking Technologies</h2>
              
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">What Are Cookies?</h3>
                  <p className="text-gray-700 mb-4">
                    Cookies are small text files stored on your device that help us provide and improve our services.
                  </p>
                  
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-xl p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Essential Cookies</h4>
                      <p className="text-gray-600 text-sm">Required for basic website functionality</p>
                    </div>
                    <div className="bg-white rounded-xl p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Analytics Cookies</h4>
                      <p className="text-gray-600 text-sm">Help us understand how you use our site</p>
                    </div>
                    <div className="bg-white rounded-xl p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Preference Cookies</h4>
                      <p className="text-gray-600 text-sm">Remember your settings and preferences</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Managing Cookies</h3>
                  <p className="text-gray-700">
                    You can control cookies through your browser settings. However, disabling certain cookies may affect website functionality.
                  </p>
                </div>
              </div>
            </div>

            {/* International Users */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">7. International Users</h2>
              
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Global Service</h3>
                <p className="text-gray-700 mb-4">
                  ResumeTeacher serves users worldwide. If you are located outside the United States, 
                  please note that your information may be transferred to and processed in the United States.
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">GDPR Compliance</h4>
                    <p className="text-gray-600 text-sm">
                      For European users, we comply with GDPR requirements and provide additional rights and protections.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Data Protection</h4>
                    <p className="text-gray-600 text-sm">
                      We implement appropriate safeguards to protect your information during international transfers.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Children's Privacy */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">8. Children's Privacy</h2>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-yellow-900 mb-4">Age Requirement</h3>
                <p className="text-yellow-800 mb-4">
                  ResumeTeacher is not intended for children under 13 years of age. We do not knowingly collect 
                  personal information from children under 13.
                </p>
                <p className="text-yellow-800">
                  If we become aware that we have collected personal information from a child under 13, 
                  we will take steps to delete such information promptly.
                </p>
              </div>
            </div>

            {/* Changes to Policy */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">9. Changes to This Privacy Policy</h2>
              
              <div className="bg-indigo-50 rounded-2xl p-8">
                <p className="text-indigo-800 mb-4">
                  We may update this Privacy Policy from time to time. When we make changes, we will:
                </p>
                <ul className="space-y-2 text-indigo-700">
                  <li>• Update the "Last Updated" date at the top of this policy</li>
                  <li>• Notify you via email if the changes are significant</li>
                  <li>• Post the updated policy on our website</li>
                  <li>• Provide a summary of key changes when appropriate</li>
                </ul>
                <p className="text-indigo-800 mt-4">
                  We encourage you to review this Privacy Policy periodically to stay informed about how we protect your information.
                </p>
              </div>
            </div>

            {/* Contact Information */}
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">10. Contact Us</h2>
              
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Get in Touch</h3>
                <p className="text-gray-700 mb-6">
                  If you have any questions about this Privacy Policy or our privacy practices, please contact us:
                </p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">General Inquiries</h4>
                    <div className="space-y-2 text-gray-700">
                      <p>Email: privacy@resumeteacher.com</p>
                      <p>Response time: Within 48 hours</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Data Protection Officer</h4>
                    <div className="space-y-2 text-gray-700">
                      <p>Email: dpo@resumeteacher.com</p>
                      <p>For GDPR-related inquiries</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}