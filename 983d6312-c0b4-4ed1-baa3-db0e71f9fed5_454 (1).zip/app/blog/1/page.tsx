'use client';

import Link from 'next/link';

export default function BlogPost1() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-50 to-blue-50 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium">
              Resume Tips
            </span>
            <h1 className="mt-6 text-4xl font-bold text-gray-900 sm:text-5xl">
              10 Resume Mistakes That Are Costing You Job Interviews
            </h1>
            <div className="mt-6 flex items-center justify-center space-x-6 text-gray-600">
              <span>By Sarah Johnson</span>
              <span>•</span>
              <span>8 min read</span>
              <span>•</span>
              <span>Dec 15, 2024</span>
            </div>
          </div>
        </div>
      </section>

      {/* Article Content */}
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="prose prose-lg max-w-none">
          <img 
            src="https://readdy.ai/api/search-image?query=Professional%20woman%20reviewing%20resume%20documents%20at%20modern%20office%20desk%20with%20laptop%2C%20focused%20expression%2C%20clean%20workspace%20with%20coffee%20and%20notes%2C%20bright%20natural%20lighting%2C%20business%20professional%20atmosphere&width=800&height=400&seq=resume-mistakes-hero&orientation=landscape"
            alt="Professional reviewing resume"
            className="w-full h-96 object-cover rounded-xl mb-8"
          />

          <p className="text-xl text-gray-700 leading-relaxed mb-8">
            Your resume is your first impression with potential employers, but common mistakes could be preventing you from landing those crucial job interviews. Here are the 10 most damaging resume errors and how to fix them.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">1. Using an Unprofessional Email Address</h2>
          <p className="text-gray-700 mb-6">
            Email addresses like "partygirl123@email.com" or "coolguy2000@email.com" immediately signal unprofessionalism. Create a simple email using your first and last name, such as john.smith@email.com or johnsmith2024@email.com.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">2. Including Irrelevant Personal Information</h2>
          <p className="text-gray-700 mb-6">
            Your resume shouldn't include your age, marital status, photo (unless specifically requested), or personal hobbies unrelated to the job. This information takes up valuable space and can lead to unconscious bias.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">3. Poor Formatting and Design</h2>
          <p className="text-gray-700 mb-6">
            Inconsistent fonts, poor spacing, and cluttered layouts make your resume hard to read. Use consistent formatting throughout, plenty of white space, and stick to 1-2 professional fonts like Arial or Calibri.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">4. Generic Objective Statements</h2>
          <p className="text-gray-700 mb-6">
            Avoid vague statements like "Seeking a challenging position to utilize my skills." Instead, write a compelling professional summary that highlights your specific achievements and value proposition.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">5. Listing Job Duties Instead of Achievements</h2>
          <p className="text-gray-700 mb-6">
            Don't just list what you were responsible for - showcase what you accomplished. Use action verbs and quantify your achievements with specific numbers, percentages, and metrics.
          </p>
          
          <div className="bg-blue-50 border-l-4 border-blue-500 p-6 my-8">
            <h3 className="text-lg font-semibold text-blue-900 mb-2">Example Transformation:</h3>
            <p className="text-blue-800 mb-2"><strong>Before:</strong> "Responsible for managing social media accounts"</p>
            <p className="text-blue-800"><strong>After:</strong> "Increased social media engagement by 150% and grew follower base from 5K to 25K in 6 months"</p>
          </div>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">6. Spelling and Grammar Errors</h2>
          <p className="text-gray-700 mb-6">
            Even minor typos can eliminate you from consideration. Proofread multiple times, use spell-check tools, and have someone else review your resume before submitting.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">7. Including Outdated or Irrelevant Skills</h2>
          <p className="text-gray-700 mb-6">
            Remove outdated software skills (like Windows 95) and focus on current, relevant technologies. Tailor your skills section to match the job requirements.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">8. Wrong Resume Length</h2>
          <p className="text-gray-700 mb-6">
            For most professionals, one page is ideal. Senior executives may use two pages. Never exceed two pages unless you're in academia or have extensive publications.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">9. Not Tailoring for Each Application</h2>
          <p className="text-gray-700 mb-6">
            Sending the same generic resume to every job is a major mistake. Customize your resume for each position by highlighting relevant experience and using keywords from the job description.
          </p>

          <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">10. Ignoring ATS Compatibility</h2>
          <p className="text-gray-700 mb-6">
            Many companies use Applicant Tracking Systems (ATS) to screen resumes. Avoid graphics, tables, and unusual formatting that ATS can't read. Use standard section headings and save as both PDF and Word formats.
          </p>

          <div className="bg-gray-50 rounded-xl p-8 my-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Key Takeaways</h3>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start">
                <i className="ri-check-line text-green-500 mr-3 mt-1"></i>
                Use a professional email address and remove personal information
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-green-500 mr-3 mt-1"></i>
                Focus on achievements with quantifiable results, not job duties
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-green-500 mr-3 mt-1"></i>
                Maintain consistent, clean formatting throughout
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-green-500 mr-3 mt-1"></i>
                Tailor your resume for each job application
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-green-500 mr-3 mt-1"></i>
                Ensure ATS compatibility with standard formatting
              </li>
            </ul>
          </div>

          <div className="bg-indigo-600 text-white rounded-xl p-8 text-center my-12">
            <h3 className="text-2xl font-bold mb-4">Ready to Create a Winning Resume?</h3>
            <p className="text-indigo-100 mb-6">
              Use our professional resume builder to avoid these mistakes and create a resume that gets results.
            </p>
            <Link href="/builder" className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-block whitespace-nowrap">
              Build My Resume
            </Link>
          </div>
        </div>
      </article>

      {/* Related Articles */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Related Articles</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Link href="/blog/3" className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src="https://readdy.ai/api/search-image?query=Computer%20screen%20showing%20ATS%20system%20interface%20analyzing%20resume%20documents%2C%20scanning%20technology%20visualization%2C%20professional%20office%20environment%2C%20digital%20recruitment%20process%2C%20clean%20modern%20workplace&width=400&height=200&seq=ats-related&orientation=landscape"
                alt="ATS Guide"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">The Ultimate Guide to ATS-Friendly Resume Formatting</h3>
                <p className="text-gray-600">Learn how to format your resume to pass through Applicant Tracking Systems.</p>
              </div>
            </Link>
            
            <Link href="/blog/2" className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src="https://readdy.ai/api/search-image?query=Futuristic%20AI%20interface%20helping%20with%20resume%20creation%2C%20holographic%20displays%20showing%20resume%20templates%2C%20modern%20tech%20workspace%20with%20glowing%20screens%2C%20artificial%20intelligence%20visualization%2C%20professional%20tech%20environment&width=400&height=200&seq=ai-related&orientation=landscape"
                alt="AI Resume"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">How AI is Revolutionizing Resume Writing in 2024</h3>
                <p className="text-gray-600">Discover how AI is transforming resume creation for job seekers.</p>
              </div>
            </Link>

            <Link href="/blog/4" className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20job%20interview%20scene%20with%20candidate%20asking%20questions%20to%20interviewer%2C%20modern%20office%20conference%20room%2C%20engaged%20conversation%2C%20business%20professional%20attire%2C%20positive%20interview%20atmosphere&width=400&height=200&seq=interview-related&orientation=landscape"
                alt="Interview Questions"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">5 Interview Questions You Should Always Ask</h3>
                <p className="text-gray-600">Strategic questions that show engagement and help evaluate companies.</p>
              </div>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}