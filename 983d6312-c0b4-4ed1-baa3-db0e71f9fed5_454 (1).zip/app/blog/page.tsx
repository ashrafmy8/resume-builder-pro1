'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../../components/Header';

export default function BlogPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Resume Tips', 'Career Advice', 'Interview Prep', 'Job Search', 'Industry Insights'];

  const blogPosts = [
    {
      id: 1,
      title: "10 Resume Mistakes That Are Costing You Job Interviews",
      excerpt: "Discover the most common resume mistakes that job seekers make and learn how to avoid them to increase your interview chances.",
      category: "Resume Tips",
      author: "Sarah Johnson",
      date: "Dec 15, 2024",
      readTime: "8 min read",
      image: "https://readdy.ai/api/search-image?query=Professional%20woman%20reviewing%20resume%20documents%20at%20modern%20office%20desk%20with%20laptop%2C%20focused%20expression%2C%20clean%20workspace%20with%20coffee%20and%20notes%2C%20bright%20natural%20lighting%2C%20business%20professional%20atmosphere&width=400&height=250&seq=resume-mistakes-blog&orientation=landscape",
      featured: true
    },
    {
      id: 2,
      title: "How AI is Revolutionizing Resume Writing in 2024",
      excerpt: "Explore how artificial intelligence is transforming the way we create resumes and what this means for job seekers.",
      category: "Industry Insights",
      author: "Michael Chen",
      date: "Dec 12, 2024",
      readTime: "6 min read",
      image: "https://readdy.ai/api/search-image?query=Futuristic%20AI%20interface%20helping%20with%20resume%20creation%2C%20holographic%20displays%20showing%20resume%20templates%2C%20modern%20tech%20workspace%20with%20glowing%20screens%2C%20artificial%20intelligence%20visualization%2C%20professional%20tech%20environment&width=400&height=250&seq=ai-resume-blog&orientation=landscape"
    },
    {
      id: 3,
      title: "The Ultimate Guide to ATS-Friendly Resume Formatting",
      excerpt: "Learn how to format your resume to pass through Applicant Tracking Systems and reach human recruiters.",
      category: "Resume Tips",
      author: "Emily Rodriguez",
      date: "Dec 10, 2024",
      readTime: "10 min read",
      image: "https://readdy.ai/api/search-image?query=Computer%20screen%20showing%20ATS%20system%20interface%20analyzing%20resume%20documents%2C%20scanning%20technology%20visualization%2C%20professional%20office%20environment%2C%20digital%20recruitment%20process%2C%20clean%20modern%20workplace&width=400&height=250&seq=ats-formatting-blog&orientation=landscape"
    },
    {
      id: 4,
      title: "5 Interview Questions You Should Always Ask",
      excerpt: "Discover the strategic questions that show you're engaged and help you evaluate if the company is right for you.",
      category: "Interview Prep",
      author: "David Kim",
      date: "Dec 8, 2024",
      readTime: "5 min read",
      image: "https://readdy.ai/api/search-image?query=Professional%20job%20interview%20scene%20with%20candidate%20asking%20questions%20to%20interviewer%2C%20modern%20office%20conference%20room%2C%20engaged%20conversation%2C%20business%20professional%20attire%2C%20positive%20interview%20atmosphere&width=400&height=250&seq=interview-questions-blog&orientation=landscape"
    },
    {
      id: 5,
      title: "Networking Strategies That Actually Work in 2024",
      excerpt: "Modern networking approaches that help you build meaningful professional relationships and advance your career.",
      category: "Career Advice",
      author: "Lisa Thompson",
      date: "Dec 5, 2024",
      readTime: "12 min read",
      image: "https://readdy.ai/api/search-image?query=Professional%20networking%20event%20with%20diverse%20professionals%20exchanging%20business%20cards%20and%20having%20conversations%2C%20modern%20corporate%20venue%2C%20warm%20lighting%2C%20business%20casual%20attire%2C%20professional%20development%20atmosphere&width=400&height=250&seq=networking-strategies-blog&orientation=landscape"
    },
    {
      id: 6,
      title: "Remote Work: How to Optimize Your Home Office Resume Section",
      excerpt: "Tips for highlighting your remote work experience and skills that employers value in distributed teams.",
      category: "Career Advice",
      author: "James Wilson",
      date: "Dec 3, 2024",
      readTime: "7 min read",
      image: "https://readdy.ai/api/search-image?query=Professional%20home%20office%20setup%20with%20person%20working%20on%20resume%2C%20modern%20desk%20with%20dual%20monitors%2C%20ergonomic%20chair%2C%20plants%20and%20good%20lighting%2C%20productive%20remote%20work%20environment%2C%20clean%20organized%20workspace&width=400&height=250&seq=remote-work-resume-blog&orientation=landscape"
    }
  ];

  const filteredPosts = selectedCategory === 'All' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === selectedCategory);

  const featuredPost = blogPosts.find(post => post.featured);
  const regularPosts = blogPosts.filter(post => !post.featured);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-50 to-purple-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Career Development Blog
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Expert insights, tips, and strategies to advance your career and land your dream job. 
            Stay updated with the latest trends in recruitment and professional development.
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full transition-colors whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Post */}
      {featuredPost && selectedCategory === 'All' && (
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl overflow-hidden shadow-xl">
              <div className="grid lg:grid-cols-2 gap-0">
                <div className="p-8 lg:p-12 text-white">
                  <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">
                    Featured Post
                  </span>
                  <h2 className="text-3xl font-bold mb-4">{featuredPost.title}</h2>
                  <p className="text-indigo-100 mb-6 text-lg">{featuredPost.excerpt}</p>
                  <div className="flex items-center space-x-4 mb-6">
                    <span className="text-indigo-200">By {featuredPost.author}</span>
                    <span className="text-indigo-200">•</span>
                    <span className="text-indigo-200">{featuredPost.date}</span>
                    <span className="text-indigo-200">•</span>
                    <span className="text-indigo-200">{featuredPost.readTime}</span>
                  </div>
                  <Link href={`/blog/${featuredPost.id}`} className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center whitespace-nowrap">
                    Read Article
                    <i className="ri-arrow-right-line ml-2"></i>
                  </Link>
                </div>
                <div className="relative h-64 lg:h-auto">
                  <img
                    src={featuredPost.image}
                    alt={featuredPost.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Blog Posts Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <article key={post.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-48">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <span>By {post.author}</span>
                    <span>{post.readTime}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500 text-sm">{post.date}</span>
                    <Link href={`/blog/${post.id}`} className="text-indigo-600 hover:text-indigo-700 font-semibold transition-colors whitespace-nowrap">
                      Read More →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Trustpilot Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <img 
              src="https://readdy.ai/api/search-image?query=Trustpilot%20logo%20with%20green%20star%20rating%20badge%2C%20professional%20clean%20design%20on%20white%20background%2C%20high%20quality%20brand%20logo%20with%20trustpilot%20text%20and%20green%20star%20symbol&width=140&height=50&seq=trustpilot-brand-logo&orientation=landscape"
              alt="Trustpilot"
              className="h-10"
            />
            <div className="flex items-center space-x-1">
              <div className="flex text-green-500">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-lg"></i>
                ))}
              </div>
              <span className="text-gray-700 font-bold ml-2">4.8/5 Excellent</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Trusted by Job Seekers Worldwide</h2>
          <p className="text-gray-600 mb-8">Based on 28,847 reviews • Join thousands who've advanced their careers</p>
          
          <div className="bg-gray-50 p-6 rounded-xl max-w-2xl mx-auto">
            <div className="flex text-green-500 justify-center mb-4">
              {[...Array(5)].map((_, i) => (
                <i key={i} className="ri-star-fill"></i>
              ))}
            </div>
            <p className="text-gray-700 italic mb-4">
              "ResumeTeacher's blog articles gave me the insights I needed to completely transform my job search strategy. Applied their tips and landed my dream role!"
            </p>
            <div className="flex items-center justify-center space-x-2">
              <span className="font-semibold text-gray-900">Rachel Kim</span>
              <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">✓ Verified</span>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-gradient-to-r from-indigo-600 to-purple-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
          <p className="text-xl text-indigo-100 mb-8">
            Get the latest career tips and job search strategies delivered to your inbox weekly.
          </p>
          <div className="flex flex-col sm:flex-row max-w-lg mx-auto gap-4">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg border-0 focus:outline-none focus:ring-2 focus:ring-white/50"
            />
            <button className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap">
              Subscribe
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-file-text-line text-white text-lg"></i>
                </div>
                <span className="text-xl font-['Pacifico']">ResumeTeacher</span>
              </div>
              <p className="text-gray-400 mb-4">
                Build professional resumes with AI assistance and land your dream job faster.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><Link href="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</Link></li>
                <li><Link href="/guides" className="text-gray-400 hover:text-white transition-colors">Career Guides</Link></li>
                <li><Link href="/tools" className="text-gray-400 hover:text-white transition-colors">Career Tools</Link></li>
                <li><Link href="/advice" className="text-gray-400 hover:text-white transition-colors">Career Advice</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Templates</h3>
              <ul className="space-y-2">
                <li><Link href="/resume-templates" className="text-gray-400 hover:text-white transition-colors">Resume Templates</Link></li>
                <li><Link href="/cv-templates" className="text-gray-400 hover:text-white transition-colors">CV Templates</Link></li>
                <li><Link href="/cover-letter-templates" className="text-gray-400 hover:text-white transition-colors">Cover Letter Templates</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2">
                <li><Link href="/help" className="text-gray-400 hover:text-white transition-colors">Help Center</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link></li>
                <li><Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2025 ResumeTeacher. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}