'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import AffiliateManager from '@/components/AffiliateManager';

export default function AffiliatesPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
    } catch (error) {
      console.error('Error checking user:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                {user ? 'Your Affiliate Dashboard' : 'The ResumeTeacher Affiliate Program'}
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                {user 
                  ? 'Track your referrals, earnings, and grow your income by sharing ResumeTeacher with friends and colleagues.'
                  : 'Earn $3 for every person you refer to ResumeTeacher. Join thousands of partners already earning with our affiliate program.'
                }
              </p>
              {!user && (
                <>
                  <Link 
                    href="/signup" 
                    className="inline-flex items-center bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors mr-4"
                  >
                    Join Affiliate Program
                    <i className="ri-arrow-right-line ml-2"></i>
                  </Link>
                  <Link 
                    href="/login" 
                    className="inline-flex items-center bg-white text-blue-600 border border-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
                  >
                    Sign In
                    <i className="ri-login-circle-line ml-2"></i>
                  </Link>
                </>
              )}
              <div className="mt-8 flex items-center text-sm text-gray-500">
                <div className="flex items-center mr-6">
                  <i className="ri-calendar-line mr-2"></i>
                  <span>Written by The ResumeTeacher Team</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-time-line mr-2"></i>
                  <span>Updated January 2025</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20affiliate%20marketing%20partnership%20program%20illustration%20showing%20diverse%20team%20of%20people%20working%20together%20with%20laptops%2C%20charts%2C%20money%20symbols%2C%20modern%20office%20environment%2C%20bright%20business%20atmosphere%2C%20partnership%20handshake%2C%20digital%20marketing%20elements&width=600&height=400&seq=affiliate-program-hero&orientation=landscape"
                alt="ResumeTeacher Affiliate Program" 
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* User Dashboard or Public Content */}
      {user ? (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <AffiliateManager />
        </div>
      ) : (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          
          {/* Quick Stats */}
          <section className="mb-16">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-200">
                <div className="text-4xl font-bold text-blue-600 mb-2">$3</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Per Referral</div>
                <div className="text-gray-600">Earn $3 USD for every successful signup</div>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-200">
                <div className="text-4xl font-bold text-green-600 mb-2">30</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Day Cookie</div>
                <div className="text-gray-600">Long tracking window for maximum earnings</div>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-200">
                <div className="text-4xl font-bold text-purple-600 mb-2">∞</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Unlimited</div>
                <div className="text-gray-600">No limits on earning potential</div>
              </div>
            </div>
          </section>

          {/* Who We Are Section */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Who we are</h2>
            <div className="text-center mb-8">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20team%20of%20resume%20writers%20and%20career%20counselors%20working%20together%20in%20modern%20office%2C%20diverse%20group%20of%20people%20with%20laptops%20and%20documents%2C%20bright%20contemporary%20workspace%2C%20collaboration%20and%20teamwork%2C%20professional%20atmosphere&width=800&height=400&seq=who-we-are-team&orientation=landscape"
                alt="Who We Are" 
                className="w-full max-w-4xl mx-auto h-auto rounded-lg"
              />
            </div>
            <div className="prose prose-lg max-w-none text-gray-600">
              <p>
                Since 2009, ResumeTeacher has been serving jobseekers around the US and the world — 
                providing them with the tools and resources they need to thrive on the job hunt.
              </p>
              <p>
                From downloadable <Link href="/resume-examples" className="text-blue-600 hover:text-blue-700">resume examples</Link> and <Link href="/resume-templates" className="text-blue-600 hover:text-blue-700">free resume templates</Link> to interview 
                resources, skills guides, how-to's and more, the ResumeTeacher team has served all sorts of users 
                at different career stages for over a decade.
              </p>
              <p>
                And with its industry-leading <Link href="/builder" className="text-blue-600 hover:text-blue-700">resume builder</Link> and <Link href="/cover-letter-builder" className="text-blue-600 hover:text-blue-700">cover letter generator</Link> continuing 
                to help thousands of users prepare their applications and earn better job opportunities daily, 
                ResumeTeacher is busy as ever.
              </p>
            </div>
          </section>

          {/* Why Work With Us Section */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Why you should work with us</h2>
            <div className="text-center mb-8">
              <img 
                src="https://readdy.ai/api/search-image?query=Business%20partnership%20benefits%20illustration%20with%20money%20growth%20charts%2C%20handshake%2C%20success%20metrics%2C%20commission%20rates%2C%20professional%20collaboration%20symbols%2C%20bright%20modern%20design%2C%20financial%20growth%20elements&width=800&height=400&seq=partnership-benefits&orientation=landscape"
                alt="Why Work With Us" 
                className="w-full max-w-4xl mx-auto h-auto rounded-lg"
              />
            </div>
            <div className="grid md:grid-cols-2 gap-6 mt-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3">
                    <i className="ri-money-dollar-circle-line text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Unlimited earning potential</h3>
                </div>
                <p className="text-gray-600">Build as much revenue as you can earn</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3">
                    <i className="ri-percent-line text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Solid commission rate</h3>
                </div>
                <p className="text-gray-600">$3 USD per subscription</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                    <i className="ri-bar-chart-line text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Real-time reporting</h3>
                </div>
                <p className="text-gray-600">Receive access to all of your referral stats in real-time, to keep you completely informed on your earnings</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center mr-3">
                    <i className="ri-customer-service-2-line text-white"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">Dedicated affiliate support team</h3>
                </div>
                <p className="text-gray-600">We've set in place a dedicated team that manages our partner program to ensure affiliate partners succeed</p>
              </div>
            </div>
            <div className="bg-yellow-50 p-6 rounded-lg mt-6">
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center mr-3">
                  <i className="ri-time-line text-white"></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900">One-month referral window</h3>
              </div>
              <p className="text-gray-600">Our cookie stays fresh for 30 days – get paid even if your referrals don't immediately make the purchase on our website</p>
            </div>
          </section>

          {/* How It Works */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">How our affiliate program works</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">1</span>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Sign Up</h4>
                <p className="text-gray-600">Create your free account to get started</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-green-600">2</span>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Get Your Link</h4>
                <p className="text-gray-600">Receive your unique referral link instantly</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-purple-600">3</span>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Share & Promote</h4>
                <p className="text-gray-600">Use the provided affiliate links to promote ResumeTeacher</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-orange-600">4</span>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Earn Commission</h4>
                <p className="text-gray-600">We'll send you $3 USD commission for every person who signs up</p>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="mb-16">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-lg text-center">
              <h3 className="text-2xl font-bold mb-4">Ready to Start Earning?</h3>
              <p className="text-xl mb-6">Join thousands of partners already earning with ResumeTeacher</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link 
                  href="/signup" 
                  className="inline-flex items-center justify-center bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                >
                  Start Earning Today
                  <i className="ri-arrow-right-line ml-2"></i>
                </Link>
                <Link 
                  href="/contact" 
                  className="inline-flex items-center justify-center border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/10 transition-colors"
                >
                  Contact Us
                  <i className="ri-customer-service-line ml-2"></i>
                </Link>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}