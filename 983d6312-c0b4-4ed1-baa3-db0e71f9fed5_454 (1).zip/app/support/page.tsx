'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function SupportPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const supportCategories = [
    { id: 'all', name: 'All Topics', icon: 'ri-grid-line' },
    { id: 'getting-started', name: 'Getting Started', icon: 'ri-rocket-line' },
    { id: 'resume-builder', name: 'Resume Builder', icon: 'ri-file-text-line' },
    { id: 'templates', name: 'Templates', icon: 'ri-layout-line' },
    { id: 'account', name: 'Account & Billing', icon: 'ri-user-line' },
    { id: 'technical', name: 'Technical Issues', icon: 'ri-tools-line' }
  ];

  const faqData = [
    {
      category: 'getting-started',
      question: 'How do I create my first resume?',
      answer: 'Click on "Build Resume" in the top navigation, choose a template, and follow our step-by-step guided process. You can complete your resume in under 15 minutes.'
    },
    {
      category: 'getting-started',
      question: 'What file formats can I download my resume in?',
      answer: 'You can download your resume in PDF, Word (DOCX), and plain text formats. PDF is recommended for most job applications.'
    },
    {
      category: 'resume-builder',
      question: 'Can I import my existing resume?',
      answer: 'Yes! Use our import feature to upload your existing resume in PDF or Word format. Our AI will extract the information and help you improve it.'
    },
    {
      category: 'resume-builder',
      question: 'How many resumes can I create?',
      answer: 'Free users can create 1 resume with basic templates. Premium users get unlimited resumes with access to all premium templates and features.'
    },
    {
      category: 'templates',
      question: 'Are your templates ATS-friendly?',
      answer: 'Yes! All our templates are designed to pass Applicant Tracking Systems (ATS). We regularly test them with major ATS software to ensure compatibility.'
    },
    {
      category: 'templates',
      question: 'Can I customize template colors and fonts?',
      answer: 'Premium users can fully customize colors, fonts, spacing, and layout. Free users have access to basic customization options.'
    },
    {
      category: 'account',
      question: 'How do I upgrade to premium?',
      answer: 'Click on any premium feature or visit your account settings. Choose from monthly or annual plans with a 30-day money-back guarantee.'
    },
    {
      category: 'account',
      question: 'Can I cancel my subscription anytime?',
      answer: 'Yes, you can cancel anytime from your account settings. You\'ll continue to have premium access until the end of your billing period.'
    },
    {
      category: 'technical',
      question: 'My resume won\'t save. What should I do?',
      answer: 'Try refreshing the page and clearing your browser cache. If the problem persists, contact our support team with your browser and device information.'
    },
    {
      category: 'technical',
      question: 'The website is loading slowly. How can I fix this?',
      answer: 'Check your internet connection and try using a different browser. Our website works best with Chrome, Firefox, Safari, and Edge.'
    }
  ];

  const filteredFAQs = faqData.filter(faq => 
    (selectedCategory === 'all' || faq.category === selectedCategory) &&
    (searchQuery === '' || 
     faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
     faq.answer.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/10 to-purple-600/10"></div>
        <div className="absolute top-10 left-10 w-32 h-32 bg-indigo-200/30 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-purple-200/30 rounded-full blur-xl animate-pulse delay-1000"></div>
        
        <div className="max-w-4xl mx-auto px-4 text-center relative">
          <div className="animate-fade-in">
            <h1 className="text-5xl font-bold text-gray-900 mb-6 leading-tight">
              How can we <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">help you?</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Find answers to common questions, get help with our tools, or contact our support team
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative max-w-2xl mx-auto animate-fade-in-up delay-200">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <i className="ri-search-line text-gray-400 text-xl"></i>
            </div>
            <input
              type="text"
              placeholder="Search for help articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 border border-gray-200 rounded-2xl focus:ring-4 focus:ring-indigo-100 focus:border-indigo-300 outline-none transition-all duration-300 text-lg shadow-lg"
            />
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-2xl bg-gradient-to-br from-indigo-50 to-indigo-100 hover:from-indigo-100 hover:to-indigo-200 transition-all duration-300 hover:scale-105 cursor-pointer group">
              <div className="w-16 h-16 bg-indigo-600 rounded-2xl mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-question-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Browse FAQs</h3>
              <p className="text-gray-600">Find quick answers to common questions</p>
            </div>

            <Link href="/contact" className="text-center p-8 rounded-2xl bg-gradient-to-br from-emerald-50 to-emerald-100 hover:from-emerald-100 hover:to-emerald-200 transition-all duration-300 hover:scale-105 cursor-pointer group">
              <div className="w-16 h-16 bg-emerald-600 rounded-2xl mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-customer-service-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Contact Support</h3>
              <p className="text-gray-600">Get personalized help from our team</p>
            </Link>

            <div className="text-center p-8 rounded-2xl bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 transition-all duration-300 hover:scale-105 cursor-pointer group">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-book-open-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">User Guides</h3>
              <p className="text-gray-600">Step-by-step tutorials and guides</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">Quick answers to help you get the most out of ResumeTeacher</p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {supportCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex items-center px-6 py-3 rounded-full font-medium transition-all duration-300 whitespace-nowrap ${
                  selectedCategory === category.id
                    ? 'bg-indigo-600 text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-indigo-50 hover:text-indigo-600 border border-gray-200'
                }`}
              >
                <i className={`${category.icon} mr-2`}></i>
                {category.name}
              </button>
            ))}
          </div>

          {/* FAQ List */}
          <div className="max-w-4xl mx-auto">
            {filteredFAQs.map((faq, index) => (
              <div key={index} className="mb-6 bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow duration-300">
                <details className="group">
                  <summary className="flex items-center justify-between p-6 cursor-pointer hover:bg-gray-50 transition-colors duration-300">
                    <h3 className="text-lg font-semibold text-gray-900 pr-4">{faq.question}</h3>
                    <i className="ri-arrow-down-s-line text-2xl text-indigo-600 group-open:rotate-180 transition-transform duration-300 flex-shrink-0"></i>
                  </summary>
                  <div className="px-6 pb-6 pt-2">
                    <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                  </div>
                </details>
              </div>
            ))}
          </div>

          {filteredFAQs.length === 0 && (
            <div className="text-center py-12">
              <i className="ri-search-line text-6xl text-gray-300 mb-4"></i>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No results found</h3>
              <p className="text-gray-500">Try adjusting your search or browse different categories</p>
            </div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Still need help?</h2>
          <p className="text-xl text-indigo-100 mb-8">Our support team is here to help you succeed</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="bg-white text-indigo-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-colors duration-300 whitespace-nowrap">
              Contact Support
            </Link>
            <Link href="/guides" className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-indigo-600 transition-all duration-300 whitespace-nowrap">
              View Guides
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}