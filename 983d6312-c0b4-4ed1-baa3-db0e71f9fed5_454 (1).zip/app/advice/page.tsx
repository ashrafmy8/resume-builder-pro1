'use client';

import Link from 'next/link';

export default function AdvicePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-50 to-blue-50 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Career Advice & Expert Tips
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Get professional guidance on resume writing, interview preparation, career development, and job search strategies from industry experts.
            </p>
            <div className="flex items-center justify-center space-x-4">
              <Link href="/builder" className="bg-indigo-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors whitespace-nowrap">
                Build Your Resume
              </Link>
              <Link href="/blog" className="bg-white text-indigo-600 border border-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition-colors whitespace-nowrap">
                Browse Articles
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Advice Categories */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Expert Advice Categories</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-file-text-line text-indigo-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Resume Writing</h3>
              <p className="text-gray-600 mb-6">Learn how to craft compelling resumes that get noticed by employers and pass through ATS systems.</p>
              <Link href="/blog/1" className="text-indigo-600 font-semibold hover:text-indigo-700 transition-colors">
                Read Resume Tips →
              </Link>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-user-voice-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Interview Preparation</h3>
              <p className="text-gray-600 mb-6">Master interview techniques, prepare for common questions, and learn what questions to ask employers.</p>
              <Link href="/blog/4" className="text-green-600 font-semibold hover:text-green-700 transition-colors">
                Interview Strategies →
              </Link>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-rocket-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Career Development</h3>
              <p className="text-gray-600 mb-6">Advance your career with networking strategies, professional development tips, and industry insights.</p>
              <Link href="/blog/5" className="text-purple-600 font-semibold hover:text-purple-700 transition-colors">
                Career Growth Tips →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Latest Career Advice</h2>
            <Link href="/blog" className="text-indigo-600 font-semibold hover:text-indigo-700 transition-colors">
              View All Articles →
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Link href="/blog/1" className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20woman%20reviewing%20resume%20documents%20at%20modern%20office%20desk%20with%20laptop%2C%20focused%20expression%2C%20clean%20workspace%20with%20coffee%20and%20notes%2C%20bright%20natural%20lighting%2C%20business%20professional%20atmosphere&width=400&height=250&seq=resume-mistakes-advice&orientation=landscape"
                alt="Resume Mistakes"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <span className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium">Resume Tips</span>
                <h3 className="text-xl font-bold text-gray-900 mt-3 mb-3">10 Resume Mistakes That Are Costing You Job Interviews</h3>
                <p className="text-gray-600 mb-4">Discover the most common resume mistakes and learn how to avoid them to increase your interview chances.</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>By Sarah Johnson</span>
                  <span>8 min read</span>
                </div>
              </div>
            </Link>

            <Link href="/blog/2" className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src="https://readdy.ai/api/search-image?query=Futuristic%20AI%20interface%20helping%20with%20resume%20creation%2C%20holographic%20displays%20showing%20resume%20templates%2C%20modern%20tech%20workspace%20with%20glowing%20screens%2C%20artificial%20intelligence%20visualization%2C%20professional%20tech%20environment&width=400&height=250&seq=ai-resume-advice&orientation=landscape"
                alt="AI Resume Writing"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">Industry Insights</span>
                <h3 className="text-xl font-bold text-gray-900 mt-3 mb-3">How AI is Revolutionizing Resume Writing in 2024</h3>
                <p className="text-gray-600 mb-4">Explore how artificial intelligence is transforming the way we create resumes and what this means for job seekers.</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>By Michael Chen</span>
                  <span>6 min read</span>
                </div>
              </div>
            </Link>

            <Link href="/blog/3" className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src="https://readdy.ai/api/search-image?query=Computer%20screen%20showing%20ATS%20system%20interface%20analyzing%20resume%20documents%2C%20scanning%20technology%20visualization%2C%20professional%20office%20environment%2C%20digital%20recruitment%20process%2C%20clean%20modern%20workplace&width=400&height=250&seq=ats-formatting-advice&orientation=landscape"
                alt="ATS Resume Formatting"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">Resume Tips</span>
                <h3 className="text-xl font-bold text-gray-900 mt-3 mb-3">The Ultimate Guide to ATS-Friendly Resume Formatting</h3>
                <p className="text-gray-600 mb-4">Learn how to format your resume to pass through Applicant Tracking Systems and reach human recruiters.</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>By Emily Rodriguez</span>
                  <span>10 min read</span>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Resume Building Tools */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Professional Resume Tools</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/builder" className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow text-center">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-edit-line text-indigo-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Resume Builder</h3>
              <p className="text-gray-600 text-sm">Create professional resumes with our easy-to-use builder</p>
            </Link>

            <Link href="/ats-resume-checker" className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-search-line text-green-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">ATS Checker</h3>
              <p className="text-gray-600 text-sm">Check if your resume is ATS-friendly</p>
            </Link>

            <Link href="/ai-resume-skills-generator" className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-magic-line text-purple-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Skills Generator</h3>
              <p className="text-gray-600 text-sm">AI-powered skills suggestions for your resume</p>
            </Link>

            <Link href="/resume-templates" className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-layout-line text-orange-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Templates</h3>
              <p className="text-gray-600 text-sm">Professional resume templates for every industry</p>
            </Link>
          </div>
        </div>
      </section>

      {/* Expert Tips */}
      <section className="bg-indigo-600 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white">
            <h2 className="text-3xl font-bold mb-6">Quick Expert Tips</h2>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <div className="bg-indigo-700 rounded-xl p-6">
                <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="ri-target-line text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold mb-3">Tailor Your Resume</h3>
                <p className="text-indigo-100">Customize your resume for each job application by incorporating relevant keywords from the job description.</p>
              </div>

              <div className="bg-indigo-700 rounded-xl p-6">
                <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="ri-bar-chart-line text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold mb-3">Quantify Achievements</h3>
                <p className="text-indigo-100">Use specific numbers, percentages, and metrics to demonstrate the impact of your work and achievements.</p>
              </div>

              <div className="bg-indigo-700 rounded-xl p-6">
                <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="ri-shield-check-line text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold mb-3">Proofread Carefully</h3>
                <p className="text-indigo-100">Eliminate all spelling and grammar errors. Have someone else review your resume before submitting.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Ready to Create Your Professional Resume?</h2>
          <p className="text-xl text-gray-600 mb-8">
            Apply these expert tips and build a resume that gets results. Our professional resume builder makes it easy to create a standout resume in minutes.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <Link href="/builder" className="bg-indigo-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-indigo-700 transition-colors whitespace-nowrap">
              Start Building Resume
            </Link>
            <Link href="/resume-templates" className="bg-white text-indigo-600 border border-indigo-600 px-8 py-4 rounded-lg font-semibold hover:bg-indigo-50 transition-colors whitespace-nowrap">
              Browse Templates
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}