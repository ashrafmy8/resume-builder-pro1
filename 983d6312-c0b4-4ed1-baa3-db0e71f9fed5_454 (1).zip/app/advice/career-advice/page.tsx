
import Link from 'next/link';

export default function CareerAdvicePage() {
  return (
    <div className="min-h-screen bg-white">
      <div className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20business%20woman%20mentor%20coaching%20young%20professional%20in%20modern%20office%20environment%2C%20consulting%20session%20with%20career%20guidance%20documents%20and%20laptop%2C%20bright%20natural%20lighting%2C%20success%20focused%20atmosphere%2C%20minimalist%20design%20with%20subtle%20corporate%20elements&width=1200&height=800&seq=career-hero-bg&orientation=landscape')`
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                  Expert <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Career Guidance</span> for Every Stage
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Get personalized career advice from industry experts. Whether you're starting out, changing careers, or aiming for executive leadership, we'll guide you to success.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/builder" className="bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-colors text-center whitespace-nowrap cursor-pointer">
                  Build Your Resume
                </Link>
                <Link href="/contact" className="border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-blue-50 transition-colors text-center whitespace-nowrap cursor-pointer">
                  Get Personal Consultation
                </Link>
              </div>

              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">92%</div>
                  <div className="text-sm text-gray-600">Success Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">45K+</div>
                  <div className="text-sm text-gray-600">Careers Advanced</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">68%</div>
                  <div className="text-sm text-gray-600">Salary Increase</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -top-4 -left-4 w-72 h-72 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full opacity-20 blur-3xl"></div>
              <div className="absolute -bottom-4 -right-4 w-64 h-64 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full opacity-20 blur-3xl"></div>
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20career%20counselor%20meeting%20with%20client%20in%20modern%20office%2C%20woman%20career%20advisor%20pointing%20at%20career%20development%20chart%2C%20professional%20consultation%20atmosphere%2C%20natural%20lighting%2C%20business%20success%20theme%2C%20corporate%20mentoring%20session&width=600&height=600&seq=career-consultation&orientation=squarish"
                alt="Career consultation session"
                className="relative z-10 w-full h-96 lg:h-[500px] object-cover rounded-2xl shadow-2xl"
              />
              
              <div className="absolute top-8 right-8 bg-white p-4 rounded-xl shadow-lg z-20">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-semibold text-gray-800">Live Career Guidance</span>
                </div>
              </div>
              
              <div className="absolute bottom-8 left-8 bg-white p-4 rounded-xl shadow-lg z-20">
                <div className="text-2xl font-bold text-blue-600">$15K+</div>
                <div className="text-sm text-gray-600">Avg. Salary Boost</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Career Guidance for Every Stage</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From entry-level to executive leadership, get expert advice tailored to your career stage and goals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-seedling-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Entry Level</h3>
              <p className="text-gray-600 mb-4">Perfect your first impression with professional resume building and interview preparation.</p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center"><i className="ri-check-line text-green-500 mr-2"></i>Resume Foundation</li>
                <li className="flex items-center"><i className="ri-check-line text-green-500 mr-2"></i>Interview Skills</li>
                <li className="flex items-center"><i className="ri-check-line text-green-500 mr-2"></i>Networking Basics</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-trending-up-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Career Growth</h3>
              <p className="text-gray-600 mb-4">Accelerate your career progression with strategic advancement planning and skill development.</p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center"><i className="ri-check-line text-blue-500 mr-2"></i>Promotion Strategy</li>
                <li className="flex items-center"><i className="ri-check-line text-blue-500 mr-2"></i>Leadership Development</li>
                <li className="flex items-center"><i className="ri-check-line text-blue-500 mr-2"></i>Skill Enhancement</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-direction-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Career Change</h3>
              <p className="text-gray-600 mb-4">Navigate career transitions successfully with strategic planning and industry insights.</p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center"><i className="ri-check-line text-purple-500 mr-2"></i>Transition Planning</li>
                <li className="flex items-center"><i className="ri-check-line text-purple-500 mr-2"></i>Industry Research</li>
                <li className="flex items-center"><i className="ri-check-line text-purple-500 mr-2"></i>Skills Transfer</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-award-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Executive Level</h3>
              <p className="text-gray-600 mb-4">Master executive presence and strategic leadership for C-suite success.</p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center"><i className="ri-check-line text-orange-500 mr-2"></i>Executive Presence</li>
                <li className="flex items-center"><i className="ri-check-line text-orange-500 mr-2"></i>Strategic Vision</li>
                <li className="flex items-center"><i className="ri-check-line text-orange-500 mr-2"></i>Board Readiness</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Comprehensive Career Development</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get detailed guidance on every aspect of your career journey with our expert-backed methodologies.
            </p>
          </div>

          <div className="space-y-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                  <i className="ri-seedling-line mr-2"></i>
                  Entry-Level Career Blueprint
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Build Your Career Foundation</h3>
                <p className="text-lg text-gray-600">
                  Start your career journey with confidence. Our entry-level guidance covers everything from crafting your first professional resume to mastering interview techniques and building industry connections.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-green-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Resume Building</h4>
                      <p className="text-sm text-gray-600">Professional formatting and content optimization</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-green-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Interview Prep</h4>
                      <p className="text-sm text-gray-600">Common questions and confident responses</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-green-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Networking</h4>
                      <p className="text-sm text-gray-600">Professional relationship building strategies</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-green-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Goal Setting</h4>
                      <p className="text-sm text-gray-600">Clear career objectives and milestones</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img 
                  src="https://readdy.ai/api/search-image?query=Young%20professional%20woman%20working%20on%20laptop%20creating%20resume%20in%20modern%20office%20workspace%2C%20focused%20concentration%20on%20career%20development%2C%20bright%20natural%20lighting%2C%20minimalist%20desk%20setup%20with%20career%20planning%20documents&width=600&height=400&seq=entry-level-career&orientation=landscape"
                  alt="Entry level career development"
                  className="w-full h-80 object-cover rounded-2xl shadow-lg"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg">
                  <div className="text-2xl font-bold text-green-600">85%</div>
                  <div className="text-sm text-gray-600">Job Success Rate</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative order-2 lg:order-1">
                <img 
                  src="https://readdy.ai/api/search-image?query=Confident%20business%20professional%20presenting%20to%20team%20in%20modern%20conference%20room%2C%20leadership%20development%20training%20session%2C%20strategic%20planning%20meeting%20with%20charts%20and%20graphs%2C%20corporate%20growth%20atmosphere&width=600&height=400&seq=career-growth&orientation=landscape"
                  alt="Career growth and leadership"
                  className="w-full h-80 object-cover rounded-2xl shadow-lg"
                />
                <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                  <div className="text-2xl font-bold text-blue-600">73%</div>
                  <div className="text-sm text-gray-600">Get Promoted</div>
                </div>
              </div>
              <div className="space-y-6 order-1 lg:order-2">
                <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                  <i className="ri-trending-up-line mr-2"></i>
                  Career Growth Strategies
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Accelerate Your Career Progression</h3>
                <p className="text-lg text-gray-600">
                  Take your career to the next level with strategic advancement planning. Learn how to position yourself for promotions, develop leadership skills, and build the professional presence that gets you noticed.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-blue-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Leadership Skills</h4>
                      <p className="text-sm text-gray-600">Team management and decision-making</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-blue-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Performance Optimization</h4>
                      <p className="text-sm text-gray-600">Exceed expectations and stand out</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-blue-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Strategic Thinking</h4>
                      <p className="text-sm text-gray-600">Big picture perspective and planning</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-blue-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Promotion Readiness</h4>
                      <p className="text-sm text-gray-600">Position yourself for advancement</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center px-4 py-2 bg-purple-100 text-purple-800 rounded-full text-sm font-semibold">
                  <i className="ri-direction-line mr-2"></i>
                  Career Transition Guide
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Navigate Career Changes Successfully</h3>
                <p className="text-lg text-gray-600">
                  Making a career change can be challenging, but with the right strategy, it's your path to greater fulfillment and success. Learn how to leverage your existing skills while building new ones for your target industry.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-purple-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Skills Assessment</h4>
                      <p className="text-sm text-gray-600">Identify transferable strengths</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-purple-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Industry Research</h4>
                      <p className="text-sm text-gray-600">Market trends and opportunities</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-purple-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Transition Timeline</h4>
                      <p className="text-sm text-gray-600">Step-by-step change roadmap</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-purple-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Risk Mitigation</h4>
                      <p className="text-sm text-gray-600">Minimize career transition risks</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20business%20person%20analyzing%20career%20transition%20options%20on%20computer%20screen%20with%20multiple%20industry%20documents%2C%20career%20change%20planning%20session%2C%20modern%20workspace%20with%20industry%20research%20materials%2C%20decision%20making%20atmosphere&width=600&height=400&seq=career-transition&orientation=landscape"
                  alt="Career transition planning"
                  className="w-full h-80 object-cover rounded-2xl shadow-lg"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg">
                  <div className="text-2xl font-bold text-purple-600">89%</div>
                  <div className="text-sm text-gray-600">Successful Transitions</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative order-2 lg:order-1">
                <img 
                  src="https://readdy.ai/api/search-image?query=Senior%20executive%20woman%20leading%20board%20meeting%20in%20modern%20corporate%20boardroom%2C%20strategic%20business%20discussion%20with%20executive%20team%2C%20professional%20leadership%20presence%2C%20high-level%20business%20environment%20with%20presentation%20screens&width=600&height=400&seq=executive-leadership&orientation=landscape"
                  alt="Executive leadership development"
                  className="w-full h-80 object-cover rounded-2xl shadow-lg"
                />
                <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                  <div className="text-2xl font-bold text-orange-600">94%</div>
                  <div className="text-sm text-gray-600">Executive Success</div>
                </div>
              </div>
              <div className="space-y-6 order-1 lg:order-2">
                <div className="inline-flex items-center px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-semibold">
                  <i className="ri-award-line mr-2"></i>
                  Executive Excellence
                </div>
                <h3 className="text-3xl font-bold text-gray-900">Master Executive Leadership</h3>
                <p className="text-lg text-gray-600">
                  Reach the pinnacle of your career with executive-level guidance. Develop the strategic vision, executive presence, and leadership capabilities needed for C-suite success and board positions.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-orange-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Executive Presence</h4>
                      <p className="text-sm text-gray-600">Command respect and influence</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-orange-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Strategic Vision</h4>
                      <p className="text-sm text-gray-600">Long-term planning and execution</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-orange-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Stakeholder Management</h4>
                      <p className="text-sm text-gray-600">Board and investor relations</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <i className="ri-check-line text-orange-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Crisis Leadership</h4>
                      <p className="text-sm text-gray-600">Navigate challenges with confidence</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Success Stories That Inspire</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real transformations from professionals who trusted us with their career journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20headshot%20of%20confident%20young%20woman%20software%20engineer%20in%20business%20attire%2C%20warm%20smile%2C%20modern%20office%20background%2C%20career%20success%20portrait%2C%20professional%20development%20achievement&width=80&height=80&seq=success-story-1&orientation=squarish"
                  alt="Sarah Chen"
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-bold text-gray-900">Sarah Chen</h4>
                  <p className="text-gray-600">Software Engineer → Tech Lead</p>
                </div>
              </div>
              <blockquote className="text-gray-700 mb-6">
                "The career guidance helped me transition from individual contributor to team lead in just 8 months. My salary increased by 40% and I now lead a team of 12 developers."
              </blockquote>
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-600 font-semibold">+$32K salary increase</span>
                <span className="text-gray-500">8 months</span>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20headshot%20of%20mature%20businessman%20in%20executive%20suit%2C%20confident%20expression%2C%20corporate%20office%20environment%2C%20senior%20leadership%20role%2C%20career%20advancement%20success%20story&width=80&height=80&seq=success-story-2&orientation=squarish"
                  alt="Michael Rodriguez"
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-bold text-gray-900">Michael Rodriguez</h4>
                  <p className="text-gray-600">Marketing Manager → VP Marketing</p>
                </div>
              </div>
              <blockquote className="text-gray-700 mb-6">
                "After 5 years at the same level, the executive coaching program helped me breakthrough to VP level. The strategic thinking framework was game-changing."
              </blockquote>
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-600 font-semibold">+$55K salary increase</span>
                <span className="text-gray-500">14 months</span>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20headshot%20of%20confident%20businesswoman%20in%20healthcare%20setting%2C%20medical%20professional%20in%20leadership%20role%2C%20healthcare%20industry%20success%20story%2C%20career%20transition%20achievement&width=80&height=80&seq=success-story-3&orientation=squarish"
                  alt="Dr. Emily Watson"
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-bold text-gray-900">Dr. Emily Watson</h4>
                  <p className="text-gray-600">Finance → Healthcare</p>
                </div>
              </div>
              <blockquote className="text-gray-700 mb-6">
                "Changing from finance to healthcare administration seemed impossible. The transition guidance made it smooth, and I'm now Director of Operations at a major hospital."
              </blockquote>
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-600 font-semibold">+$28K salary increase</span>
                <span className="text-gray-500">11 months</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Industry-Specific Career Guidance</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get targeted advice for your specific industry with insider knowledge and proven strategies.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="group cursor-pointer">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-8 rounded-2xl text-white hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <i className="ri-code-s-slash-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-3">Technology</h3>
                <p className="text-blue-100 mb-4">Software engineering, product management, data science, and tech leadership paths.</p>
                <div className="text-sm text-blue-200">
                  <div>• FAANG preparation</div>
                  <div>• Technical interview mastery</div>
                  <div>• Senior/Staff engineer growth</div>
                </div>
              </div>
            </div>

            <div className="group cursor-pointer">
              <div className="bg-gradient-to-br from-green-500 to-green-600 p-8 rounded-2xl text-white hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <i className="ri-health-book-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-3">Healthcare</h3>
                <p className="text-green-100 mb-4">Medical professionals, healthcare administration, nursing leadership, and clinical management.</p>
                <div className="text-sm text-green-200">
                  <div>• Medical residency guidance</div>
                  <div>• Healthcare administration</div>
                  <div>• Clinical leadership roles</div>
                </div>
              </div>
            </div>

            <div className="group cursor-pointer">
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-8 rounded-2xl text-white hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <i className="ri-line-chart-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-3">Finance</h3>
                <p className="text-purple-100 mb-4">Investment banking, private equity, corporate finance, and financial planning careers.</p>
                <div className="text-sm text-purple-200">
                  <div>• Wall Street preparation</div>
                  <div>• CFA/FRM certification</div>
                  <div>• Finance leadership track</div>
                </div>
              </div>
            </div>

            <div className="group cursor-pointer">
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-8 rounded-2xl text-white hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <i className="ri-megaphone-line text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-3">Marketing</h3>
                <p className="text-orange-100 mb-4">Digital marketing, brand management, growth marketing, and CMO career advancement.</p>
                <div className="text-sm text-orange-200">
                  <div>• Digital marketing mastery</div>
                  <div>• Brand strategy leadership</div>
                  <div>• Growth marketing expertise</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="text-4xl lg:text-5xl font-bold leading-tight">
                  Ready to Accelerate Your Career?
                </h2>
                <p className="text-xl text-blue-100 leading-relaxed">
                  Join thousands of professionals who have transformed their careers with our expert guidance. Start your journey to career success today.
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-400 rounded-full flex items-center justify-center flex-shrink-0">
                    <i className="ri-check-line text-green-900 text-sm"></i>
                  </div>
                  <span className="text-lg">Personalized career roadmap within 24 hours</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-400 rounded-full flex items-center justify-center flex-shrink-0">
                    <i className="ri-check-line text-green-900 text-sm"></i>
                  </div>
                  <span className="text-lg">Direct access to industry experts and mentors</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-400 rounded-full flex items-center justify-center flex-shrink-0">
                    <i className="ri-check-line text-green-900 text-sm"></i>
                  </div>
                  <span className="text-lg">Comprehensive career development resources</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/builder" className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors text-center whitespace-nowrap cursor-pointer">
                  Start Building Your Resume
                </Link>
                <Link href="/contact" className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/10 transition-colors text-center whitespace-nowrap cursor-pointer">
                  Schedule Consultation
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -top-4 -left-4 w-72 h-72 bg-gradient-to-br from-blue-400 to-purple-400 rounded-full opacity-20 blur-3xl"></div>
              <div className="absolute -bottom-4 -right-4 w-64 h-64 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full opacity-20 blur-3xl"></div>
              <img 
                src="https://readdy.ai/api/search-image?query=Diverse%20group%20of%20successful%20professionals%20celebrating%20career%20achievement%20in%20modern%20office%2C%20team%20of%20business%20leaders%20with%20laptops%20and%20documents%2C%20career%20success%20celebration%2C%20motivational%20workplace%20atmosphere&width=600&height=500&seq=career-success-team&orientation=landscape"
                alt="Career success team"
                className="relative z-10 w-full h-96 object-cover rounded-2xl shadow-2xl"
              />
              
              <div className="absolute top-8 right-8 bg-white/10 backdrop-blur-sm p-4 rounded-xl z-20">
                <div className="text-2xl font-bold">24/7</div>
                <div className="text-sm text-blue-100">Expert Support</div>
              </div>
              
              <div className="absolute bottom-8 left-8 bg-white/10 backdrop-blur-sm p-4 rounded-xl z-20">
                <div className="text-2xl font-bold">92%</div>
                <div className="text-sm text-blue-100">Success Rate</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Career Resources & Tools</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Access our comprehensive suite of career development tools and resources.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Link href="/builder" className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-file-text-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Resume Builder</h3>
              <p className="text-gray-600 mb-4">Create professional resumes with our AI-powered builder and expert templates.</p>
              <div className="flex items-center text-blue-600 font-semibold">
                Build Resume <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/resume-templates" className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-layout-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Resume Templates</h3>
              <p className="text-gray-600 mb-4">Choose from hundreds of professionally designed resume templates for every industry.</p>
              <div className="flex items-center text-green-600 font-semibold">
                Browse Templates <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/interview-tips" className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-question-answer-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Interview Tips</h3>
              <p className="text-gray-600 mb-4">Master your interviews with expert tips, common questions, and proven strategies.</p>
              <div className="flex items-center text-purple-600 font-semibold">
                Learn More <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/cover-letter" className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-mail-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Cover Letters</h3>
              <p className="text-gray-600 mb-4">Create compelling cover letters that complement your resume and get you noticed.</p>
              <div className="flex items-center text-orange-600 font-semibold">
                Create Cover Letter <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/ats-resume-checker" className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-red-400 to-red-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-search-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">ATS Checker</h3>
              <p className="text-gray-600 mb-4">Optimize your resume for Applicant Tracking Systems with our AI-powered analysis.</p>
              <div className="flex items-center text-red-600 font-semibold">
                Check ATS Score <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/blog" className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-400 to-indigo-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-article-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Career Blog</h3>
              <p className="text-gray-600 mb-4">Stay updated with the latest career advice, industry trends, and success strategies.</p>
              <div className="flex items-center text-indigo-600 font-semibold">
                Read Articles <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
