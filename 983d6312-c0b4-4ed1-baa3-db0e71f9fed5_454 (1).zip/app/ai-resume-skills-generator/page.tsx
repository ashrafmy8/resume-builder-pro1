'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function AIResumeSkillsGeneratorPage() {
  const [jobTitle, setJobTitle] = useState('');
  const [industry, setIndustry] = useState('');
  const [experience, setExperience] = useState('');
  const [generatedSkills, setGeneratedSkills] = useState<string[]>([]);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const industries = [
    'Technology', 'Healthcare', 'Finance', 'Marketing', 'Sales', 'Education',
    'Manufacturing', 'Retail', 'Consulting', 'Legal', 'Real Estate', 'Media'
  ];

  const experienceLevels = [
    'Entry Level (0-2 years)',
    'Mid Level (3-5 years)', 
    'Senior Level (6-10 years)',
    'Executive Level (10+ years)'
  ];

  const skillDatabase = {
    'software engineer': {
      technical: ['React', 'Node.js', 'Python', 'JavaScript', 'TypeScript', 'AWS', 'Docker', 'Kubernetes', 'Git', 'SQL'],
      soft: ['Problem Solving', 'Team Collaboration', 'Agile Development', 'Code Review', 'Technical Documentation']
    },
    'marketing manager': {
      technical: ['Google Analytics', 'SEO/SEM', 'Adobe Creative Suite', 'CRM Software', 'Email Marketing', 'Social Media Marketing'],
      soft: ['Strategic Planning', 'Brand Management', 'Campaign Development', 'Market Research', 'Content Strategy']
    },
    'data scientist': {
      technical: ['Python', 'R', 'Machine Learning', 'SQL', 'Tableau', 'TensorFlow', 'Pandas', 'Scikit-learn', 'Statistics'],
      soft: ['Data Visualization', 'Statistical Analysis', 'Research', 'Problem Solving', 'Communication']
    },
    'project manager': {
      technical: ['Jira', 'Asana', 'Microsoft Project', 'Agile/Scrum', 'Risk Management', 'Budget Management'],
      soft: ['Leadership', 'Communication', 'Team Management', 'Strategic Planning', 'Stakeholder Management']
    },
    'financial analyst': {
      technical: ['Excel', 'Financial Modeling', 'Bloomberg Terminal', 'SAP', 'Power BI', 'VBA', 'SQL'],
      soft: ['Analytical Thinking', 'Attention to Detail', 'Risk Assessment', 'Financial Reporting', 'Forecasting']
    }
  };

  const generateSkills = async () => {
    setIsGenerating(true);
    setGeneratedSkills([]);
    
    // Simulate AI processing
    setTimeout(() => {
      const jobKey = jobTitle.toLowerCase();
      let skills: string[] = [];
      
      // Find matching skills or use generic ones
      const matchedJob = Object.keys(skillDatabase).find(key => jobKey.includes(key));
      
      if (matchedJob) {
        const jobSkills = skillDatabase[matchedJob as keyof typeof skillDatabase];
        skills = [...jobSkills.technical, ...jobSkills.soft];
      } else {
        // Generic skills based on industry
        const genericSkills = [
          'Communication', 'Leadership', 'Problem Solving', 'Team Collaboration',
          'Project Management', 'Time Management', 'Critical Thinking', 'Adaptability',
          'Customer Service', 'Data Analysis', 'Strategic Planning', 'Innovation'
        ];
        skills = genericSkills;
      }
      
      // Add experience-level appropriate skills
      if (experience.includes('Senior') || experience.includes('Executive')) {
        skills.push('Strategic Leadership', 'Mentoring', 'Business Development', 'Change Management');
      }
      
      // Add industry-specific skills
      if (industry === 'Technology') {
        skills.push('Agile Development', 'Cloud Computing', 'DevOps', 'API Development');
      } else if (industry === 'Marketing') {
        skills.push('Digital Marketing', 'Brand Strategy', 'Content Marketing', 'Analytics');
      }
      
      setGeneratedSkills([...new Set(skills)].slice(0, 20));
      setIsGenerating(false);
    }, 2000);
  };

  const toggleSkill = (skill: string) => {
    setSelectedSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const addToResume = () => {
    if (selectedSkills.length > 0) {
      // Store skills in localStorage for the resume builder
      localStorage.setItem('aiGeneratedSkills', JSON.stringify(selectedSkills));
      // Redirect to builder
      window.location.href = '/builder';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg shadow-lg border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center group">
              <div className="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <i className="ri-file-text-line text-white text-xl"></i>
              </div>
              <h1 className="ml-3 text-2xl font-['Pacifico'] bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Resume Teacher</h1>
            </Link>
            <Link href="/builder" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-xl hover:shadow-lg transition-all duration-300 whitespace-nowrap">
              Resume Builder
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative py-16 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://readdy.ai/api/search-image?query=AI%20artificial%20intelligence%20technology%20generating%20professional%20skills%20and%20competencies%20for%20resume%2C%20futuristic%20digital%20interface%20with%20skill%20recommendations%2C%20modern%20workspace%20with%20AI%20assistant%2C%20data%20visualization%20and%20skill%20analysis%2C%20bright%20tech%20environment%20with%20holographic%20displays&width=1200&height=400&seq=ai-skills-hero&orientation=landscape"
            alt="AI Skills Generator"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/80 to-indigo-900/80"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            AI Resume Skills Generator
          </h1>
          <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
            Let artificial intelligence analyze your job title and industry to suggest the most relevant skills for your resume. 
            Get personalized skill recommendations that match employer expectations.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-brain-line text-3xl text-purple-300 mb-2"></i>
              <div className="font-semibold">AI-Powered</div>
              <div className="text-sm">Smart skill matching</div>
            </div>
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-target-line text-3xl text-indigo-300 mb-2"></i>
              <div className="font-semibold">Industry-Specific</div>
              <div className="text-sm">Tailored recommendations</div>
            </div>
            <div className="bg-white/20 backdrop-blur-lg rounded-lg p-4 text-white">
              <i className="ri-time-line text-3xl text-blue-300 mb-2"></i>
              <div className="font-semibold">Instant Results</div>
              <div className="text-sm">Get skills in seconds</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Input Form */}
        <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20 mb-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Tell Us About Your Role</h2>
            <p className="text-gray-600">Provide your job details and let AI generate the perfect skills for your resume</p>
          </div>

          <div className="space-y-6">
            {/* Job Title */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                <i className="ri-briefcase-line mr-2 text-indigo-600"></i>
                Job Title
              </label>
              <input
                type="text"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                placeholder="e.g., Software Engineer, Marketing Manager, Data Scientist"
                className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
              />
            </div>

            {/* Industry */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                <i className="ri-building-line mr-2 text-indigo-600"></i>
                Industry
              </label>
              <select
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm pr-8"
              >
                <option value="">Select your industry</option>
                {industries.map((ind) => (
                  <option key={ind} value={ind}>{ind}</option>
                ))}
              </select>
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                <i className="ri-medal-line mr-2 text-indigo-600"></i>
                Experience Level
              </label>
              <select
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                className="w-full px-4 py-3 bg-white/80 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm pr-8"
              >
                <option value="">Select your experience level</option>
                {experienceLevels.map((level) => (
                  <option key={level} value={level}>{level}</option>
                ))}
              </select>
            </div>

            {/* Generate Button */}
            <div className="text-center pt-4">
              <button
                onClick={generateSkills}
                disabled={!jobTitle || !industry || !experience || isGenerating}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
              >
                {isGenerating ? (
                  <span className="flex items-center">
                    <i className="ri-loader-4-line animate-spin mr-3"></i>
                    Generating Skills...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <i className="ri-magic-line mr-3"></i>
                    Generate AI Skills
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Generated Skills */}
        {generatedSkills.length > 0 && (
          <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20 mb-8">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                <i className="ri-lightbulb-line text-yellow-500 mr-2"></i>
                AI-Generated Skills
              </h3>
              <p className="text-gray-600">Click on skills to select them for your resume</p>
            </div>

            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-3 mb-8">
              {generatedSkills.map((skill, index) => (
                <button
                  key={index}
                  onClick={() => toggleSkill(skill)}
                  className={`p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                    selectedSkills.includes(skill)
                      ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                      : 'border-gray-200 bg-white/60 text-gray-700 hover:border-indigo-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <i className={`ri-star-line ${
                      selectedSkills.includes(skill) ? 'text-indigo-600' : 'text-gray-400'
                    }`}></i>
                    {selectedSkills.includes(skill) && (
                      <i className="ri-check-line text-indigo-600"></i>
                    )}
                  </div>
                  <div className="font-semibold text-sm">{skill}</div>
                </button>
              ))}
            </div>

            {/* Selected Skills Summary */}
            {selectedSkills.length > 0 && (
              <div className="bg-indigo-50/80 backdrop-blur-sm rounded-xl p-6 border border-indigo-200/50 mb-6">
                <h4 className="font-semibold text-indigo-900 mb-3">
                  Selected Skills ({selectedSkills.length})
                </h4>
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedSkills.map((skill, index) => (
                    <span key={index} className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm font-medium">
                      {skill}
                    </span>
                  ))}
                </div>
                <button
                  onClick={addToResume}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 whitespace-nowrap"
                >
                  <i className="ri-add-line mr-2"></i>
                  Add to Resume Builder
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tips Section */}
        <div className="bg-white/70 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
          <h3 className="text-xl font-bold text-gray-900 mb-6">
            <i className="ri-lightbulb-line text-yellow-500 mr-2"></i>
            Tips for Using AI-Generated Skills
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start">
                <i className="ri-check-line text-emerald-600 mr-3 mt-1 flex-shrink-0"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Customize for Each Job</h4>
                  <p className="text-sm text-gray-600">Tailor your selected skills to match specific job requirements</p>
                </div>
              </div>
              <div className="flex items-start">
                <i className="ri-check-line text-emerald-600 mr-3 mt-1 flex-shrink-0"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Balance Technical & Soft Skills</h4>
                  <p className="text-sm text-gray-600">Include both hard technical skills and soft interpersonal skills</p>
                </div>
              </div>
              <div className="flex items-start">
                <i className="ri-check-line text-emerald-600 mr-3 mt-1 flex-shrink-0"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Be Honest</h4>
                  <p className="text-sm text-gray-600">Only include skills you actually possess and can demonstrate</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start">
                <i className="ri-check-line text-emerald-600 mr-3 mt-1 flex-shrink-0"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Use Keywords</h4>
                  <p className="text-sm text-gray-600">Include industry keywords that ATS systems look for</p>
                </div>
              </div>
              <div className="flex items-start">
                <i className="ri-check-line text-emerald-600 mr-3 mt-1 flex-shrink-0"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Provide Evidence</h4>
                  <p className="text-sm text-gray-600">Back up your skills with examples in your experience section</p>
                </div>
              </div>
              <div className="flex items-start">
                <i className="ri-check-line text-emerald-600 mr-3 mt-1 flex-shrink-0"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Keep It Relevant</h4>
                  <p className="text-sm text-gray-600">Focus on skills that are most relevant to your target role</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 py-16 mt-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Build Your Skills-Optimized Resume?
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Use our AI-powered resume builder with your generated skills
          </p>
          <Link href="/builder" className="inline-flex items-center bg-white text-purple-600 px-8 py-4 rounded-xl font-bold hover:bg-purple-50 transition-all duration-300 whitespace-nowrap">
            <i className="ri-rocket-line mr-3 text-xl"></i>
            Start Building Resume
          </Link>
        </div>
      </div>
    </div>
  );
}