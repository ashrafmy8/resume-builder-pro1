'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function HowToWriteCVPage() {
  const [activeSection, setActiveSection] = useState('getting-started');
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const sections = [
    { id: 'getting-started', name: 'Getting Started', icon: 'ri-rocket-line' },
    { id: 'structure', name: 'CV Structure', icon: 'ri-layout-line' },
    { id: 'content', name: 'Writing Content', icon: 'ri-edit-line' },
    { id: 'sections', name: 'Key Sections', icon: 'ri-list-check' },
    { id: 'formatting', name: 'Formatting Tips', icon: 'ri-palette-line' },
    { id: 'common-mistakes', name: 'Common Mistakes', icon: 'ri-error-warning-line' },
    { id: 'examples', name: 'Examples', icon: 'ri-file-text-line' }
  ];

  const cvSections = [
    {
      title: 'Personal Information',
      icon: 'ri-user-line',
      color: 'blue',
      required: true,
      description: 'Essential contact details and professional identity',
      tips: [
        'Include full name, professional email, phone number',
        'Add LinkedIn profile and professional website if relevant',
        'Include current city and country (full address not necessary)',
        'Use a professional email address (avoid nicknames or numbers)'
      ],
      example: 'Dr. Sarah Johnson\nsarah.johnson@email.com\n+1 (555) 123-4567\nBoston, MA, USA\nlinkedin.com/in/sarahjohnson'
    },
    {
      title: 'Professional Summary / Objective',
      icon: 'ri-target-line',
      color: 'green',
      required: true,
      description: 'Compelling overview of your expertise and career goals',
      tips: [
        'Write 3-4 sentences highlighting your expertise',
        'Mention years of experience and key achievements',
        'Align with the specific role or field you\'re targeting',
        'Include your unique value proposition'
      ],
      example: 'Accomplished biomedical researcher with 12+ years of experience in cardiovascular disease research. Published 35+ peer-reviewed articles with 2,000+ citations. Proven track record of securing competitive research funding ($3.2M) and leading interdisciplinary teams.'
    },
    {
      title: 'Education',
      icon: 'ri-graduation-cap-line',
      color: 'purple',
      required: true,
      description: 'Academic qualifications and educational background',
      tips: [
        'List in reverse chronological order (most recent first)',
        'Include degree type, field of study, institution, and graduation year',
        'Add GPA if exceptional (3.7+ for undergrad, 3.5+ for graduate)',
        'Include thesis title for graduate degrees',
        'Mention relevant coursework, honors, or distinctions'
      ],
      example: 'Ph.D. in Biomedical Engineering, Stanford University (2015)\nThesis: "Novel Approaches to Cardiac Tissue Engineering"\nM.S. in Bioengineering, UC Berkeley (2011)\nB.S. in Biomedical Engineering, Johns Hopkins University (2009), Magna Cum Laude'
    },
    {
      title: 'Professional Experience',
      icon: 'ri-briefcase-line',
      color: 'orange',
      required: true,
      description: 'Work history and professional accomplishments',
      tips: [
        'Use reverse chronological order',
        'Include job title, organization, location, and dates',
        'Focus on achievements rather than job duties',
        'Quantify results with specific numbers and metrics',
        'Use strong action verbs to begin bullet points'
      ],
      example: 'Senior Research Scientist, Cardiovascular Institute (2018-Present)\n• Led breakthrough research resulting in 15 publications in top-tier journals\n• Secured $1.2M NIH R01 grant for innovative cardiac therapy development\n• Mentored 8 PhD students and 12 postdoctoral researchers'
    },
    {
      title: 'Publications',
      icon: 'ri-article-line',
      color: 'red',
      required: false,
      description: 'Scholarly publications and research contributions',
      tips: [
        'Organize by type: peer-reviewed articles, book chapters, conference papers',
        'Use standard academic citation format',
        'Include impact factor or journal ranking if impressive',
        'Highlight first-author and corresponding-author papers',
        'Consider creating separate sections for different publication types'
      ],
      example: 'Peer-Reviewed Articles (h-index: 18, citations: 2,400+)\n1. Johnson, S.*, Smith, R. "Breakthrough in Cardiac Regeneration." Nature Medicine, 2023. IF: 36.1\n2. Johnson, S., et al. "Novel Biomaterials for Heart Repair." Cell, 2022. IF: 41.6\n*Corresponding author'
    },
    {
      title: 'Research Experience',
      icon: 'ri-microscope-line',
      color: 'teal',
      required: false,
      description: 'Research projects and scientific contributions',
      tips: [
        'Include project titles, institutions, supervisors, and dates',
        'Describe methodology, key findings, and impact',
        'Mention any patents, inventions, or breakthroughs',
        'Include collaborative projects and international partnerships',
        'Highlight funding secured for research projects'
      ],
      example: 'Principal Investigator, Cardiac Regeneration Project (2020-2023)\nStanford Cardiovascular Institute, $1.5M NIH funding\n• Developed novel stem cell therapy increasing cardiac function by 40%\n• Filed 3 patents for innovative treatment methodologies'
    }
  ];

  const writingTips = [
    {
      category: 'Language & Tone',
      icon: 'ri-chat-3-line',
      tips: [
        'Use clear, professional language throughout',
        'Write in third person or passive voice (avoid "I")',
        'Be concise while providing comprehensive information',
        'Use field-specific terminology appropriately',
        'Maintain consistent verb tenses'
      ]
    },
    {
      category: 'Quantification',
      icon: 'ri-bar-chart-line',
      tips: [
        'Include specific numbers, percentages, and metrics',
        'Mention team sizes you\'ve led or been part of',
        'Quantify research impact (citations, h-index, impact factor)',
        'Include funding amounts secured',
        'Specify duration of projects and roles'
      ]
    },
    {
      category: 'Keywords & ATS',
      icon: 'ri-key-line',
      tips: [
        'Research job descriptions for relevant keywords',
        'Include field-specific technical terms',
        'Use standard academic and professional terminology',
        'Balance keyword optimization with natural language',
        'Include skill-related keywords throughout content'
      ]
    },
    {
      category: 'Achievements Focus',
      icon: 'ri-trophy-line',
      tips: [
        'Emphasize accomplishments over responsibilities',
        'Show progression and career growth',
        'Highlight unique contributions and innovations',
        'Include awards, recognitions, and honors',
        'Demonstrate leadership and collaboration skills'
      ]
    }
  ];

  const commonMistakes = [
    {
      mistake: 'Including Irrelevant Personal Information',
      description: 'Adding personal details like age, marital status, photo (unless required), or hobbies unrelated to your profession.',
      solution: 'Focus only on professional information that\'s relevant to your career goals and target positions.'
    },
    {
      mistake: 'Using Generic Content',
      description: 'Submitting the same CV for different positions without customization.',
      solution: 'Tailor your CV for each application, emphasizing relevant experience, skills, and achievements.'
    },
    {
      mistake: 'Poor Organization and Structure',
      description: 'Inconsistent formatting, unclear sections, or illogical information flow.',
      solution: 'Use clear headings, consistent formatting, and logical chronological or thematic organization.'
    },
    {
      mistake: 'Lack of Quantification',
      description: 'Describing accomplishments without specific numbers, metrics, or measurable outcomes.',
      solution: 'Include specific data: publication counts, citation numbers, funding amounts, team sizes, etc.'
    },
    {
      mistake: 'Excessive Length Without Purpose',
      description: 'Creating unnecessarily long CVs with repetitive or irrelevant information.',
      solution: 'Be comprehensive but concise. Every section should add value and support your candidacy.'
    },
    {
      mistake: 'Neglecting Proofreading',
      description: 'Submitting CVs with spelling errors, grammatical mistakes, or inconsistent formatting.',
      solution: 'Carefully proofread multiple times, use spell-check, and have colleagues review your CV.'
    }
  ];

  const stepByStepGuide = [
    {
      step: 1,
      title: 'Research and Planning',
      description: 'Before writing, research your target positions and institutions',
      actions: [
        'Analyze job descriptions for required qualifications',
        'Research institutional culture and values',
        'Identify key skills and experiences to highlight',
        'Gather all relevant information and documents'
      ]
    },
    {
      step: 2,
      title: 'Choose the Right Structure',
      description: 'Select a CV format that best showcases your strengths',
      actions: [
        'Chronological: Best for linear career progression',
        'Functional: Emphasizes skills over timeline',
        'Hybrid: Combines chronological and functional elements',
        'Academic: Detailed format for academic positions'
      ]
    },
    {
      step: 3,
      title: 'Write Compelling Content',
      description: 'Craft content that demonstrates your value and expertise',
      actions: [
        'Start with a strong professional summary',
        'Use action verbs and quantifiable achievements',
        'Tailor content to match job requirements',
        'Ensure each section adds unique value'
      ]
    },
    {
      step: 4,
      title: 'Format and Design',
      description: 'Create a professional, readable, and attractive layout',
      actions: [
        'Use consistent fonts and spacing',
        'Ensure adequate white space',
        'Create clear section divisions',
        'Test readability across different devices'
      ]
    },
    {
      step: 5,
      title: 'Review and Refine',
      description: 'Polish your CV through careful review and feedback',
      actions: [
        'Proofread for errors and consistency',
        'Get feedback from mentors or colleagues',
        'Test with ATS systems if applicable',
        'Update regularly with new achievements'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-list-3-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap">
                CV Builder
              </Link>
              <Link href="/cv" className="text-gray-700 hover:text-indigo-600 transition-colors whitespace-nowrap">
                CV Guide
              </Link>
              <Link href="/cv-templates" className="text-gray-700 hover:text-indigo-600 transition-colors whitespace-nowrap">
                CV Templates
              </Link>
              <Link href="/cv-examples" className="text-gray-700 hover:text-indigo-600 transition-colors whitespace-nowrap">
                CV Examples
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-indigo-600 transition-colors border border-gray-300 rounded-lg hover:border-indigo-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Complete Guide to Writing a Professional CV
            </h1>
            <p className="text-xl text-indigo-100 mb-8 max-w-3xl mx-auto">
              Master the art of CV writing with our comprehensive guide. Learn from experts, 
              avoid common mistakes, and create a compelling CV that opens doors to your dream career.
            </p>
            <div className="flex items-center justify-center space-x-8 text-indigo-100">
              <div className="flex items-center">
                <i className="ri-book-open-line mr-2"></i>
                <span>Step-by-step Guide</span>
              </div>
              <div className="flex items-center">
                <i className="ri-lightbulb-line mr-2"></i>
                <span>Expert Tips</span>
              </div>
              <div className="flex items-center">
                <i className="ri-checkbox-circle-line mr-2"></i>
                <span>Proven Methods</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Table of Contents */}
      <section className="py-12 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Table of Contents</h2>
          <div className="flex flex-wrap justify-center gap-3">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`flex items-center px-4 py-3 rounded-lg border-2 transition-all duration-300 whitespace-nowrap ${
                  activeSection === section.id
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-gray-700 border-gray-200 hover:border-indigo-300 hover:text-indigo-600'
                }`}
              >
                <i className={`${section.icon} mr-2`}></i>
                {section.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Getting Started Section */}
        {activeSection === 'getting-started' && (
          <div className="space-y-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Getting Started with Your CV</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                A CV (Curriculum Vitae) is your professional story told through achievements, qualifications, and expertise. 
                Unlike a resume, a CV provides a comprehensive overview of your entire career.
              </p>
            </div>

            {/* CV vs Resume */}
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                  <i className="ri-file-list-3-line text-indigo-600 mr-3"></i>
                  Curriculum Vitae (CV)
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <i className="ri-check-line text-indigo-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Length:</strong> Comprehensive (2+ pages)
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-indigo-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Content:</strong> Complete career overview
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-indigo-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Best for:</strong> Academic, research, medical positions
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-indigo-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Focus:</strong> Publications, research, academic achievements
                    </div>
                  </li>
                </ul>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                  <i className="ri-file-text-line text-blue-600 mr-3"></i>
                  Resume
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <i className="ri-check-line text-blue-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Length:</strong> Concise (1-2 pages)
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-blue-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Content:</strong> Targeted, relevant information
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-blue-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Best for:</strong> Corporate, industry positions
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-blue-600 mr-2 mt-1"></i>
                    <div>
                      <strong>Focus:</strong> Skills, experience, job-specific achievements
                    </div>
                  </li>
                </ul>
              </div>
            </div>

            {/* Step-by-Step Process */}
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Step-by-Step CV Writing Process</h3>
              <div className="space-y-8">
                {stepByStepGuide.map((step) => (
                  <div key={step.step} className="flex items-start space-x-6">
                    <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold">{step.step}</span>
                    </div>
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200 flex-1">
                      <h4 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h4>
                      <p className="text-gray-600 mb-4">{step.description}</p>
                      <ul className="space-y-2">
                        {step.actions.map((action, index) => (
                          <li key={index} className="flex items-start">
                            <i className="ri-arrow-right-s-line text-indigo-600 mr-2 mt-1 flex-shrink-0"></i>
                            <span className="text-gray-700">{action}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Key Sections Content */}
        {activeSection === 'sections' && (
          <div className="space-y-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Essential CV Sections</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Master each section of your CV with detailed guidance, examples, and expert tips.
              </p>
            </div>

            <div className="space-y-8">
              {cvSections.map((section, index) => (
                <div key={index} className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                  <div className={`bg-${section.color}-50 border-b border-${section.color}-200 p-6`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-12 h-12 bg-${section.color}-600 rounded-lg flex items-center justify-center mr-4`}>
                          <i className={`${section.icon} text-white text-xl`}></i>
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-gray-900">{section.title}</h3>
                          <p className="text-gray-600">{section.description}</p>
                        </div>
                      </div>
                      {section.required && (
                        <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-semibold">
                          Required
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="grid lg:grid-cols-2 gap-8">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-4">Writing Tips:</h4>
                        <ul className="space-y-3">
                          {section.tips.map((tip, tipIndex) => (
                            <li key={tipIndex} className="flex items-start">
                              <i className={`ri-check-line text-${section.color}-600 mr-2 mt-1 flex-shrink-0`}></i>
                              <span className="text-gray-700">{tip}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-4">Example:</h4>
                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                          <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono leading-relaxed">
                            {section.example}
                          </pre>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Writing Content Section */}
        {activeSection === 'content' && (
          <div className="space-y-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Writing Compelling CV Content</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Learn how to craft content that captures attention and demonstrates your professional value.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {writingTips.map((category, index) => (
                <div key={index} className="bg-white rounded-xl shadow-lg border border-gray-200 p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mr-4">
                      <i className={`${category.icon} text-indigo-600 text-xl`}></i>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">{category.category}</h3>
                  </div>
                  <ul className="space-y-3">
                    {category.tips.map((tip, tipIndex) => (
                      <li key={tipIndex} className="flex items-start">
                        <i className="ri-arrow-right-s-line text-indigo-600 mr-2 mt-1 flex-shrink-0"></i>
                        <span className="text-gray-700">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Action Verbs Section */}
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Powerful Action Verbs for CVs</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Leadership</h4>
                  <div className="flex flex-wrap gap-2">
                    {['Led', 'Directed', 'Managed', 'Supervised', 'Coordinated', 'Guided'].map((verb) => (
                      <span key={verb} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
                        {verb}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Research</h4>
                  <div className="flex flex-wrap gap-2">
                    {['Investigated', 'Analyzed', 'Discovered', 'Studied', 'Examined', 'Evaluated'].map((verb) => (
                      <span key={verb} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
                        {verb}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Achievement</h4>
                  <div className="flex flex-wrap gap-2">
                    {['Achieved', 'Accomplished', 'Secured', 'Obtained', 'Earned', 'Won'].map((verb) => (
                      <span key={verb} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
                        {verb}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Innovation</h4>
                  <div className="flex flex-wrap gap-2">
                    {['Developed', 'Created', 'Designed', 'Innovated', 'Pioneered', 'Established'].map((verb) => (
                      <span key={verb} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
                        {verb}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Common Mistakes Section */}
        {activeSection === 'common-mistakes' && (
          <div className="space-y-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Common CV Mistakes to Avoid</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Learn from common pitfalls and ensure your CV stands out for all the right reasons.
              </p>
            </div>

            <div className="space-y-6">
              {commonMistakes.map((item, index) => (
                <div key={index} className="bg-white rounded-xl shadow-lg border border-gray-200 p-8">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="ri-close-circle-line text-red-600 text-xl"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-3">{item.mistake}</h3>
                      <p className="text-gray-600 mb-4">{item.description}</p>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div className="flex items-start space-x-2">
                          <i className="ri-check-circle-line text-green-600 mt-1 flex-shrink-0"></i>
                          <div>
                            <strong className="text-green-800">Solution: </strong>
                            <span className="text-green-700">{item.solution}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Additional sections would be implemented similarly... */}
        {activeSection === 'structure' && (
          <div className="text-center py-20">
            <i className="ri-layout-line text-6xl text-gray-400 mb-4"></i>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">CV Structure Guide</h3>
            <p className="text-gray-600">Detailed information about CV structure and organization coming soon...</p>
          </div>
        )}

        {activeSection === 'formatting' && (
          <div className="text-center py-20">
            <i className="ri-palette-line text-6xl text-gray-400 mb-4"></i>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Formatting Guidelines</h3>
            <p className="text-gray-600">Professional formatting tips and design principles coming soon...</p>
          </div>
        )}

        {activeSection === 'examples' && (
          <div className="text-center py-20">
            <i className="ri-file-text-line text-6xl text-gray-400 mb-4"></i>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">CV Examples</h3>
            <p className="text-gray-600 mb-6">Explore our comprehensive collection of professional CV examples</p>
            <Link href="/cv-examples" className="inline-block bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition-colors font-semibold">
              View CV Examples
            </Link>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <section className="py-16 bg-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Ready to Get Started?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Link href="/builder?type=cv" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 text-center group">
              <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-edit-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Build Your CV</h3>
              <p className="text-gray-600">Use our AI-powered builder to create your professional CV</p>
            </Link>

            <Link href="/cv-templates" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 text-center group">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-layout-2-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Browse Templates</h3>
              <p className="text-gray-600">Choose from professionally designed CV templates</p>
            </Link>

            <Link href="/cv-examples" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 text-center group">
              <div className="w-16 h-16 bg-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className="ri-user-star-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">View Examples</h3>
              <p className="text-gray-600">Learn from successful professionals' CVs</p>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Start Writing Your Professional CV Today</h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
            Apply these expert guidelines and create a compelling CV that showcases your expertise and achievements
          </p>
          <Link
            href="/builder?type=cv"
            className="inline-block bg-white text-indigo-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap"
          >
            Build My CV Now
          </Link>
        </div>
      </section>
    </div>
  );
}