
'use client';

import { useState, useEffect } from 'react';
import PersonalInfoSection from './sections/PersonalInfoSection';
import SummarySection from './sections/SummarySection';
import ExperienceSection from './sections/ExperienceSection';
import EducationSection from './sections/EducationSection';
import SkillsSection from './sections/SkillsSection';
import CertificationsSection from './sections/CertificationsSection';
import ReferencesSection from './sections/ReferencesSection';
import LanguagesSection from './sections/LanguagesSection';

interface Language {
  language: string;
  proficiency: string;
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  summary: string;
  targetJobRole: string;
  experience: Experience[];
  education: Education[];
  skills: Skill[];
  certifications: Certification[];
  references: Reference[];
  languages: Language[];
}

interface ResumeFormProps {
  data: ResumeData;
  onChange: (data: ResumeData) => void;
}

export default function ResumeForm({ data, onChange }: ResumeFormProps) {
  const [activeSection, setActiveSection] = useState('personal');

  const sections = [
    { id: 'personal', name: 'Personal Info', icon: 'ri-user-line' },
    { id: 'summary', name: 'Summary', icon: 'ri-file-text-line' },
    { id: 'experience', name: 'Experience', icon: 'ri-briefcase-line' },
    { id: 'education', name: 'Education', icon: 'ri-graduation-cap-line' },
    { id: 'skills', name: 'Skills', icon: 'ri-tools-line' },
    { id: 'languages', name: 'Languages', icon: 'ri-global-line' },
    { id: 'certifications', name: 'Certifications', icon: 'ri-award-line' },
    { id: 'references', name: 'References', icon: 'ri-contacts-line' }
  ];

  const renderSection = () => {
    switch (activeSection) {
      case 'personal':
        return (
          <PersonalInfoSection
            resumeData={data}
            setResumeData={onChange}
          />
        );
      case 'summary':
        return (
          <SummarySection
            summary={data.summary}
            onChange={(summary) => onChange({ ...data, summary })}
          />
        );
      case 'experience':
        return (
          <ExperienceSection
            experience={data.experience}
            onChange={(experience) => onChange({ ...data, experience })}
          />
        );
      case 'education':
        return (
          <EducationSection
            education={data.education}
            onChange={(education) => onChange({ ...data, education })}
          />
        );
      case 'skills':
        return (
          <SkillsSection
            skills={data.skills}
            onChange={(skills) => onChange({ ...data, skills })}
          />
        );
      case 'languages':
        return (
          <LanguagesSection
            languages={data.languages}
            onChange={(languages) => onChange({ ...data, languages })}
          />
        );
      case 'certifications':
        return (
          <CertificationsSection
            certifications={data.certifications}
            onChange={(certifications) => onChange({ ...data, certifications })}
          />
        );
      case 'references':
        return (
          <ReferencesSection
            references={data.references}
            onChange={(references) => onChange({ ...data, references })}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-2xl">
      {/* Personal Information */}
      {currentStep === 1 && (
        <PersonalInfoSection 
          resumeData={resumeData} 
          setResumeData={setResumeData}
          selectedTemplate={selectedTemplate}
        />
      )}
    </div>
  );
}
