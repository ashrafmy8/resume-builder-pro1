
'use client';

import { useState } from 'react';

interface TemplateSelectorProps {
  resumeData: any;
  setResumeData: (data: any) => void;
  onTemplateSelect: (templateId: string) => void;
}

export default function TemplateSelector({ resumeData, setResumeData, onTemplateSelect }: TemplateSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTemplate, setSelectedTemplate] = useState('');

  const templates = [
    // Modern Templates (6)
    {
      id: 'galaxy-modern',
      name: 'Galaxy Modern',
      category: 'modern',
      description: 'Dark space theme with gradient headers and glassmorphism effects for tech professionals',
      color: 'slate',
      premium: false,
      rating: 4.9,
      downloads: '52.3K',
      preview: 'https://readdy.ai/api/search-image?query=Modern%20professional%20resume%20template%20with%20dark%20galaxy%20theme%2C%20gradient%20purple%20to%20blue%20header%20section%2C%20glassmorphism%20white%20cards%20with%20backdrop%20blur%20effects%2C%20professional%20photo%20placeholder%2C%20space-inspired%20design%20elements%2C%20contemporary%20typography%2C%20technical%20skills%20visualization%20with%20progress%20bars&width=120&height=150&seq=galaxy-modern&orientation=portrait'
    },
    {
      id: 'quantum-tech',
      name: 'Quantum Tech',
      category: 'modern',
      description: 'Emerald/cyan gradients perfect for AI/tech professionals with futuristic design elements',
      color: 'emerald',
      premium: false,
      rating: 4.8,
      downloads: '48.7K',
      preview: 'https://readdy.ai/api/search-image?query=Futuristic%20tech%20resume%20template%20with%20emerald%20to%20cyan%20gradient%20elements%2C%20quantum-inspired%20design%2C%20glassmorphism%20cards%2C%20AI%20and%20machine%20learning%20focus%2C%20modern%20technical%20typography%2C%20circuit%20board%20subtle%20patterns%2C%20tech%20professional%20formatting&width=120&height=150&seq=quantum-tech&orientation=portrait'
    },
    {
      id: 'velocity-modern',
      name: 'Velocity Modern',
      category: 'modern',
      description: 'Blue/purple gradients with contemporary card layouts and dynamic visual elements',
      color: 'blue',
      premium: false,
      rating: 4.9,
      downloads: '45.2K',
      preview: 'https://readdy.ai/api/search-image?query=Contemporary%20modern%20resume%20template%20with%20blue%20to%20purple%20gradient%20background%2C%20velocity-inspired%20dynamic%20elements%2C%20floating%20cards%20design%2C%20contemporary%20typography%2C%20professional%20photo%20treatment%2C%20modern%20skill%20visualization%2C%20speed%20and%20motion%20visual%20metaphors&width=120&height=150&seq=velocity-modern&orientation=portrait'
    },
    {
      id: 'matrix-tech',
      name: 'Matrix Tech',
      category: 'modern',
      description: 'Cyberpunk-inspired design with green terminal aesthetics for developers',
      color: 'green',
      premium: true,
      rating: 5.0,
      downloads: '28.9K',
      preview: 'https://readdy.ai/api/search-image?query=Cyberpunk%20matrix%20resume%20template%20with%20dark%20background%2C%20green%20terminal-inspired%20accents%2C%20code-like%20typography%2C%20developer%20and%20hacker%20aesthetic%2C%20digital%20rain%20effects%2C%20futuristic%20professional%20formatting%2C%20cybersecurity%20focus&width=120&height=150&seq=matrix-tech&orientation=portrait'
    },
    {
      id: 'flux-modern',
      name: 'Flux Modern',
      category: 'modern',
      description: 'Cyan/blue gradients with floating elements and modern typography',
      color: 'cyan',
      premium: false,
      rating: 4.8,
      downloads: '41.6K',
      preview: 'https://readdy.ai/api/search-image?query=Modern%20flux%20resume%20template%20with%20cyan%20to%20blue%20gradient%20elements%2C%20floating%20geometric%20shapes%2C%20contemporary%20card-based%20layout%2C%20modern%20sans-serif%20typography%2C%20professional%20photo%20with%20gradient%20border%2C%20dynamic%20visual%20flow&width=120&height=150&seq=flux-modern&orientation=portrait'
    },
    {
      id: 'echo-modern',
      name: 'Echo Modern',
      category: 'modern',
      description: 'Orange/red gradients with dynamic visual elements and contemporary design',
      color: 'orange',
      premium: false,
      rating: 4.7,
      downloads: '35.8K',
      preview: 'https://readdy.ai/api/search-image?query=Echo%20modern%20resume%20template%20with%20orange%20to%20red%20gradient%20background%2C%20sound%20wave%20visual%20elements%2C%20dynamic%20typography%2C%20contemporary%20professional%20design%2C%20creative%20visual%20metaphors%2C%20modern%20card%20layouts&width=120&height=150&seq=echo-modern&orientation=portrait'
    },

    // Creative Templates (4)
    {
      id: 'nexus-creative',
      name: 'Nexus Creative',
      category: 'creative',
      description: 'Purple/violet gradients with artistic flair and creative visual elements',
      color: 'purple',
      premium: false,
      rating: 4.8,
      downloads: '32.4K',
      preview: 'https://readdy.ai/api/search-image?query=Creative%20nexus%20resume%20template%20with%20purple%20to%20violet%20gradient%20background%2C%20artistic%20connection%20points%20and%20network%20visuals%2C%20creative%20typography%2C%20portfolio%20project%20showcase%2C%20artistic%20photo%20treatment%2C%20creative%20industry%20formatting&width=120&height=150&seq=nexus-creative&orientation=portrait'
    },
    {
      id: 'spectrum-creative',
      name: 'Spectrum Creative',
      category: 'creative',
      description: 'Yellow/orange/red gradients for motion graphics and visual artists',
      color: 'amber',
      premium: false,
      rating: 4.7,
      downloads: '28.2K',
      preview: 'https://readdy.ai/api/search-image?query=Spectrum%20creative%20resume%20template%20with%20rainbow%20gradient%20from%20yellow%20through%20orange%20to%20red%2C%20color%20spectrum%20visual%20elements%2C%20motion%20graphics%20inspired%20design%2C%20creative%20skills%20visualization%2C%20artistic%20typography%2C%20visual%20arts%20professional%20formatting&width=120&height=150&seq=spectrum-creative&orientation=portrait'
    },
    {
      id: 'aurora-creative',
      name: 'Aurora Creative',
      category: 'creative',
      description: 'Pink/purple/indigo gradients with artistic photo treatments',
      color: 'pink',
      premium: false,
      rating: 4.9,
      downloads: '26.5K',
      preview: 'https://readdy.ai/api/search-image?query=Aurora%20creative%20resume%20template%20with%20pink%20to%20purple%20to%20indigo%20gradient%20background%2C%20northern%20lights%20inspired%20design%2C%20artistic%20photo%20treatment%20with%20creative%20borders%2C%20ethereal%20visual%20elements%2C%20creative%20portfolio%20showcase&width=120&height=150&seq=aurora-creative&orientation=portrait'
    },
    {
      id: 'neon-creative',
      name: 'Neon Creative',
      category: 'creative',
      description: 'Dark theme with neon accents perfect for digital artists and NFT creators',
      color: 'purple',
      premium: true,
      rating: 4.9,
      downloads: '19.7K',
      preview: 'https://readdy.ai/api/search-image?query=Neon%20creative%20resume%20template%20with%20dark%20black%20background%2C%20bright%20neon%20purple%20and%20cyan%20accents%2C%20digital%20art%20aesthetic%2C%20NFT%20and%20crypto%20art%20focus%2C%20glowing%20text%20effects%2C%20futuristic%20creative%20professional%20formatting&width=120&height=150&seq=neon-creative&orientation=portrait'
    },

    // Professional Templates (4)
    {
      id: 'astral-professional',
      name: 'Astral Professional',
      category: 'professional',
      description: 'Rose/orange gradients with structured business formatting',
      color: 'rose',
      premium: false,
      rating: 4.8,
      downloads: '38.9K',
      preview: 'https://readdy.ai/api/search-image?query=Astral%20professional%20resume%20template%20with%20rose%20to%20orange%20gradient%20elements%2C%20space-inspired%20professional%20design%2C%20structured%20business%20formatting%2C%20clean%20typography%2C%20professional%20photo%20placement%2C%20corporate%20consulting%20style&width=120&height=150&seq=astral-professional&orientation=portrait'
    },
    {
      id: 'horizon-professional',
      name: 'Horizon Professional',
      category: 'professional',
      description: 'Clean white background with teal accents and professional layout',
      color: 'teal',
      premium: false,
      rating: 4.7,
      downloads: '44.2K',
      preview: 'https://readdy.ai/api/search-image?query=Horizon%20professional%20resume%20template%20with%20clean%20white%20background%2C%20teal%20accent%20colors%2C%20horizon%20line%20design%20elements%2C%20professional%20business%20formatting%2C%20structured%20sections%20with%20clean%20borders%2C%20corporate%20typography&width=120&height=150&seq=horizon-professional&orientation=portrait'
    },
    {
      id: 'cosmos-professional',
      name: 'Cosmos Professional',
      category: 'professional',
      description: 'Traditional design with indigo accents and centered photo',
      color: 'indigo',
      premium: false,
      rating: 4.6,
      downloads: '36.8K',
      preview: 'https://readdy.ai/api/search-image?query=Cosmos%20professional%20resume%20template%20with%20traditional%20business%20layout%2C%20indigo%20accent%20colors%2C%20centered%20professional%20photo%2C%20cosmic%20subtle%20elements%2C%20structured%20professional%20formatting%2C%20business%20consulting%20style&width=120&height=150&seq=cosmos-professional&orientation=portrait'
    },
    {
      id: 'vertex-professional',
      name: 'Vertex Professional',
      category: 'professional',
      description: 'Green theme with project management focus and structured layout',
      color: 'green',
      premium: false,
      rating: 4.7,
      downloads: '31.5K',
      preview: 'https://readdy.ai/api/search-image?query=Vertex%20professional%20resume%20template%20with%20green%20accent%20colors%2C%20geometric%20vertex%20design%20elements%2C%20project%20management%20focus%2C%20structured%20professional%20layout%2C%20clean%20business%20typography%2C%20management%20consulting%20formatting&width=120&height=150&seq=vertex-professional&orientation=portrait'
    },

    // Executive Templates (2)
    {
      id: 'prism-executive',
      name: 'Prism Executive',
      category: 'executive',
      description: 'Sophisticated slate colors with premium gradient headers',
      color: 'slate',
      premium: true,
      rating: 4.9,
      downloads: '15.3K',
      preview: 'https://readdy.ai/api/search-image?query=Prism%20executive%20resume%20template%20with%20sophisticated%20slate%20color%20scheme%2C%20premium%20gradient%20header%2C%20prism%20light%20refraction%20design%20elements%2C%20executive%20photo%20treatment%2C%20luxury%20business%20formatting%2C%20C-suite%20professional%20style&width=120&height=150&seq=prism-executive&orientation=portrait'
    },
    {
      id: 'platinum-executive',
      name: 'Platinum Executive',
      category: 'executive',
      description: 'Luxury gray/white design for C-suite professionals',
      color: 'slate',
      premium: true,
      rating: 5.0,
      downloads: '12.8K',
      preview: 'https://readdy.ai/api/search-image?query=Platinum%20executive%20resume%20template%20with%20luxury%20platinum%20and%20white%20color%20scheme%2C%20premium%20executive%20formatting%2C%20sophisticated%20design%20elements%2C%20C-suite%20professional%20layout%2C%20high-end%20business%20typography%2C%20luxury%20corporate%20style&width=120&height=150&seq=platinum-executive&orientation=portrait'
    },

    // Minimalist Templates (2)
    {
      id: 'zenith-minimalist',
      name: 'Zenith Minimalist',
      category: 'minimalist',
      description: 'Ultra-clean white design with indigo accents and minimal elements',
      color: 'indigo',
      premium: false,
      rating: 4.8,
      downloads: '29.7K',
      preview: 'https://readdy.ai/api/search-image?query=Zenith%20minimalist%20resume%20template%20with%20ultra-clean%20white%20background%2C%20minimal%20indigo%20accents%2C%20maximum%20white%20space%2C%20clean%20sans-serif%20typography%2C%20minimal%20design%20elements%2C%20Scandinavian-inspired%20professional%20formatting&width=120&height=150&seq=zenith-minimalist&orientation=portrait'
    },
    {
      id: 'zen-minimalist',
      name: 'Zen Minimalist',
      category: 'minimalist',
      description: 'Scandinavian-inspired layout with maximum white space',
      color: 'blue',
      premium: false,
      rating: 4.7,
      downloads: '25.4K',
      preview: 'https://readdy.ai/api/search-image?query=Zen%20minimalist%20resume%20template%20with%20Scandinavian%20design%20principles%2C%20maximum%20white%20space%2C%20subtle%20blue%20accents%2C%20zen-inspired%20minimal%20elements%2C%20clean%20typography%2C%20Nordic%20professional%20formatting&width=120&height=150&seq=zen-minimalist&orientation=portrait'
    },

    // Entry Level Templates (2)
    {
      id: 'nova-entry-level',
      name: 'Nova Entry Level',
      category: 'entry-level',
      description: 'Bright colors for students and new graduates',
      color: 'orange',
      premium: false,
      rating: 4.6,
      downloads: '42.8K',
      preview: 'https://readdy.ai/api/search-image?query=Nova%20entry%20level%20resume%20template%20with%20bright%20orange%20and%20yellow%20colors%2C%20student-friendly%20design%2C%20fresh%20graduate%20formatting%2C%20education%20section%20emphasis%2C%20internship%20experience%20highlight%2C%20energetic%20typography&width=120&height=150&seq=nova-entry-level&orientation=portrait'
    },
    {
      id: 'spark-entry-level',
      name: 'Spark Entry Level',
      category: 'entry-level',
      description: 'Energetic design for fresh professionals',
      color: 'red',
      premium: false,
      rating: 4.5,
      downloads: '38.1K',
      preview: 'https://readdy.ai/api/search-image?query=Spark%20entry%20level%20resume%20template%20with%20energetic%20red%20and%20orange%20colors%2C%20spark-inspired%20design%20elements%2C%20fresh%20professional%20formatting%2C%20entry-level%20focus%2C%20dynamic%20typography%2C%20new%20graduate%20style&width=120&height=150&seq=spark-entry-level&orientation=portrait'
    }
  ];

  const categories = [
    { id: 'all', name: 'All Templates', count: templates.length },
    { id: 'modern', name: 'Modern', count: templates.filter(t => t.category === 'modern').length },
    { id: 'professional', name: 'Professional', count: templates.filter(t => t.category === 'professional').length },
    { id: 'creative', name: 'Creative', count: templates.filter(t => t.category === 'creative').length },
    { id: 'executive', name: 'Executive', count: templates.filter(t => t.category === 'executive').length },
    { id: 'minimalist', name: 'Minimalist', count: templates.filter(t => t.category === 'minimalist').length },
    { id: 'entry-level', name: 'Entry Level', count: templates.filter(t => t.category === 'entry-level').length }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
  };

  const handleContinue = () => {
    if (selectedTemplate) {
      onTemplateSelect(selectedTemplate);
    }
  };

  const getColorClasses = (color: string, isSelected: boolean) => {
    const colors = {
      blue: isSelected ? 'border-blue-500 bg-blue-50 shadow-blue-200/50' : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50/50',
      indigo: isSelected ? 'border-indigo-500 bg-indigo-50 shadow-indigo-200/50' : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/50',
      purple: isSelected ? 'border-purple-500 bg-purple-50 shadow-purple-200/50' : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/50',
      green: isSelected ? 'border-green-500 bg-green-50 shadow-green-200/50' : 'border-gray-200 hover:border-green-300 hover:bg-green-50/50',
      emerald: isSelected ? 'border-emerald-500 bg-emerald-50 shadow-emerald-200/50' : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/50',
      teal: isSelected ? 'border-teal-500 bg-teal-50 shadow-teal-200/50' : 'border-gray-200 hover:border-teal-300 hover:bg-teal-50/50',
      orange: isSelected ? 'border-orange-500 bg-orange-50 shadow-orange-200/50' : 'border-gray-200 hover:border-orange-300 hover:bg-orange-50/50',
      rose: isSelected ? 'border-rose-500 bg-rose-50 shadow-rose-200/50' : 'border-gray-200 hover:border-rose-300 hover:bg-rose-50/50',
      amber: isSelected ? 'border-amber-500 bg-amber-50 shadow-amber-200/50' : 'border-gray-200 hover:border-amber-300 hover:bg-amber-50/50',
      slate: isSelected ? 'border-slate-500 bg-slate-50 shadow-slate-200/50' : 'border-gray-200 hover:border-slate-300 hover:bg-slate-50/50',
      pink: isSelected ? 'border-pink-500 bg-pink-50 shadow-pink-200/50' : 'border-gray-200 hover:border-pink-300 hover:bg-pink-50/50',
      cyan: isSelected ? 'border-cyan-500 bg-cyan-50 shadow-cyan-200/50' : 'border-gray-200 hover:border-cyan-300 hover:bg-cyan-50/50',
      red: isSelected ? 'border-red-500 bg-red-50 shadow-red-200/50' : 'border-gray-200 hover:border-red-300 hover:bg-red-50/50'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
          Choose Your Perfect Template
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Professional resume templates with modern designs, contemporary typography, and ATS-optimized formatting. 
          Each template features complete content and industry-specific layouts.
        </p>
        <div className="flex justify-center space-x-8 text-sm text-gray-600 mt-6">
          <div className="flex items-center">
            <i className="ri-check-line text-green-500 mr-2"></i>
            <span>A4 Format</span>
          </div>
          <div className="flex items-center">
            <i className="ri-check-line text-green-500 mr-2"></i>
            <span>ATS Optimized</span>
          </div>
          <div className="flex items-center">
            <i className="ri-check-line text-green-500 mr-2"></i>
            <span>Professional Content</span>
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="mb-8 space-y-4">
        <div className="relative max-w-md mx-auto">
          <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
          <input
            type="text"
            placeholder="Search templates by name or style..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white/90 backdrop-blur-sm text-lg"
          />
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 whitespace-nowrap ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg transform scale-105'
                  : 'bg-white/90 text-gray-700 hover:bg-indigo-50 border-2 border-gray-200 hover:border-indigo-300'
              }`}
            >
              {category.name} ({category.count})
            </button>
          ))}
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
        {filteredTemplates.map((template) => (
          <div
            key={template.id}
            onClick={() => handleTemplateSelect(template.id)}
            className={`group border-2 rounded-2xl p-6 cursor-pointer transition-all duration-500 hover:shadow-2xl hover:scale-105 ${
              getColorClasses(template.color, selectedTemplate === template.id)
            } ${selectedTemplate === template.id ? 'shadow-2xl transform scale-105' : ''}`}
          >
            <div className="relative mb-4">
              <img
                src={template.preview}
                alt={`${template.name} Resume Template`}
                className="w-full h-48 object-cover object-top rounded-xl border border-white/50 shadow-lg group-hover:shadow-xl transition-all duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              {selectedTemplate === template.id && (
                <div className="absolute top-3 right-3 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg animate-bounce">
                  <i className="ri-check-line text-white text-lg font-bold"></i>
                </div>
              )}
              {template.premium && (
                <div className="absolute top-3 left-3 px-3 py-1 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-xs rounded-full font-bold shadow-lg">
                  <i className="ri-vip-crown-line mr-1"></i>
                  Premium
                </div>
              )}
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">
                  {template.name}
                </h3>
                <div className="flex items-center space-x-1 text-sm text-amber-500">
                  <i className="ri-star-fill"></i>
                  <span className="font-medium">{template.rating}</span>
                </div>
              </div>
              
              <p className="text-gray-600 text-sm leading-relaxed line-clamp-2">{template.description}</p>
              
              <div className="flex items-center justify-between pt-3 border-t border-gray-200/50">
                <span className={`px-3 py-1 text-xs rounded-full font-medium ${
                  template.category === 'modern' ? 'bg-blue-100 text-blue-700' :
                  template.category === 'professional' ? 'bg-emerald-100 text-emerald-700' :
                  template.category === 'creative' ? 'bg-purple-100 text-purple-700' :
                  template.category === 'executive' ? 'bg-slate-100 text-slate-700' :
                  template.category === 'minimalist' ? 'bg-indigo-100 text-indigo-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {template.category.charAt(0).toUpperCase() + template.category.slice(1).replace('-', ' ')}
                </span>
                <div className="flex items-center space-x-1 text-xs text-gray-500">
                  <i className="ri-download-line"></i>
                  <span>{template.downloads}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {filteredTemplates.length === 0 && (
          <div className="col-span-full text-center py-16">
            <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <i className="ri-search-line text-gray-400 text-3xl"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">No templates found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria to find the perfect template</p>
          </div>
        )}
      </div>

      {/* Continue Button */}
      {selectedTemplate && (
        <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50">
          <button
            onClick={handleContinue}
            className="px-8 py-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold rounded-2xl hover:from-indigo-600 hover:to-purple-700 transition-all duration-300 shadow-2xl hover:shadow-indigo-500/25 hover:scale-105 flex items-center space-x-3 whitespace-nowrap"
          >
            <span className="text-lg">Continue with {templates.find(t => t.id === selectedTemplate)?.name}</span>
            <i className="ri-arrow-right-line text-xl"></i>
          </button>
        </div>
      )}

      {/* Template Features */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-200/50">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <i className="ri-palette-line text-white text-xl"></i>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Modern Design</h3>
          <p className="text-gray-600 text-sm">Contemporary layouts inspired by leading design platforms</p>
        </div>
        
        <div className="text-center p-6 bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl border border-emerald-200/50">
          <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <i className="ri-robot-line text-white text-xl"></i>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">ATS Optimized</h3>
          <p className="text-gray-600 text-sm">Formatted to pass applicant tracking systems seamlessly</p>
        </div>
        
        <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-200/50">
          <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <i className="ri-printer-line text-white text-xl"></i>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Print Perfect</h3>
          <p className="text-gray-600 text-sm">Optimized for A4 and Letter size with proper margins</p>
        </div>

        <div className="text-center p-6 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl border border-amber-200/50">
          <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <i className="ri-download-cloud-line text-white text-xl"></i>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Export Ready</h3>
          <p className="text-gray-600 text-sm">Download as PDF or Word with formatting preserved</p>
        </div>
      </div>

      {/* Template Selection Info */}
      <div className="mt-8 p-6 bg-gradient-to-r from-indigo-50/80 to-purple-50/80 backdrop-blur-sm border-2 border-indigo-200/50 rounded-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <i className="ri-information-line text-indigo-600 text-2xl"></i>
            <div>
              <div className="font-bold text-indigo-900 text-lg">
                {filteredTemplates.length} Professional Templates Available
              </div>
              <div className="text-indigo-700 text-sm">
                {selectedTemplate ? 'Template selected! Click continue to start building your resume.' : 'Select a template that matches your industry and personal style'}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-6 text-sm text-indigo-600">
            <span className="flex items-center">
              <i className="ri-star-line mr-2"></i>
              Premium options
            </span>
            <span className="flex items-center">
              <i className="ri-palette-line mr-2"></i>
              Multiple styles
            </span>
            <span className="flex items-center">
              <i className="ri-download-line mr-2"></i>
              {templates.reduce((sum, t) => sum + parseFloat(t.downloads.replace('K', '')), 0).toFixed(0)}K+ downloads
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
