
'use client';

interface ResumePreviewProps {
  resumeData: any;
  selectedTemplate?: string;
  showWatermark?: boolean;
}

export default function ResumePreview({ resumeData, selectedTemplate = 'modern-minimalist', showWatermark = true }: ResumePreviewProps) {
  // Safely access resume data with defaults
  const safeResumeData = {
    personalInfo: resumeData?.personalInfo || {
      firstName: '',
      lastName: '',
      jobTitle: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      country: '',
      linkedin: '',
      website: '',
      profilePhoto: ''
    },
    experience: Array.isArray(resumeData?.experience) ? resumeData.experience : [],
    education: Array.isArray(resumeData?.education) ? resumeData.education : [],
    skills: Array.isArray(resumeData?.skills) ? resumeData.skills : [],
    languages: Array.isArray(resumeData?.languages) ? resumeData.languages : [],
    summary: resumeData?.summary || '',
    certifications: Array.isArray(resumeData?.certifications) ? resumeData.certifications : [],
    references: resumeData?.references || { showReferences: false, referencesType: 'upon-request', references: [] }
  };

  // Enhanced template styles with accurate color schemes and layouts
  const getTemplateStyle = (templateId: string) => {
    const templates = {
      'professional-classic': {
        container: "bg-white min-h-[1200px] max-w-[8.5in] mx-auto shadow-2xl font-serif",
        wrapper: "relative",
        header: "bg-gradient-to-r from-navy-900 via-navy-800 to-navy-900 text-white px-12 py-16 -mx-0 -mt-0",
        headerContent: "text-center relative z-10",
        name: "text-5xl font-bold text-white mb-4 tracking-wide uppercase",
        title: "text-2xl text-blue-200 mb-8 font-semibold uppercase tracking-wider",
        contact: "flex flex-wrap justify-center gap-8 text-sm text-blue-100 mt-8",
        contactItem: "flex items-center space-x-2",
        body: "px-12 py-8",
        sectionHeader: "text-2xl font-bold text-navy-900 mb-8 pb-3 border-b-3 border-navy-900 uppercase tracking-wide",
        experienceItem: "mb-10 pb-6 border-b border-gray-200 last:border-b-0",
        experienceHeader: "flex justify-between items-start mb-4",
        experienceTitle: "text-xl font-bold text-gray-900",
        experienceCompany: "text-navy-700 font-semibold text-lg",
        experienceLocation: "text-gray-600 text-sm mt-1",
        experienceDate: "text-sm text-navy-600 font-medium bg-navy-100 px-4 py-2 rounded whitespace-nowrap",
        experienceDescription: "text-gray-700 leading-relaxed mt-3",
        skillTag: "bg-navy-900 text-white px-5 py-3 text-sm font-medium mr-4 mb-4 inline-block",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-6",
        photo: "w-40 h-40 rounded-full object-cover border-6 border-white shadow-2xl mx-auto"
      },
      'professional-executive': {
        container: "bg-white min-h-[1200px] max-w-[8.5in] mx-auto shadow-2xl font-serif border-t-8 border-slate-800",
        wrapper: "relative",
        header: "px-16 py-12 bg-gradient-to-br from-slate-50 to-slate-100 border-b-4 border-slate-800",
        headerContent: "text-left relative z-10",
        name: "text-5xl font-bold text-slate-900 mb-4 tracking-wide",
        title: "text-2xl text-slate-600 mb-8 font-semibold italic",
        contact: "grid grid-cols-2 gap-6 text-sm text-slate-700 bg-white p-8 rounded-xl shadow-lg mt-8",
        contactItem: "flex items-center space-x-3",
        body: "px-16 py-8",
        sectionHeader: "text-2xl font-bold text-slate-800 mb-10 pb-3 border-b-3 border-slate-300 uppercase tracking-wider",
        experienceItem: "mb-12 pb-8 border-b-2 border-slate-200 last:border-b-0",
        experienceHeader: "flex justify-between items-start mb-6",
        experienceTitle: "text-2xl font-bold text-slate-900",
        experienceCompany: "text-slate-700 font-semibold text-xl",
        experienceLocation: "text-slate-500 text-base mt-1",
        experienceDate: "text-base text-slate-600 font-medium bg-slate-100 px-6 py-3 rounded-xl whitespace-nowrap",
        experienceDescription: "text-slate-700 leading-relaxed text-base mt-4",
        skillTag: "bg-slate-800 text-white px-6 py-3 text-base font-medium mr-4 mb-4 inline-block",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-8 flex justify-start",
        photo: "w-36 h-36 rounded-full object-cover border-4 border-slate-300 shadow-xl"
      },
      'modern-minimalist': {
        container: "bg-white min-h-[1200px] max-w-[8.5in] mx-auto shadow-2xl font-sans border-l-8 border-blue-500",
        wrapper: "relative",
        header: "px-12 py-12 bg-gradient-to-br from-blue-50 to-indigo-50",
        headerContent: "relative z-10",
        name: "text-5xl font-light text-gray-900 mb-3 tracking-wide",
        title: "text-2xl text-blue-500 mb-8 font-medium uppercase tracking-wider",
        contact: "grid grid-cols-2 gap-6 text-sm text-gray-600 bg-white p-8 rounded-2xl shadow-lg mt-8",
        contactItem: "flex items-center space-x-3",
        body: "px-12 py-8",
        sectionHeader: "text-2xl font-light text-gray-900 mb-10 pb-4 border-b-2 border-blue-500 flex items-center",
        sectionIcon: "w-8 h-8 text-blue-500 mr-4 flex items-center justify-center",
        experienceItem: "mb-12 relative pl-8 border-l-3 border-blue-200",
        experienceHeader: "flex justify-between items-start mb-4",
        experienceTitle: "text-xl font-semibold text-gray-900",
        experienceCompany: "text-blue-500 font-medium text-lg",
        experienceLocation: "text-gray-500 text-sm mt-1",
        experienceDate: "text-sm text-white bg-blue-500 px-6 py-3 rounded-full whitespace-nowrap font-medium shadow-lg",
        experienceDescription: "text-gray-600 leading-relaxed mt-3",
        skillTag: "bg-blue-500 text-white px-8 py-4 rounded-full text-sm font-medium mr-4 mb-4 inline-block shadow-lg hover:bg-blue-600 transition-colors",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-8 flex justify-center",
        photo: "w-32 h-32 rounded-full object-cover border-4 border-blue-500 shadow-xl"
      },
      'modern-tech': {
        container: "bg-white min-h-[1200px] max-w-[8.5in] mx-auto shadow-xl font-mono border-l-6 border-green-500",
        wrapper: "relative",
        header: "bg-gradient-to-r from-gray-900 via-green-900 to-gray-900 text-white px-12 py-12",
        headerContent: "relative z-10",
        name: "text-4xl font-bold text-white mb-3 font-mono",
        title: "text-xl text-green-300 mb-8 font-medium font-mono",
        contact: "grid grid-cols-2 gap-6 text-sm text-green-100 bg-black/20 p-6 rounded-xl mt-6",
        contactItem: "flex items-center space-x-2",
        body: "px-12 py-8",
        sectionHeader: "text-xl font-bold text-gray-900 mb-8 pb-3 border-b-3 border-green-500 font-mono uppercase",
        experienceItem: "mb-10 bg-gray-50 p-8 rounded-xl border-l-4 border-green-500",
        experienceHeader: "flex justify-between items-start mb-4",
        experienceTitle: "text-lg font-bold text-gray-900 font-mono",
        experienceCompany: "text-green-600 font-semibold font-mono text-lg",
        experienceLocation: "text-gray-600 text-sm",
        experienceDate: "text-sm text-green-600 bg-green-100 px-4 py-2 rounded font-mono whitespace-nowrap",
        experienceDescription: "text-gray-700 leading-relaxed text-sm mt-3",
        skillTag: "bg-green-600 text-white px-6 py-3 rounded text-sm font-mono mr-4 mb-4 inline-block",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-6 flex justify-center",
        photo: "w-28 h-28 rounded-lg object-cover border-2 border-green-500 shadow-lg"
      },
      'creative-artistic': {
        container: "bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50 min-h-[1200px] max-w-[8.5in] mx-auto shadow-2xl font-sans",
        wrapper: "relative",
        header: "px-12 py-16 text-center relative overflow-hidden",
        headerContent: "relative z-10",
        name: "text-6xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-6",
        title: "text-2xl text-purple-700 mb-10 font-medium italic",
        contact: "flex flex-wrap justify-center gap-8 text-sm text-gray-700 mt-8",
        contactItem: "flex items-center space-x-2 bg-white/80 rounded-full px-6 py-3 shadow-lg backdrop-blur-sm",
        body: "px-12 py-8",
        sectionHeader: "text-3xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-10 pb-4 border-b-3 border-purple-300 text-center",
        experienceItem: "mb-10 bg-white/90 rounded-3xl p-8 shadow-xl backdrop-blur-sm border border-purple-200",
        experienceHeader: "flex justify-between items-start mb-6",
        experienceTitle: "text-xl font-bold text-purple-800",
        experienceCompany: "text-pink-600 font-semibold text-lg",
        experienceLocation: "text-gray-600 text-sm",
        experienceDate: "text-sm text-purple-600 bg-purple-100 px-6 py-3 rounded-full whitespace-nowrap font-medium",
        experienceDescription: "text-gray-700 leading-relaxed text-sm mt-4",
        skillTag: "bg-gradient-to-r from-pink-500 to-purple-500 text-white px-6 py-3 rounded-full text-sm font-medium mr-4 mb-4 inline-block shadow-xl",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-8 flex justify-center",
        photo: "w-36 h-36 rounded-full object-cover border-6 border-white shadow-2xl"
      },
      'entry-graduate': {
        container: "bg-white min-h-[1200px] max-w-[8.5i n] mx-auto shadow-xl font-sans border-3 border-blue-200",
        wrapper: "relative",
        header: "px-12 py-12 bg-gradient-to-r from-blue-50 to-indigo-50 text-center rounded-t-3xl",
        headerContent: "relative z-10",
        name: "text-4xl font-bold text-gray-900 mb-3",
        title: "text-xl text-blue-600 mb-8 font-medium",
        contact: "flex flex-wrap justify-center gap-6 text-sm text-gray-700 mt-6",
        contactItem: "flex items-center space-x-2 bg-white rounded-full px-5 py-3 shadow-md",
        body: "px-12 py-8",
        sectionHeader: "text-xl font-bold text-blue-600 mb-8 pb-3 border-b-2 border-blue-200 flex items-center",
        sectionIcon: "w-6 h-6 text-blue-600 mr-3 flex items-center justify-center",
        experienceItem: "mb-8 bg-blue-50 rounded-2xl p-8",
        experienceHeader: "flex justify-between items-start mb-4",
        experienceTitle: "text-lg font-semibold text-gray-900",
        experienceCompany: "text-blue-600 font-medium",
        experienceLocation: "text-gray-600 text-sm",
        experienceDate: "text-sm text-blue-600 bg-white px-4 py-2 rounded-full whitespace-nowrap font-medium shadow-sm",
        experienceDescription: "text-gray-700 leading-relaxed text-sm mt-3",
        skillTag: "bg-blue-100 text-blue-700 px-5 py-3 rounded-full text-sm font-medium mr-4 mb-4 inline-block border-2 border-blue-200",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-6 flex justify-center",
        photo: "w-32 h-32 rounded-full object-cover border-4 border-blue-300 shadow-lg"
      },
      'executive-ceo': {
        container: "bg-white min-h-[1200px] max-w-[8.5in] mx-auto shadow-2xl font-serif border-t-12 border-slate-900",
        wrapper: "relative",
        header: "px-20 py-16 text-center border-b-6 border-slate-900 bg-gradient-to-r from-slate-50 to-slate-100",
        headerContent: "relative z-10",
        name: "text-6xl font-bold text-slate-900 mb-6 tracking-wide uppercase",
        title: "text-3xl text-slate-600 mb-10 font-semibold italic",
        contact: "grid grid-cols-2 gap-8 text-base text-slate-700 bg-white p-10 rounded-2xl shadow-xl mt-10",
        contactItem: "flex items-center space-x-4",
        body: "px-20 py-12",
        sectionHeader: "text-3xl font-bold text-slate-900 mb-12 pb-4 border-b-6 border-slate-300 uppercase tracking-widest",
        experienceItem: "mb-16 pb-12 border-b-3 border-slate-200 last:border-b-0",
        experienceHeader: "flex justify-between items-start mb-8",
        experienceTitle: "text-3xl font-bold text-slate-900",
        experienceCompany: "text-slate-700 font-bold text-2xl",
        experienceLocation: "text-slate-500 text-lg",
        experienceDate: "text-base text-slate-600 font-bold bg-slate-100 px-8 py-4 rounded-xl whitespace-nowrap",
        experienceDescription: "text-slate-700 leading-relaxed text-lg mt-6",
        skillTag: "bg-slate-900 text-white px-8 py-4 text-lg font-bold mr-6 mb-6 inline-block uppercase tracking-wide",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-10 flex justify-center",
        photo: "w-44 h-44 rounded-full object-cover border-8 border-slate-300 shadow-2xl"
      },
      'academic-professor': {
        container: "bg-white min-h-[1200px] max-w-[8.5in] mx-auto shadow-xl font-serif border-t-4 border-blue-800",
        wrapper: "relative",
        header: "px-16 py-12 bg-gradient-to-r from-blue-50 to-blue-100 border-b-2 border-blue-800",
        headerContent: "text-left relative z-10",
        name: "text-5xl font-bold text-blue-900 mb-4",
        title: "text-2xl text-blue-700 mb-8 italic",
        contact: "grid grid-cols-2 gap-6 text-sm text-blue-800 bg-white p-8 rounded-xl shadow-lg mt-8",
        contactItem: "flex items-center space-x-3",
        body: "px-16 py-8",
        sectionHeader: "text-2xl font-bold text-blue-900 mb-10 pb-3 border-b-2 border-blue-300 uppercase",
        experienceItem: "mb-12 pb-8 border-b border-blue-100 last:border-b-0",
        experienceHeader: "flex justify-between items-start mb-6",
        experienceTitle: "text-xl font-bold text-blue-900",
        experienceCompany: "text-blue-700 font-semibold text-lg italic",
        experienceLocation: "text-gray-600 text-base",
        experienceDate: "text-base text-blue-700 bg-blue-100 px-6 py-3 rounded whitespace-nowrap",
        experienceDescription: "text-gray-800 leading-relaxed mt-4",
        skillTag: "bg-blue-800 text-white px-6 py-3 text-sm mr-4 mb-4 inline-block",
        skillsGrid: "flex flex-wrap",
        photoContainer: "mb-8 flex justify-start",
        photo: "w-36 h-36 rounded-full object-cover border-4 border-blue-300 shadow-lg"
      }
    };

    return templates[templateId] || templates['modern-minimalist'];
  };

  const currentStyle = getTemplateStyle(selectedTemplate);

  // Check if template should show photo
  const shouldShowPhoto = (templateId: string) => {
    const photoTemplates = [
      'professional-classic',
      'professional-executive', 
      'modern-minimalist',
      'creative-artistic',
      'executive-ceo',
      'academic-professor'
    ];
    return photoTemplates.includes(templateId);
  };

  // Existing render functions remain the same
  const renderExperience = (experience: any[]) => {
    if (!Array.isArray(experience) || experience.length === 0) return null;
    
    return experience.map((exp, index) => {
      if (!exp) return null;
      
      const safeExp = {
        id: exp.id || index,
        jobTitle: exp.jobTitle || '',
        company: exp.company || '',
        location: exp.location || '',
        startDate: exp.startDate || '',
        endDate: exp.endDate || '',
        isCurrentJob: Boolean(exp.isCurrentJob),
        description: exp.description || ''
      };
      
      return (
        <div key={safeExp.id} className={currentStyle.experienceItem}>
          <div className={currentStyle.experienceHeader}>
            <div className="flex-1">
              <h3 className={currentStyle.experienceTitle}>{safeExp.jobTitle}</h3>
              <p className={currentStyle.experienceCompany}>{safeExp.company}</p>
              {safeExp.location && (
                <p className={currentStyle.experienceLocation}>{safeExp.location}</p>
              )}
            </div>
            <span className={currentStyle.experienceDate}>
              {safeExp.startDate} - {safeExp.isCurrentJob ? 'Present' : safeExp.endDate}
            </span>
          </div>
          {safeExp.description && (
            <div className={currentStyle.experienceDescription}>
              {safeExp.description.split('\n').map((line, lineIndex) => (
                <p key={lineIndex} className="mb-2">{line}</p>
              ))}
            </div>
          )}
        </div>
      );
    });
  };

  const renderEducation = (education: any[]) => {
    if (!Array.isArray(education) || education.length === 0) return null;
    
    return education.map((edu, index) => {
      if (!edu) return null;
      
      return (
        <div key={index} className={currentStyle.experienceItem}>
          <div className={currentStyle.experienceHeader}>
            <div className="flex-1">
              <h3 className={currentStyle.experienceTitle}>{edu.degree || ''}</h3>
              <p className={currentStyle.experienceCompany}>{edu.school || ''}</p>
              {edu.location && (
                <p className={currentStyle.experienceLocation}>{edu.location}</p>
              )}
            </div>
            {edu.graduationDate && (
              <span className={currentStyle.experienceDate}>
                {edu.graduationDate}
              </span>
            )}
          </div>
          {edu.description && (
            <div className={currentStyle.experienceDescription}>
              <p>{edu.description}</p>
            </div>
          )}
        </div>
      );
    });
  };

  const renderCertifications = (certifications: any[]) => {
    if (!Array.isArray(certifications) || certifications.length === 0) return null;
    
    return certifications.map((cert, index) => {
      if (!cert) return null;
      
      return (
        <div key={index} className={currentStyle.experienceItem}>
          <div className={currentStyle.experienceHeader}>
            <div className="flex-1">
              <h3 className={currentStyle.experienceTitle}>{cert.name || ''}</h3>
              <p className={currentStyle.experienceCompany}>{cert.issuer || ''}</p>
            </div>
            {cert.date && (
              <span className={currentStyle.experienceDate}>
                {cert.date}
              </span>
            )}
          </div>
        </div>
      );
    });
  };

  const getSectionIcon = (section: string) => {
    const icons = {
      'Work Experience': 'ri-briefcase-line',
      'Education': 'ri-graduation-cap-line',
      'Skills': 'ri-code-s-slash-line',
      'Languages': 'ri-global-line',
      'Certifications': 'ri-award-line',
      'Professional Summary': 'ri-file-text-line',
      'References': 'ri-contacts-line'
    };
    return icons[section] || 'ri-circle-line';
  };

  const renderReferences = () => {
    if (!safeResumeData.references.showReferences) return null;

    return (
      <div className="mb-10">
        <h2 className={currentStyle.sectionHeader}>
          {currentStyle.sectionIcon && <i className={`${getSectionIcon('References')} ${currentStyle.sectionIcon}`}></i>}
          References
        </h2>
        
        {safeResumeData.references.referencesType === 'upon-request' ? (
          <div className="text-center py-8 bg-gray-50 rounded-xl border-2 border-dashed border-gray-300">
            <i className="ri-contacts-line text-4xl text-gray-400 mb-4 flex justify-center"></i>
            <p className="text-gray-600 font-medium text-lg">References available upon request</p>
            <p className="text-gray-500 text-sm mt-2">Professional references will be provided when requested</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {safeResumeData.references.references.map((reference: any, index: number) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 border-l-4 border-blue-500">
                <h3 className="font-bold text-gray-900 text-lg mb-2">
                  {reference.name || 'Reference Name'}
                </h3>
                
                {reference.title && (
                  <p className="text-blue-600 font-semibold mb-1">
                    {reference.title}
                  </p>
                )}
                
                {reference.company && (
                  <p className="text-gray-700 font-medium mb-2">
                    {reference.company}
                  </p>
                )}
                
                {reference.relationship && (
                  <p className="text-gray-600 text-sm mb-3 italic">
                    {reference.relationship}
                  </p>
                )}
                
                <div className="space-y-2">
                  {reference.email && (
                    <div className="flex items-center space-x-2 text-sm text-gray-700">
                      <i className="ri-mail-line text-blue-500"></i>
                      <span>{reference.email}</span>
                    </div>
                  )}
                  
                  {reference.phone && (
                    <div className="flex items-center space-x-2 text-sm text-gray-700">
                      <i className="ri-phone-line text-blue-500"></i>
                      <span>{reference.phone}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={currentStyle.container} style={{ fontSize: '14px', lineHeight: '1.5' }}>
      <div className={currentStyle.wrapper} style={{ position: 'relative' }}>
        {/* Watermark */}
        {showWatermark && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            <div className="text-gray-200 text-6xl font-bold opacity-10 rotate-45 select-none">
              RESUME TEACHER
            </div>
          </div>
        )}

        {/* Header Section */}
        <div className={currentStyle.header}>
          <div className={currentStyle.headerContent}>
            {/* Profile Photo */}
            {shouldShowPhoto(selectedTemplate) && safeResumeData.personalInfo.profilePhoto && (
              <div className={currentStyle.photoContainer}>
                <img
                  src={safeResumeData.personalInfo.profilePhoto}
                  alt="Profile"
                  className={currentStyle.photo}
                />
              </div>
            )}
            
            <h1 className={currentStyle.name}>
              {safeResumeData.personalInfo.firstName} {safeResumeData.personalInfo.lastName}
            </h1>
            <p className={currentStyle.title}>{safeResumeData.personalInfo.jobTitle || safeResumeData.personalInfo.targetRole}</p>
            
            <div className={currentStyle.contact}>
              {safeResumeData.personalInfo.email && (
                <div className={currentStyle.contactItem}>
                  <i className="ri-mail-line"></i>
                  <span>{safeResumeData.personalInfo.email}</span>
                </div>
              )}
              {safeResumeData.personalInfo.phone && (
                <div className={currentStyle.contactItem}>
                  <i className="ri-phone-line"></i>
                  <span>{safeResumeData.personalInfo.phone}</span>
                </div>
              )}
              {(safeResumeData.personalInfo.city || safeResumeData.personalInfo.country) && (
                <div className={currentStyle.contactItem}>
                  <i className="ri-map-pin-line"></i>
                  <span>
                    {safeResumeData.personalInfo.city}{safeResumeData.personalInfo.city && safeResumeData.personalInfo.country && ', '}{safeResumeData.personalInfo.country}
                  </span>
                </div>
              )}
              {safeResumeData.personalInfo.linkedin && (
                <div className={currentStyle.contactItem}>
                  <i className="ri-linkedin-line"></i>
                  <span>LinkedIn Profile</span>
                </div>
              )}
              {safeResumeData.personalInfo.website && (
                <div className={currentStyle.contactItem}>
                  <i className="ri-global-line"></i>
                  <span>{safeResumeData.personalInfo.website}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className={currentStyle.body}>
          {/* Professional Summary */}
          {safeResumeData.summary && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-file-text-line ${currentStyle.sectionIcon}`}></i>}
                Professional Summary
              </h2>
              <p className="text-gray-700 leading-relaxed text-justify">{safeResumeData.summary}</p>
            </div>
          )}

          {/* Work Experience */}
          {safeResumeData.experience.length > 0 && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-briefcase-line ${currentStyle.sectionIcon}`}></i>}
                Work Experience
              </h2>
              <div>
                {safeResumeData.experience.map((exp: any, index: number) => {
                  if (!exp) return null;
                  
                  const safeExp = {
                    id: exp.id || index,
                    jobTitle: exp.jobTitle || '',
                    company: exp.company || '',
                    location: exp.location || '',
                    startDate: exp.startDate || '',
                    endDate: exp.endDate || '',
                    isCurrentJob: Boolean(exp.isCurrentJob),
                    description: exp.description || ''
                  };
                  
                  return (
                    <div key={safeExp.id} className={currentStyle.experienceItem}>
                      <div className={currentStyle.experienceHeader}>
                        <div className="flex-1">
                          <h3 className={currentStyle.experienceTitle}>{safeExp.jobTitle}</h3>
                          <p className={currentStyle.experienceCompany}>{safeExp.company}</p>
                          {safeExp.location && (
                            <p className={currentStyle.experienceLocation}>{safeExp.location}</p>
                          )}
                        </div>
                        <span className={currentStyle.experienceDate}>
                          {safeExp.startDate} - {safeExp.isCurrentJob ? 'Present' : safeExp.endDate}
                        </span>
                      </div>
                      {safeExp.description && (
                        <div className={currentStyle.experienceDescription}>
                          {safeExp.description.split('\n').map((line: string, lineIndex: number) => (
                            <p key={lineIndex} className="mb-2">{line}</p>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Education */}
          {safeResumeData.education.length > 0 && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-graduation-cap-line ${currentStyle.sectionIcon}`}></i>}
                Education
              </h2>
              <div>
                {safeResumeData.education.map((edu: any, index: number) => {
                  if (!edu) return null;
                  
                  return (
                    <div key={index} className={currentStyle.experienceItem}>
                      <div className={currentStyle.experienceHeader}>
                        <div className="flex-1">
                          <h3 className={currentStyle.experienceTitle}>{edu.degree || ''}</h3>
                          <p className={currentStyle.experienceCompany}>{edu.school || ''}</p>
                          {edu.location && (
                            <p className={currentStyle.experienceLocation}>{edu.location}</p>
                          )}
                        </div>
                        {edu.graduationDate && (
                          <span className={currentStyle.experienceDate}>
                            {edu.graduationDate}
                          </span>
                        )}
                      </div>
                      {edu.description && (
                        <div className={currentStyle.experienceDescription}>
                          <p>{edu.description}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Certifications */}
          {safeResumeData.certifications.length > 0 && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-award-line ${currentStyle.sectionIcon}`}></i>}
                Certifications
              </h2>
              <div>
                {safeResumeData.certifications.map((cert: any, index: number) => {
                  if (!cert) return null;
                  
                  return (
                    <div key={index} className={currentStyle.experienceItem}>
                      <div className={currentStyle.experienceHeader}>
                        <div className="flex-1">
                          <h3 className={currentStyle.experienceTitle}>{cert.name || ''}</h3>
                          <p className={currentStyle.experienceCompany}>{cert.issuer || ''}</p>
                        </div>
                        {cert.date && (
                          <span className={currentStyle.experienceDate}>
                            {cert.date}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Skills */}
          {safeResumeData.skills.length > 0 && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-code-s-slash-line ${currentStyle.sectionIcon}`}></i>}
                Skills
              </h2>
              <div className={currentStyle.skillsGrid}>
                {safeResumeData.skills.map((skill: any, index: number) => (
                  <span
                    key={index}
                    className={currentStyle.skillTag}
                  >
                    {typeof skill === 'string' ? skill : skill?.name || ''}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Languages */}
          {safeResumeData.languages.length > 0 && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-global-line ${currentStyle.sectionIcon}`}></i>}
                Languages
              </h2>
              <div>
                {safeResumeData.languages.map((language: any, index: number) => (
                  <div key={index} className="flex justify-between items-center bg-blue-50 rounded-xl p-5 mb-4 border-l-4 border-blue-500">
                    <span className="font-semibold text-gray-900 text-lg">
                      {language?.language || ''}
                    </span>
                    <span className="text-sm text-blue-600 bg-white px-4 py-2 rounded-full font-semibold">
                      {language?.proficiency || ''}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* References */}
          {safeResumeData.references.showReferences && (
            <div className="mb-10">
              <h2 className={currentStyle.sectionHeader}>
                {currentStyle.sectionIcon && <i className={`ri-contacts-line ${currentStyle.sectionIcon}`}></i>}
                References
              </h2>
              
              {safeResumeData.references.referencesType === 'upon-request' ? (
                <div className="text-center py-8 bg-gray-50 rounded-xl border-2 border-dashed border-gray-300">
                  <i className="ri-contacts-line text-4xl text-gray-400 mb-4 flex justify-center"></i>
                  <p className="text-gray-600 font-medium text-lg">References available upon request</p>
                  <p className="text-gray-500 text-sm mt-2">Professional references will be provided when requested</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {safeResumeData.references.references.map((reference: any, index: number) => (
                    <div key={index} className="bg-gray-50 rounded-xl p-6 border-l-4 border-blue-500">
                      <h3 className="font-bold text-gray-900 text-lg mb-2">
                        {reference.name || 'Reference Name'}
                      </h3>
                      
                      {reference.title && (
                        <p className="text-blue-600 font-semibold mb-1">
                          {reference.title}
                        </p>
                      )}
                      
                      {reference.company && (
                        <p className="text-gray-700 font-medium mb-2">
                          {reference.company}
                        </p>
                      )}
                      
                      {reference.relationship && (
                        <p className="text-gray-600 text-sm mb-3 italic">
                          {reference.relationship}
                        </p>
                      )}
                      
                      <div className="space-y-2">
                        {reference.email && (
                          <div className="flex items-center space-x-2 text-sm text-gray-700">
                            <i className="ri-mail-line text-blue-500"></i>
                            <span>{reference.email}</span>
                          </div>
                        )}
                        
                        {reference.phone && (
                          <div className="flex items-center space-x-2 text-sm text-gray-700">
                            <i className="ri-phone-line text-blue-500"></i>
                            <span>{reference.phone}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Template Footer */}
          <div className="mt-16 pt-8 border-t border-gray-200 text-center">
            <div className="inline-flex items-center space-x-2 text-gray-400 text-sm">
              <i className="ri-award-line"></i>
              <span className="font-medium">Created with Resume Teacher</span>
              <span className="mx-2">•</span>
              <span className="capitalize">{selectedTemplate?.replace(/-/g, ' ')} Template</span>
              <i className="ri-shield-check-line"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
