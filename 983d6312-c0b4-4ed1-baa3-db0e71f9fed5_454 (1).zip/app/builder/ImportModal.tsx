'use client';

import { useState } from 'react';
import Link from 'next/link';

interface ImportModalProps {
  onClose: () => void;
  onImportComplete: (data: any) => void;
}

export default function ImportModal({ onClose, onImportComplete }: ImportModalProps) {
  const [importMethod, setImportMethod] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [extractionError, setExtractionError] = useState('');

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (file: File) => {
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    
    if (!allowedTypes.includes(file.type)) {
      alert('Please upload a PDF, Word document, or text file');
      return;
    }

    setSelectedFile(file);
    setExtractionError('');
    await extractResumeData(file);
  };

  const extractResumeData = async (file: File) => {
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Simulate progress during upload
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + Math.random() * 20;
        });
      }, 200);

      // Call the AI extraction function
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/extract-resume-data`, {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`,
        },
      });

      clearInterval(progressInterval);
      
      if (!response.ok) {
        throw new Error('Failed to extract resume data');
      }

      const result = await response.json();
      
      if (result.success) {
        setUploadProgress(100);
        setUploadComplete(true);
        
        // Auto-complete import after 1 second to show success
        setTimeout(() => {
          onImportComplete(result.data);
        }, 1000);
      } else {
        throw new Error(result.error || 'Extraction failed');
      }
      
    } catch (error) {
      console.error('Extraction error:', error);
      setExtractionError('Failed to extract resume data. Please try again.');
      setUploadProgress(0);
    } finally {
      setIsUploading(false);
    }
  };

  const handleLinkedInImport = () => {
    if (!linkedinUrl.includes('linkedin.com')) {
      alert('Please enter a valid LinkedIn profile URL');
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          setUploadComplete(true);
          // Simulate LinkedIn data extraction
          setTimeout(() => {
            const mockLinkedInData = {
              personalInfo: {
                fullName: 'Sarah Johnson',
                email: 'sarah.johnson@email.com',
                phone: '+1 (555) 987-6543',
                location: 'San Francisco, CA',
                linkedin: linkedinUrl,
                website: 'sarahjohnson.portfolio.com'
              },
              summary: 'Digital marketing specialist with expertise in social media strategy, content creation, and data analytics. Proven track record of increasing brand engagement by 200%.',
              experience: [
                {
                  position: 'Digital Marketing Manager',
                  company: 'Growth Marketing Agency',
                  duration: '2021 - Present',
                  description: 'Managed social media campaigns for 15+ clients, resulting in average 150% increase in engagement. Developed content strategies that boosted brand awareness.'
                }
              ],
              education: [
                {
                  degree: 'Master of Business Administration',
                  school: 'Business School',
                  year: '2021'
                }
              ],
              skills: ['Digital Marketing', 'Social Media Strategy', 'Google Analytics', 'Content Creation', 'SEO', 'Email Marketing']
            };
            onImportComplete(mockLinkedInData);
          }, 1000);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/95 backdrop-blur-lg rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/20">
        <div className="sticky top-0 bg-white/90 backdrop-blur-lg border-b border-gray-200/50 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <i className="ri-import-line text-white text-lg"></i>
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Import Your Data</h2>
                <p className="text-sm text-gray-600">AI will automatically extract and organize your information</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-700 transition-colors"
            >
              <i className="ri-close-line text-lg"></i>
            </button>
          </div>
        </div>

        <div className="p-6">
          {!uploadComplete ? (
            <div className="space-y-6">
              {/* Import Method Selection */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">Choose Import Method</h3>
                
                <div className="grid gap-4">
                  <label className="flex items-start p-4 border-2 rounded-xl cursor-pointer hover:bg-blue-50/50 transition-colors group">
                    <input
                      type="radio"
                      name="importMethod"
                      value="file"
                      checked={importMethod === 'file'}
                      onChange={(e) => setImportMethod(e.target.value)}
                      className="mt-1 mr-4"
                    />
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <i className="ri-file-upload-line text-blue-600 text-xl mr-2"></i>
                        <span className="font-semibold text-gray-900">Upload Resume File</span>
                      </div>
                      <p className="text-sm text-gray-600">Upload your existing resume and let AI extract all information automatically</p>
                      <div className="mt-2 flex items-center space-x-4 text-xs">
                        <span className="flex items-center text-green-600">
                          <i className="ri-check-line mr-1"></i>
                          Auto data extraction
                        </span>
                        <span className="flex items-center text-green-600">
                          <i className="ri-check-line mr-1"></i>
                          Editable fields
                        </span>
                      </div>
                    </div>
                  </label>

                  <label className="flex items-start p-4 border-2 rounded-xl cursor-pointer hover:bg-blue-50/50 transition-colors group">
                    <input
                      type="radio"
                      name="importMethod"
                      value="linkedin"
                      checked={importMethod === 'linkedin'}
                      onChange={(e) => setImportMethod(e.target.value)}
                      className="mt-1 mr-4"
                    />
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <i className="ri-linkedin-fill text-blue-600 text-xl mr-2"></i>
                        <span className="font-semibold text-gray-900">Import from LinkedIn</span>
                      </div>
                      <p className="text-sm text-gray-600">Connect your LinkedIn profile to automatically import your professional information</p>
                      <div className="mt-2 flex items-center space-x-4 text-xs">
                        <span className="flex items-center text-green-600">
                          <i className="ri-check-line mr-1"></i>
                          Professional experience
                        </span>
                        <span className="flex items-center text-green-600">
                          <i className="ri-check-line mr-1"></i>
                          Skills & endorsements
                        </span>
                      </div>
                    </div>
                  </label>

                  <label className="flex items-start p-4 border-2 rounded-xl cursor-pointer hover:bg-blue-50/50 transition-colors group">
                    <input
                      type="radio"
                      name="importMethod"
                      value="manual"
                      checked={importMethod === 'manual'}
                      onChange={(e) => setImportMethod(e.target.value)}
                      className="mt-1 mr-4"
                    />
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <i className="ri-edit-line text-blue-600 text-xl mr-2"></i>
                        <span className="font-semibold text-gray-900">Start Fresh</span>
                      </div>
                      <p className="text-sm text-gray-600">Begin with a blank template and fill in your information manually</p>
                      <div className="mt-2 flex items-center space-x-4 text-xs">
                        <span className="flex items-center text-green-600">
                          <i className="ri-check-line mr-1"></i>
                          Full control
                        </span>
                        <span className="flex items-center text-green-600">
                          <i className="ri-check-line mr-1"></i>
                          AI writing assistance
                        </span>
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* File Upload Section */}
              {importMethod === 'file' && (
                <div className="space-y-4">
                  <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
                      dragActive 
                        ? 'border-blue-500 bg-blue-50/50 scale-[1.02]' 
                        : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50/30'
                    }`}
                  >
                    <div className="space-y-4">
                      <div className="flex justify-center">
                        <div className={`w-16 h-16 rounded-xl flex items-center justify-center transition-all duration-300 ${
                          dragActive 
                            ? 'bg-gradient-to-r from-blue-500 to-indigo-600 scale-110' 
                            : 'bg-gradient-to-r from-gray-400 to-gray-500 hover:from-blue-500 hover:to-indigo-600'
                        }`}>
                          <i className={`text-white text-2xl transition-transform duration-300 ${
                            dragActive ? 'ri-download-cloud-line animate-bounce' : 'ri-upload-cloud-line'
                          }`}></i>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">
                          {dragActive ? 'Drop your resume here!' : 'Upload Your Resume'}
                        </h4>
                        <p className="text-sm text-gray-600 mb-4">
                          AI will automatically extract your information into editable fields
                        </p>
                        
                        <input
                          type="file"
                          id="fileInput"
                          className="hidden"
                          accept=".pdf,.doc,.docx,.txt"
                          onChange={handleFileInput}
                        />
                        
                        <label
                          htmlFor="fileInput"
                          className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-blue-200/50 hover:-translate-y-0.5 whitespace-nowrap"
                        >
                          <i className="ri-folder-open-line mr-2"></i>
                          Choose File
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <i className="ri-file-pdf-line text-red-500"></i>
                          <span>PDF</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <i className="ri-file-word-line text-blue-500"></i>
                          <span>DOC/DOCX</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <i className="ri-file-text-line text-gray-500"></i>
                          <span>TXT</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Upload Progress */}
                  {isUploading && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <i className="ri-file-text-line text-blue-600"></i>
                          <span className="text-sm font-medium text-gray-900">{selectedFile?.name}</span>
                        </div>
                        <span className="text-sm text-blue-600 font-semibold">{Math.round(uploadProgress)}%</span>
                      </div>
                      
                      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-300 ease-out"
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      
                      <div className="flex items-center justify-center space-x-2 text-blue-600 text-sm">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></div>
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-100"></div>
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-200"></div>
                        <span className="ml-2 font-medium">AI is extracting your data...</span>
                      </div>
                    </div>
                  )}

                  {/* Error Display */}
                  {extractionError && (
                    <div className="p-4 bg-red-50/80 backdrop-blur-sm border border-red-200/50 rounded-xl">
                      <div className="flex items-start space-x-3">
                        <i className="ri-error-warning-line text-red-500 text-xl flex-shrink-0 mt-0.5"></i>
                        <div>
                          <h4 className="font-semibold text-red-800 mb-1">Extraction Failed</h4>
                          <p className="text-red-700 text-sm">{extractionError}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* LinkedIn Import Section */}
              {importMethod === 'linkedin' && (
                <div className="space-y-4">
                  <div className="p-6 bg-gradient-to-r from-blue-50/80 to-indigo-50/80 backdrop-blur-sm border border-blue-200/50 rounded-xl">
                    <div className="flex items-start space-x-3">
                      <i className="ri-linkedin-fill text-blue-600 text-2xl flex-shrink-0 mt-1"></i>
                      <div className="space-y-4 flex-1">
                        <div>
                          <h4 className="font-semibold text-blue-900 mb-2">Import from LinkedIn Profile</h4>
                          <p className="text-sm text-blue-800 mb-4">
                            Paste your LinkedIn profile URL to automatically extract your professional information
                          </p>
                        </div>
                        
                        <div className="space-y-3">
                          <label className="block text-sm font-medium text-blue-900">
                            LinkedIn Profile URL
                          </label>
                          <input
                            type="url"
                            value={linkedinUrl}
                            onChange={(e) => setLinkedinUrl(e.target.value)}
                            placeholder="https://www.linkedin.com/in/your-profile"
                            className="w-full px-4 py-3 border border-blue-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white/80 backdrop-blur-sm text-sm"
                          />
                          
                          <button
                            onClick={handleLinkedInImport}
                            disabled={!linkedinUrl || isUploading}
                            className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed shadow-lg hover:shadow-blue-200/50 hover:-translate-y-0.5 whitespace-nowrap"
                          >
                            {isUploading ? (
                              <span className="flex items-center justify-center">
                                <i className="ri-loader-4-line animate-spin mr-2"></i>
                                Importing...
                              </span>
                            ) : (
                              <span className="flex items-center justify-center">
                                <i className="ri-import-line mr-2"></i>
                                Import from LinkedIn
                              </span>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* LinkedIn Progress */}
                  {isUploading && (
                    <div className="space-y-3">
                      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-300 ease-out"
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      
                      <div className="flex items-center justify-center space-x-2 text-blue-600 text-sm">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></div>
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-100"></div>
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-200"></div>
                        <span className="ml-2 font-medium">Extracting LinkedIn data...</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Manual Entry Section */}
              {importMethod === 'manual' && (
                <div className="p-6 bg-gradient-to-r from-emerald-50/80 to-green-50/80 backdrop-blur-sm border border-emerald-200/50 rounded-xl">
                  <div className="flex items-start space-x-3">
                    <i className="ri-edit-line text-emerald-600 text-2xl flex-shrink-0 mt-1"></i>
                    <div>
                      <h4 className="font-semibold text-emerald-900 mb-2">Start with a Clean Slate</h4>
                      <p className="text-sm text-emerald-800 mb-4">
                        Begin building your resume from scratch with our intuitive form and AI writing assistance
                      </p>
                      <button
                        onClick={() => {
                          onImportComplete({
                            personalInfo: { fullName: '', email: '', phone: '', location: '', linkedin: '', website: '' },
                            summary: '',
                            experience: [],
                            education: [],
                            skills: []
                          });
                        }}
                        className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-lg hover:from-emerald-700 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-emerald-200/50 hover:-translate-y-0.5 whitespace-nowrap"
                      >
                        <i className="ri-add-line mr-2"></i>
                        Start Building
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Alternative Actions */}
              <div className="pt-4 border-t border-gray-200/50">
                <p className="text-sm text-gray-600 mb-4">Need more comprehensive import options?</p>
                <Link 
                  href="/import"
                  className="inline-flex items-center px-4 py-2 text-blue-600 hover:text-blue-700 transition-colors text-sm font-medium"
                >
                  <i className="ri-external-link-line mr-2"></i>
                  Visit Full Import Page
                </Link>
              </div>
            </div>
          ) : (
            /* Import Success */
            <div className="text-center space-y-6 py-8">
              <div className="flex justify-center">
                <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-green-600 rounded-2xl flex items-center justify-center animate-pulse">
                  <i className="ri-check-line text-white text-3xl"></i>
                </div>
              </div>
              
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Data Extracted Successfully!</h3>
                <p className="text-gray-600 mb-6">
                  Your information has been automatically extracted and will be populated in the form fields where you can edit and enhance it.
                </p>
              </div>
              
              <div className="bg-green-50/80 backdrop-blur-sm border border-green-200/50 rounded-xl p-4">
                <div className="flex items-center justify-center space-x-2 text-green-700 text-sm">
                  <i className="ri-magic-line"></i>
                  <span>All fields are now editable and ready for your enhancements</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}