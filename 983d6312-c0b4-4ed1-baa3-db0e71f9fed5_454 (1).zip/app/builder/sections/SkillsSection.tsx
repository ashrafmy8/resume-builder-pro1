'use client';

import { useState } from 'react';
import AIAssistant from '../../../components/AIAssistant';

export default function SkillsSection({ resumeData, setResumeData }) {
  const [skills, setSkills] = useState(resumeData.skills || []);
  const [newSkill, setNewSkill] = useState('');
  const [skillLevel, setSkillLevel] = useState('Intermediate');
  const [jobRole, setJobRole] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [targetRole, setTargetRole] = useState('');

  const skillLevels = [
    { value: 'Beginner', color: 'bg-red-500', label: 'Beginner' },
    { value: 'Intermediate', color: 'bg-yellow-500', label: 'Intermediate' },
    { value: 'Advanced', color: 'bg-green-500', label: 'Advanced' },
    { value: 'Expert', color: 'bg-blue-500', label: 'Expert' }
  ];

  const commonSkills = {
    'Technical Skills': [
      'JavaScript', 'Python', 'Java', 'React', 'Node.js', 'SQL', 'HTML/CSS', 
      'Git', 'Docker', 'AWS', 'MongoDB', 'TypeScript', 'Vue.js', 'Angular'
    ],
    'Soft Skills': [
      'Communication', 'Leadership', 'Problem Solving', 'Teamwork', 'Time Management',
      'Critical Thinking', 'Adaptability', 'Creativity', 'Public Speaking', 'Negotiation'
    ],
    'Languages': [
      'English', 'Spanish', 'French', 'German', 'Chinese', 'Japanese', 'Portuguese', 'Italian'
    ]
  };

  const addSkill = (skillName = newSkill, level = skillLevel) => {
    if (skillName.trim()) {
      const updated = [...skills, { name: skillName, level: level }];
      setSkills(updated);
      setResumeData(prev => ({ ...prev, skills: updated }));
      setNewSkill('');
    }
  };

  const removeSkill = (index) => {
    const updated = skills.filter((_, i) => i !== index);
    setSkills(updated);
    setResumeData(prev => ({ ...prev, skills: updated }));
  };

  const updateSkillLevel = (index, newLevel) => {
    const updated = [...skills];
    updated[index].level = newLevel;
    setSkills(updated);
    setResumeData(prev => ({ ...prev, skills: updated }));
  };

  const getSkillColor = (level) => {
    const skillLevel = skillLevels.find(s => s.value === level);
    return skillLevel ? skillLevel.color : 'bg-gray-500';
  };

  const getLevelWidth = (level) => {
    switch (level) {
      case 'Beginner': return 'w-1/4';
      case 'Intermediate': return 'w-2/4';
      case 'Advanced': return 'w-3/4';
      case 'Expert': return 'w-full';
      default: return 'w-2/4';
    }
  };

  const generateAISkills = async () => {
    if (!targetRole.trim()) return;
    
    setIsGenerating(true);
    
    const skillSuggestions = {
      'Software Engineer': [
        { name: 'JavaScript', level: 'Advanced' },
        { name: 'React', level: 'Advanced' },
        { name: 'Node.js', level: 'Intermediate' },
        { name: 'Python', level: 'Intermediate' },
        { name: 'SQL', level: 'Advanced' },
        { name: 'Git', level: 'Advanced' },
        { name: 'Problem Solving', level: 'Expert' },
        { name: 'Team Collaboration', level: 'Advanced' }
      ],
      'Marketing Manager': [
        { name: 'Digital Marketing', level: 'Expert' },
        { name: 'Google Analytics', level: 'Advanced' },
        { name: 'SEO/SEM', level: 'Advanced' },
        { name: 'Content Strategy', level: 'Advanced' },
        { name: 'Social Media Marketing', level: 'Expert' },
        { name: 'Leadership', level: 'Advanced' },
        { name: 'Data Analysis', level: 'Intermediate' },
        { name: 'Project Management', level: 'Advanced' }
      ],
      'Data Analyst': [
        { name: 'Python', level: 'Advanced' },
        { name: 'SQL', level: 'Expert' },
        { name: 'Tableau', level: 'Advanced' },
        { name: 'Excel', level: 'Expert' },
        { name: 'R', level: 'Intermediate' },
        { name: 'Statistical Analysis', level: 'Advanced' },
        { name: 'Data Visualization', level: 'Advanced' },
        { name: 'Critical Thinking', level: 'Expert' }
      ],
      'UX Designer': [
        { name: 'Figma', level: 'Advanced' },
        { name: 'User Research', level: 'Advanced' },
        { name: 'Wireframing', level: 'Expert' },
        { name: 'Prototyping', level: 'Advanced' },
        { name: 'Adobe Creative Suite', level: 'Advanced' },
        { name: 'Usability Testing', level: 'Advanced' },
        { name: 'Design Systems', level: 'Intermediate' },
        { name: 'Collaboration', level: 'Expert' }
      ],
      'DevOps Engineer': [
        { name: 'Docker', level: 'Advanced' },
        { name: 'Kubernetes', level: 'Advanced' },
        { name: 'AWS', level: 'Advanced' },
        { name: 'CI/CD', level: 'Expert' },
        { name: 'Linux', level: 'Advanced' },
        { name: 'Terraform', level: 'Intermediate' },
        { name: 'Monitoring', level: 'Advanced' },
        { name: 'Problem Solving', level: 'Expert' }
      ]
    };

    // Smart matching - find closest role match
    const roleKey = Object.keys(skillSuggestions).find(role => 
      targetRole.toLowerCase().includes(role.toLowerCase().split(' ')[0]) ||
      role.toLowerCase().includes(targetRole.toLowerCase().split(' ')[0])
    );

    setTimeout(() => {
      const suggestions = skillSuggestions[roleKey] || skillSuggestions[targetRole] || [
        { name: 'Communication', level: 'Advanced' },
        { name: 'Leadership', level: 'Intermediate' },
        { name: 'Problem Solving', level: 'Advanced' },
        { name: 'Time Management', level: 'Advanced' },
        { name: 'Teamwork', level: 'Advanced' },
        { name: 'Critical Thinking', level: 'Advanced' },
        { name: 'Adaptability', level: 'Intermediate' },
        { name: 'Project Management', level: 'Intermediate' }
      ];
      
      setAiSuggestions(suggestions);
      setIsGenerating(false);
    }, 1500);
  };

  const addAISuggestion = (suggestion) => {
    if (!skills.some(s => s.name.toLowerCase() === suggestion.name.toLowerCase())) {
      const updated = [...skills, suggestion];
      setSkills(updated);
      setResumeData(prev => ({ ...prev, skills: updated }));
    }
  };

  const handleAISuggestion = (suggestion) => {
    setNewSkill(suggestion);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 lg:p-10">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3">Skills & Expertise</h2>
          <p className="text-lg text-gray-600 leading-relaxed">
            Add your technical skills, soft skills, and languages. Include your proficiency level for each.
          </p>
        </div>
        <AIAssistant 
          section="skills" 
          context={resumeData} 
          onSuggestion={handleAISuggestion}
        />
      </div>

      {/* AI Skills Generator */}
      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-100 mb-8">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mr-4">
            <i className="ri-brain-line text-2xl text-purple-600"></i>
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">AI Skills Recommendation</h3>
            <p className="text-gray-600">Get personalized skill suggestions based on your target role</p>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Target Job Role</label>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              placeholder="Type your target role (e.g., Software Engineer, Marketing Manager)"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors bg-white"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={generateAISkills}
              disabled={!targetRole.trim() || isGenerating}
              className="w-full px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                  Generating...
                </>
              ) : (
                <>
                  <i className="ri-magic-line mr-2"></i>
                  Generate Skills
                </>
              )}
            </button>
          </div>
        </div>

        {aiSuggestions.length > 0 && (
          <div>
            <h4 className="text-md font-bold text-gray-900 mb-3">AI Recommended Skills</h4>
            <div className="grid md:grid-cols-2 gap-3">
              {aiSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => addAISuggestion(suggestion)}
                  disabled={skills.some(s => s.name.toLowerCase() === suggestion.name.toLowerCase())}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${
                    skills.some(s => s.name.toLowerCase() === suggestion.name.toLowerCase())
                      ? 'bg-green-50 border-green-200 text-green-700 cursor-not-allowed'
                      : 'bg-white border-purple-200 hover:border-purple-400 hover:bg-purple-50'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{suggestion.name}</span>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      skills.some(s => s.name.toLowerCase() === suggestion.name.toLowerCase())
                        ? 'bg-green-100 text-green-700'
                        : 'bg-purple-100 text-purple-700'
                    }`}>
                      {suggestion.level}
                    </span>
                  </div>
                  {skills.some(s => s.name.toLowerCase() === suggestion.name.toLowerCase()) && (
                    <div className="flex items-center mt-1 text-sm text-green-600">
                      <i className="ri-check-line mr-1"></i>
                      Already added
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Current Skills */}
      {skills.length > 0 && (
        <div className="mb-8">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Your Skills</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {skills.map((skill, index) => (
              <div key={index} className="bg-gradient-to-r from-red-50 to-orange-50 rounded-2xl p-6 border border-red-100">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <h4 className="text-lg font-bold text-gray-900 mb-2">{skill.name}</h4>
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-semibold text-gray-600">{skill.level}</span>
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div className={`${getSkillColor(skill.level)} h-2 rounded-full ${getLevelWidth(skill.level)} transition-all duration-300`}></div>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => removeSkill(index)}
                    className="w-8 h-8 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors flex items-center justify-center ml-4"
                  >
                    <i className="ri-close-line text-sm"></i>
                  </button>
                </div>
                <div className="flex space-x-2">
                  {skillLevels.map((level) => (
                    <button
                      key={level.value}
                      onClick={() => updateSkillLevel(index, level.value)}
                      className={`px-3 py-1 text-xs font-semibold rounded-full transition-colors ${
                        skill.level === level.value
                          ? `${level.color} text-white`
                          : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                      }`}
                    >
                      {level.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add New Skill */}
      <div className="bg-gray-50 rounded-2xl p-8 border border-gray-200 mb-8">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Add New Skill</h3>
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-gray-900 mb-3">
                Skill Name
              </label>
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-red-500 focus:ring-0 transition-colors"
                placeholder="Enter skill name"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-900 mb-3">
                Proficiency Level
              </label>
              <select
                value={skillLevel}
                onChange={(e) => setSkillLevel(e.target.value)}
                className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-red-500 focus:ring-0 transition-colors bg-white"
              >
                {skillLevels.map((level) => (
                  <option key={level.value} value={level.value}>{level.label}</option>
                ))}
              </select>
            </div>
          </div>
          <button
            onClick={() => addSkill()}
            disabled={!newSkill.trim()}
            className="px-8 py-4 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            <i className="ri-add-line mr-2"></i>
            Add Skill
          </button>
        </div>
      </div>

      {/* Quick Add Skills */}
      <div className="space-y-8">
        {Object.entries(commonSkills).map(([category, skillList]) => (
          <div key={category}>
            <h3 className="text-xl font-bold text-gray-900 mb-4">{category}</h3>
            <div className="flex flex-wrap gap-3">
              {skillList.map((skill) => (
                <button
                  key={skill}
                  onClick={() => addSkill(skill, 'Intermediate')}
                  disabled={skills.some(s => s.name.toLowerCase() === skill.toLowerCase())}
                  className={`px-4 py-2 rounded-xl font-medium transition-all ${
                    skills.some(s => s.name.toLowerCase() === skill.toLowerCase())
                      ? 'bg-green-100 text-green-700 cursor-not-allowed'
                      : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-red-300 hover:bg-red-50'
                  }`}
                >
                  {skills.some(s => s.name.toLowerCase() === skill.toLowerCase()) ? (
                    <>
                      <i className="ri-check-line mr-1"></i>
                      {skill}
                    </>
                  ) : (
                    <>
                      <i className="ri-add-line mr-1"></i>
                      {skill}
                    </>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Enhanced Tips Panel with AI Insights */}
      <div className="mt-10 bg-gradient-to-r from-red-50 to-orange-50 rounded-2xl p-6 border border-red-100">
        <div className="flex items-start">
          <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0 mr-4">
            <i className="ri-lightbulb-line text-lg text-red-600"></i>
          </div>
          <div>
            <h4 className="text-lg font-bold text-red-900 mb-3">🛠️ AI-Enhanced Skills Tips</h4>
            <ul className="space-y-2 text-red-800">
              <li className="flex items-start">
                <i className="ri-check-line text-red-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Use AI to discover in-demand skills for your target role</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-red-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Balance technical skills with soft skills (aim for 60/40 ratio)</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-red-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Be honest about proficiency levels - employers often test them</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-red-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Include emerging technologies relevant to your field</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-red-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Consider adding certifications as separate skills</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
