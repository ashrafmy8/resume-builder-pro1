'use client';

import { useState } from 'react';

interface Language {
  language: string;
  proficiency: string;
}

interface LanguagesSectionProps {
  languages: Language[];
  onChange: (languages: Language[]) => void;
}

export default function LanguagesSection({ languages, onChange }: LanguagesSectionProps) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>({
    language: '',
    proficiency: 'Native'
  });

  const proficiencyLevels = [
    'Native',
    'Fluent',
    'Proficient',
    'Intermediate',
    'Basic'
  ];

  const addLanguage = () => {
    if (currentLanguage.language.trim()) {
      onChange([...languages, currentLanguage]);
      setCurrentLanguage({ language: '', proficiency: 'Native' });
    }
  };

  const removeLanguage = (index: number) => {
    onChange(languages.filter((_, i) => i !== index));
  };

  const updateLanguage = (index: number, field: keyof Language, value: string) => {
    const updated = languages.map((lang, i) => 
      i === index ? { ...lang, [field]: value } : lang
    );
    onChange(updated);
  };

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-800">Languages</h3>
      
      {/* Add Language Form */}
      <div className="bg-gray-50 p-4 rounded-lg space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Language
            </label>
            <input
              type="text"
              value={currentLanguage.language}
              onChange={(e) => setCurrentLanguage({ ...currentLanguage, language: e.target.value })}
              placeholder="e.g. English, Spanish, French"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proficiency Level
            </label>
            <select
              value={currentLanguage.proficiency}
              onChange={(e) => setCurrentLanguage({ ...currentLanguage, proficiency: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm pr-8"
            >
              {proficiencyLevels.map(level => (
                <option key={level} value={level}>{level}</option>
              ))}
            </select>
          </div>
        </div>
        
        <button
          type="button"
          onClick={addLanguage}
          className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium whitespace-nowrap"
        >
          Add Language
        </button>
      </div>

      {/* Languages List */}
      {languages.length > 0 && (
        <div className="space-y-3">
          {languages.map((language, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Language
                    </label>
                    <input
                      type="text"
                      value={language.language}
                      onChange={(e) => updateLanguage(index, 'language', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Proficiency Level
                    </label>
                    <select
                      value={language.proficiency}
                      onChange={(e) => updateLanguage(index, 'proficiency', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent text-sm pr-8"
                    >
                      {proficiencyLevels.map(level => (
                        <option key={level} value={level}>{level}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <button
                  type="button"
                  onClick={() => removeLanguage(index)}
                  className="ml-4 text-red-600 hover:text-red-800 transition-colors cursor-pointer"
                  title="Remove Language"
                >
                  <i className="ri-delete-bin-line text-lg w-5 h-5 flex items-center justify-center"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}