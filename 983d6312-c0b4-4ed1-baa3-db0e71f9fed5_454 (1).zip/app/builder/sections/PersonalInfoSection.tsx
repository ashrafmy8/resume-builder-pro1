
'use client';

import { useState, useRef } from 'react';

interface PersonalInfoSectionProps {
  resumeData: any;
  setResumeData: (data: any) => void;
  onAiSuggestion?: (suggestion: string) => void;
  selectedTemplate?: string;
}

export default function PersonalInfoSection({ resumeData, setResumeData, selectedTemplate }: PersonalInfoSectionProps) {
  const data = resumeData.personalInfo || {};
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [photoUploading, setPhotoUploading] = useState(false);
  
  const handleChange = (field: string, value: string) => {
    setResumeData({
      ...resumeData,
      personalInfo: {
        ...resumeData.personalInfo,
        [field]: value
      }
    });
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Photo size should be less than 5MB');
        return;
      }

      if (!file.type.startsWith('image/')) {
        alert('Please select a valid image file');
        return;
      }

      setPhotoUploading(true);
      const reader = new FileReader();
      reader.onload = (e) => {
        const photoUrl = e.target?.result as string;
        handleChange('profilePhoto', photoUrl);
        setPhotoUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    handleChange('profilePhoto', '');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const isFieldFilled = (value: string) => value && value.trim().length > 0;

  // Check if the selected template typically uses photos
  const templateUsesPhoto = (templateId: string) => {
    const photoTemplates = [
      'professional-classic',
      'professional-executive', 
      'modern-minimalist',
      'creative-artistic',
      'executive-ceo',
      'academic-professor'
    ];
    return photoTemplates.includes(templateId || 'modern-minimalist');
  };

  const shouldShowPhoto = templateUsesPhoto(selectedTemplate || 'modern-minimalist');

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
        <i className="ri-user-line text-purple-600 mr-3"></i>
        Personal Information
      </h2>

      {/* Photo Upload Section - Show only for templates that use photos */}
      {shouldShowPhoto && (
        <div className="mb-8 p-6 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border-2 border-purple-100">
          <label className="block text-gray-700 font-medium mb-4 flex items-center">
            <i className="ri-camera-line text-purple-600 mr-2"></i>
            Profile Photo (Optional)
          </label>
          
          <div className="flex items-center space-x-6">
            {data.profilePhoto ? (
              <div className="relative">
                <img
                  src={data.profilePhoto}
                  alt="Profile"
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
                <button
                  onClick={removePhoto}
                  className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
                >
                  <i className="ri-close-line text-sm"></i>
                </button>
              </div>
            ) : (
              <div className="w-24 h-24 border-2 border-dashed border-purple-300 rounded-full flex items-center justify-center bg-purple-50">
                <i className="ri-user-line text-purple-400 text-2xl"></i>
              </div>
            )}
            
            <div className="flex-1">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={photoUploading}
                className="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
              >
                {photoUploading ? (
                  <span className="flex items-center">
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Uploading...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <i className="ri-upload-2-line mr-2"></i>
                    {data.profilePhoto ? 'Change Photo' : 'Upload Photo'}
                  </span>
                )}
              </button>
              
              <p className="text-sm text-gray-600 mt-2">
                Recommended: Square image, max 5MB (JPG, PNG, GIF)
              </p>
              
              {selectedTemplate && (
                <div className="mt-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full inline-block">
                  Photo recommended for {selectedTemplate.replace(/-/g, ' ')} template
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-gray-700 font-medium mb-2">First Name</label>
          <div className="relative">
            <input
              type="text"
              value={data.firstName || ''}
              onChange={(e) => handleChange('firstName', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="Enter your first name"
            />
            {isFieldFilled(data.firstName) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Last Name</label>
          <div className="relative">
            <input
              type="text"
              value={data.lastName || ''}
              onChange={(e) => handleChange('lastName', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="Enter your last name"
            />
            {isFieldFilled(data.lastName) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div className="md:col-span-2 relative">
          <label className="block text-gray-700 font-medium mb-2">Target Job Role</label>
          <div className="relative">
            <input
              type="text"
              value={data.targetRole || ''}
              onChange={(e) => handleChange('targetRole', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="Start typing your target job role..."
            />
            {isFieldFilled(data.targetRole) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Email Address</label>
          <div className="relative">
            <input
              type="email"
              value={data.email || ''}
              onChange={(e) => handleChange('email', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="your.email@example.com"
            />
            {isFieldFilled(data.email) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Phone Number</label>
          <div className="relative">
            <input
              type="tel"
              value={data.phone || ''}
              onChange={(e) => handleChange('phone', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="+1 (555) 123-4567"
            />
            {isFieldFilled(data.phone) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Address</label>
          <div className="relative">
            <input
              type="text"
              value={data.address || ''}
              onChange={(e) => handleChange('address', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="Street address"
            />
            {isFieldFilled(data.address) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">City</label>
          <div className="relative">
            <input
              type="text"
              value={data.city || ''}
              onChange={(e) => handleChange('city', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="City"
            />
            {isFieldFilled(data.city) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Country</label>
          <div className="relative">
            <input
              type="text"
              value={data.country || ''}
              onChange={(e) => handleChange('country', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="Country"
            />
            {isFieldFilled(data.country) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">LinkedIn Profile (Optional)</label>
          <div className="relative">
            <input
              type="url"
              value={data.linkedin || ''}
              onChange={(e) => handleChange('linkedin', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="https://linkedin.com/in/yourprofile"
            />
            {isFieldFilled(data.linkedin) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">Website/Portfolio (Optional)</label>
          <div className="relative">
            <input
              type="url"
              value={data.website || ''}
              onChange={(e) => handleChange('website', e.target.value)}
              className="w-full px-4 py-3 pr-12 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
              placeholder="https://yourwebsite.com"
            />
            {isFieldFilled(data.website) && (
              <i className="ri-check-line absolute right-4 top-1/2 transform -translate-y-1/2 text-green-500 text-xl"></i>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
