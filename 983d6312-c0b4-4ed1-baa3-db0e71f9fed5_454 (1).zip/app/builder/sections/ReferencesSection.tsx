'use client';

import { useState } from 'react';

interface Reference {
  id: string;
  name: string;
  title: string;
  company: string;
  phone: string;
  email: string;
  relationship: string;
}

interface ReferencesSectionProps {
  data: {
    showReferences: boolean;
    referencesType: 'upon-request' | 'listed';
    references: Reference[];
  };
  onChange: (data: any) => void;
}

export default function ReferencesSection({ data, onChange }: ReferencesSectionProps) {
  const [expandedReference, setExpandedReference] = useState<string | null>(null);

  const handleToggleReferences = (show: boolean) => {
    onChange({
      ...data,
      showReferences: show,
      referencesType: show ? (data.referencesType || 'upon-request') : 'upon-request'
    });
  };

  const handleReferenceTypeChange = (type: 'upon-request' | 'listed') => {
    onChange({
      ...data,
      referencesType: type,
      references: type === 'upon-request' ? [] : data.references
    });
  };

  const addReference = () => {
    const newReference: Reference = {
      id: Date.now().toString(),
      name: '',
      title: '',
      company: '',
      phone: '',
      email: '',
      relationship: ''
    };

    onChange({
      ...data,
      references: [...data.references, newReference]
    });
    setExpandedReference(newReference.id);
  };

  const updateReference = (id: string, field: string, value: string) => {
    const updatedReferences = data.references.map(ref =>
      ref.id === id ? { ...ref, [field]: value } : ref
    );

    onChange({
      ...data,
      references: updatedReferences
    });
  };

  const deleteReference = (id: string) => {
    const updatedReferences = data.references.filter(ref => ref.id !== id);
    onChange({
      ...data,
      references: updatedReferences
    });
    setExpandedReference(null);
  };

  const toggleExpand = (id: string) => {
    setExpandedReference(expandedReference === id ? null : id);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">References</h3>
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={data.showReferences}
            onChange={(e) => handleToggleReferences(e.target.checked)}
            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-600">Include references section</span>
        </label>
      </div>

      {data.showReferences && (
        <div className="space-y-4">
          <div className="space-y-3">
            <label className="flex items-center space-x-3">
              <input
                type="radio"
                name="referencesType"
                value="upon-request"
                checked={data.referencesType === 'upon-request'}
                onChange={() => handleReferenceTypeChange('upon-request')}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Available upon request</span>
            </label>

            <label className="flex items-center space-x-3">
              <input
                type="radio"
                name="referencesType"
                value="listed"
                checked={data.referencesType === 'listed'}
                onChange={() => handleReferenceTypeChange('listed')}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">List references</span>
            </label>
          </div>

          {data.referencesType === 'listed' && (
            <div className="space-y-4">
              {data.references.map((reference) => (
                <div key={reference.id} className="border rounded-lg overflow-hidden">
                  <div
                    className={`p-4 cursor-pointer transition-colors ${
                      expandedReference === reference.id
                        ? 'bg-blue-50 border-blue-200'
                        : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                    onClick={() => toggleExpand(reference.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">
                          {reference.name || 'Reference Name'}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {reference.title && reference.company
                            ? `${reference.title} at ${reference.company}`
                            : reference.title || reference.company || 'Position & Company'}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteReference(reference.id);
                          }}
                          className="p-1 text-red-500 hover:text-red-700 transition-colors"
                        >
                          <i className="ri-delete-bin-line w-4 h-4 flex items-center justify-center"></i>
                        </button>
                        <i className={`ri-arrow-${expandedReference === reference.id ? 'up' : 'down'}-s-line w-4 h-4 flex items-center justify-center text-gray-400`}></i>
                      </div>
                    </div>
                  </div>

                  {expandedReference === reference.id && (
                    <div className="p-4 bg-white border-t space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Full Name *
                          </label>
                          <input
                            type="text"
                            value={reference.name}
                            onChange={(e) => updateReference(reference.id, 'name', e.target.value)}
                            placeholder="John Smith"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Job Title *
                          </label>
                          <input
                            type="text"
                            value={reference.title}
                            onChange={(e) => updateReference(reference.id, 'title', e.target.value)}
                            placeholder="Senior Manager"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Company *
                          </label>
                          <input
                            type="text"
                            value={reference.company}
                            onChange={(e) => updateReference(reference.id, 'company', e.target.value)}
                            placeholder="ABC Corporation"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Relationship
                          </label>
                          <input
                            type="text"
                            value={reference.relationship}
                            onChange={(e) => updateReference(reference.id, 'relationship', e.target.value)}
                            placeholder="Former Supervisor"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Phone Number
                          </label>
                          <input
                            type="tel"
                            value={reference.phone}
                            onChange={(e) => updateReference(reference.id, 'phone', e.target.value)}
                            placeholder="(555) 123-4567"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Email Address
                          </label>
                          <input
                            type="email"
                            value={reference.email}
                            onChange={(e) => updateReference(reference.id, 'email', e.target.value)}
                            placeholder="john.smith@company.com"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}

              <button
                onClick={addReference}
                className="w-full px-4 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors text-sm font-medium"
              >
                <i className="ri-add-line w-4 h-4 flex items-center justify-center mr-2"></i>
                Add another reference
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}