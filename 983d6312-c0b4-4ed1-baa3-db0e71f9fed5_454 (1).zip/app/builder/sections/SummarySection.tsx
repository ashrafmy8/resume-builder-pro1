
'use client';

import { useState } from 'react';
import AIAssistant from '../../../components/AIAssistant';

interface SummarySectionProps {
  data?: any;
  resumeData?: any;
  setResumeData?: (data: any) => void;
  summary?: string;
  onChange?: (updated: any) => void;
  onAiSuggestion?: (suggestion: string) => void;
}

export default function SummarySection({ 
  data, 
  resumeData, 
  setResumeData, 
  summary, 
  onChange, 
  onAiSuggestion 
}: SummarySectionProps) {
  // Handle different prop patterns
  const currentData = resumeData || data || {};
  const currentSummary = currentData.summary || summary || '';
  
  const [summaryText, setSummaryText] = useState(currentSummary);
  const [activeTab, setActiveTab] = useState('write');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [aiEnhancements, setAiEnhancements] = useState([]);
  const [userInput, setUserInput] = useState('');

  const handleSummaryChange = (value) => {
    setSummaryText(value);
    
    // Handle different callback patterns
    if (setResumeData && resumeData) {
      setResumeData({ ...resumeData, summary: value });
    } else if (onChange) {
      onChange({ summary: value });
    }
  };

  const enhanceWithAI = async () => {
    if (!userInput.trim()) return;

    setIsEnhancing(true);

    // Simulate AI enhancement based on user input
    const enhancements = [
      `Results-driven professional with ${userInput.toLowerCase()}, consistently delivering exceptional performance and measurable business impact through strategic leadership and innovative problem-solving.`,
      `Experienced ${userInput.toLowerCase()} specialist with proven track record of driving organizational success through data-driven decision making and collaborative team leadership.`,
      `Dynamic professional specializing in ${userInput.toLowerCase()}, with demonstrated expertise in optimizing processes and achieving ambitious targets while fostering positive team environments.`
    ];

    setTimeout(() => {
      setAiEnhancements(enhancements);
      setIsEnhancing(false);
    }, 2000);
  };

  const generateSmartSummary = async () => {
    setIsEnhancing(true);

    // Use existing resume data to generate smart summary
    const { experience = [], skills = [], education = [] } = currentData;

    const yearsExp = experience.length > 0 ? Math.max(...experience.map(exp => new Date().getFullYear() - new Date(exp.startDate || '2020').getFullYear())) : 3;
    const topSkills = skills.slice(0, 3).map(s => s.name || s).join(', ') || 'leadership, problem-solving, communication';
    const degree = education.length > 0 ? education[0].degree : 'relevant degree';

    const smartSummary = `Accomplished professional with ${yearsExp}+ years of experience leveraging expertise in ${topSkills} to drive exceptional results. Proven track record of leading successful initiatives that improve operational efficiency and deliver measurable business impact. Strong ${degree} background combined with hands-on experience in fast-paced environments. Passionate about innovation and committed to achieving organizational goals through collaborative leadership and strategic thinking.`;

    setTimeout(() => {
      handleSummaryChange(smartSummary);
      setIsEnhancing(false);
    }, 2000);
  };

  const wordCount = summaryText.trim().split(/\s+/).filter(word => word.length > 0).length;
  const charCount = summaryText.length;
  const recommendedWords = { min: 50, max: 100 };

  const summaryTemplates = [
    {
      title: 'Software Engineer',
      content: 'Experienced software engineer with 5+ years of expertise in full-stack development using React, Node.js, and cloud technologies. Proven track record of delivering scalable web applications that serve millions of users. Strong problem-solving skills and passion for clean, efficient code. Led development teams of 3-5 engineers and mentored junior developers.'
    },
    {
      title: 'Marketing Manager',
      content: 'Results-driven marketing manager with 7+ years of experience in digital marketing, brand strategy, and campaign management. Successfully increased brand awareness by 150% and generated $2M+ in revenue through integrated marketing campaigns. Expert in SEO, social media marketing, and marketing analytics. Strong leadership skills with experience managing cross-functional teams.'
    },
    {
      title: 'Project Manager',
      content: 'Certified Project Manager (PMP) with 6+ years of experience leading complex projects in technology and healthcare sectors. Successfully delivered 25+ projects on time and within budget, managing teams of up to 15 members. Expert in Agile and Waterfall methodologies. Strong communication and stakeholder management skills with proven ability to drive results.'
    },
    {
      title: 'Data Analyst',
      content: 'Detail-oriented data analyst with 4+ years of experience in statistical analysis, data visualization, and business intelligence. Proficient in Python, R, SQL, and Tableau. Successfully identified cost-saving opportunities worth $500K+ through data-driven insights. Strong analytical thinking and ability to communicate complex findings to non-technical stakeholders.'
    }
  ];

  const useTemplate = (template) => {
    handleSummaryChange(template.content);
    setActiveTab('write');
  };

  const handleAISuggestion = (suggestion) => {
    handleSummaryChange(suggestion);
    if (onAiSuggestion) {
      onAiSuggestion(suggestion);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 lg:p-10">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3">Professional Summary</h2>
          <p className="text-lg text-gray-600 leading-relaxed">
            Write a compelling summary that highlights your key achievements, skills, and career goals.
          </p>
        </div>
        <AIAssistant 
          section="summary" 
          context={currentData} 
          onSuggestion={handleAISuggestion}
        />
      </div>

      {/* AI Smart Generator */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100 mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mr-4">
              <i className="ri-brain-line text-2xl text-indigo-600"></i>
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-1">AI Summary Generator</h3>
              <p className="text-gray-600">Generate personalized summary based on your resume data</p>
            </div>
          </div>
          <button 
            onClick={generateSmartSummary}
            disabled={isEnhancing}
            className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center whitespace-nowrap"
          >
            {isEnhancing ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                Generating...
              </>
            ) : (
              <>
                <i className="ri-magic-line mr-2"></i>
                Smart Generate
              </>
            )}
          </button>
        </div>
        
        {/* Custom Enhancement */}
        <div className="grid md:grid-cols-4 gap-4">
          <div className="md:col-span-3">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Enter your specialty or role (e.g., 'digital marketing and brand strategy')"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-indigo-500 focus:ring-0 transition-colors"
            />
          </div>
          <button
            onClick={enhanceWithAI}
            disabled={!userInput.trim() || isEnhancing}
            className="px-6 py-3 bg-purple-600 text-white font-medium rounded-xl hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
          >
            Enhance
          </button>
        </div>

        {aiEnhancements.length > 0 && (
          <div className="mt-6">
            <h4 className="font-semibold text-gray-900 mb-3">AI Enhanced Options</h4>
            <div className="space-y-3">
              {aiEnhancements.map((enhancement, index) => (
                <div
                  key={index}
                  className="p-4 bg-white rounded-xl border border-indigo-200 cursor-pointer hover:border-indigo-400 transition-colors"
                  onClick={() => handleSummaryChange(enhancement)}
                >
                  <p className="text-gray-700 leading-relaxed">{enhancement}</p>
                  <div className="mt-2 text-sm text-indigo-600">
                    {enhancement.trim().split(/\s+/).length} words • Click to use
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-100 rounded-xl p-1 mb-8">
        <button
          onClick={() => setActiveTab('write')}
          className={`flex-1 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
            activeTab === 'write'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <i className="ri-edit-line mr-2"></i>
          Write Summary
        </button>
        <button
          onClick={() => setActiveTab('templates')}
          className={`flex-1 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
            activeTab === 'templates'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <i className="ri-file-text-line mr-2"></i>
          Use Templates
        </button>
      </div>

      {activeTab === 'write' ? (
        <div className="space-y-6">
          <div>
            <label className="block text-lg font-semibold text-gray-800 mb-3">
              Professional Summary
            </label>
            <div className="space-y-3">
              {/* Rich Text Editor Toolbar */}
              <div className="border border-gray-200 rounded-lg p-3 bg-gray-50">
                <div className="flex flex-wrap items-center gap-2">
                  {/* Text Formatting */}
                  <div className="flex items-center gap-1 border-r border-gray-300 pr-2">
                    <button
                      type="button"
                      onClick={() => document.execCommand('bold', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Bold"
                    >
                      <i className="ri-bold text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('italic', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Italic"
                    >
                      <i className="ri-italic text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('underline', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Underline"
                    >
                      <i className="ri-underline text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('strikeThrough', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Strikethrough"
                    >
                      <i className="ri-strikethrough text-gray-700"></i>
                    </button>
                  </div>

                  {/* Font Size */}
                  <div className="flex items-center gap-1 border-r border-gray-300 pr-2">
                    <select
                      onChange={(e) => document.execCommand('fontSize', false, e.target.value)}
                      defaultValue="3"
                      className="text-sm border border-gray-300 rounded px-2 py-1 pr-8"
                      title="Font Size"
                    >
                      <option value="1">Small</option>
                      <option value="2">Normal</option>
                      <option value="3">Medium</option>
                      <option value="4">Large</option>
                      <option value="5">X-Large</option>
                      <option value="6">XX-Large</option>
                    </select>
                  </div>

                  {/* Colors */}
                  <div className="flex items-center gap-1 border-r border-gray-300 pr-2">
                    <div className="flex items-center gap-1">
                      <span className="text-sm text-gray-600">Text:</span>
                      <div className="grid grid-cols-6 gap-1">
                        {['#000000', '#333333', '#666666', '#999999', '#CC0000', '#FF0000',
                          '#FF6600', '#FFCC00', '#FFFF00', '#66FF00', '#00FF00', '#00FFFF',
                          '#0066FF', '#0000FF', '#6600FF', '#FF00FF', '#FF0066', '#FFFFFF',
                          '#F0F0F0', '#D0D0D0', '#B0B0B0', '#808080', '#404040', '#202020'].map((color) => (
                          <button
                            key={color}
                            type="button"
                            onClick={() => document.execCommand('foreColor', false, color)}
                            className="w-4 h-4 rounded border border-gray-300 hover:scale-110 transition-transform"
                            style={{ backgroundColor: color }}
                            title={`Text Color: ${color}`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Lists */}
                  <div className="flex items-center gap-1 border-r border-gray-300 pr-2">
                    <button
                      type="button"
                      onClick={() => document.execCommand('insertUnorderedList', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Bullet List"
                    >
                      <i className="ri-list-unordered text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('insertOrderedList', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Numbered List"
                    >
                      <i className="ri-list-ordered text-gray-700"></i>
                    </button>
                  </div>

                  {/* Alignment */}
                  <div className="flex items-center gap-1 border-r border-gray-300 pr-2">
                    <button
                      type="button"
                      onClick={() => document.execCommand('justifyLeft', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Align Left"
                    >
                      <i className="ri-align-left text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('justifyCenter', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Align Center"
                    >
                      <i className="ri-align-center text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('justifyRight', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Align Right"
                    >
                      <i className="ri-align-right text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('justifyFull', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Justify"
                    >
                      <i className="ri-align-justify text-gray-700"></i>
                    </button>
                  </div>

                  {/* Utilities */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => document.execCommand('undo', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Undo"
                    >
                      <i className="ri-arrow-go-back-line text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('redo', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Redo"
                    >
                      <i className="ri-arrow-go-forward-line text-gray-700"></i>
                    </button>
                    <button
                      type="button"
                      onClick={() => document.execCommand('removeFormat', false, '')}
                      className="p-2 rounded hover:bg-gray-200 transition-colors"
                      title="Clear Formatting"
                    >
                      <i className="ri-format-clear text-gray-700"></i>
                    </button>
                  </div>
                </div>
              </div>

              {/* Rich Text Editor */}
              <div
                contentEditable
                suppressContentEditableWarning={true}
                onInput={(e) => {
                  const target = e.target as HTMLDivElement;
                  handleSummaryChange(target.innerHTML);
                }}
                onPaste={(e) => {
                  e.preventDefault();
                  const text = e.clipboardData.getData('text/plain');
                  document.execCommand('insertText', false, text);
                }}
                className="w-full min-h-[200px] px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-indigo-500 focus:outline-none transition-colors leading-relaxed"
                style={{ whiteSpace: 'pre-wrap' }}
                dangerouslySetInnerHTML={{ __html: summaryText || '' }}
              />

              {/* Formatting Tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-800 mb-2 flex items-center">
                  <i className="ri-lightbulb-line mr-2"></i>
                  Formatting Tips
                </h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Use <strong>bold text</strong> for key achievements and skills</li>
                  <li>• Apply <em>italic formatting</em> for company names or emphasis</li>
                  <li>• Create bullet points for multiple accomplishments</li>
                  <li>• Keep font sizes consistent for professional appearance</li>
                  <li>• Use colors sparingly to maintain readability</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl font-bold text-gray-900 mb-2">Professional Summary Templates</h3>
            <p className="text-gray-600">Choose a template that matches your role and customize it</p>
          </div>
          
          <div className="grid gap-6">
            {summaryTemplates.map((template, index) => (
              <div key={index} className="bg-gradient-to-r from-gray-50 to-indigo-50 rounded-2xl p-6 border border-gray-200 hover:border-indigo-300 transition-all">
                <div className="flex justify-between items-start mb-4">
                  <h4 className="text-lg font-bold text-gray-900">{template.title}</h4>
                  <button
                    onClick={() => useTemplate(template)}
                    className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap"
                  >
                    Use Template
                  </button>
                </div>
                <p className="text-gray-700 leading-relaxed">{template.content}</p>
                <div className="mt-4 text-sm text-gray-500">
                  {template.content.trim().split(/\s+/).length} words
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Enhanced Tips Panel with AI Insights */}
      <div className="mt-10 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100">
        <div className="flex items-start">
          <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center flex-shrink-0 mr-4">
            <i className="ri-lightbulb-line text-lg text-indigo-600"></i>
          </div>
          <div>
            <h4 className="text-lg font-bold text-indigo-900 mb-3">📝 AI-Enhanced Summary Tips</h4>
            <ul className="space-y-2 text-indigo-800">
              <li className="flex items-start">
                <i className="ri-check-line text-indigo-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Use AI to generate multiple versions and choose the best fit</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-indigo-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Include quantifiable achievements (percentages, dollar amounts, team sizes)</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-indigo-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Start with your years of experience and key expertise area</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-indigo-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Match keywords from your target job descriptions</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-indigo-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>End with your value proposition or career goals</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
