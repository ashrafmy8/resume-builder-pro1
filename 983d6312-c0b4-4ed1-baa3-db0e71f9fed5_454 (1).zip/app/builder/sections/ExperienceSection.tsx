
'use client';

import { useState } from 'react';
import RichTextEditor from '../../../components/RichTextEditor';

interface Experience {
  id: string;
  jobTitle: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  isCurrentJob: boolean;
  description: string;
}

interface ExperienceSectionProps {
  resumeData?: any;
  setResumeData?: (data: any) => void;
  experiences?: Experience[];
  onUpdate?: (experiences: Experience[]) => void;
  experience?: Experience[];
  onChange?: (experiences: Experience[]) => void;
}

const jobRoles = [
  // Technology & Engineering
  'Software Engineer', 'Frontend Developer', 'Backend Developer', 'Full Stack Developer', 'Mobile App Developer',
  'Data Scientist', 'Data Analyst', 'Machine Learning Engineer', 'AI Specialist', 'DevOps Engineer',
  'Cloud Architect', 'Cybersecurity Analyst', 'Network Administrator', 'Database Administrator', 'System Administrator',
  'IT Support Specialist', 'Web Developer', 'Game Developer', 'Blockchain Developer', 'QA Engineer',
  'Technical Writer', 'Product Manager', 'Scrum Master', 'IT Consultant', 'Solutions Architect',

  // Business & Management
  'CEO', 'COO', 'CFO', 'CTO', 'General Manager', 'Operations Manager', 'Business Analyst', 'Management Consultant',
  'Strategy Consultant', 'Business Development Manager', 'Program Manager', 'Portfolio Manager', 'Change Manager',
  'Risk Manager', 'Compliance Officer', 'Executive Assistant', 'Administrative Assistant', 'Office Manager',
  'Team Lead', 'Department Head', 'Regional Manager', 'Branch Manager', 'Startup Founder',

  // Sales & Marketing
  'Sales Manager', 'Account Executive', 'Sales Representative', 'Business Development Representative', 'Inside Sales Representative',
  'Marketing Manager', 'Digital Marketing Manager', 'Content Marketing Manager', 'Social Media Manager', 'SEO Specialist',
  'PPC Specialist', 'Email Marketing Specialist', 'Brand Manager', 'Product Marketing Manager', 'Growth Hacker',
  'Marketing Analyst', 'Customer Success Manager', 'Account Manager', 'Sales Director', 'Marketing Director',
  'Public Relations Manager', 'Communications Manager', 'Event Manager',

  // Finance & Accounting
  'Financial Analyst', 'Senior Financial Analyst', 'Investment Banker', 'Investment Analyst', 'Portfolio Manager',
  'Financial Advisor', 'Wealth Manager', 'Accountant', 'Senior Accountant', 'Staff Accountant', 'CPA',
  'Controller', 'Finance Manager', 'CFO', 'Treasurer', 'Credit Analyst', 'Risk Analyst', 'Auditor',
  'Tax Specialist', 'Bookkeeper', 'Payroll Specialist', 'Budget Analyst', 'Cost Accountant', 'Financial Planner',

  // Healthcare & Medical
  'Physician', 'Surgeon', 'Nurse', 'Registered Nurse', 'Nurse Practitioner', 'Physician Assistant',
  'Medical Assistant', 'Healthcare Administrator', 'Hospital Administrator', 'Medical Technician',
  'Pharmacist', 'Physical Therapist', 'Occupational Therapist', 'Respiratory Therapist', 'Speech Therapist',
  'Dentist', 'Dental Hygienist', 'Veterinarian', 'Medical Researcher', 'Clinical Research Coordinator',
  'Healthcare Consultant', 'Medical Device Sales', 'Health Information Manager',

  // Education & Training
  'Teacher', 'Elementary School Teacher', 'High School Teacher', 'Special Education Teacher', 'Professor',
  'Assistant Professor', 'Associate Professor', 'Principal', 'Vice Principal', 'School Administrator',
  'Education Consultant', 'Curriculum Developer', 'Instructional Designer', 'Training Manager',
  'Corporate Trainer', 'Online Course Creator', 'Tutor', 'School Counselor',

  // Legal & Government
  'Lawyer', 'Attorney', 'Corporate Lawyer', 'Criminal Defense Attorney', 'Personal Injury Lawyer',
  'Paralegal', 'Legal Assistant', 'Legal Secretary', 'Judge', 'Court Clerk', 'Legal Consultant',
  'Government Official', 'Policy Analyst', 'Legislative Assistant', 'City Planner', 'Public Administrator',
  'Diplomat',

  // Creative & Media
  'Graphic Designer', 'Web Designer', 'UX Designer', 'UI Designer', 'Product Designer', 'Art Director',
  'Creative Director', 'Copywriter', 'Content Writer', 'Technical Writer', 'Editor', 'Journalist',
  'Photographer', 'Videographer', 'Video Editor', 'Animator', 'Illustrator', 'Music Producer',
  'Sound Engineer', 'Film Director', 'Producer', 'Actor',

  // Customer Service
  'Customer Service Representative', 'Customer Success Manager', 'Customer Support Specialist',
  'Call Center Agent', 'Technical Support Specialist', 'Help Desk Technician', 'Client Relations Manager',
  'Customer Experience Manager', 'Support Manager', 'Community Manager',

  // Manufacturing & Production
  'Production Manager', 'Manufacturing Engineer', 'Quality Control Inspector', 'Quality Assurance Manager',
  'Plant Manager', 'Operations Supervisor', 'Production Supervisor', 'Maintenance Technician',
  'Industrial Engineer', 'Process Engineer', 'Supply Chain Manager', 'Logistics Coordinator',
  'Warehouse Manager', 'Inventory Manager', 'Procurement Specialist', 'Purchasing Manager',

  // Retail & Hospitality
  'Store Manager', 'Assistant Store Manager', 'Retail Sales Associate', 'Cashier', 'Merchandiser',
  'Visual Merchandiser', 'Buyer', 'Hotel Manager', 'Restaurant Manager', 'Chef', 'Line Cook',
  'Server', 'Bartender', 'Front Desk Agent', 'Housekeeping Manager', 'Event Coordinator',
  'Travel Agent', 'Tour Guide', 'Concierge',

  // Real Estate & Construction
  'Real Estate Agent', 'Real Estate Broker', 'Property Manager', 'Real Estate Developer',
  'Construction Manager', 'Project Manager', 'Site Supervisor', 'Architect', 'Civil Engineer',
  'Electrical Engineer', 'Mechanical Engineer', 'Contractor', 'Carpenter', 'Electrician',
  'Plumber', 'HVAC Technician', 'Construction Worker', 'Estimator',

  // Transportation & Logistics
  'Truck Driver', 'Delivery Driver', 'Uber Driver', 'Taxi Driver', 'Pilot', 'Flight Attendant',
  'Air Traffic Controller', 'Ship Captain', 'Maritime Engineer', 'Logistics Manager',
  'Supply Chain Analyst', 'Transportation Coordinator', 'Fleet Manager', 'Dispatcher',

  // Science & Research
  'Research Scientist', 'Biologist', 'Chemist', 'Physicist', 'Environmental Scientist',
  'Laboratory Technician', 'Research Assistant', 'Clinical Research Associate', 'Biostatistician',
  'Epidemiologist', 'Geneticist', 'Microbiologist', 'Geologist', 'Meteorologist',

  // Public Safety & Security
  'Police Officer', 'Detective', 'Sheriff', 'Firefighter', 'EMT', 'Paramedic', 'Security Guard',
  'Security Manager', 'Loss Prevention Specialist', 'Private Investigator', 'Correctional Officer',
  'Border Patrol Agent', 'TSA Agent',

  // Agriculture & Environment
  'Farmer', 'Agricultural Engineer', 'Veterinary Technician', 'Environmental Engineer',
  'Environmental Consultant', 'Conservation Scientist', 'Park Ranger', 'Wildlife Biologist',
  'Landscape Architect', 'Forestry Technician', 'Agricultural Inspector', 'Sustainability Consultant',

  // Sports & Fitness
  'Personal Trainer', 'Fitness Instructor', 'Athletic Coach', 'Sports Coach', 'Gym Manager',
  'Athletic Director', 'Sports Agent', 'Physical Education Teacher', 'Nutritionist',

  // Non-Profit & Social Services
  'Social Worker', 'Case Manager', 'Counselor', 'Therapist', 'Psychologist', 'Nonprofit Director',
  'Program Coordinator', 'Community Outreach Coordinator', 'Fundraiser', 'Grant Writer',
  'Volunteer Coordinator', 'Youth Counselor', 'Family Therapist', 'Substance Abuse Counselor'
];

const jobDescriptionTemplates: { [key: string]: string[] } = {
  'Software Engineer': [
    'Developed and maintained scalable web applications using modern frameworks like React, Node.js, and Python',
    'Collaborated with cross-functional teams to design and implement new features, improving user experience by 40%',
    'Optimized database queries and application performance, reducing load times by 60%',
    'Participated in code reviews and mentored junior developers, maintaining high code quality standards',
    'Implemented automated testing strategies, achieving 90% code coverage and reducing bugs by 50%'
  ],
  'Marketing Manager': [
    'Led comprehensive marketing campaigns that increased brand awareness by 45% and generated $2M in revenue',
    'Managed social media strategy across multiple platforms, growing follower base by 200% in 12 months',
    'Coordinated with design and content teams to create compelling marketing materials and campaigns',
    'Analyzed market trends and competitor strategies to identify new opportunities for growth',
    'Managed marketing budget of $500K annually, consistently delivering projects under budget and on time'
  ],
  'Project Manager': [
    'Successfully managed 15+ cross-functional projects with budgets ranging from $100K to $1M',
    'Implemented Agile methodologies, improving team productivity by 35% and project delivery speed by 25%',
    'Coordinated with stakeholders across multiple departments to ensure project alignment with business objectives',
    'Developed comprehensive project plans, risk assessments, and resource allocation strategies',
    'Led project teams of 8-12 members, fostering collaboration and maintaining high team morale'
  ],
  'Sales Representative': [
    'Exceeded sales quotas by 120% for three consecutive years, generating over $3M in annual revenue',
    'Built and maintained relationships with 200+ clients, achieving 95% customer retention rate',
    'Conducted product demonstrations and presentations to potential clients, closing 85% of qualified leads',
    'Collaborated with marketing team to develop targeted sales strategies and campaigns',
    'Mentored new sales team members and contributed to team training programs'
  ]
};

const getJobDescriptionSuggestions = (jobTitle: string): string[] => {
  // Direct match
  if (jobDescriptionTemplates[jobTitle]) {
    return jobDescriptionTemplates[jobTitle];
  }
  
  // Fuzzy matching for similar roles
  const lowerTitle = jobTitle.toLowerCase();
  
  if (lowerTitle.includes('software') || lowerTitle.includes('developer') || lowerTitle.includes('engineer')) {
    return jobDescriptionTemplates['Software Engineer'];
  }
  if (lowerTitle.includes('marketing') || lowerTitle.includes('brand')) {
    return jobDescriptionTemplates['Marketing Manager'];
  }
  if (lowerTitle.includes('project') || lowerTitle.includes('program')) {
    return jobDescriptionTemplates['Project Manager'];
  }
  if (lowerTitle.includes('sales') || lowerTitle.includes('account')) {
    return jobDescriptionTemplates['Sales Representative'];
  }
  
  // Generic suggestions for other roles
  return [
    'Led key initiatives that improved operational efficiency and drove measurable business results',
    'Collaborated with cross-functional teams to achieve department goals and objectives',
    'Developed and implemented processes that enhanced workflow and productivity',
    'Managed multiple projects simultaneously while maintaining high quality standards',
    'Contributed to team success through effective communication and problem-solving skills'
  ];
};

export default function ExperienceSection({ 
  resumeData, 
  setResumeData, 
  experiences, 
  onUpdate, 
  experience, 
  onChange 
}: ExperienceSectionProps) {
  const [showSuggestions, setShowSuggestions] = useState<{[key: string]: boolean}>({});
  const [filteredSuggestions, setFilteredSuggestions] = useState<{[key: string]: string[]}>({});
  const [showDescriptionSuggestions, setShowDescriptionSuggestions] = useState<{[key: string]: boolean}>({});
  const [isGenerating, setIsGenerating] = useState<{[key: string]: boolean}>({});

  // Determine the current experiences array and update function
  const currentExperiences = experiences || experience || resumeData?.experience || [];
  const updateExperiences = (newExperiences: Experience[]) => {
    if (onUpdate) {
      onUpdate(newExperiences);
    } else if (onChange) {
      onChange(newExperiences);
    } else if (setResumeData && resumeData) {
      setResumeData({
        ...resumeData,
        experience: newExperiences
      });
    }
  };

  const addExperience = () => {
    const newExperience: Experience = {
      id: Date.now().toString(),
      jobTitle: '',
      company: '',
      location: '',
      startDate: '',
      endDate: '',
      isCurrentJob: false,
      description: ''
    };
    
    const updatedExperiences = [...currentExperiences, newExperience];
    updateExperiences(updatedExperiences);
  };

  const updateExperience = (id: string, field: keyof Experience, value: string | boolean) => {
    const updatedExperiences = currentExperiences.map(exp =>
      exp.id === id ? { ...exp, [field]: value } : exp
    );
    updateExperiences(updatedExperiences);
  };

  const removeExperience = (id: string) => {
    const updatedExperiences = currentExperiences.filter(exp => exp.id !== id);
    updateExperiences(updatedExperiences);
  };

  const handleJobTitleChange = (id: string, value: string) => {
    updateExperience(id, 'jobTitle', value);
    
    if (value.length > 0) {
      const filtered = jobRoles.filter(role =>
        role.toLowerCase().includes(value.toLowerCase())
      ).slice(0, 10);
      
      setFilteredSuggestions(prev => ({ ...prev, [id]: filtered }));
      setShowSuggestions(prev => ({ ...prev, [id]: true }));
    } else {
      setShowSuggestions(prev => ({ ...prev, [id]: false }));
    }
  };

  const selectSuggestion = (id: string, suggestion: string) => {
    updateExperience(id, 'jobTitle', suggestion);
    setShowSuggestions(prev => ({ ...prev, [id]: false }));
  };

  const generateJobDescription = async (experienceId: string, jobTitle: string) => {
    if (!jobTitle.trim()) return;
    
    setIsGenerating(prev => ({ ...prev, [experienceId]: true }));
    
    try {
      // Get suggestions based on job title
      const suggestions = getJobDescriptionSuggestions(jobTitle);
      
      // Add a random selection of 2-3 suggestions
      const selectedSuggestions = suggestions
        .sort(() => 0.5 - Math.random())
        .slice(0, Math.floor(Math.random() * 2) + 2);
      
      const generatedDescription = selectedSuggestions.join('\n• ');
      const finalDescription = '• ' + generatedDescription;
      
      updateExperience(experienceId, 'description', finalDescription);
    } catch (error) {
      console.error('Error generating description:', error);
    } finally {
      setIsGenerating(prev => ({ ...prev, [experienceId]: false }));
    }
  };

  const enhanceDescription = async (experienceId: string, currentDescription: string, jobTitle: string) => {
    if (!jobTitle.trim()) return;
    
    setIsGenerating(prev => ({ ...prev, [experienceId]: true }));
    
    try {
      const suggestions = getJobDescriptionSuggestions(jobTitle);
      
      // Get unused suggestions
      const usedPoints = currentDescription.toLowerCase();
      const unusedSuggestions = suggestions.filter(suggestion => 
        !usedPoints.includes(suggestion.substring(0, 30).toLowerCase())
      );
      
      if (unusedSuggestions.length > 0) {
        const newSuggestion = unusedSuggestions[Math.floor(Math.random() * unusedSuggestions.length)];
        const enhancedDescription = currentDescription + '\n• ' + newSuggestion;
        updateExperience(experienceId, 'description', enhancedDescription);
      }
    } catch (error) {
      console.error('Error enhancing description:', error);
    } finally {
      setIsGenerating(prev => ({ ...prev, [experienceId]: false }));
    }
  };

  const addSuggestionToDescription = (experienceId: string, suggestion: string, currentDescription: string) => {
    const newDescription = currentDescription 
      ? currentDescription + '\n• ' + suggestion 
      : '• ' + suggestion;
    updateExperience(experienceId, 'description', newDescription);
    setShowDescriptionSuggestions(prev => ({ ...prev, [experienceId]: false }));
  };

  if (currentExperiences.length === 0) {
    return (
      <div className="bg-white rounded-xl border-2 border-gray-100 p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Work Experience</h2>
        </div>
        
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-briefcase-line text-2xl text-purple-600"></i>
          </div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Add Your Work Experience</h3>
          <p className="text-gray-500 mb-6">Share your professional journey and highlight your achievements</p>
          
          <button
            onClick={addExperience}
            className="bg-purple-600 text-white px-6 py-3 rounded-xl hover:bg-purple-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
          >
            Add Your First Experience
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border-2 border-gray-100 p-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Work Experience</h2>
        <button
          onClick={addExperience}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors font-medium whitespace-nowrap cursor-pointer"
        >
          <i className="ri-add-line mr-2"></i>
          Add Experience
        </button>
      </div>

      <div className="space-y-6">
        {currentExperiences.map((experience, index) => (
          <div key={experience.id} className="border-2 border-gray-100 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-700">Experience {index + 1}</h3>
              <button
                onClick={() => removeExperience(experience.id)}
                className="text-red-500 hover:text-red-700 transition-colors cursor-pointer"
              >
                <i className="ri-delete-bin-line text-lg"></i>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="relative">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Job Title *
                </label>
                <input
                  type="text"
                  value={experience.jobTitle}
                  onChange={(e) => handleJobTitleChange(experience.id, e.target.value)}
                  onFocus={() => {
                    if (experience.jobTitle.length > 0) {
                      const filtered = jobRoles.filter(role =>
                        role.toLowerCase().includes(experience.jobTitle.toLowerCase())
                      ).slice(0, 10);
                      setFilteredSuggestions(prev => ({ ...prev, [experience.id]: filtered }));
                      setShowSuggestions(prev => ({ ...prev, [experience.id]: true }));
                    }
                  }}
                  onBlur={() => {
                    setTimeout(() => {
                      setShowSuggestions(prev => ({ ...prev, [experience.id]: false }));
                    }, 200);
                  }}
                  placeholder="e.g. Software Engineer, Marketing Manager"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
                />
                
                {showSuggestions[experience.id] && filteredSuggestions[experience.id]?.length > 0 && (
                  <div className="absolute z-[60] w-full mt-1 bg-white border-2 border-purple-300 rounded-xl shadow-xl max-h-48 overflow-y-auto">
                    {filteredSuggestions[experience.id].map((suggestion, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onMouseDown={(e) => {
                          e.preventDefault();
                          selectSuggestion(experience.id, suggestion);
                        }}
                        className="w-full px-4 py-3 text-left hover:bg-purple-50 hover:text-purple-600 transition-colors cursor-pointer flex items-center space-x-3 border-b border-gray-100 last:border-b-0"
                      >
                        <i className="ri-briefcase-fill text-purple-500 text-sm"></i>
                        <span>{suggestion}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Company *
                </label>
                <input
                  type="text"
                  value={experience.company}
                  onChange={(e) => updateExperience(experience.id, 'company', e.target.value)}
                  placeholder="Company name"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  value={experience.location}
                  onChange={(e) => updateExperience(experience.id, 'location', e.target.value)}
                  placeholder="City, State"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date *
                </label>
                <input
                  type="month"
                  value={experience.startDate}
                  onChange={(e) => updateExperience(experience.id, 'startDate', e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date
                </label>
                <input
                  type="month"
                  value={experience.endDate}
                  onChange={(e) => updateExperience(experience.id, 'endDate', e.target.value)}
                  disabled={experience.isCurrentJob}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors disabled:bg-gray-100"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={experience.isCurrentJob}
                  onChange={(e) => {
                    updateExperience(experience.id, 'isCurrentJob', e.target.checked);
                    if (e.target.checked) {
                      updateExperience(experience.id, 'endDate', '');
                    }
                  }}
                  className="w-4 h-4 text-purple-600 border-2 border-gray-300 rounded focus:ring-purple-500"
                />
                <span className="ml-2 text-sm text-gray-700">I currently work here</span>
              </label>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Job Description
                </label>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setShowDescriptionSuggestions(prev => ({ 
                      ...prev, 
                      [experience.id]: !prev[experience.id] 
                    }))}
                    className="text-xs text-purple-600 hover:text-purple-700 font-medium cursor-pointer flex items-center space-x-1"
                  >
                    <i className="ri-lightbulb-line"></i>
                    <span>Suggestions</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => generateJobDescription(experience.id, experience.jobTitle)}
                    disabled={isGenerating[experience.id] || !experience.jobTitle}
                    className="text-xs bg-purple-600 text-white px-3 py-1 rounded-full hover:bg-purple-700 disabled:bg-gray-300 cursor-pointer flex items-center space-x-1 whitespace-nowrap"
                  >
                    {isGenerating[experience.id] ? (
                      <>
                        <i className="ri-loader-4-line animate-spin"></i>
                        <span>Generating...</span>
                      </>
                    ) : (
                      <>
                        <i className="ri-magic-line"></i>
                        <span>AI Generate</span>
                      </>
                    )}
                  </button>
                  {experience.description && (
                    <button
                      type="button"
                      onClick={() => enhanceDescription(experience.id, experience.description, experience.jobTitle)}
                      disabled={isGenerating[experience.id] || !experience.jobTitle}
                      className="text-xs bg-green-600 text-white px-3 py-1 rounded-full hover:bg-green-700 disabled:bg-gray-300 cursor-pointer flex items-center space-x-1 whitespace-nowrap"
                    >
                      {isGenerating[experience.id] ? (
                        <>
                          <i className="ri-loader-4-line animate-spin"></i>
                          <span>Enhancing...</span>
                        </>
                      ) : (
                        <>
                          <i className="ri-add-circle-line"></i>
                          <span>Enhance</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              {showDescriptionSuggestions[experience.id] && experience.jobTitle && (
                <div className="mb-3 p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <h4 className="text-sm font-medium text-purple-800 mb-2 flex items-center">
                    <i className="ri-lightbulb-fill mr-2"></i>
                    Suggestions for {experience.jobTitle}
                  </h4>
                  <div className="space-y-2">
                    {getJobDescriptionSuggestions(experience.jobTitle).slice(0, 3).map((suggestion, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => addSuggestionToDescription(experience.id, suggestion, experience.description)}
                        className="w-full text-left p-3 bg-white rounded-lg hover:bg-purple-100 transition-colors text-sm text-gray-700 cursor-pointer border border-gray-200"
                      >
                        <div className="flex items-start space-x-2">
                          <i className="ri-add-line text-purple-600 mt-0.5 flex-shrink-0"></i>
                          <span>{suggestion}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="relative">
                <RichTextEditor
                  value={experience.description}
                  onChange={(value) => updateExperience(experience.id, 'description', value)}
                  placeholder="Describe your responsibilities, achievements, and key projects..."
                  rows={4}
                />
                
                {!experience.description && experience.jobTitle && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="bg-white/90 px-4 py-2 rounded-lg shadow-sm border border-gray-200">
                      <p className="text-sm text-gray-500 text-center">
                        Click "AI Generate" to create a professional description
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
