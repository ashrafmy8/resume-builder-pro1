
'use client';

import { useState } from 'react';
import RichTextEditor from '../../../components/RichTextEditor';

export default function EducationSection({ resumeData, setResumeData }) {
  const [education, setEducation] = useState(resumeData.education || []);
  const [showForm, setShowForm] = useState(false);
  const [editingIndex, setEditingIndex] = useState(-1);
  const [currentEducation, setCurrentEducation] = useState({
    degree: '',
    institution: '',
    location: '',
    graduationDate: '',
    gpa: '',
    description: ''
  });

  const handleInputChange = (field, value) => {
    setCurrentEducation(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addEducation = () => {
    if (editingIndex >= 0) {
      const updated = [...education];
      updated[editingIndex] = currentEducation;
      setEducation(updated);
      setResumeData(prev => ({ ...prev, education: updated }));
    } else {
      const updated = [...education, currentEducation];
      setEducation(updated);
      setResumeData(prev => ({ ...prev, education: updated }));
    }
    resetForm();
  };

  const resetForm = () => {
    setCurrentEducation({
      degree: '',
      institution: '',
      location: '',
      graduationDate: '',
      gpa: '',
      description: ''
    });
    setShowForm(false);
    setEditingIndex(-1);
  };

  const editEducation = (index) => {
    setCurrentEducation(education[index]);
    setEditingIndex(index);
    setShowForm(true);
  };

  const deleteEducation = (index) => {
    const updated = education.filter((_, i) => i !== index);
    setEducation(updated);
    setResumeData(prev => ({ ...prev, education: updated }));
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 lg:p-10">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Education</h2>
        <p className="text-lg text-gray-600 leading-relaxed">
          Add your educational background, starting with your highest level of education.
        </p>
      </div>

      {/* Education List */}
      {education.length > 0 && (
        <div className="space-y-6 mb-8">
          {education.map((edu, index) => (
            <div key={index} className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-100">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{edu.degree}</h3>
                  <div className="text-lg font-semibold text-purple-700 mb-2">{edu.institution}</div>
                  <div className="flex items-center space-x-4 text-gray-600">
                    <span className="flex items-center">
                      <i className="ri-map-pin-line mr-2"></i>
                      {edu.location}
                    </span>
                    <span className="flex items-center">
                      <i className="ri-calendar-line mr-2"></i>
                      {edu.graduationDate}
                    </span>
                    {edu.gpa && (
                      <span className="flex items-center">
                        <i className="ri-star-line mr-2"></i>
                        GPA: {edu.gpa}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex space-x-2 ml-4">
                  <button
                    onClick={() => editEducation(index)}
                    className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl hover:bg-blue-200 transition-colors flex items-center justify-center"
                  >
                    <i className="ri-edit-line"></i>
                  </button>
                  <button
                    onClick={() => deleteEducation(index)}
                    className="w-10 h-10 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors flex items-center justify-center"
                  >
                    <i className="ri-delete-bin-line"></i>
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <RichTextEditor
                  value={edu.description}
                  onChange={(value) => updateEducation(index, 'description', value)}
                  placeholder="• Magna Cum Laude graduate • Relevant coursework: Data Structures, Algorithms, Software Engineering • Dean's List for 4 consecutive semesters"
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Education Form */}
      {showForm ? (
        <div className="bg-gray-50 rounded-2xl p-8 border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">
              {editingIndex >= 0 ? 'Edit Education' : 'Add New Education'}
            </h3>
            <button
              onClick={resetForm}
              className="w-8 h-8 bg-gray-200 text-gray-600 rounded-lg hover:bg-gray-300 transition-colors flex items-center justify-center"
            >
              <i className="ri-close-line"></i>
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-900 mb-3">
                Degree/Qualification *
              </label>
              <input
                type="text"
                value={currentEducation.degree}
                onChange={(e) => handleInputChange('degree', e.target.value)}
                className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-0 transition-colors"
                placeholder="Bachelor of Science in Computer Science"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3">
                  Institution *
                </label>
                <input
                  type="text"
                  value={currentEducation.institution}
                  onChange={(e) => handleInputChange('institution', e.target.value)}
                  className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus-border-purple-500 focus:ring-0 transition-colors"
                  placeholder="University of Technology"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3">
                  Location
                </label>
                <input
                  type="text"
                  value={currentEducation.location}
                  onChange={(e) => handleInputChange('location', e.target.value)}
                  className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus-border-purple-500 focus:ring-0 transition-colors"
                  placeholder="Boston, MA"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3">
                  Graduation Date *
                </label>
                <input
                  type="month"
                  value={currentEducation.graduationDate}
                  onChange={(e) => handleInputChange('graduationDate', e.target.value)}
                  className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus-border-purple-500 focus:ring-0 transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3">
                  GPA (Optional)
                </label>
                <input
                  type="text"
                  value={currentEducation.gpa}
                  onChange={(e) => handleInputChange('gpa', e.target.value)}
                  className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus-border-purple-500 focus:ring-0 transition-colors"
                  placeholder="3.8/4.0"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-900 mb-3">
                Additional Information
              </label>
              <textarea
                value={currentEducation.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                className="w-full px-4 py-4 text-lg border-2 border-gray-200 rounded-xl focus-border-purple-500 focus:ring-0 transition-colors resize-none"
                placeholder="• Magna Cum Laude graduate&#10;• Relevant coursework: Data Structures, Algorithms, Software Engineering&#10;• Dean's List for 4 consecutive semesters"
              />
              <p className="mt-2 text-sm text-gray-500">
                Include honors, relevant coursework, or academic achievements
              </p>
            </div>

            <div className="flex justify-end space-x-4">
              <button
                onClick={resetForm}
                className="px-6 py-3 bg-gray-200 text-gray-700 font-medium rounded-xl hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={addEducation}
                disabled={!currentEducation.degree || !currentEducation.institution}
                className="px-6 py-3 bg-purple-600 text-white font-medium rounded-xl hover:bg-purple-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {editingIndex >= 0 ? 'Update Education' : 'Add Education'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className="w-full p-8 border-3 border-dashed border-purple-300 rounded-2xl hover:border-purple-400 hover:bg-purple-50 transition-all group"
        >
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
            <i className="ri-add-line text-2xl text-purple-600"></i>
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">Add Education</h3>
          <p className="text-gray-600">Click to add your educational background</p>
        </button>
      )}

      {/* Tips Panel */}
      <div className="mt-10 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-100">
        <div className="flex items-start">
          <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0 mr-4">
            <i className="ri-lightbulb-line text-lg text-purple-600"></i>
          </div>
          <div>
            <h4 className="text-lg font-bold text-purple-900 mb-3">🎓 Education Section Tips</h4>
            <ul className="space-y-2 text-purple-800">
              <li className="flex items-start">
                <i className="ri-check-line text-purple-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>List your highest level of education first</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-purple-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Include GPA only if it's 3.5 or higher</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-purple-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Mention relevant coursework for entry-level positions</span>
              </li>
              <li className="flex items-start">
                <i className="ri-check-line text-purple-600 mr-2 mt-0.5 flex-shrink-0"></i>
                <span>Include academic honors, scholarships, or achievements</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
