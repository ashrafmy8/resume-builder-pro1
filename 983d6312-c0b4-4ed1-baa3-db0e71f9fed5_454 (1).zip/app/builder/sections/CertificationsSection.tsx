
'use client';

import { useState } from 'react';

interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
  credentialId?: string;
}

interface CertificationsSectionProps {
  resumeData: any;
  setResumeData: (data: any) => void;
  onAiSuggestion?: (suggestion: string) => void;
}

export default function CertificationsSection({ resumeData, setResumeData, onAiSuggestion }: CertificationsSectionProps) {
  const [expandedCert, setExpandedCert] = useState<string | null>(null);
  
  // Ensure certifications array exists
  const certifications = resumeData.certifications || [];

  const addCertification = () => {
    const newCert: Certification = {
      id: Date.now().toString(),
      name: '',
      issuer: '',
      date: '',
      credentialId: ''
    };
    const updatedCertifications = [...certifications, newCert];
    setResumeData({
      ...resumeData,
      certifications: updatedCertifications
    });
    setExpandedCert(newCert.id);
  };

  const updateCertification = (id: string, field: keyof Certification, value: string) => {
    const updated = certifications.map(cert =>
      cert.id === id ? { ...cert, [field]: value } : cert
    );
    setResumeData({
      ...resumeData,
      certifications: updated
    });
  };

  const deleteCertification = (id: string) => {
    const updated = certifications.filter(cert => cert.id !== id);
    setResumeData({
      ...resumeData,
      certifications: updated
    });
  };

  const toggleExpanded = (id: string) => {
    setExpandedCert(expandedCert === id ? null : id);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Professional Certifications</h2>
        <p className="text-gray-600 text-lg">Add your professional certifications and licenses to showcase your expertise</p>
      </div>

      <div className="space-y-6">
        {certifications.map((cert, index) => (
          <div key={cert.id} className={`${expandedCert === cert.id ? 'bg-white border-2 border-blue-300 shadow-lg' : 'bg-gray-50 border-2 border-gray-200'} rounded-2xl p-6 transition-all duration-200 hover:shadow-md`}>
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => toggleExpanded(cert.id)}
                className="flex-1 text-left"
              >
                <div className="text-lg font-semibold text-gray-800 mb-2">
                  {cert.name || `License or Certification #${index + 1}`}
                </div>
                {cert.name && (
                  <div className="text-base text-gray-500">
                    {cert.issuer} {cert.date && `• ${cert.date}`}
                  </div>
                )}
                {!cert.name && (
                  <div className="text-base text-gray-400 italic">
                    e.g. Project Management Professional (PMP)
                  </div>
                )}
              </button>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => toggleExpanded(cert.id)}
                  className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${
                    expandedCert === cert.id 
                      ? 'bg-blue-100 text-blue-600 hover:bg-blue-200' 
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  <i className={`ri-${expandedCert === cert.id ? 'subtract' : 'add'}-line text-lg`}></i>
                </button>
                <button
                  onClick={() => deleteCertification(cert.id)}
                  className="w-10 h-10 flex items-center justify-center bg-gray-100 text-gray-500 hover:bg-red-100 hover:text-red-600 rounded-xl transition-all"
                >
                  <i className="ri-delete-bin-line text-lg"></i>
                </button>
              </div>
            </div>

            {expandedCert === cert.id && (
              <div className="space-y-6 border-t border-gray-200 pt-6 animate-in slide-in-from-top-2 duration-200">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Certification Name *
                  </label>
                  <input
                    type="text"
                    value={cert.name}
                    onChange={(e) => updateCertification(cert.id, 'name', e.target.value)}
                    placeholder="e.g. Project Management Professional (PMP)"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Issuing Organization *
                  </label>
                  <input
                    type="text"
                    value={cert.issuer}
                    onChange={(e) => updateCertification(cert.id, 'issuer', e.target.value)}
                    placeholder="e.g. Project Management Institute"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base transition-all"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Date Obtained
                    </label>
                    <input
                      type="month"
                      value={cert.date}
                      onChange={(e) => updateCertification(cert.id, 'date', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Credential ID (optional)
                    </label>
                    <input
                      type="text"
                      value={cert.credentialId || ''}
                      onChange={(e) => updateCertification(cert.id, 'credentialId', e.target.value)}
                      placeholder="e.g. 12345-ABC"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base transition-all"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}

        {certifications.length === 0 && (
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-dashed border-blue-300 rounded-2xl p-12 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-award-line text-3xl text-blue-600"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">No certifications added yet</h3>
            <p className="text-gray-600 mb-6 max-w-md mx-auto">
              Add your professional certifications and licenses to showcase your expertise and qualifications
            </p>
            <button
              onClick={addCertification}
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all hover:scale-105 shadow-lg"
            >
              Add Your First Certification
            </button>
          </div>
        )}

        {certifications.length > 0 && (
          <button
            onClick={addCertification}
            className="flex items-center justify-center w-full py-4 text-lg font-semibold text-gray-700 hover:text-blue-600 transition-all duration-200 border-2 border-dashed border-gray-300 hover:border-blue-400 rounded-2xl hover:bg-blue-50"
          >
            <div className="w-8 h-8 border-2 border-current rounded-full flex items-center justify-center mr-3">
              <i className="ri-add-line text-lg"></i>
            </div>
            Add another license or certification
          </button>
        )}
      </div>

      {/* Tips Section */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-6">
        <div className="flex items-start space-x-4">
          <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <i className="ri-lightbulb-line text-white text-lg"></i>
          </div>
          <div>
            <h4 className="text-lg font-bold text-amber-900 mb-2">Pro Tips for Certifications</h4>
            <ul className="text-amber-800 space-y-1 text-sm">
              <li>• Include only relevant certifications for your target role</li>
              <li>• List certifications in reverse chronological order (newest first)</li>
              <li>• Include expiration dates if they're still current</li>
              <li>• Add credential IDs when available for verification</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
