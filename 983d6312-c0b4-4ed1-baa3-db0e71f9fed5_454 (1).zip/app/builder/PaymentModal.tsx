
'use client';

import { useState, useEffect } from 'react';
import DownloadManager from './DownloadManager';

interface PaymentModalProps {
  action: string;
  onClose: () => void;
  resumeData: any;
  previewRef?: React.RefObject<HTMLElement>;
}

export default function PaymentModal({ action, onClose, resumeData, previewRef }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState('');
  const [subscriptionType, setSubscriptionType] = useState('one-time');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: ''
  });
  const [processing, setProcessing] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [selectedFormats, setSelectedFormats] = useState<string[]>(['pdf']);
  const [emailAddress, setEmailAddress] = useState('');
  const [cloudService, setCloudService] = useState<'gdrive' | 'dropbox'>('gdrive');

  // Initialize download manager
  const downloadManager = previewRef ? DownloadManager({ resumeData, previewRef }) : null;

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const formatOptions = [
    { id: 'pdf', name: 'PDF Document', icon: 'ri-file-pdf-line', color: 'red', description: 'Best for sharing and printing' },
    { id: 'docx', name: 'Word Document', icon: 'ri-file-word-line', color: 'blue', description: 'Editable Microsoft Word format' },
    { id: 'html', name: 'HTML File', icon: 'ri-html5-line', color: 'orange', description: 'Web-ready format' },
    { id: 'png', name: 'PNG Image', icon: 'ri-image-line', color: 'green', description: 'High-quality image format' },
    { id: 'jpg', name: 'JPG Image', icon: 'ri-image-line', color: 'yellow', description: 'Compressed image format' },
    { id: 'txt', name: 'Text File', icon: 'ri-file-text-line', color: 'gray', description: 'Plain text format' }
  ];

  const getActionText = () => {
    switch (action) {
      case 'save': return 'Save Resume';
      case 'download': return 'Download Resume';
      case 'email': return 'Email Resume';
      case 'cloud': return 'Save to Cloud';
      default: return 'Complete Action';
    }
  };

  const getPriceText = () => {
    return subscriptionType === 'one-time' ? '$2' : '$5/month';
  };

  const handleFormatToggle = (formatId: string) => {
    setSelectedFormats(prev => 
      prev.includes(formatId) 
        ? prev.filter(f => f !== formatId)
        : [...prev, formatId]
    );
  };

  const executeAction = async () => {
    if (!downloadManager) {
      alert('Download system not available. Please try again.');
      return;
    }

    try {
      switch (action) {
        case 'download':
          for (const format of selectedFormats) {
            switch (format) {
              case 'pdf':
                await downloadManager.downloadAsPDF();
                break;
              case 'docx':
                await downloadManager.downloadAsWord();
                break;
              case 'html':
                downloadManager.downloadAsHTML();
                break;
              case 'png':
                await downloadManager.downloadAsImage('png');
                break;
              case 'jpg':
                await downloadManager.downloadAsImage('jpg');
                break;
              case 'txt':
                downloadManager.downloadAsText();
                break;
            }
            // Small delay between downloads
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          break;
          
        case 'email':
          if (emailAddress) {
            await downloadManager.sendEmail(emailAddress, selectedFormats);
          } else {
            alert('Please enter an email address.');
          }
          break;
          
        case 'cloud':
          await downloadManager.saveToCloud(cloudService);
          break;
          
        case 'save':
          // Save all formats locally
          for (const format of selectedFormats) {
            switch (format) {
              case 'pdf':
                await downloadManager.downloadAsPDF();
                break;
              case 'docx':
                await downloadManager.downloadAsWord();
                break;
              default:
                await downloadManager.downloadAsPDF(); // Default to PDF
            }
            await new Promise(resolve => setTimeout(resolve, 500));
          }
          break;
      }
    } catch (error) {
      console.error('Action execution failed:', error);
      alert('Failed to complete action. Please try again.');
    }
  };

  const handlePayment = async () => {
    setProcessing(true);
    
    // Simulate payment processing
    setTimeout(async () => {
      setProcessing(false);
      setPaymentSuccess(true);
      
      // Auto-execute action after payment
      setTimeout(async () => {
        await executeAction();
      }, 1500);
    }, 3000);
  };

  if (paymentSuccess) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white/95 backdrop-blur-lg rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-white/20">
          
          {/* Success Header */}
          <div className="p-8 text-center border-b border-gray-200/50">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center animate-bounce">
              <i className="ri-check-line text-white text-3xl"></i>
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Payment Successful! 🎉</h2>
            <p className="text-gray-600 mb-4">
              Your {subscriptionType === 'one-time' ? 'one-time access' : 'monthly subscription'} is now active.
            </p>

            {downloadManager?.isGenerating && (
              <div className="flex items-center justify-center space-x-3 bg-blue-50 p-4 rounded-xl">
                <div className="w-5 h-5 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
                <span className="text-blue-700 font-medium">
                  Generating {downloadManager.currentFormat}...
                </span>
              </div>
            )}
          </div>

          {/* Format Selection */}
          <div className="p-6">
            <h3 className="font-semibold text-gray-800 mb-4 flex items-center">
              <i className="ri-file-line text-indigo-500 mr-2"></i>
              Choose Your Formats
            </h3>
            
            <div className="grid grid-cols-2 gap-3 mb-6">
              {formatOptions.map((format) => (
                <label
                  key={format.id}
                  className={`group relative flex items-center p-4 border-2 rounded-xl cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedFormats.includes(format.id)
                      ? `border-${format.color}-400 bg-${format.color}-50/80 shadow-${format.color}-100/50 shadow-lg`
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50/50'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selectedFormats.includes(format.id)}
                    onChange={() => handleFormatToggle(format.id)}
                    className="sr-only"
                  />
                  <div className="flex items-center space-x-3 flex-1">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      selectedFormats.includes(format.id) 
                        ? `bg-${format.color}-500 text-white` 
                        : `bg-${format.color}-100 text-${format.color}-600`
                    } transition-all duration-300`}>
                      <i className={`${format.icon} text-lg`}></i>
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 text-sm">{format.name}</div>
                      <div className="text-xs text-gray-500">{format.description}</div>
                    </div>
                    {selectedFormats.includes(format.id) && (
                      <div className={`w-5 h-5 bg-${format.color}-500 rounded-full flex items-center justify-center`}>
                        <i className="ri-check-line text-white text-xs"></i>
                      </div>
                    )}
                  </div>
                </label>
              ))}
            </div>

            {/* Email Input for Email Action */}
            {action === 'email' && (
              <div className="mb-6 p-4 bg-blue-50/50 rounded-xl border border-blue-200/50">
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <i className="ri-mail-line text-blue-500 mr-2"></i>
                  Email Details
                </h4>
                <div className="space-y-3">
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    placeholder="Enter recipient email address"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  />
                  <p className="text-xs text-gray-600">
                    Selected formats will be downloaded and you can attach them to your email.
                  </p>
                </div>
              </div>
            )}

            {/* Cloud Service Selection */}
            {action === 'cloud' && (
              <div className="mb-6 p-4 bg-purple-50/50 rounded-xl border border-purple-200/50">
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <i className="ri-cloud-line text-purple-500 mr-2"></i>
                  Choose Cloud Service
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <label className={`flex items-center p-3 border-2 rounded-lg cursor-pointer transition-all duration-300 ${
                    cloudService === 'gdrive' ? 'border-blue-400 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                  }`}>
                    <input
                      type="radio"
                      name="cloud"
                      value="gdrive"
                      checked={cloudService === 'gdrive'}
                      onChange={(e) => setCloudService(e.target.value as 'gdrive')}
                      className="mr-3"
                    />
                    <i className="ri-google-line text-blue-600 mr-2"></i>
                    <span className="font-medium">Google Drive</span>
                  </label>
                  <label className={`flex items-center p-3 border-2 rounded-lg cursor-pointer transition-all duration-300 ${
                    cloudService === 'dropbox' ? 'border-blue-400 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                  }`}>
                    <input
                      type="radio"
                      name="cloud"
                      value="dropbox"
                      checked={cloudService === 'dropbox'}
                      onChange={(e) => setCloudService(e.target.value as 'dropbox')}
                      className="mr-3"
                    />
                    <i className="ri-dropbox-line text-blue-600 mr-2"></i>
                    <span className="font-medium">Dropbox</span>
                  </label>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <button
                onClick={executeAction}
                disabled={selectedFormats.length === 0 || downloadManager?.isGenerating || (action === 'email' && !emailAddress)}
                className="flex-1 px-6 py-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl hover:from-indigo-600 hover:to-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300 font-semibold hover:scale-105 hover:shadow-lg flex items-center justify-center space-x-2"
              >
                {downloadManager?.isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <i className={`${action === 'download' ? 'ri-download-line' : action === 'email' ? 'ri-mail-send-line' : action === 'cloud' ? 'ri-cloud-upload-line' : 'ri-save-line'}`}></i>
                    <span>{getActionText()}</span>
                  </>
                )}
              </button>
              
              <button
                onClick={onClose}
                className="px-6 py-4 border-2 border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all duration-300 font-medium hover:scale-105"
              >
                Done
              </button>
            </div>

            {/* Format Info */}
            <div className="mt-6 p-4 bg-gradient-to-r from-emerald-50/80 to-green-50/80 backdrop-blur-sm border border-emerald-200/50 rounded-xl">
              <div className="flex items-start space-x-3">
                <i className="ri-information-line text-emerald-600 mt-0.5"></i>
                <div className="text-sm text-emerald-700">
                  <div className="font-semibold mb-1">Selected formats: {selectedFormats.length}</div>
                  <div className="text-emerald-600">
                    {selectedFormats.map(f => formatOptions.find(opt => opt.id === f)?.name).join(', ')}
                  </div>
                  <div className="mt-2 text-xs">
                    {subscriptionType === 'one-time' 
                      ? 'One-time access - download all formats now'
                      : 'Monthly subscription - unlimited access to all features'
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`bg-white/95 backdrop-blur-lg rounded-3xl max-w-lg w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-white/20 transition-all duration-700 ${
        isVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-10'
      }`}>
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-3xl">
          <div className="absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-gradient-to-r from-emerald-400/10 to-cyan-400/10 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>

        {/* Header */}
        <div className="relative p-6 pb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center animate-pulse">
                <i className="ri-vip-crown-line text-white text-lg"></i>
              </div>
              <div>
                <h2 className="text-xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">Unlock Premium Access</h2>
                <p className="text-xs text-gray-600">Choose your plan to {action}</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-8 h-8 bg-gray-100/80 hover:bg-gray-200/80 rounded-xl flex items-center justify-center text-gray-500 hover:text-gray-700 transition-all duration-300 hover:scale-110 backdrop-blur-sm"
            >
              <i className="ri-close-line text-lg"></i>
            </button>
          </div>

          {/* Action Badge */}
          <div className="inline-flex items-center px-3 py-1.5 bg-gradient-to-r from-blue-100/80 to-indigo-100/80 backdrop-blur-sm rounded-full border border-blue-200/50 mb-4">
            <i className={`${action === 'save' ? 'ri-save-line' : action === 'download' ? 'ri-download-line' : action === 'email' ? 'ri-mail-line' : 'ri-cloud-line'} text-blue-600 mr-2 text-sm`}></i>
            <span className="text-blue-800 font-medium text-xs">{getActionText()}</span>
          </div>
        </div>

        <div className="relative px-6 pb-6">
          {/* Format Preview */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center text-sm">
              <i className="ri-file-line text-indigo-500 mr-2"></i>
              Available Formats
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {formatOptions.slice(0, 6).map((format) => (
                <div key={format.id} className={`p-2 border border-gray-200 rounded-lg text-center hover:border-${format.color}-300 hover:bg-${format.color}-50/30 transition-all duration-300`}>
                  <i className={`${format.icon} text-lg text-${format.color}-600 mb-1`}></i>
                  <div className="text-xs font-medium text-gray-700">{format.name.split(' ')[0]}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Subscription Plan Selection */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center text-sm">
              <i className="ri-star-line text-yellow-500 mr-2"></i>
              Select Your Plan
            </h3>
            <div className="space-y-3">
              <label className={`group relative flex items-center p-4 border-2 rounded-xl cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
                subscriptionType === 'one-time' 
                  ? 'border-green-400 bg-gradient-to-r from-green-50/80 to-emerald-50/80 shadow-green-100/50 shadow-lg' 
                  : 'border-gray-200 hover:border-green-300 hover:bg-green-50/30'
              }`}>
                <input
                  type="radio"
                  name="subscription"
                  value="one-time"
                  checked={subscriptionType === 'one-time'}
                  onChange={(e) => setSubscriptionType(e.target.value)}
                  className="mr-3 w-4 h-4 text-green-600 border-2 border-gray-300 focus:ring-green-500"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <span className="font-bold text-gray-900">One-Time Access</span>
                      <div className="ml-2 px-2 py-0.5 bg-green-500 text-white text-xs font-bold rounded-full animate-pulse">
                        POPULAR
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">$2</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">Perfect for immediate use. {getActionText().toLowerCase()} right now.</p>
                  <div className="flex items-center text-xs text-green-700">
                    <i className="ri-check-line mr-1 text-green-600"></i>
                    All formats • Instant access • No recurring charges
                  </div>
                </div>
              </label>

              <label className={`group relative flex items-center p-4 border-2 rounded-xl cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
                subscriptionType === 'monthly' 
                  ? 'border-indigo-400 bg-gradient-to-r from-indigo-50/80 to-purple-50/80 shadow-indigo-100/50 shadow-lg' 
                  : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/30'
              }`}>
                <input
                  type="radio"
                  name="subscription"
                  value="monthly"
                  checked={subscriptionType === 'monthly'}
                  onChange={(e) => setSubscriptionType(e.target.value)}
                  className="mr-3 w-4 h-4 text-indigo-600 border-2 border-gray-300 focus:ring-indigo-500"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <span className="font-bold text-gray-900">Monthly Subscription</span>
                      <div className="ml-2 px-2 py-0.5 bg-indigo-500 text-white text-xs font-bold rounded-full">
                        UNLIMITED
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-indigo-600">$5</span>
                      <span className="text-gray-500 text-xs">/month</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">Unlimited access to all features. Cancel anytime.</p>
                  <div className="space-y-1">
                    <div className="flex items-center text-xs text-indigo-700">
                      <i className="ri-check-line mr-1 text-indigo-600"></i>
                      Unlimited downloads in all formats
                    </div>
                    <div className="flex items-center text-xs text-indigo-700">
                      <i className="ri-check-line mr-1 text-indigo-600"></i>
                      Premium templates & AI features
                    </div>
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center text-sm">
              <i className="ri-secure-payment-line text-blue-600 mr-2"></i>
              Choose Payment Method
            </h3>
            
            <div className="space-y-2">
              <label className={`group flex items-center p-3 border-2 rounded-lg cursor-pointer transition-all duration-300 hover:shadow-md hover:-translate-y-0.5 ${
                paymentMethod === 'mtn' 
                  ? 'border-yellow-400 bg-yellow-50/80 shadow-yellow-100/50 shadow-md' 
                  : 'border-gray-200 hover:border-yellow-300 hover:bg-yellow-50/50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="mtn"
                  checked={paymentMethod === 'mtn'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="mr-3 w-4 h-4 text-yellow-600"
                />
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-lg flex items-center justify-center text-white text-xs font-bold mr-3 group-hover:scale-110 transition-transform duration-300">
                    MTN
                  </div>
                  <span className="font-medium text-gray-900 text-sm">MTN Mobile Money</span>
                </div>
              </label>

              <label className={`group flex items-center p-3 border-2 rounded-lg cursor-pointer transition-all duration-300 hover:shadow-md hover:-translate-y-0.5 ${
                paymentMethod === 'airtel' 
                  ? 'border-red-400 bg-red-50/80 shadow-red-100/50 shadow-md' 
                  : 'border-gray-200 hover:border-red-300 hover:bg-red-50/50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="airtel"
                  checked={paymentMethod === 'airtel'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="mr-3 w-4 h-4 text-red-600"
                />
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-red-600 rounded-lg flex items-center justify-center text-white text-xs font-bold mr-3 group-hover:scale-110 transition-transform duration-300">
                    AIRTEL
                  </div>
                  <span className="font-medium text-gray-900 text-sm">Airtel Money</span>
                </div>
              </label>

              <label className={`group flex items-center p-3 border-2 rounded-lg cursor-pointer transition-all duration-300 hover:shadow-md hover:-translate-y-0.5 ${
                paymentMethod === 'card' 
                  ? 'border-blue-400 bg-blue-50/80 shadow-blue-100/50 shadow-md' 
                  : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50/50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="card"
                  checked={paymentMethod === 'card'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="mr-3 w-4 h-4 text-blue-600"
                />
                <div className="flex items-center">
                  <i className="ri-bank-card-line text-xl text-blue-600 mr-3 group-hover:scale-110 transition-transform duration-300"></i>
                  <span className="font-medium text-gray-900 text-sm">Credit/Debit Card</span>
                </div>
              </label>
            </div>

            {/* Phone Number Input for Mobile Money */}
            {(paymentMethod === 'mtn' || paymentMethod === 'airtel') && (
              <div className="bg-white/80 backdrop-blur-sm p-4 rounded-xl border border-gray-200/50 animate-fadeIn">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Phone Number
                </label>
                <div className="relative">
                  <i className="ri-phone-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="Enter your phone number"
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300 text-sm"
                  />
                </div>
              </div>
            )}

            {/* Card Details for Card Payment */}
            {paymentMethod === 'card' && (
              <div className="bg-white/80 backdrop-blur-sm p-4 rounded-xl border border-gray-200/50 space-y-4 animate-fadeIn">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Card Number
                  </label>
                  <div className="relative">
                    <i className="ri-bank-card-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <input
                      type="text"
                      value={cardDetails.number}
                      onChange={(e) => setCardDetails({...cardDetails, number: e.target.value})}
                      placeholder="1234 5678 9012 3456"
                      className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300 text-sm"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Expiry
                    </label>
                    <input
                      type="text"
                      value={cardDetails.expiry}
                      onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})}
                      placeholder="MM/YY"
                      className="w-full px-3 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      CVV
                    </label>
                    <input
                      type="text"
                      value={cardDetails.cvv}
                      onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})}
                      placeholder="123"
                      className="w-full px-3 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300 text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Cardholder Name
                  </label>
                  <div className="relative">
                    <i className="ri-user-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <input
                      type="text"
                      value={cardDetails.name}
                      onChange={(e) => setCardDetails({...cardDetails, name: e.target.value})}
                      placeholder="John Doe"
                      className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white/90 backdrop-blur-sm transition-all duration-300 hover:border-gray-300 text-sm"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="relative p-6 pt-4 border-t border-gray-200/50">
          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-3 border-2 border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 hover:border-gray-300 transition-all duration-300 font-medium hover:scale-105 text-sm"
            >
              Cancel
            </button>
            <button
              onClick={handlePayment}
              disabled={!paymentMethod || processing}
              className={`flex-1 px-4 py-3 text-white rounded-lg hover:opacity-90 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300 font-semibold hover:scale-105 hover:shadow-lg text-sm ${
                subscriptionType === 'one-time' 
                  ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 shadow-green-200/50' 
                  : 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 shadow-indigo-200/50'
              }`}
            >
              {processing ? (
                <span className="flex items-center justify-center">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                  Processing...
                </span>
              ) : (
                <span className="flex items-center justify-center">
                  <i className="ri-secure-payment-line mr-2"></i>
                  Pay {getPriceText()}
                </span>
              )}
            </button>
          </div>
          
          {/* Security Badge */}
          <div className="flex items-center justify-center mt-3 text-xs text-gray-500">
            <i className="ri-shield-check-line text-green-500 mr-1"></i>
            <span>Secure payment with 256-bit SSL encryption</span>
          </div>
        </div>
      </div>
    </div>
  );
}
