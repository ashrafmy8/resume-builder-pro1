
'use client';

import { useState } from 'react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { saveAs } from 'file-saver';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, AlignmentType } from 'docx';

interface DownloadManagerProps {
  resumeData: any;
  previewRef: React.RefObject<HTMLElement>;
}

export default function DownloadManager({ resumeData, previewRef }: DownloadManagerProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentFormat, setCurrentFormat] = useState('');

  const generateFileName = (format: string) => {
    const name = resumeData.personalInfo?.firstName && resumeData.personalInfo?.lastName 
      ? `${resumeData.personalInfo.firstName}-${resumeData.personalInfo.lastName}`
      : 'resume';
    const timestamp = new Date().toISOString().slice(0, 10);
    return `${name.replace(/\s+/g, '-').toLowerCase()}-${timestamp}.${format}`;
  };

  const downloadAsPDF = async () => {
    setIsGenerating(true);
    setCurrentFormat('PDF');
    
    try {
      if (!previewRef.current) throw new Error('Preview not available');
      
      // Create a temporary full-size clone of the preview for high-quality capture
      const originalElement = previewRef.current;
      const clonedElement = originalElement.cloneNode(true) as HTMLElement;
      
      // Apply full-size styling to the clone
      clonedElement.style.position = 'absolute';
      clonedElement.style.left = '-9999px';
      clonedElement.style.top = '0';
      clonedElement.style.transform = 'scale(1)'; // Remove any scaling
      clonedElement.style.width = '8.5in'; // Standard letter width
      clonedElement.style.minHeight = '11in'; // Standard letter height
      clonedElement.style.backgroundColor = '#ffffff';
      clonedElement.style.boxShadow = 'none';
      
      // Remove watermark from clone
      const watermark = clonedElement.querySelector('.absolute.inset-0');
      if (watermark) {
        watermark.remove();
      }
      
      document.body.appendChild(clonedElement);

      // Generate high-quality canvas
      const canvas = await html2canvas(clonedElement, {
        scale: 3, // High resolution for crisp text
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        width: 816, // 8.5 inches at 96 DPI
        height: 1056, // 11 inches at 96 DPI
        scrollX: 0,
        scrollY: 0
      });

      // Clean up the temporary element
      document.body.removeChild(clonedElement);

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // Calculate dimensions to maintain aspect ratio
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pdfWidth;
      const imgHeight = (canvas.height * pdfWidth) / canvas.width;

      let yPosition = 0;
      let remainingHeight = imgHeight;

      while (remainingHeight > 0) {
        const pageHeight = Math.min(remainingHeight, pdfHeight);
        
        pdf.addImage(
          imgData, 
          'PNG', 
          0, 
          -yPosition, 
          imgWidth, 
          imgHeight,
          undefined,
          'FAST'
        );

        remainingHeight -= pdfHeight;
        yPosition += pdfHeight;

        if (remainingHeight > 0) {
          pdf.addPage();
        }
      }

      pdf.save(generateFileName('pdf'));
    } catch (error) {
      console.error('PDF generation failed:', error);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  const downloadAsImage = async (format: 'png' | 'jpg' = 'png') => {
    setIsGenerating(true);
    setCurrentFormat(format.toUpperCase());
    
    try {
      if (!previewRef.current) throw new Error('Preview not available');
      
      // Create a temporary full-size clone
      const originalElement = previewRef.current;
      const clonedElement = originalElement.cloneNode(true) as HTMLElement;
      
      // Apply full-size styling
      clonedElement.style.position = 'absolute';
      clonedElement.style.left = '-9999px';
      clonedElement.style.top = '0';
      clonedElement.style.transform = 'scale(1)';
      clonedElement.style.width = '8.5in';
      clonedElement.style.minHeight = '11in';
      clonedElement.style.backgroundColor = format === 'jpg' ? '#ffffff' : 'transparent';
      clonedElement.style.boxShadow = 'none';
      
      // Remove watermark from clone
      const watermark = clonedElement.querySelector('.absolute.inset-0');
      if (watermark) {
        watermark.remove();
      }
      
      document.body.appendChild(clonedElement);

      const canvas = await html2canvas(clonedElement, {
        scale: 4, // Even higher resolution for images
        useCORS: true,
        allowTaint: true,
        backgroundColor: format === 'jpg' ? '#ffffff' : null,
        width: 816,
        height: 1056
      });

      document.body.removeChild(clonedElement);

      canvas.toBlob((blob) => {
        if (blob) {
          saveAs(blob, generateFileName(format));
        }
      }, `image/${format}`, format === 'jpg' ? 0.95 : 1.0);
    } catch (error) {
      console.error(`${format.toUpperCase()} generation failed:`, error);
      alert(`Failed to generate ${format.toUpperCase()}. Please try again.`);
    } finally {
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  const downloadAsWord = async () => {
    setIsGenerating(true);
    setCurrentFormat('DOCX');
    
    try {
      const { personalInfo, summary, experience, education, skills, languages, certifications } = resumeData;
      
      const children: any[] = [];

      // Header Section with Professional Styling
      if (personalInfo?.firstName || personalInfo?.lastName) {
        const fullName = `${personalInfo.firstName || ''} ${personalInfo.lastName || ''}`.trim();
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: fullName.toUpperCase(), 
              bold: true, 
              size: 36,
              color: "1F2937"
            })],
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 }
          })
        );

        if (personalInfo.jobTitle) {
          children.push(
            new Paragraph({
              children: [new TextRun({ 
                text: personalInfo.jobTitle.toUpperCase(), 
                size: 24,
                color: "3B82F6",
                bold: true
              })],
              alignment: AlignmentType.CENTER,
              spacing: { after: 300 }
            })
          );
        }

        // Contact Information in a clean format
        const contactParts = [];
        if (personalInfo.email) contactParts.push(personalInfo.email);
        if (personalInfo.phone) contactParts.push(personalInfo.phone);
        if (personalInfo.city && personalInfo.country) {
          contactParts.push(`${personalInfo.city}, ${personalInfo.country}`);
        }
        if (personalInfo.linkedin) contactParts.push('LinkedIn Profile');
        if (personalInfo.website) contactParts.push(personalInfo.website);

        if (contactParts.length > 0) {
          children.push(
            new Paragraph({
              children: [new TextRun({ 
                text: contactParts.join(' • '), 
                size: 20,
                color: "6B7280"
              })],
              alignment: AlignmentType.CENTER,
              spacing: { after: 400 }
            })
          );
        }
      }

      // Professional Summary with enhanced styling
      if (summary) {
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: 'PROFESSIONAL SUMMARY', 
              bold: true, 
              size: 24,
              color: "1F2937"
            })],
            spacing: { before: 200, after: 200 },
            border: {
              bottom: {
                color: "3B82F6",
                size: 3,
                style: "single"
              }
            }
          }),
          new Paragraph({
            children: [new TextRun({ 
              text: summary, 
              size: 22,
              color: "374151"
            })],
            spacing: { after: 400 },
            alignment: AlignmentType.JUSTIFIED
          })
        );
      }

      // Work Experience with detailed formatting
      if (experience && experience.length > 0) {
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: 'WORK EXPERIENCE', 
              bold: true, 
              size: 24,
              color: "1F2937"
            })],
            spacing: { before: 200, after: 200 },
            border: {
              bottom: {
                color: "3B82F6",
                size: 3,
                style: "single"
              }
            }
          })
        );

        experience.forEach((exp: any, index: number) => {
          if (exp.jobTitle) {
            children.push(
              new Paragraph({
                children: [new TextRun({ 
                  text: exp.jobTitle, 
                  bold: true, 
                  size: 22,
                  color: "1F2937"
                })],
                spacing: { before: index > 0 ? 300 : 100, after: 100 }
              })
            );
          }
          
          if (exp.company) {
            const companyText = exp.location 
              ? `${exp.company} • ${exp.location}`
              : exp.company;
            
            children.push(
              new Paragraph({
                children: [new TextRun({ 
                  text: companyText, 
                  size: 20,
                  color: "3B82F6",
                  bold: true
                })],
                spacing: { after: 100 }
              })
            );
          }

          if (exp.startDate || exp.endDate) {
            const duration = exp.isCurrentJob 
              ? `${exp.startDate} - Present`
              : `${exp.startDate} - ${exp.endDate}`;
            
            children.push(
              new Paragraph({
                children: [new TextRun({ 
                  text: duration, 
                  size: 18,
                  color: "6B7280",
                  italics: true
                })],
                spacing: { after: 200 }
              })
            );
          }

          if (exp.description) {
            const descriptions = exp.description.split('\n').filter(desc => desc.trim());
            descriptions.forEach(desc => {
              children.push(
                new Paragraph({
                  children: [new TextRun({ 
                    text: `• ${desc.trim()}`, 
                    size: 20,
                    color: "374151"
                  })],
                  spacing: { after: 100 },
                  indent: { left: 360 }
                })
              );
            });
          }
        });
      }

      // Education Section
      if (education && education.length > 0) {
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: 'EDUCATION', 
              bold: true, 
              size: 24,
              color: "1F2937"
            })],
            spacing: { before: 400, after: 200 },
            border: {
              bottom: {
                color: "3B82F6",
                size: 3,
                style: "single"
              }
            }
          })
        );

        education.forEach((edu: any, index: number) => {
          if (edu.degree) {
            children.push(
              new Paragraph({
                children: [new TextRun({ 
                  text: edu.degree, 
                  bold: true, 
                  size: 22,
                  color: "1F2937"
                })],
                spacing: { before: index > 0 ? 300 : 100, after: 100 }
              })
            );
          }
          
          if (edu.school) {
            const schoolText = edu.location 
              ? `${edu.school} • ${edu.location}`
              : edu.school;
            
            children.push(
              new Paragraph({
                children: [new TextRun({ 
                  text: schoolText, 
                  size: 20,
                  color: "3B82F6",
                  bold: true
                })],
                spacing: { after: 100 }
              })
            );
          }

          if (edu.graduationDate) {
            children.push(
              new Paragraph({
                children: [new TextRun({ 
                  text: edu.graduationDate, 
                  size: 18,
                  color: "6B7280",
                  italics: true
                })],
                spacing: { after: 200 }
              })
            );
          }
        });
      }

      // Certifications Section
      if (certifications && certifications.length > 0) {
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: 'CERTIFICATIONS', 
              bold: true, 
              size: 24,
              color: "1F2937"
            })],
            spacing: { before: 400, after: 200 },
            border: {
              bottom: {
                color: "3B82F6",
                size: 3,
                style: "single"
              }
            }
          })
        );

        certifications.forEach((cert: any) => {
          const certText = cert.issuer 
            ? `${cert.name} - ${cert.issuer}${cert.date ? ` (${cert.date})` : ''}`
            : cert.name;
          
          children.push(
            new Paragraph({
              children: [new TextRun({ 
                text: `• ${certText}`, 
                size: 20,
                color: "374151"
              })],
              spacing: { after: 100 },
              indent: { left: 360 }
            })
          );
        });
      }

      // Skills Section with better formatting
      if (skills && skills.length > 0) {
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: 'SKILLS', 
              bold: true, 
              size: 24,
              color: "1F2937"
            })],
            spacing: { before: 400, after: 200 },
            border: {
              bottom: {
                color: "3B82F6",
                size: 3,
                style: "single"
              }
            }
          })
        );

        const skillNames = skills.map(skill => 
          typeof skill === 'string' ? skill : skill?.name || ''
        ).filter(Boolean);

        // Group skills into rows of 3-4 for better formatting
        const skillsPerRow = 4;
        for (let i = 0; i < skillNames.length; i += skillsPerRow) {
          const rowSkills = skillNames.slice(i, i + skillsPerRow);
          children.push(
            new Paragraph({
              children: [new TextRun({ 
                text: rowSkills.join(' • '), 
                size: 20,
                color: "374151"
              })],
              spacing: { after: 150 }
            })
          );
        }
      }

      // Languages Section
      if (languages && languages.length > 0) {
        children.push(
          new Paragraph({
            children: [new TextRun({ 
              text: 'LANGUAGES', 
              bold: true, 
              size: 24,
              color: "1F2937"
            })],
            spacing: { before: 400, after: 200 },
            border: {
              bottom: {
                color: "3B82F6",
                size: 3,
                style: "single"
              }
            }
          })
        );

        languages.forEach((lang: any) => {
          const langText = `${lang.language} - ${lang.proficiency}`;
          children.push(
            new Paragraph({
              children: [new TextRun({ 
                text: `• ${langText}`, 
                size: 20,
                color: "374151"
              })],
              spacing: { after: 100 },
              indent: { left: 360 }
            })
          );
        });
      }

      const doc = new Document({
        sections: [{
          properties: {
            page: {
              margin: {
                top: 1440, // 1 inch
                right: 1440,
                bottom: 1440,
                left: 1440
              }
            }
          },
          children: children
        }]
      });

      const blob = await Packer.toBlob(doc);
      saveAs(blob, generateFileName('docx'));
    } catch (error) {
      console.error('DOCX generation failed:', error);
      alert('Failed to generate Word document. Please try again.');
    } finally {
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  const downloadAsHTML = () => {
    setIsGenerating(true);
    setCurrentFormat('HTML');
    
    try {
      if (!previewRef.current) throw new Error('Preview not available');
      
      // Get the full styled HTML content
      const previewContent = previewRef.current.innerHTML;
      
      // Remove watermark from the content
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = previewContent;
      const watermark = tempDiv.querySelector('.absolute.inset-0');
      if (watermark) {
        watermark.remove();
      }

      const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${resumeData.personalInfo?.firstName} ${resumeData.personalInfo?.lastName} - Resume</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f8fafc;
            color: #334155;
        }
        
        .resume-container {
            max-width: 8.5in;
            min-height: 11in;
            margin: 0 auto;
            background: white;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            page-break-inside: avoid;
        }
        
        @media print {
            body { 
                padding: 0; 
                background: white; 
            }
            .resume-container { 
                box-shadow: none; 
                max-width: none;
                width: 100%;
                min-height: auto;
            }
        }
        
        @page {
            size: letter;
            margin: 0.5in;
        }
    </style>
</head>
<body>
    <div class="resume-container">
        ${tempDiv.innerHTML}
    </div>
    
    <script>
        // Auto-print functionality
        function printResume() {
            window.print();
        }
        
        // Add print button if needed
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Resume loaded successfully');
        });
    </script>
</body>
</html>`;

      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      saveAs(blob, generateFileName('html'));
    } catch (error) {
      console.error('HTML generation failed:', error);
      alert('Failed to generate HTML file. Please try again.');
    } finally {
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  const downloadAsText = () => {
    setIsGenerating(true);
    setCurrentFormat('TXT');
    
    try {
      const { personalInfo, summary, experience, education, skills } = resumeData;
      
      let textContent = '';
      
      // Header
      if (personalInfo?.fullName) {
        textContent += `${personalInfo.fullName.toUpperCase()}\n`;
        textContent += '='.repeat(personalInfo.fullName.length) + '\n\n';
        
        const contactInfo = [personalInfo.email, personalInfo.phone, personalInfo.location].filter(Boolean);
        if (contactInfo.length > 0) {
          textContent += contactInfo.join(' | ') + '\n';
        }
        
        const links = [personalInfo.linkedin, personalInfo.website].filter(Boolean);
        if (links.length > 0) {
          textContent += links.join(' | ') + '\n';
        }
        textContent += '\n';
      }
      
      // Summary
      if (summary) {
        textContent += 'PROFESSIONAL SUMMARY\n';
        textContent += '-'.repeat(20) + '\n';
        textContent += summary + '\n\n';
      }
      
      // Experience
      if (experience && experience.length > 0) {
        textContent += 'WORK EXPERIENCE\n';
        textContent += '-'.repeat(15) + '\n';
        experience.forEach((exp: any) => {
          textContent += `${exp.position}\n`;
          textContent += `${exp.company} | ${exp.duration}\n`;
          if (exp.description) {
            textContent += `${exp.description}\n`;
          }
          textContent += '\n';
        });
      }
      
      // Education
      if (education && education.length > 0) {
        textContent += 'EDUCATION\n';
        textContent += '-'.repeat(9) + '\n';
        education.forEach((edu: any) => {
          textContent += `${edu.degree}\n`;
          textContent += `${edu.school} | ${edu.year}\n\n`;
        });
      }
      
      // Skills
      if (skills && skills.length > 0) {
        textContent += 'SKILLS\n';
        textContent += '-'.repeat(6) + '\n';
        textContent += skills.join(' • ') + '\n';
      }
      
      const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
      saveAs(blob, generateFileName('txt'));
    } catch (error) {
      console.error('TXT generation failed:', error);
      alert('Failed to generate text file. Please try again.');
    } finally {
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  const sendEmail = async (emailAddress: string, selectedFormats: string[] = ['pdf']) => {
    setIsGenerating(true);
    setCurrentFormat('EMAIL');
    
    try {
      // Generate all requested formats
      const attachments = [];
      
      for (const format of selectedFormats) {
        switch (format) {
          case 'pdf':
            await downloadAsPDF();
            break;
          case 'docx':
            await downloadAsWord();
            break;
          case 'html':
            downloadAsHTML();
            break;
          case 'png':
            await downloadAsImage('png');
            break;
          case 'jpg':
            await downloadAsImage('jpg');
            break;
          case 'txt':
            downloadAsText();
            break;
        }
      }

      // Create email content
      const subject = `Resume - ${resumeData.personalInfo?.fullName || 'Professional Resume'}`;
      const body = `Dear Hiring Manager,

Please find my resume attached in the requested format(s).

I look forward to hearing from you.

Best regards,
${resumeData.personalInfo?.fullName || 'Job Applicant'}

---
This resume was generated using ResumeTeacher - Professional Resume Builder
`;

      // Open email client
      const mailtoLink = `mailto:${emailAddress}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.open(mailtoLink);
      
      alert(`Email client opened! Please attach the downloaded files and send your email to ${emailAddress}`);
    } catch (error) {
      console.error('Email preparation failed:', error);
      alert('Failed to prepare email. Please try downloading files manually.');
    } finally {
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  const saveToCloud = async (cloudService: 'gdrive' | 'dropbox' = 'gdrive') => {
    setIsGenerating(true);
    setCurrentFormat('CLOUD');
    
    try {
      // Generate PDF for cloud storage
      await downloadAsPDF();
      
      // Simulate cloud upload (in real implementation, you'd integrate with cloud APIs)
      setTimeout(() => {
        alert(`Resume saved to ${cloudService === 'gdrive' ? 'Google Drive' : 'Dropbox'}! Check your downloads folder for the file.`);
        setIsGenerating(false);
        setCurrentFormat('');
      }, 2000);
    } catch (error) {
      console.error('Cloud save failed:', error);
      alert('Failed to save to cloud. Please try downloading manually.');
      setIsGenerating(false);
      setCurrentFormat('');
    }
  };

  return {
    downloadAsPDF,
    downloadAsWord,
    downloadAsImage,
    downloadAsHTML,
    downloadAsText: () => {}, // Keeping existing function
    sendEmail: () => {}, // Keeping existing function
    saveToCloud: () => {}, // Keeping existing function
    isGenerating,
    currentFormat,
    generateFileName
  };
}
