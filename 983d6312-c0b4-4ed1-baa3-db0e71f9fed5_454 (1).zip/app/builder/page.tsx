'use client';

import { useState, useEffect, useRef } from 'react';
import PersonalInfoSection from './sections/PersonalInfoSection';
import ExperienceSection from './sections/ExperienceSection';
import EducationSection from './sections/EducationSection';
import SkillsSection from './sections/SkillsSection';
import SummarySection from './sections/SummarySection';
import CertificationsSection from './sections/CertificationsSection';
import ReferencesSection from './sections/ReferencesSection';
import ResumePreview from './ResumePreview';
import TemplateSelector from './TemplateSelector';
import PaymentModal from './PaymentModal';
import ImportModal from './ImportModal';
import AIAssistant from '../../components/AIAssistant';
import LanguagesSection from './sections/LanguagesSection';

export default function ResumeBuilder() {
  const [currentStep, setCurrentStep] = useState('template');
  const [currentFormStep, setCurrentFormStep] = useState(0);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [showFullscreenPreview, setShowFullscreenPreview] = useState(false);
  const [paymentAction, setPaymentAction] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [showAiTips, setShowAiTips] = useState(true);
  const previewRef = useRef<HTMLDivElement>(null);
  
  const [resumeData, setResumeData] = useState({
    template: '',
    personalInfo: {
      firstName: '',
      lastName: '',
      jobTitle: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      country: '',
      nationality: '',
      drivingLicense: '',
      linkedin: '',
      website: '',
      photo: null
    },
    experience: [],
    education: [],
    skills: [],
    languages: [],
    summary: '',
    certifications: [],
    references: {
      showReferences: false,
      referencesType: 'upon-request',
      references: []
    }
  });

  const formSteps = [
    { 
      id: 0, 
      name: 'Personal Info', 
      icon: 'ri-user-3-line', 
      color: 'from-blue-400 to-blue-600',
      description: 'Your contact details and basic information',
      aiTip: 'Use a professional email and ensure all contact information is current'
    },
    { 
      id: 1, 
      name: 'Work Experience', 
      icon: 'ri-briefcase-line', 
      color: 'from-emerald-400 to-emerald-600',
      description: 'Your professional work history and achievements',
      aiTip: 'Focus on quantifiable achievements and use action verbs'
    },
    { 
      id: 2, 
      name: 'Education', 
      icon: 'ri-graduation-cap-line', 
      color: 'from-purple-400 to-purple-600',
      description: 'Your academic background and qualifications',
      aiTip: 'Include relevant coursework and academic achievements'
    },
    { 
      id: 3, 
      name: 'Certifications', 
      icon: 'ri-award-line', 
      color: 'from-orange-400 to-orange-600',
      description: 'Professional certifications and licenses',
      aiTip: 'Add certifications that are relevant to your target role'
    },
    { 
      id: 4, 
      name: 'Skills', 
      icon: 'ri-code-s-slash-line', 
      color: 'from-red-400 to-red-600',
      description: 'Technical and soft skills',
      aiTip: 'Balance technical skills with soft skills and leadership abilities'
    },
    { 
      id: 5, 
      name: 'Languages', 
      icon: 'ri-global-line', 
      color: 'from-cyan-400 to-cyan-600',
      description: 'Languages you speak and proficiency levels',
      aiTip: 'Be honest about your proficiency levels and include relevant languages'
    },
    { 
      id: 6, 
      name: 'References', 
      icon: 'ri-contacts-line', 
      color: 'from-pink-400 to-pink-600',
      description: 'Professional references and contacts',
      aiTip: 'Choose references who can speak to your professional abilities'
    },
    { 
      id: 7, 
      name: 'Summary', 
      icon: 'ri-file-text-line', 
      color: 'from-indigo-400 to-indigo-600',
      description: 'Professional summary and career objective',
      aiTip: 'Keep it concise and highlight your unique value proposition'
    },
    { 
      id: 8, 
      name: 'Review & Export', 
      icon: 'ri-check-double-line', 
      color: 'from-emerald-500 to-teal-600',
      description: 'Finalize and download your resume',
      aiTip: 'Review all sections and customize for each job application'
    }
  ];

  const getCompletionPercentage = () => {
    let completedSteps = 0;
    if (resumeData.personalInfo.firstName && resumeData.personalInfo.lastName && resumeData.personalInfo.email) completedSteps++;
    if (resumeData.experience.length > 0) completedSteps++;
    if (resumeData.education.length > 0) completedSteps++;
    if (resumeData.skills.length > 0) completedSteps++;
    if (resumeData.languages.length > 0) completedSteps++;
    if (resumeData.summary) completedSteps++;
    return Math.round((completedSteps / 8) * 100);
  };

  const isStepCompleted = (stepId) => {
    switch (stepId) {
      case 0: return resumeData.personalInfo.firstName && resumeData.personalInfo.lastName && resumeData.personalInfo.email;
      case 1: return resumeData.experience.length > 0;
      case 2: return resumeData.education.length > 0;
      case 3: return resumeData.certifications.length > 0;
      case 4: return resumeData.skills.length > 0;
      case 5: return resumeData.languages.length > 0;
      case 6: return resumeData.references.showReferences;
      case 7: return resumeData.summary.length > 0;
      case 8: return true;
      default: return false;
    }
  };

  const handleTemplateSelect = (templateId) => {
    setResumeData({
      ...resumeData,
      template: templateId
    });
    setCurrentStep('form');
  };

  const handlePaymentAction = (action) => {
    setPaymentAction(action);
    setShowPaymentModal(true);
  };

  const handleAiSuggestion = (suggestion: string) => {
    // This will be handled by individual sections
    console.log('AI Suggestion:', suggestion);
  };

  const getCurrentSectionName = () => {
    return formSteps[currentFormStep]?.name.toLowerCase().replace(' ', '');
  };

  const renderCurrentSection = () => {
    const sectionProps = {
      resumeData,
      setResumeData,
      onAiSuggestion: handleAiSuggestion
    };

    switch (currentFormStep) {
      case 0:
        return <PersonalInfoSection {...sectionProps} />;
      case 1:
        return <ExperienceSection {...sectionProps} />;
      case 2:
        return <EducationSection {...sectionProps} />;
      case 3:
        return <CertificationsSection {...sectionProps} />;
      case 4:
        return <SkillsSection {...sectionProps} />;
      case 5:
        return <LanguagesSection 
          languages={resumeData.languages}
          onChange={(languages) => setResumeData({...resumeData, languages})}
        />;
      case 6:
        return <ReferencesSection 
          data={resumeData.references}
          onChange={(data) => setResumeData({...resumeData, references: data})}
        />;
      case 7:
        return <SummarySection {...sectionProps} />;
      case 8:
        return (
          <div className="space-y-8">
            {/* Completion Status */}
            <div className="bg-gradient-to-r from-emerald-50 via-blue-50 to-purple-50 rounded-3xl p-8 border border-emerald-200">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-2">
                    Resume Complete! 🎉
                  </h2>
                  <p className="text-lg text-gray-600">Your professional resume is ready for download</p>
                </div>
                <div className="text-right">
                  <div className="text-4xl font-bold text-emerald-600">{getCompletionPercentage()}%</div>
                  <div className="text-sm text-gray-500">Complete</div>
                </div>
              </div>
              
              <div className="w-full bg-white/80 rounded-full h-4 mb-4 shadow-inner">
                <div 
                  className="bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-500 h-4 rounded-full transition-all duration-1000 shadow-sm"
                  style={{ width: `${getCompletionPercentage()}%` }}
                ></div>
              </div>
              
              <div className="grid grid-cols-4 gap-4 text-center">
                <div className="bg-white/70 rounded-xl p-3">
                  <div className="text-2xl font-bold text-blue-600">{resumeData.experience.length}</div>
                  <div className="text-xs text-gray-600">Experience</div>
                </div>
                <div className="bg-white/70 rounded-xl p-3">
                  <div className="text-2xl font-bold text-purple-600">{resumeData.skills.length}</div>
                  <div className="text-xs text-gray-600">Skills</div>
                </div>
                <div className="bg-white/70 rounded-xl p-3">
                  <div className="text-2xl font-bold text-emerald-600">{resumeData.education.length}</div>
                  <div className="text-xs text-gray-600">Education</div>
                </div>
                <div className="bg-white/70 rounded-xl p-3">
                  <div className="text-2xl font-bold text-cyan-600">{resumeData.languages.length}</div>
                  <div className="text-xs text-gray-600">Languages</div>
                </div>
              </div>
            </div>

            {/* Action Cards */}
            <div className="grid md:grid-cols-2 gap-6">
              <div 
                onClick={() => handlePaymentAction('download')}
                className="group relative overflow-hidden bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl p-8 cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-500/20 backdrop-blur-sm"></div>
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <i className="ri-download-cloud-line text-3xl text-white"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Download Resume</h3>
                  <p className="text-blue-100 mb-4">Get your resume in PDF, Word, and other formats</p>
                  <div className="flex items-center text-white/80 text-sm">
                    <i className="ri-check-line mr-2"></i>
                    <span>Multiple formats available</span>
                  </div>
                </div>
              </div>

              <div 
                onClick={() => handlePaymentAction('email')}
                className="group relative overflow-hidden bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-8 cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-teal-500/20 backdrop-blur-sm"></div>
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <i className="ri-mail-send-line text-3xl text-white"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Email Resume</h3>
                  <p className="text-emerald-100 mb-4">Send directly to employers or your email</p>
                  <div className="flex items-center text-white/80 text-sm">
                    <i className="ri-check-line mr-2"></i>
                    <span>Professional email formatting</span>
                  </div>
                </div>
              </div>

              <div 
                onClick={() => handlePaymentAction('print')}
                className="group relative overflow-hidden bg-gradient-to-br from-orange-500 to-red-500 rounded-3xl p-8 cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-orange-400/20 to-red-400/20 backdrop-blur-sm"></div>
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <i className="ri-printer-line text-3xl text-white"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Print Resume</h3>
                  <p className="text-orange-100 mb-4">High-quality print-ready version</p>
                  <div className="flex items-center text-white/80 text-sm">
                    <i className="ri-check-line mr-2"></i>
                    <span>Optimized for printing</span>
                  </div>
                </div>
              </div>

              <div 
                onClick={() => setShowImportModal(true)}
                className="group relative overflow-hidden bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl p-8 cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400/20 to-pink-400/20 backdrop-blur-sm"></div>
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <i className="ri-upload-cloud-line text-3xl text-white"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Import Resume</h3>
                  <p className="text-purple-100 mb-4">Upload existing resume to auto-fill</p>
                  <div className="flex items-center text-white/80 text-sm">
                    <i className="ri-check-line mr-2"></i>
                    <span>AI-powered extraction</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Premium Notice */}
            <div className="bg-gradient-to-r from-amber-50 via-yellow-50 to-orange-50 border-2 border-amber-200 rounded-3xl p-8">
              <div className="flex items-start space-x-6">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <i className="ri-vip-crown-line text-white text-2xl"></i>
                </div>
                <div className="flex-1">
                  <h4 className="text-2xl font-bold text-amber-900 mb-3">Unlock Premium Features</h4>
                  <p className="text-amber-800 mb-6 text-lg">
                    Get the most out of your resume with our premium features
                  </p>
                  <div className="grid md:grid-cols-2 gap-4 text-amber-700">
                    <div className="flex items-center space-x-3">
                      <i className="ri-check-line text-amber-600 text-lg"></i>
                      <span>Remove watermarks completely</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-check-line text-amber-600 text-lg"></i>
                      <span>Download in all formats</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-check-line text-amber-600 text-lg"></i>
                      <span>Direct email to employers</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-check-line text-amber-600 text-lg"></i>
                      <span>Advanced AI assistance</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const handleFullscreenToggle = () => {
    setShowFullscreenPreview(!showFullscreenPreview);
  };

  // Handle escape key to close fullscreen
  useEffect(() => {
    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && showFullscreenPreview) {
        setShowFullscreenPreview(false);
      }
    };

    document.addEventListener('keydown', handleEscapeKey);
    return () => document.removeEventListener('keydown', handleEscapeKey);
  }, [showFullscreenPreview]);

  // Template Selection Screen
  if (currentStep === 'template') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <div className="relative overflow-hidden">
          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-emerald-400/20 to-blue-600/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          </div>
          
          <div className="relative z-10 max-w-7xl mx-auto p-8">
            {/* Header */}
            <div className="text-center mb-12">
              <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent mb-6">
                Choose Your Perfect Template
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Select from our collection of professionally designed templates, each optimized for different industries and career levels
              </p>
            </div>

            {/* Template Selector */}
            <div className="bg-white/70 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/30 p-8">
              <TemplateSelector 
                resumeData={resumeData} 
                setResumeData={setResumeData}
                onTemplateSelect={handleTemplateSelect}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Form Building Screen
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <div className="flex">
        {/* Enhanced Left Sidebar */}
        <div className="w-96 bg-white/80 backdrop-blur-xl shadow-2xl border-r border-white/30 min-h-screen">
          <div className="p-8">
            {/* Header */}
            <div className="mb-8">
              <button
                onClick={() => setCurrentStep('template')}
                className="flex items-center text-blue-600 hover:text-blue-700 mb-6 transition-colors group"
              >
                <i className="ri-arrow-left-line mr-2 group-hover:-translate-x-1 transition-transform"></i>
                <span className="text-sm font-medium">Change Template</span>
              </button>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-3">
                Resume Builder
              </h1>
              <p className="text-gray-600">Build your professional resume with AI assistance</p>
            </div>

            {/* AI Tips Card */}
            {showAiTips && formSteps[currentFormStep] && (
              <div className="mb-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl border border-purple-200">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center">
                    <i className="ri-lightbulb-line text-purple-600 mr-2"></i>
                    <span className="text-sm font-semibold text-purple-900">AI Tip</span>
                  </div>
                  <button 
                    onClick={() => setShowAiTips(false)}
                    className="text-purple-400 hover:text-purple-600 transition-colors"
                  >
                    <i className="ri-close-line text-sm"></i>
                  </button>
                </div>
                <p className="text-sm text-purple-800 leading-relaxed">
                  {formSteps[currentFormStep].aiTip}
                </p>
              </div>
            )}

            {/* Template Preview */}
            <div className="mb-8 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border border-blue-200">
              <div className="flex items-center mb-3">
                <i className="ri-palette-line text-blue-600 mr-2"></i>
                <span className="text-sm font-semibold text-blue-900">Selected Template</span>
              </div>
              <div className="text-sm text-blue-800 font-medium">
                {resumeData.template ? 
                  resumeData.template.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : 
                  'Professional Modern'
                }
              </div>
            </div>

            {/* Enhanced Progress Bar */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-semibold text-gray-700">Overall Progress</span>
                <span className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                  {getCompletionPercentage()}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 shadow-inner">
                <div 
                  className="bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-500 h-3 rounded-full transition-all duration-1000 shadow-sm"
                  style={{ width: `${getCompletionPercentage()}%` }}
                ></div>
              </div>
              <div className="mt-2 text-xs text-gray-500 text-center">
                {getCompletionPercentage() === 100 ? '🎉 Ready to export!' : 'Keep going, you\'re doing great!'}
              </div>
            </div>

            {/* Enhanced Steps Navigation */}
            <nav className="space-y-3">
              {formSteps.map((step, index) => (
                <button
                  key={step.id}
                  onClick={() => setCurrentFormStep(step.id)}
                  className={`w-full group relative overflow-hidden rounded-2xl transition-all duration-300 ${
                    currentFormStep === step.id
                      ? 'bg-gradient-to-r ' + step.color + ' text-white shadow-lg shadow-blue-500/25 scale-105'
                      : 'bg-white/60 hover:bg-white/80 border border-gray-200 hover:border-gray-300 hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center p-5">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center mr-4 transition-all ${
                      isStepCompleted(step.id)
                        ? currentFormStep === step.id 
                          ? 'bg-white/20 text-white' 
                          : 'bg-emerald-100 text-emerald-600'
                        : currentFormStep === step.id
                        ? 'bg-white/20 text-white'
                        : 'bg-gray-100 text-gray-500 group-hover:bg-gray-200'
                    }`}>
                      {isStepCompleted(step.id) ? (
                        <i className="ri-check-line text-xl font-bold"></i>
                      ) : (
                        <i className={`${step.icon} text-xl`}></i>
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <div className={`font-bold text-lg ${
                        currentFormStep === step.id ? 'text-white' : 'text-gray-800'
                      }`}>
                        {step.name}
                      </div>
                      <div className={`text-sm ${
                        currentFormStep === step.id ? 'text-white/80' : 'text-gray-500'
                      }`}>
                        {step.description}
                      </div>
                    </div>
                    {isStepCompleted(step.id) && (
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        currentFormStep === step.id ? 'bg-white/20' : 'bg-emerald-500'
                      }`}>
                        <i className={`ri-check-line text-sm ${
                          currentFormStep === step.id ? 'text-white' : 'text-white'
                        }`}></i>
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main Content - Full Width */}
        <div className="flex-1">
          {/* Enhanced Form Section */}
          <div className="p-8 lg:p-12">
            {/* Current Step Header */}
            <div className="mb-8 text-center">
              <div className={`inline-flex items-center px-6 py-3 rounded-full text-white font-semibold mb-4 bg-gradient-to-r ${formSteps[currentFormStep]?.color}`}>
                <i className={`${formSteps[currentFormStep]?.icon} mr-2 text-xl`}></i>
                Step {currentFormStep + 1} of {formSteps.length}
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {formSteps[currentFormStep]?.name}
              </h2>
              <p className="text-gray-600 text-lg">
                {formSteps[currentFormStep]?.description}
              </p>
            </div>

            {/* AI Assistant Integration */}
            <div className="mb-8 flex justify-center">
              <AIAssistant 
                section={getCurrentSectionName()}
                context={resumeData}
                onSuggestion={handleAiSuggestion}
              />
            </div>

            {/* Form Content */}
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/50 p-8 lg:p-10 mb-10">
              {renderCurrentSection()}
            </div>
            
            {/* Enhanced Navigation Buttons */}
            {currentFormStep < 8 && (
              <div className="flex justify-between items-center mb-10">
                <button
                  onClick={() => setCurrentFormStep(Math.max(0, currentFormStep - 1))}
                  disabled={currentFormStep === 0}
                  className={`flex items-center px-8 py-4 font-semibold rounded-2xl transition-all ${
                    currentFormStep === 0
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : 'bg-white text-gray-700 border-2 border-gray-200 hover:border-gray-400 hover:bg-gray-50 hover:shadow-lg hover:-translate-y-1'
                  }`}
                >
                  <i className="ri-arrow-left-line mr-2"></i>
                  Previous
                </button>

                <div className="flex space-x-2">
                  {formSteps.slice(0, -1).map((_, index) => (
                    <div
                      key={index}
                      className={`w-3 h-3 rounded-full transition-all ${
                        index <= currentFormStep ? 'bg-blue-500' : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={() => setCurrentFormStep(Math.min(8, currentFormStep + 1))}
                  className="flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all hover:shadow-lg hover:-translate-y-1"
                >
                  {currentFormStep === 7 ? 'Review & Export' : 'Next Step'}
                  <i className="ri-arrow-right-line ml-2"></i>
                </button>
              </div>
            )}

            {/* Live Resume Preview Section - Now Below Form */}
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/50 p-8 lg:p-10">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 flex items-center mb-2">
                    <i className="ri-eye-line mr-3 text-blue-600"></i>
                    Live Resume Preview
                  </h3>
                  <p className="text-gray-600">See how your resume looks as you build it</p>
                </div>
                <div className="flex items-center space-x-4">
                  {/* Preview Stats */}
                  <div className="flex space-x-4">
                    <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl px-4 py-2 text-center">
                      <div className="text-lg font-bold text-blue-600">{resumeData.experience.length}</div>
                      <div className="text-xs text-blue-800">Positions</div>
                    </div>
                    <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl px-4 py-2 text-center">
                      <div className="text-lg font-bold text-purple-600">{resumeData.skills.length}</div>
                      <div className="text-xs text-purple-800">Skills</div>
                    </div>
                    <div className="bg-gradient-to-r from-emerald-50 to-emerald-100 rounded-xl px-4 py-2 text-center">
                      <div className="text-lg font-bold text-emerald-600">{getCompletionPercentage()}%</div>
                      <div className="text-xs text-emerald-800">Complete</div>
                    </div>
                  </div>
                  <button 
                    onClick={handleFullscreenToggle}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all hover:scale-105 shadow-lg"
                    title="View Fullscreen"
                  >
                    <i className="ri-fullscreen-line"></i>
                    <span className="whitespace-nowrap">Fullscreen</span>
                  </button>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-6 border border-gray-200">
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden max-w-4xl mx-auto">
                  <div ref={previewRef} className="transform scale-90 origin-top">
                    <ResumePreview resumeData={resumeData} showWatermark={true} />
                  </div>
                </div>
                
                {/* Preview Actions */}
                <div className="flex justify-center space-x-4 mt-6">
                  <button
                    onClick={() => handlePaymentAction('download')}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all hover:scale-105 shadow-lg"
                  >
                    <i className="ri-download-line"></i>
                    <span className="whitespace-nowrap">Download PDF</span>
                  </button>
                  <button
                    onClick={() => handlePaymentAction('email')}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all hover:scale-105 shadow-lg"
                  >
                    <i className="ri-mail-send-line"></i>
                    <span className="whitespace-nowrap">Email Resume</span>
                  </button>
                  <button
                    onClick={() => handlePaymentAction('print')}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl hover:from-orange-600 hover:to-orange-700 transition-all hover:scale-105 shadow-lg"
                  >
                    <i className="ri-printer-line"></i>
                    <span className="whitespace-nowrap">Print</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Fullscreen Preview Modal */}
      {showFullscreenPreview && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-5xl max-h-full bg-white rounded-2xl shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <i className="ri-file-text-line text-white text-lg"></i>
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Resume Preview</h2>
                  <p className="text-sm text-gray-600">
                    {resumeData.personalInfo.firstName} {resumeData.personalInfo.lastName}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handlePaymentAction('download')}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all flex items-center space-x-2"
                >
                  <i className="ri-download-line"></i>
                  <span>Download</span>
                </button>
                <button
                  onClick={handleFullscreenToggle}
                  className="w-10 h-10 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-xl flex items-center justify-center transition-all"
                  title="Close Fullscreen"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
            </div>
            
            {/* Modal Content */}
            <div className="max-h-[calc(100vh-200px)] overflow-y-auto p-6">
              <div className="flex justify-center">
                <div className="w-full max-w-4xl">
                  <ResumePreview 
                    resumeData={resumeData} 
                    selectedTemplate={resumeData.template}
                    showWatermark={false}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      {showPaymentModal && (
        <PaymentModal 
          action={paymentAction}
          onClose={() => setShowPaymentModal(false)}
          resumeData={resumeData}
          previewRef={previewRef}
        />
      )}

      {showImportModal && (
        <ImportModal 
          onClose={() => setShowImportModal(false)}
          onImport={(data) => {
            setResumeData(data);
            setShowImportModal(false);
          }}
        />
      )}
    </div>
  );
}