
import Link from 'next/link';

export default function CareerAdvicePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div>
                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Transform Your 
                  <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Career Journey</span>
                </h1>
                <p className="text-xl text-gray-600 mt-6 leading-relaxed">
                  Get expert career guidance tailored to your professional stage. From entry-level to executive positions, we provide proven strategies to accelerate your career growth.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/builder" className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors text-center whitespace-nowrap cursor-pointer">
                  Start Your Resume
                </Link>
                <Link href="/guides" className="border border-gray-300 text-gray-700 px-8 py-4 rounded-lg font-semibold hover:bg-gray-50 transition-colors text-center whitespace-nowrap cursor-pointer">
                  Browse Guides
                </Link>
              </div>

              <div className="flex items-center space-x-8 pt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">92%</div>
                  <div className="text-sm text-gray-600">Success Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">45K+</div>
                  <div className="text-sm text-gray-600">Careers Advanced</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">$15K+</div>
                  <div className="text-sm text-gray-600">Avg Salary Increase</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20career%20counselor%20consulting%20with%20client%20in%20modern%20office%20setting%2C%20career%20development%20discussion%2C%20business%20meeting%2C%20professional%20guidance%2C%20clean%20modern%20office%20environment%20with%20charts%20and%20career%20planning%20materials%2C%20bright%20natural%20lighting%2C%20professional%20atmosphere&width=600&height=500&seq=career-hero-1&orientation=landscape"
                alt="Career Consultation"
                className="rounded-2xl shadow-2xl object-cover w-full h-[500px]"
              />
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-gray-700">Live Career Support</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Career Stages Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Career Guidance for Every Stage
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Whether you're starting out, looking to advance, changing careers, or aiming for executive roles, we have the expertise to guide you.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-user-add-line text-2xl text-blue-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Entry Level</h3>
              <p className="text-gray-600 mb-6">
                Build a strong foundation with resume basics, interview preparation, and networking strategies for new graduates and career starters.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Resume writing fundamentals
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Interview preparation
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Professional networking
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-arrow-up-line text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Career Growth</h3>
              <p className="text-gray-600 mb-6">
                Accelerate your progression with leadership development, skill advancement, and strategic career moves for mid-level professionals.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Leadership development
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Promotion strategies
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Skill enhancement
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-exchange-line text-2xl text-purple-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Career Change</h3>
              <p className="text-gray-600 mb-6">
                Navigate successful transitions with industry research, transferable skills identification, and strategic repositioning.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Industry transition
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Skills assessment
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Strategic repositioning
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-crown-line text-2xl text-orange-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Executive Level</h3>
              <p className="text-gray-600 mb-6">
                Reach C-suite excellence with executive presence development, strategic vision planning, and board readiness preparation.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Executive presence
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Strategic leadership
                </li>
                <li className="flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  Board preparation
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Detailed Guidance Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Comprehensive Career Development
            </h2>
            <p className="text-xl text-gray-600">
              Deep-dive into specialized strategies for each career phase
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 mb-20">
            <div>
              <img 
                src="https://readdy.ai/api/search-image?query=Young%20professional%20writing%20resume%20at%20modern%20workspace%2C%20entry%20level%20career%20development%2C%20laptop%20computer%20with%20resume%20template%2C%20organized%20desk%20setup%2C%20professional%20development%20materials%2C%20bright%20clean%20office%20environment%2C%20career%20planning%20session&width=600&height=400&seq=entry-level-1&orientation=landscape"
                alt="Entry Level Career Development"
                className="rounded-xl shadow-lg object-cover w-full h-[400px] mb-8"
              />
            </div>
            <div className="space-y-8">
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-4">Entry-Level Career Blueprint</h3>
                <p className="text-lg text-gray-600 mb-6">
                  Start your career journey with confidence. Our entry-level guidance covers everything from crafting your first professional resume to acing interviews and building meaningful professional relationships.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-file-text-line text-blue-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Resume Foundation Building</h4>
                    <p className="text-gray-600">Learn to highlight your education, internships, projects, and transferable skills effectively. Master ATS optimization from day one.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-chat-1-line text-green-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Interview Excellence</h4>
                    <p className="text-gray-600">Prepare for behavioral questions, technical assessments, and salary negotiations. Practice with industry-specific scenarios.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-group-line text-purple-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Professional Networking</h4>
                    <p className="text-gray-600">Build meaningful connections through LinkedIn, industry events, and mentorship programs. Turn connections into opportunities.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 mb-20">
            <div className="order-2 lg:order-1 space-y-8">
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-4">Growth Acceleration Strategies</h3>
                <p className="text-lg text-gray-600 mb-6">
                  Take your career to the next level with proven advancement strategies. Learn to position yourself for promotions, develop leadership skills, and maximize your professional impact.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-award-line text-orange-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Leadership Development</h4>
                    <p className="text-gray-600">Cultivate essential leadership skills through project management, team collaboration, and strategic thinking exercises.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-rocket-line text-red-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Performance Optimization</h4>
                    <p className="text-gray-600">Master time management, goal setting, and performance metrics to consistently exceed expectations and stand out.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-lightbulb-line text-indigo-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Skill Enhancement</h4>
                    <p className="text-gray-600">Identify emerging skills in your industry and create a development plan to stay ahead of trends and market demands.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20business%20meeting%20with%20team%20leader%20presenting%20growth%20strategy%2C%20career%20advancement%20discussion%2C%20modern%20conference%20room%2C%20business%20charts%20and%20graphs%2C%20professional%20development%20planning%2C%20leadership%20skills%20demonstration%2C%20corporate%20environment&width=600&height=400&seq=growth-strategy-1&orientation=landscape"
                alt="Career Growth Strategy"
                className="rounded-xl shadow-lg object-cover w-full h-[400px] mb-8"
              />
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 mb-20">
            <div>
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20career%20transition%20planning%20session%2C%20career%20change%20consultation%2C%20industry%20research%20materials%2C%20career%20assessment%20tools%2C%20transition%20strategy%20planning%2C%20professional%20guidance%20meeting%2C%20modern%20office%20setting%20with%20career%20planning%20documents&width=600&height=400&seq=career-change-1&orientation=landscape"
                alt="Career Transition Planning"
                className="rounded-xl shadow-lg object-cover w-full h-[400px] mb-8"
              />
            </div>
            <div className="space-y-8">
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-4">Career Transition Guide</h3>
                <p className="text-lg text-gray-600 mb-6">
                  Navigate career changes with confidence. Whether switching industries, roles, or returning to work, our comprehensive transition strategies minimize risk and maximize success.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-search-line text-teal-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Skills Assessment & Gap Analysis</h4>
                    <p className="text-gray-600">Identify transferable skills and knowledge gaps. Create targeted learning plans to bridge skill requirements in your new field.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-map-line text-pink-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Industry Research & Positioning</h4>
                    <p className="text-gray-600">Understand new industry dynamics, key players, and success factors. Position your background as an asset rather than a limitation.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-shield-check-line text-yellow-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Risk Mitigation Strategies</h4>
                    <p className="text-gray-600">Plan your transition timeline, financial cushions, and backup options to ensure a smooth and secure career change.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            <div className="order-2 lg:order-1 space-y-8">
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-4">Executive Excellence Mastery</h3>
                <p className="text-lg text-gray-600 mb-6">
                  Prepare for C-suite leadership with advanced strategies for executive presence, strategic vision, and stakeholder management. Excel in board rooms and lead organizational transformation.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-violet-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-user-star-line text-violet-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Executive Presence Development</h4>
                    <p className="text-gray-600">Master commanding presence, persuasive communication, and authentic leadership that inspires confidence at all organizational levels.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-compass-line text-emerald-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Strategic Vision & Planning</h4>
                    <p className="text-gray-600">Develop long-term strategic thinking, market analysis capabilities, and the ability to guide organizations through complex transformations.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-cyan-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-team-line text-cyan-600"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Stakeholder Management</h4>
                    <p className="text-gray-600">Excel in board relations, investor communications, and cross-functional leadership. Build coalitions and drive organizational alignment.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <img 
                src="https://readdy.ai/api/search-image?query=Executive%20business%20leader%20in%20boardroom%20presentation%2C%20C-suite%20leadership%20meeting%2C%20strategic%20planning%20session%2C%20executive%20presence%20demonstration%2C%20corporate%20boardroom%20environment%2C%20professional%20leadership%20excellence%2C%20high-level%20business%20strategy%20discussion&width=600&height=400&seq=executive-leadership-1&orientation=landscape"
                alt="Executive Leadership Excellence"
                className="rounded-xl shadow-lg object-cover w-full h-[400px] mb-8"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Career Transformation Success Stories
            </h2>
            <p className="text-xl text-gray-600">
              Real professionals, real results, real career breakthroughs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20Asian%20woman%20software%20engineer%20in%20modern%20tech%20office%2C%20successful%20career%20advancement%2C%20confident%20business%20professional%2C%20technology%20workspace%20background%2C%20career%20success%20portrait%2C%20professional%20headshot%20style&width=80&height=80&seq=success-sarah-1&orientation=squarish"
                  alt="Sarah Chen"
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-bold text-gray-900">Sarah Chen</h3>
                  <p className="text-gray-600 text-sm">Software Engineer → Tech Lead</p>
                </div>
              </div>
              <div className="mb-4">
                <div className="text-2xl font-bold text-green-600 mb-2">+$32,000</div>
                <div className="text-sm text-gray-600">Salary increase in 8 months</div>
              </div>
              <p className="text-gray-700 mb-4">
                "ResumeTeacher's growth strategies helped me transition from individual contributor to team leadership. The promotion guidance was invaluable."
              </p>
              <div className="flex items-center text-yellow-500">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
              </div>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20Hispanic%20male%20business%20executive%20in%20corporate%20setting%2C%20successful%20career%20advancement%20to%20VP%20level%2C%20confident%20leadership%20portrait%2C%20modern%20office%20environment%2C%20executive%20business%20professional%2C%20leadership%20success%20story&width=80&height=80&seq=success-michael-1&orientation=squarish"
                  alt="Michael Rodriguez"
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-bold text-gray-900">Michael Rodriguez</h3>
                  <p className="text-gray-600 text-sm">Manager → VP Operations</p>
                </div>
              </div>
              <div className="mb-4">
                <div className="text-2xl font-bold text-green-600 mb-2">+$55,000</div>
                <div className="text-sm text-gray-600">Promotion in 14 months</div>
              </div>
              <p className="text-gray-700 mb-4">
                "The executive development roadmap was exactly what I needed. Went from middle management to VP level with clear strategic guidance."
              </p>
              <div className="flex items-center text-yellow-500">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
              </div>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20African%20American%20woman%20healthcare%20administrator%20in%20medical%20setting%2C%20successful%20career%20change%20from%20finance%20to%20healthcare%2C%20confident%20medical%20professional%2C%20hospital%20or%20clinic%20environment%2C%20career%20transition%20success%20story&width=80&height=80&seq=success-emily-1&orientation=squarish"
                  alt="Dr. Emily Watson"
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-bold text-gray-900">Dr. Emily Watson</h3>
                  <p className="text-gray-600 text-sm">Finance → Healthcare Admin</p>
                </div>
              </div>
              <div className="mb-4">
                <div className="text-2xl font-bold text-green-600 mb-2">+$28,000</div>
                <div className="text-sm text-gray-600">Career change success</div>
              </div>
              <p className="text-gray-700 mb-4">
                "The career transition guide made my industry switch possible. Now I'm thriving in healthcare administration with better work-life balance."
              </p>
              <div className="flex items-center text-yellow-500">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Industry-Specific Guidance */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Industry-Specific Career Guidance
            </h2>
            <p className="text-xl text-gray-600">
              Specialized advice tailored to your industry's unique requirements
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-8 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-blue-500 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-code-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Technology</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• FAANG interview preparation</li>
                <li>• Technical skill development</li>
                <li>• Startup vs corporate paths</li>
                <li>• Open source contributions</li>
                <li>• Tech leadership transition</li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-8 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-green-500 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-heart-pulse-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Healthcare</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• Medical residency matching</li>
                <li>• Clinical leadership roles</li>
                <li>• Healthcare administration</li>
                <li>• Telemedicine opportunities</li>
                <li>• Medical specialization</li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-8 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-purple-500 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-line-chart-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Finance</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• Investment banking prep</li>
                <li>• CFA certification path</li>
                <li>• FinTech opportunities</li>
                <li>• Risk management roles</li>
                <li>• Quantitative finance</li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-8 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="w-16 h-16 bg-orange-500 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-megaphone-line text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Marketing</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• Digital marketing mastery</li>
                <li>• Brand strategy development</li>
                <li>• Marketing analytics</li>
                <li>• Growth hacking techniques</li>
                <li>• CMO preparation path</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Resources Integration */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete Career Development Toolkit
            </h2>
            <p className="text-xl text-gray-600">
              Access all the tools and resources you need for career success
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Link href="/builder" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-file-text-line text-2xl text-blue-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">Resume Builder</h3>
              <p className="text-gray-600 mb-4">
                Create professional, ATS-optimized resumes with our intelligent builder. Choose from expert-designed templates.
              </p>
              <div className="flex items-center text-blue-600 font-medium">
                Build Resume <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/ats-resume-checker" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-search-line text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-green-600 transition-colors">ATS Checker</h3>
              <p className="text-gray-600 mb-4">
                Analyze your resume's ATS compatibility and get instant feedback on improvements for better visibility.
              </p>
              <div className="flex items-center text-green-600 font-medium">
                Check ATS Score <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/interview-tips" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-chat-1-line text-2xl text-purple-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-purple-600 transition-colors">Interview Tips</h3>
              <p className="text-gray-600 mb-4">
                Master interview techniques with proven strategies, common questions, and industry-specific preparation guides.
              </p>
              <div className="flex items-center text-purple-600 font-medium">
                Get Interview Tips <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/cover-letter" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
              <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-mail-line text-2xl text-orange-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-orange-600 transition-colors">Cover Letters</h3>
              <p className="text-gray-600 mb-4">
                Craft compelling cover letters that complement your resume and showcase your personality and motivation.
              </p>
              <div className="flex items-center text-orange-600 font-medium">
                Write Cover Letter <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/guides" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-book-line text-2xl text-red-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-red-600 transition-colors">Career Guides</h3>
              <p className="text-gray-600 mb-4">
                Access comprehensive guides covering resume writing, career planning, job search strategies, and more.
              </p>
              <div className="flex items-center text-red-600 font-medium">
                Browse Guides <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>

            <Link href="/blog" className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
              <div className="w-16 h-16 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-article-line text-2xl text-indigo-600"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-indigo-600 transition-colors">Career Blog</h3>
              <p className="text-gray-600 mb-4">
                Stay updated with the latest career trends, industry insights, and professional development tips.
              </p>
              <div className="flex items-center text-indigo-600 font-medium">
                Read Articles <i className="ri-arrow-right-line ml-2"></i>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Career?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of professionals who have accelerated their careers with ResumeTeacher's expert guidance.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/builder" className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-center whitespace-nowrap cursor-pointer">
              Start Building Your Resume
            </Link>
            <Link href="/contact" className="border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors text-center whitespace-nowrap cursor-pointer">
              Get Personal Consultation
            </Link>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-white">15K+</div>
              <div className="text-blue-100">Success Stories</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-white">92%</div>
              <div className="text-blue-100">Interview Success Rate</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-white">$18K+</div>
              <div className="text-blue-100">Average Salary Boost</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
