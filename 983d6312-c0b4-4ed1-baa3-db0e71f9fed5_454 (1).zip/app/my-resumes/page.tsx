'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface Resume {
  id: string;
  title: string;
  template: string;
  lastModified: string;
  status: 'draft' | 'completed';
  previewUrl?: string;
}

export default function MyResumesPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [resumes, setResumes] = useState<Resume[]>([
    {
      id: '1',
      title: 'Software Engineer Resume',
      template: 'Modern Professional',
      lastModified: '2024-01-15T10:30:00Z',
      status: 'completed'
    },
    {
      id: '2',
      title: 'Marketing Manager Resume',
      template: 'Creative Blue',
      lastModified: '2024-01-12T14:45:00Z',
      status: 'draft'
    },
    {
      id: '3',
      title: 'Project Manager Resume',
      template: 'Executive',
      lastModified: '2024-01-10T09:15:00Z',
      status: 'completed'
    }
  ]);

  useEffect(() => {
    const checkAuth = () => {
      const authStatus = localStorage.getItem('isAuthenticated');
      const userData = localStorage.getItem('user');
      
      if (authStatus === 'true' && userData) {
        setUser(JSON.parse(userData));
      } else {
        router.push('/login');
      }
      setLoading(false);
    };

    checkAuth();
  }, [router]);

  const handleDeleteResume = (resumeId: string) => {
    const confirmed = window.confirm('Are you sure you want to delete this resume?');
    if (confirmed) {
      setResumes(prev => prev.filter(resume => resume.id !== resumeId));
    }
  };

  const handleDuplicateResume = (resume: Resume) => {
    const duplicatedResume: Resume = {
      ...resume,
      id: Date.now().toString(),
      title: `${resume.title} (Copy)`,
      lastModified: new Date().toISOString(),
      status: 'draft'
    };
    setResumes(prev => [duplicatedResume, ...prev]);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your resumes...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">My Resumes</h1>
              <p className="text-gray-600 mt-2">Manage and organize all your resumes in one place</p>
            </div>
            <div className="flex items-center space-x-4">
              <Link 
                href="/dashboard"
                className="flex items-center px-4 py-2 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Back to Dashboard
              </Link>
              <Link 
                href="/builder"
                className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
              >
                <i className="ri-add-line mr-2"></i>
                Create New Resume
              </Link>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="ri-file-list-line text-2xl text-blue-600"></i>
              </div>
              <div className="ml-4">
                <h3 className="text-2xl font-bold text-gray-900">{resumes.length}</h3>
                <p className="text-gray-600">Total Resumes</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="ri-check-circle-line text-2xl text-green-600"></i>
              </div>
              <div className="ml-4">
                <h3 className="text-2xl font-bold text-gray-900">
                  {resumes.filter(r => r.status === 'completed').length}
                </h3>
                <p className="text-gray-600">Completed</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="ri-draft-line text-2xl text-orange-600"></i>
              </div>
              <div className="ml-4">
                <h3 className="text-2xl font-bold text-gray-900">
                  {resumes.filter(r => r.status === 'draft').length}
                </h3>
                <p className="text-gray-600">Drafts</p>
              </div>
            </div>
          </div>
        </div>

        {/* Resumes Grid */}
        {resumes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {resumes.map((resume) => (
              <div key={resume.id} className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
                {/* Resume Preview */}
                <div className="aspect-[3/4] bg-gray-100 rounded-t-xl relative overflow-hidden">
                  <div className="absolute inset-4 bg-white rounded-lg shadow-sm p-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      <div className="h-px bg-gray-200 my-3"></div>
                      <div className="space-y-1">
                        <div className="h-2 bg-gray-200 rounded w-full"></div>
                        <div className="h-2 bg-gray-200 rounded w-5/6"></div>
                        <div className="h-2 bg-gray-200 rounded w-3/4"></div>
                      </div>
                      <div className="h-px bg-gray-200 my-3"></div>
                      <div className="space-y-1">
                        <div className="h-2 bg-gray-200 rounded w-full"></div>
                        <div className="h-2 bg-gray-200 rounded w-4/5"></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Status Badge */}
                  <div className="absolute top-3 right-3">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      resume.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-orange-100 text-orange-800'
                    }`}>
                      {resume.status === 'completed' ? (
                        <><i className="ri-check-line mr-1"></i>Complete</>
                      ) : (
                        <><i className="ri-edit-line mr-1"></i>Draft</>
                      )}
                    </span>
                  </div>
                </div>

                {/* Resume Info */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{resume.title}</h3>
                  <p className="text-sm text-gray-600 mb-1">Template: {resume.template}</p>
                  <p className="text-sm text-gray-500 mb-4">
                    Last modified: {new Date(resume.lastModified).toLocaleDateString()}
                  </p>

                  {/* Actions */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Link 
                        href={`/builder?resume=${resume.id}`}
                        className="flex items-center px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
                      >
                        <i className="ri-edit-line mr-1"></i>
                        Edit
                      </Link>
                      <button 
                        onClick={() => handleDuplicateResume(resume)}
                        className="flex items-center px-3 py-2 text-sm text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap"
                      >
                        <i className="ri-file-copy-line mr-1"></i>
                        Duplicate
                      </button>
                    </div>

                    <div className="relative">
                      <button className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors">
                        <i className="ri-more-2-line"></i>
                      </button>
                      {/* Dropdown would go here */}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-file-list-line text-4xl text-gray-400"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No resumes yet</h3>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              Create your first resume to get started on your career journey. Our AI-powered builder makes it easy and fast.
            </p>
            <Link 
              href="/builder"
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
            >
              <i className="ri-add-line mr-2"></i>
              Create Your First Resume
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}