
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function ResourcesPage() {
  const [activeTab, setActiveTab] = useState('tools');
  const [selectedCalculator, setSelectedCalculator] = useState(null);

  const tabs = [
    { id: 'tools', name: 'Career Tools', icon: 'ri-tools-line' },
    { id: 'templates', name: 'Templates & Guides', icon: 'ri-book-line' },
    { id: 'calculators', name: 'Calculators', icon: 'ri-calculator-line' },
    { id: 'checklists', name: 'Checklists', icon: 'ri-checkbox-line' }
  ];

  const careerTools = [
    {
      id: 'ats-checker',
      name: 'ATS Resume Checker',
      description: 'Scan your resume for ATS compatibility and get suggestions to improve keyword optimization.',
      icon: 'ri-shield-check-line',
      color: 'blue',
      features: ['Keyword analysis', 'Format checking', 'Readability score', 'Industry comparison'],
      link: '/ats-resume-checker'
    },
    {
      id: 'skills-generator',
      name: 'AI Skills Generator',
      description: 'Generate relevant skills for your resume based on your job title and industry using AI.',
      icon: 'ri-magic-line',
      color: 'purple',
      features: ['AI-powered suggestions', 'Industry-specific skills', 'Trending technologies', 'Skill categorization'],
      link: '/ai-resume-skills-generator'
    },
    {
      id: 'resume-review',
      name: 'Resume Review Tool',
      description: 'Get instant AI-powered feedback on your resume with actionable improvement suggestions.',
      icon: 'ri-search-eye-line',
      color: 'green',
      features: ['Content analysis', 'Format review', 'Impact scoring', 'Improvement tips'],
      link: '/ai-review'
    },
    {
      id: 'cover-letter-builder',
      name: 'Cover Letter Builder',
      description: 'Create professional cover letters that complement your resume and impress employers.',
      icon: 'ri-file-edit-line',
      color: 'orange',
      features: ['Professional templates', 'AI assistance', 'Industry customization', 'Quick generation'],
      link: '/cover-letter'
    },
    {
      id: 'linkedin-optimizer',
      name: 'LinkedIn Optimizer',
      description: 'Optimize your LinkedIn profile with AI suggestions to attract more recruiters.',
      icon: 'ri-links-line',
      color: 'teal',
      features: ['Profile optimization', 'Keyword suggestions', 'Headline generator', 'Summary enhancement'],
      link: '/linkedin-optimizer'
    },
    {
      id: 'interview-simulator',
      name: 'Interview Simulator',
      description: 'Practice common interview questions with AI feedback to boost your confidence.',
      icon: 'ri-discuss-line',
      color: 'red',
      features: ['Question database', 'AI feedback', 'Video practice', 'Industry-specific scenarios'],
      link: '/interview-simulator'
    }
  ];

  const templatesAndGuides = [
    {
      category: 'Resume Templates',
      icon: 'ri-file-text-line',
      items: [
        { name: 'Professional Resume Template', type: 'Template', downloads: '45K+' },
        { name: 'Creative Resume Template', type: 'Template', downloads: '32K+' },
        { name: 'Executive Resume Template', type: 'Template', downloads: '28K+' },
        { name: 'Entry-Level Resume Template', type: 'Template', downloads: '38K+' }
      ]
    },
    {
      category: 'CV Templates',
      icon: 'ri-file-list-3-line',
      items: [
        { name: 'Academic CV Template', type: 'Template', downloads: '22K+' },
        { name: 'Medical CV Template', type: 'Template', downloads: '18K+' },
        { name: 'Research CV Template', type: 'Template', downloads: '15K+' },
        { name: 'Legal CV Template', type: 'Template', downloads: '12K+' }
      ]
    },
    {
      category: 'Cover Letter Templates',
      icon: 'ri-mail-line',
      items: [
        { name: 'Professional Cover Letter', type: 'Template', downloads: '35K+' },
        { name: 'Creative Cover Letter', type: 'Template', downloads: '24K+' },
        { name: 'Academic Cover Letter', type: 'Template', downloads: '16K+' },
        { name: 'Career Change Cover Letter', type: 'Template', downloads: '19K+' }
      ]
    },
    {
      category: 'Career Guides',
      icon: 'ri-book-open-line',
      items: [
        { name: 'Complete Resume Writing Guide', type: 'Guide', downloads: '67K+' },
        { name: 'Interview Preparation Manual', type: 'Guide', downloads: '54K+' },
        { name: 'Salary Negotiation Guide', type: 'Guide', downloads: '43K+' },
        { name: 'Career Change Handbook', type: 'Guide', downloads: '31K+' }
      ]
    }
  ];

  const calculators = [
    {
      id: 'salary',
      name: 'Salary Calculator',
      description: 'Calculate market salary ranges for your position, experience level, and location.',
      icon: 'ri-money-dollar-line',
      color: 'blue',
      inputs: ['Job Title', 'Experience Level', 'Location', 'Education'],
      results: ['Base Salary Range', 'Total Compensation', 'Market Percentile', 'Industry Comparison']
    },
    {
      id: 'career-timeline',
      name: 'Career Timeline Planner',
      description: 'Plan your career progression and set realistic goals with timeline visualization.',
      icon: 'ri-calendar-line',
      color: 'green',
      inputs: ['Current Role', 'Target Role', 'Skills Gap', 'Timeline'],
      results: ['Career Path', 'Milestone Dates', 'Required Skills', 'Action Plan']
    },
    {
      id: 'roi',
      name: 'Education ROI Calculator',
      description: 'Calculate the return on investment for certifications, degrees, and training programs.',
      icon: 'ri-graduation-cap-line',
      color: 'purple',
      inputs: ['Program Cost', 'Duration', 'Current Salary', 'Expected Increase'],
      results: ['Break-even Time', 'Lifetime ROI', 'Annual Benefit', 'Payback Period']
    },
    {
      id: 'job-match',
      name: 'Job Match Score',
      description: 'Analyze how well your skills match specific job requirements and opportunities.',
      icon: 'ri-target-line',
      color: 'orange',
      inputs: ['Your Skills', 'Job Requirements', 'Experience Level', 'Industry'],
      results: ['Match Percentage', 'Skill Gaps', 'Improvement Areas', 'Application Strength']
    }
  ];

  const checklists = [
    {
      category: 'Job Search',
      icon: 'ri-search-line',
      color: 'blue',
      items: [
        'Update resume and LinkedIn profile',
        'Research target companies and roles',
        'Set up job alerts on multiple platforms',
        'Prepare elevator pitch and interview responses',
        'Build and activate professional network',
        'Organize application tracking system',
        'Practice interview skills regularly',
        'Prepare references and portfolio'
      ]
    },
    {
      category: 'Interview Preparation',
      icon: 'ri-discuss-line',
      color: 'green',
      items: [
        'Research company history and culture',
        'Study job description thoroughly',
        'Prepare STAR method examples',
        'Plan interview outfit and logistics',
        'Prepare thoughtful questions to ask',
        'Practice common interview questions',
        'Review your resume and portfolio',
        'Plan follow-up thank you message'
      ]
    },
    {
      category: 'Resume Optimization',
      icon: 'ri-file-text-line',
      color: 'purple',
      items: [
        'Tailor resume to specific job posting',
        'Include relevant keywords from job description',
        'Quantify achievements with specific numbers',
        'Use strong action verbs throughout',
        'Ensure ATS-friendly formatting',
        'Proofread for grammar and consistency',
        'Get feedback from industry professionals',
        'Test resume with ATS checker tools'
      ]
    },
    {
      category: 'Career Development',
      icon: 'ri-line-chart-line',
      color: 'orange',
      items: [
        'Set clear short and long-term career goals',
        'Identify skill gaps in target roles',
        'Create professional development plan',
        'Build mentor and sponsor relationships',
        'Attend industry events and conferences',
        'Maintain and expand professional network',
        'Seek feedback regularly from supervisors',
        'Document achievements and learnings'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/resume" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Resume
              </Link>
              <Link href="/cv" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                CV
              </Link>
              <Link href="/cover-letter" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Cover Letter
              </Link>
              <Link href="/advice" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Advice
              </Link>
              <Link href="/resources" className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-1 whitespace-nowrap">
                Resources
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-emerald-50 to-teal-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Career Resources & Tools
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Everything you need to succeed in your career journey. From AI-powered tools to downloadable templates, 
            we've got you covered with professional resources.
          </p>
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setActiveTab('tools')}
              className="inline-flex items-center px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors whitespace-nowrap"
            >
              <i className="ri-tools-line mr-2"></i>
              Explore Tools
            </button>
            <button
              onClick={() => setActiveTab('templates')}
              className="inline-flex items-center px-6 py-3 border-2 border-emerald-600 text-emerald-600 rounded-lg hover:bg-emerald-50 transition-colors whitespace-nowrap"
            >
              <i className="ri-book-line mr-2"></i>
              Browse Templates
            </button>
          </div>
        </div>
      </section>

      {/* Tabs Navigation */}
      <section className="py-8 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-6 py-3 rounded-lg border-2 transition-all duration-300 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-white text-gray-700 border-gray-200 hover:border-emerald-300 hover:text-emerald-600'
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Tab */}
      {activeTab === 'tools' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Professional Career Tools</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                AI-powered tools and interactive features to optimize your job search and career development.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {careerTools.map((tool) => (
                <div key={tool.id} className={`bg-gradient-to-br from-${tool.color}-50 to-${tool.color}-100 border border-${tool.color}-200 rounded-xl p-6 hover:shadow-xl transition-all duration-300 group`}>
                  <div className={`w-12 h-12 bg-${tool.color}-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <i className={`${tool.icon} text-white text-xl`}></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{tool.name}</h3>
                  <p className="text-gray-600 mb-4">{tool.description}</p>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Features:</h4>
                    <div className="flex flex-wrap gap-2">
                      {tool.features.map((feature, index) => (
                        <span key={index} className={`bg-${tool.color}-100 text-${tool.color}-700 px-2 py-1 rounded text-sm`}>
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <Link href={tool.link} className={`inline-flex items-center text-${tool.color}-600 font-semibold hover:text-${tool.color}-700 transition-colors`}>
                    Use Tool
                    <i className="ri-arrow-right-line ml-2"></i>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Templates Tab */}
      {activeTab === 'templates' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Templates & Guides Collection</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Professional templates and comprehensive guides to support every stage of your career journey.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {templatesAndGuides.map((category, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-xl p-8 hover:shadow-lg transition-shadow">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-emerald-600 rounded-lg flex items-center justify-center mr-4">
                      <i className={`${category.icon} text-white text-xl`}></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">{category.category}</h3>
                  </div>
                  
                  <div className="space-y-4">
                    {category.items.map((item, itemIndex) => (
                      <div key={itemIndex} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                        <div>
                          <h4 className="font-medium text-gray-900">{item.name}</h4>
                          <div className="flex items-center space-x-4 mt-1">
                            <span className="text-sm text-emerald-600 font-medium">{item.type}</span>
                            <span className="text-sm text-gray-500">{item.downloads} downloads</span>
                          </div>
                        </div>
                        <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm whitespace-nowrap">
                          Download
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Calculators Tab */}
      {activeTab === 'calculators' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Career Calculators</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Make informed career decisions with our interactive calculators and planning tools.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {calculators.map((calculator) => (
                <div key={calculator.id} className={`bg-gradient-to-br from-${calculator.color}-50 to-${calculator.color}-100 border border-${calculator.color}-200 rounded-xl p-8 hover:shadow-xl transition-all duration-300`}>
                  <div className={`w-16 h-16 bg-${calculator.color}-600 rounded-full flex items-center justify-center mx-auto mb-6`}>
                    <i className={`${calculator.icon} text-white text-2xl`}></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 text-center">{calculator.name}</h3>
                  <p className="text-gray-600 mb-6 text-center">{calculator.description}</p>
                  
                  <div className="grid grid-cols-2 gap-6 mb-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Inputs:</h4>
                      <ul className="space-y-1">
                        {calculator.inputs.map((input, index) => (
                          <li key={index} className="text-sm text-gray-600 flex items-center">
                            <i className="ri-arrow-right-s-line text-gray-400 mr-1"></i>
                            {input}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Results:</h4>
                      <ul className="space-y-1">
                        {calculator.results.map((result, index) => (
                          <li key={index} className="text-sm text-gray-600 flex items-center">
                            <i className={`ri-check-line text-${calculator.color}-600 mr-1`}></i>
                            {result}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setSelectedCalculator(calculator.id)}
                    className={`w-full px-6 py-3 bg-${calculator.color}-600 text-white rounded-lg hover:bg-${calculator.color}-700 transition-colors font-semibold`}
                  >
                    Launch Calculator
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Checklists Tab */}
      {activeTab === 'checklists' && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Career Checklists</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Comprehensive checklists to keep you organized and on track throughout your career journey.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {checklists.map((checklist, index) => (
                <div key={index} className={`bg-${checklist.color}-50 border border-${checklist.color}-200 rounded-xl p-8`}>
                  <div className="flex items-center mb-6">
                    <div className={`w-12 h-12 bg-${checklist.color}-600 rounded-lg flex items-center justify-center mr-4`}>
                      <i className={`${checklist.icon} text-white text-xl`}></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">{checklist.category} Checklist</h3>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    {checklist.items.map((item, itemIndex) => (
                      <label key={itemIndex} className="flex items-start space-x-3 cursor-pointer group">
                        <input
                          type="checkbox"
                          className={`w-5 h-5 text-${checklist.color}-600 bg-white border-2 border-gray-300 rounded focus:ring-${checklist.color}-500 focus:ring-2 mt-0.5`}
                        />
                        <span className="text-gray-700 group-hover:text-gray-900 transition-colors">
                          {item}
                        </span>
                      </label>
                    ))}
                  </div>
                  
                  <button className={`w-full px-6 py-3 bg-${checklist.color}-600 text-white rounded-lg hover:bg-${checklist.color}-700 transition-colors font-semibold`}>
                    Download PDF Checklist
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Trusted by Professionals Worldwide</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join millions of professionals who have used our resources to advance their careers.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-600 mb-2">2.5M+</div>
              <p className="text-gray-600">Users Worldwide</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">850K+</div>
              <p className="text-gray-600">Templates Downloaded</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">1.2M+</div>
              <p className="text-gray-600">Resumes Created</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">92%</div>
              <p className="text-gray-600">Success Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-emerald-600 to-teal-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Start Building Your Career Today
          </h2>
          <p className="text-xl text-emerald-100 mb-8 max-w-3xl mx-auto">
            Use our professional tools and resources to create a resume that opens doors to new opportunities.
          </p>
          <Link href="/builder" className="inline-flex items-center px-8 py-4 bg-white text-emerald-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-rocket-2-line mr-2"></i>
            Build Resume Now
          </Link>
        </div>
      </section>
    </div>
  );
}
