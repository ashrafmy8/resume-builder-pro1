
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function CoverLetterPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', name: 'Cover Letter Guide', icon: 'ri-file-edit-line' },
    { id: 'templates', name: 'Templates', icon: 'ri-layout-2-line' },
    { id: 'examples', name: 'Examples', icon: 'ri-newspaper-line' },
    { id: 'builder', name: 'Builder', icon: 'ri-edit-2-line' }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-['Pacifico'] text-blue-600">ResumeTeacher</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/builder" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Builder
              </Link>
              <Link href="/resume" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Resume
              </Link>
              <Link href="/cv" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                CV
              </Link>
              <Link href="/cover-letter" className="text-blue-600 font-semibold border-b-2 border-blue-600 pb-1 whitespace-nowrap">
                Cover Letter
              </Link>
              <Link href="/advice" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Advice
              </Link>
              <Link href="/resources" className="text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap">
                Resources
              </Link>
            </nav>

            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap">
                Login
              </Link>
              <Link href="/signup" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                Free Account
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-50 to-pink-100 py-20 relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=Modern%20professional%20woman%20writing%20cover%20letter%20at%20elegant%20desk%20with%20laptop%20and%20documents%2C%20bright%20contemporary%20office%20space%20with%20natural%20lighting%2C%20focused%20and%20confident%20expression%2C%20minimalist%20workspace%20design%20with%20plants%20and%20coffee%20cup%2C%20inspiring%20career%20development%20atmosphere&width=1200&height=600&seq=cover-letter-hero&orientation=landscape"
            alt="Cover Letter Writing"
            className="w-full h-full object-cover object-top opacity-20"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Professional Cover Letter Builder
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Create compelling cover letters that complement your resume and grab employers' attention. 
            Stand out from the competition with personalized, professional cover letters.
          </p>
          <Link href="/cover-letter-builder" className="inline-flex items-center px-8 py-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-file-edit-line mr-2"></i>
            Create Cover Letter
          </Link>
        </div>
      </section>

      {/* Quick Navigation */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <Link href="/cover-letter-builder" className="group bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-xl p-8 hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-edit-2-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Cover Letter Builder</h3>
              <p className="text-gray-600 text-center">Create professional cover letters with our AI-powered builder</p>
            </Link>

            <Link href="/cover-letter-templates" className="group bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-8 hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-layout-2-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Cover Letter Templates</h3>
              <p className="text-gray-600 text-center">Browse professional templates for different industries</p>
            </Link>

            <Link href="/cover-letter-examples" className="group bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl p-8 hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <i className="ri-newspaper-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Cover Letter Examples</h3>
              <p className="text-gray-600 text-center">Learn from successful cover letter examples</p>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Write Your Winning Cover Letter?
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
            Create a compelling cover letter that complements your resume and gets you noticed by employers.
          </p>
          <Link href="/cover-letter-builder" className="inline-flex items-center px-8 py-4 bg-white text-purple-600 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap">
            <i className="ri-edit-2-line mr-2"></i>
            Start Writing Now
          </Link>
        </div>
      </section>
    </div>
  );
}
