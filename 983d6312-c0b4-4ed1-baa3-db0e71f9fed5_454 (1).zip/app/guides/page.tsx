
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../../components/Header';

export default function GuidesPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Resume Writing', 'Cover Letters', 'Interview Prep', 'Career Change', 'Industry Specific'];

  const guides = [
    {
      id: 1,
      title: "Complete Resume Writing Guide for 2024",
      description: "Master the art of resume writing with our comprehensive step-by-step guide covering everything from formatting to content optimization.",
      category: "Resume Writing",
      difficulty: "Beginner",
      readTime: "25 min read",
      chapters: 12,
      image: "https://readdy.ai/api/search-image?query=Professional%20resume%20writing%20guide%20with%20modern%20templates%20displayed%20on%20desk%2C%20organized%20workspace%20with%20laptop%20and%20coffee%2C%20bright%20natural%20lighting%2C%20clean%20business%20environment%2C%20inspiring%20career%20development%20atmosphere&width=400&height=250&seq=resume-writing-guide&orientation=landscape",
      featured: true
    },
    {
      id: 2,
      title: "Career Change Playbook: Pivot Successfully",
      description: "Navigate career transitions with confidence using proven strategies for switching industries, roles, or career paths.",
      category: "Career Change",
      difficulty: "Intermediate",
      readTime: "30 min read",
      chapters: 15,
      image: "https://readdy.ai/api/search-image?query=Professional%20woman%20at%20crossroads%20choosing%20career%20path%2C%20multiple%20directional%20signs%20showing%20different%20career%20options%2C%20bright%20modern%20office%20background%2C%20decision%20making%20concept%2C%20inspiring%20career%20transition%20moment&width=400&height=250&seq=career-change-guide&orientation=landscape"
    },
    {
      id: 3,
      title: "Tech Industry Resume & Interview Guide",
      description: "Specialized guide for breaking into tech roles, including resume formatting, technical skills presentation, and coding interview prep.",
      category: "Industry Specific",
      difficulty: "Intermediate",
      readTime: "35 min read",
      chapters: 18,
      image: "https://readdy.ai/api/search-image?query=Software%20developer%20working%20on%20resume%20with%20multiple%20monitors%20showing%20code%20and%20professional%20templates%2C%20modern%20tech%20workspace%20with%20programming%20languages%20visible%2C%20clean%20contemporary%20office%20environment&width=400&height=250&seq=tech-industry-guide&orientation=landscape"
    },
    {
      id: 4,
      title: "Cover Letter Mastery: From Generic to Compelling",
      description: "Transform your cover letter from a boring template into a powerful tool that gets you noticed by hiring managers.",
      category: "Cover Letters",
      difficulty: "Beginner",
      readTime: "20 min read",
      chapters: 10,
      image: "https://readdy.ai/api/search-image?query=Professional%20writing%20compelling%20cover%20letter%20at%20elegant%20desk%20with%20fountain%20pen%2C%20draft%20papers%20and%20laptop%2C%20focused%20expression%2C%20warm%20lighting%2C%20sophisticated%20office%20environment%20with%20books%20and%20plants&width=400&height=250&seq=cover-letter-mastery&orientation=landscape"
    },
    {
      id: 5,
      title: "Interview Confidence Builder: From Nervous to Natural",
      description: "Build unshakeable interview confidence with psychology-backed techniques and practical preparation strategies.",
      category: "Interview Prep",
      difficulty: "All Levels",
      readTime: "28 min read",
      chapters: 14,
      image: "https://readdy.ai/api/search-image?query=Confident%20professional%20in%20successful%20job%20interview%20handshake%20moment%2C%20modern%20office%20conference%20room%20with%20positive%20atmosphere%2C%20professional%20attire%2C%20successful%20career%20moment%2C%20inspiring%20business%20environment&width=400&height=250&seq=interview-confidence-guide&orientation=landscape"
    },
    {
      id: 6,
      title: "Healthcare Professional's Career Guide",
      description: "Specialized career guidance for healthcare workers, including resume tips for medical fields and healthcare-specific interview strategies.",
      category: "Industry Specific",
      difficulty: "Intermediate",
      readTime: "32 min read",
      chapters: 16,
      image: "https://readdy.ai/api/search-image?query=Healthcare%20professional%20doctor%20reviewing%20career%20documents%20in%20modern%20medical%20office%2C%20stethoscope%20and%20medical%20charts%20visible%2C%20professional%20medical%20environment%2C%20career%20development%20in%20healthcare%20setting&width=400&height=250&seq=healthcare-career-guide&orientation=landscape"
    }
  ];

  const filteredGuides = selectedCategory === 'All' 
    ? guides 
    : guides.filter(guide => guide.category === selectedCategory);

  const featuredGuide = guides.find(guide => guide.featured);
  const regularGuides = guides.filter(guide => !guide.featured);

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-700';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-700';
      case 'Advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-blue-100 text-blue-700';
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-emerald-50 to-teal-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Career Development Guides
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive, step-by-step guides to accelerate your career growth. From resume writing to industry-specific 
            strategies, master the skills that matter most in today's job market.
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full transition-colors whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Guide */}
      {featuredGuide && selectedCategory === 'All' && (
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl overflow-hidden shadow-xl">
              <div className="grid lg:grid-cols-2 gap-0">
                <div className="p-8 lg:p-12 text-white">
                  <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">
                    Featured Guide
                  </span>
                  <h2 className="text-3xl font-bold mb-4">{featuredGuide.title}</h2>
                  <p className="text-emerald-100 mb-6 text-lg">{featuredGuide.description}</p>
                  <div className="flex items-center space-x-4 mb-6">
                    <span className="text-emerald-200">{featuredGuide.chapters} Chapters</span>
                    <span className="text-emerald-200">•</span>
                    <span className="text-emerald-200">{featuredGuide.readTime}</span>
                    <span className="text-emerald-200">•</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium bg-white/20 text-white`}>
                      {featuredGuide.difficulty}
                    </span>
                  </div>
                  <Link href={`/guides/${featuredGuide.id}`} className="bg-white text-emerald-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center whitespace-nowrap">
                    Start Reading
                    <i className="ri-arrow-right-line ml-2"></i>
                  </Link>
                </div>
                <div className="relative h-64 lg:h-auto">
                  <img
                    src={featuredGuide.image}
                    alt={featuredGuide.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Guides Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src="https://readdy.ai/api/search-image?query=Modern%20resume%20writing%20workspace%20with%20elegant%20desktop%20setup%2C%20professional%20documents%20spread%20out%2C%20sleek%20laptop%20displaying%20resume%20templates%2C%20warm%20golden%20hour%20lighting%20streaming%20through%20large%20windows%2C%20minimalist%20office%20design%20with%20plants%20and%20coffee%20cup%2C%20inspiring%20productivity%20atmosphere&width=400&height=250&seq=resume-writing-modern&orientation=landscape"
                  alt="Complete Resume Writing Guide for 2024"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">Resume Writing</span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">Beginner</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">Complete Resume Writing Guide for 2024</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">Master the art of resume writing with our comprehensive step-by-step guide covering everything from formatting to content optimization.</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>12 Chapters</span>
                  <span>25 min read</span>
                </div>
                <Link href="/guides/1" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-center block whitespace-nowrap">
                  Start Guide
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src="https://readdy.ai/api/search-image?query=Professional%20businesswoman%20standing%20at%20modern%20crossroads%20with%20multiple%20illuminated%20career%20pathway%20signs%2C%20city%20skyline%20backdrop%20at%20sunset%2C%20confident%20posture%20with%20briefcase%2C%20dynamic%20lighting%20creating%20inspiring%20career%20transition%20moment%2C%20contemporary%20urban%20business%20environment&width=400&height=250&seq=career-change-modern&orientation=landscape"
                  alt="Career Change Playbook: Pivot Successfully"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">Career Change</span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">Intermediate</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">Career Change Playbook: Pivot Successfully</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">Navigate career transitions with confidence using proven strategies for switching industries, roles, or career paths.</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>15 Chapters</span>
                  <span>30 min read</span>
                </div>
                <Link href="/guides/2" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-center block whitespace-nowrap">
                  Start Guide
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src="https://readdy.ai/api/search-image?query=High-tech%20software%20development%20workspace%20with%20multiple%20ultra-wide%20monitors%20displaying%20code%20and%20resume%20templates%2C%20programmer%20working%20in%20modern%20glass%20office%20with%20city%20lights%2C%20futuristic%20tech%20environment%20with%20holographic%20displays%2C%20inspiring%20innovation%20atmosphere&width=400&height=250&seq=tech-industry-modern&orientation=landscape"
                  alt="Tech Industry Resume & Interview Guide"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">Industry Specific</span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">Intermediate</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">Tech Industry Resume & Interview Guide</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">Specialized guide for breaking into tech roles, including resume formatting, technical skills presentation, and coding interview prep.</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>18 Chapters</span>
                  <span>35 min read</span>
                </div>
                <Link href="/guides/3" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-center block whitespace-nowrap">
                  Start Guide
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src="https://readdy.ai/api/search-image?query=Elegant%20executive%20writing%20personalized%20cover%20letter%20with%20luxury%20fountain%20pen%20on%20mahogany%20desk%2C%20premium%20leather%20portfolio%20open%20with%20professional%20letterhead%2C%20soft%20ambient%20lighting%20from%20vintage%20desk%20lamp%2C%20sophisticated%20executive%20office%20with%20awards%20and%20books&width=400&height=250&seq=cover-letter-luxury&orientation=landscape"
                  alt="Cover Letter Mastery: From Generic to Compelling"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">Cover Letters</span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">Beginner</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">Cover Letter Mastery: From Generic to Compelling</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">Transform your cover letter from a boring template into a powerful tool that gets you noticed by hiring managers.</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>10 Chapters</span>
                  <span>20 min read</span>
                </div>
                <Link href="/guides/4" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-center block whitespace-nowrap">
                  Start Guide
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src="https://readdy.ai/api/search-image?query=Confident%20CEO%20closing%20successful%20business%20deal%20with%20firm%20handshake%20in%20luxurious%20boardroom%2C%20floor-to-ceiling%20windows%20overlooking%20city%20skyline%2C%20professional%20attire%20and%20positive%20body%20language%2C%20golden%20hour%20lighting%20creating%20powerful%20success%20moment%2C%20premium%20corporate%20environment&width=400&height=250&seq=interview-success-luxury&orientation=landscape"
                  alt="Interview Confidence Builder: From Nervous to Natural"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">Interview Prep</span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">All Levels</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">Interview Confidence Builder: From Nervous to Natural</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">Build unshakeable interview confidence with psychology-backed techniques and practical preparation strategies.</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>14 Chapters</span>
                  <span>28 min read</span>
                </div>
                <Link href="/guides/5" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-center block whitespace-nowrap">
                  Start Guide
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src="https://readdy.ai/api/search-image?query=Senior%20medical%20doctor%20reviewing%20career%20advancement%20documents%20in%20state-of-the-art%20hospital%20office%2C%20modern%20medical%20equipment%20and%20digital%20displays%20visible%2C%20professional%20white%20coat%20with%20stethoscope%2C%20bright%20clinical%20environment%20with%20medical%20charts%20and%20technology%2C%20inspiring%20healthcare%20leadership%20moment&width=400&height=250&seq=healthcare-modern&orientation=landscape"
                  alt="Healthcare Professional's Career Guide"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">Industry Specific</span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">Intermediate</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">Healthcare Professional's Career Guide</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">Specialized career guidance for healthcare workers, including resume tips for medical fields and healthcare-specific interview strategies.</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>16 Chapters</span>
                  <span>32 min read</span>
                </div>
                <Link href="/guides/6" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors font-semibold text-center block whitespace-nowrap">
                  Start Guide
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trustpilot Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <img 
              src="https://readdy.ai/api/search-image?query=Trustpilot%20logo%20with%20green%20star%20rating%20badge%2C%20professional%20clean%20design%20on%20white%20background%2C%20high%20quality%20brand%20logo%20with%20trustpilot%20text%20and%20green%20star%20symbol&width=140&height=50&seq=trustpilot-brand-logo&orientation=landscape"
              alt="Trustpilot"
              className="h-10"
            />
            <div className="flex items-center space-x-1">
              <div className="flex text-green-500">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-lg"></i>
                ))}
              </div>
              <span className="text-gray-700 font-bold ml-2">4.8/5 Excellent</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Guides That Get Results</h2>
          <p className="text-gray-600 mb-8">Based on 28,847 reviews • Trusted career guidance</p>
          
          <div className="bg-gray-50 p-6 rounded-xl max-w-2xl mx-auto">
            <div className="flex text-green-500 justify-center mb-4">
              {[...Array(5)].map((_, i) => (
                <i key={i} className="ri-star-fill"></i>
              ))}
            </div>
            <p className="text-gray-700 italic mb-4">
              "The Complete Resume Writing Guide completely transformed how I approach my job applications. Following the step-by-step process, I landed 5 interviews in 2 weeks!"
            </p>
            <div className="flex items-center justify-center space-x-2">
              <span className="font-semibold text-gray-900">Marcus Johnson</span>
              <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">✓ Verified</span>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-emerald-600 to-teal-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Accelerate Your Career?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Start with our most popular guide and see immediate improvements in your job search success.
          </p>
          <Link href="/guides/1" className="bg-white text-emerald-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg inline-flex items-center whitespace-nowrap">
            Start Your First Guide
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-file-text-line text-white text-lg"></i>
                </div>
                <span className="text-xl font-['Pacifico']">ResumeTeacher</span>
              </div>
              <p className="text-gray-400 mb-4">
                Build professional resumes with AI assistance and land your dream job faster.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Career Guides</h3>
              <ul className="space-y-2">
                <li><Link href="/guides" className="text-gray-400 hover:text-white transition-colors">All Guides</Link></li>
                <li><Link href="/guides?category=Resume%20Writing" className="text-gray-400 hover:text-white transition-colors">Resume Writing</Link></li>
                <li><Link href="/guides?category=Interview%20Prep" className="text-gray-400 hover:text-white transition-colors">Interview Prep</Link></li>
                <li><Link href="/guides?category=Career%20Change" className="text-gray-400 hover:text-white transition-colors">Career Change</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Tools</h3>
              <ul className="space-y-2">
                <li><Link href="/builder" className="text-gray-400 hover:text-white transition-colors">Resume Builder</Link></li>
                <li><Link href="/cover-letter-builder" className="text-gray-400 hover:text-white transition-colors">Cover Letter Builder</Link></li>
                <li><Link href="/ats-resume-checker" className="text-gray-400 hover:text-white transition-colors">ATS Checker</Link></li>
                <li><Link href="/tools" className="text-gray-400 hover:text-white transition-colors">All Tools</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2">
                <li><Link href="/help" className="text-gray-400 hover:text-white transition-colors">Help Center</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link></li>
                <li><Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2025 ResumeTeacher. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
