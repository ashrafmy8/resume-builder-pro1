
import Link from 'next/link';

export default function TechIndustryGuide() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/guides" className="text-emerald-600 hover:text-emerald-700 mb-4 inline-flex items-center">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Guides
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">Industry Specific</span>
            <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">Intermediate</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Tech Industry Resume & Interview Guide</h1>
          <p className="text-xl text-gray-600 mb-6">Specialized guide for breaking into tech roles, including resume formatting, technical skills presentation, and coding interview prep.</p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <i className="ri-book-line"></i>
              18 Chapters
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-time-line"></i>
              35 min read
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-user-line"></i>
              Intermediate Level
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Tech Career Paths */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Popular Tech Career Paths</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2">Software Development</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Frontend Developer</li>
                  <li>• Backend Developer</li>
                  <li>• Full-Stack Developer</li>
                  <li>• Mobile Developer</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2">Data & Analytics</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Data Scientist</li>
                  <li>• Data Analyst</li>
                  <li>• Machine Learning Engineer</li>
                  <li>• Business Intelligence</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2">Product & Design</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Product Manager</li>
                  <li>• UX/UI Designer</li>
                  <li>• Product Designer</li>
                  <li>• Technical Writer</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2">Infrastructure</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• DevOps Engineer</li>
                  <li>• Cloud Architect</li>
                  <li>• Site Reliability Engineer</li>
                  <li>• Cybersecurity Specialist</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2">Emerging Fields</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• AI/ML Engineer</li>
                  <li>• Blockchain Developer</li>
                  <li>• AR/VR Developer</li>
                  <li>• IoT Engineer</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2">Management</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Engineering Manager</li>
                  <li>• Technical Lead</li>
                  <li>• CTO</li>
                  <li>• VP of Engineering</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Tech Resume Structure */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Tech Resume Structure & Best Practices</h2>
            <div className="prose prose-lg max-w-none">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Essential Sections for Tech Resumes</h3>
              <div className="bg-emerald-50 rounded-lg p-6 mb-6">
                <ol className="space-y-3 text-gray-700">
                  <li><strong>1. Header with Portfolio Links</strong> - Include GitHub, LinkedIn, personal website</li>
                  <li><strong>2. Professional Summary</strong> - Focus on technical expertise and impact</li>
                  <li><strong>3. Technical Skills</strong> - Organized by category (languages, frameworks, tools)</li>
                  <li><strong>4. Professional Experience</strong> - Emphasize projects and quantifiable results</li>
                  <li><strong>5. Projects Section</strong> - Showcase personal/side projects with links</li>
                  <li><strong>6. Education & Certifications</strong> - Include relevant coursework and certifications</li>
                </ol>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Technical Skills Organization</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">❌ Poor Skills Section</h4>
                  <div className="bg-red-50 p-3 rounded text-sm">
                    <p><strong>Skills:</strong> JavaScript, Python, React, Node.js, MongoDB, AWS, Git, Docker, Kubernetes, TypeScript, GraphQL, PostgreSQL</p>
                  </div>
                  <p className="text-xs text-red-600 mt-2">Problems: No organization, no proficiency levels, hard to scan</p>
                </div>
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">✅ Good Skills Section</h4>
                  <div className="bg-green-50 p-3 rounded text-sm space-y-2">
                    <p><strong>Languages:</strong> JavaScript (Expert), Python (Advanced), TypeScript (Intermediate)</p>
                    <p><strong>Frontend:</strong> React, Vue.js, HTML5/CSS3, Sass</p>
                    <p><strong>Backend:</strong> Node.js, Express, Django, RESTful APIs</p>
                    <p><strong>Databases:</strong> PostgreSQL, MongoDB, Redis</p>
                    <p><strong>Cloud/DevOps:</strong> AWS, Docker, Kubernetes, CI/CD</p>
                  </div>
                  <p className="text-xs text-green-600 mt-2">Benefits: Organized, shows depth, easy to scan</p>
                </div>
              </div>
            </div>
          </div>

          {/* Project Showcase */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Showcasing Technical Projects</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Projects are crucial for tech resumes, especially for entry-level positions or career changers. They demonstrate your ability to build and ship real applications.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Project Description Framework</h3>
              <div className="bg-blue-50 rounded-lg p-6 mb-6">
                <h4 className="font-semibold text-gray-900 mb-3">Follow the STAR Method for Projects:</h4>
                <ul className="space-y-3 text-gray-700">
                  <li><strong>Situation:</strong> What problem does the project solve?</li>
                  <li><strong>Task:</strong> What was your role and responsibilities?</li>
                  <li><strong>Action:</strong> What technologies and approaches did you use?</li>
                  <li><strong>Result:</strong> What was the outcome? Include metrics if possible.</li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Example Project Descriptions</h3>
              <div className="space-y-6">
                <div className="border-l-4 border-blue-500 pl-6">
                  <h4 className="font-semibold text-gray-900 mb-2">E-Commerce Analytics Dashboard</h4>
                  <p className="text-gray-600 text-sm mb-2">React • Node.js • PostgreSQL • D3.js</p>
                  <p className="text-gray-700 mb-3">
                    Built a real-time analytics dashboard for e-commerce businesses to track sales, customer behavior, and inventory. 
                    Implemented data visualization with D3.js and real-time updates using WebSocket connections. 
                    Achieved 40% faster load times through optimized database queries and implemented caching strategies.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <a href="#" className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
                      <i className="ri-github-line"></i>
                      GitHub
                    </a>
                    <a href="#" className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
                      <i className="ri-external-link-line"></i>
                      Live Demo
                    </a>
                  </div>
                </div>

                <div className="border-l-4 border-green-500 pl-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Machine Learning Stock Predictor</h4>
                  <p className="text-gray-600 text-sm mb-2">Python • TensorFlow • Flask • AWS</p>
                  <p className="text-gray-700 mb-3">
                    Developed a machine learning model to predict stock prices using LSTM neural networks. 
                    Created a Flask API to serve predictions and deployed on AWS EC2 with auto-scaling. 
                    Achieved 85% accuracy on test data and processed over 1M data points daily.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <a href="#" className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
                      <i className="ri-github-line"></i>
                      GitHub
                    </a>
                    <a href="#" className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
                      <i className="ri-article-line"></i>
                      Technical Blog Post
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ATS Optimization for Tech */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">ATS Optimization for Tech Resumes</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Tech companies heavily rely on ATS systems to filter resumes. Understanding how to optimize for these systems while maintaining readability is crucial.
              </p>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-green-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-3">✅ ATS-Friendly Practices</h3>
                  <ul className="space-y-2 text-green-700 text-sm">
                    <li>• Use standard section headings</li>
                    <li>• Include exact keyword matches from job descriptions</li>
                    <li>• Use standard fonts (Arial, Calibri, Times New Roman)</li>
                    <li>• Save as .docx or .pdf (check job posting)</li>
                    <li>• Use bullet points for easy parsing</li>
                    <li>• Include both acronyms and full terms (AI and Artificial Intelligence)</li>
                  </ul>
                </div>
                <div className="bg-red-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-3">❌ ATS Killers</h3>
                  <ul className="space-y-2 text-red-700 text-sm">
                    <li>• Complex graphics and charts</li>
                    <li>• Text in images or headers/footers</li>
                    <li>• Tables for layout (use for data only)</li>
                    <li>• Creative fonts or formatting</li>
                    <li>• Columns that break content flow</li>
                    <li>• Special characters or symbols</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Tech-Specific Keywords by Role</h3>
              <div className="overflow-x-auto mb-6">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Role</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Essential Keywords</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Frontend Developer</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">React, Angular, Vue.js, JavaScript, TypeScript, HTML5, CSS3, Responsive Design, User Experience, Cross-browser Compatibility</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Backend Developer</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Node.js, Python, Java, REST API, GraphQL, Database Design, Microservices, Cloud Computing, Server Architecture</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Data Scientist</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Machine Learning, Python, R, SQL, TensorFlow, PyTorch, Data Visualization, Statistical Analysis, Big Data, Predictive Modeling</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">DevOps Engineer</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">AWS, Docker, Kubernetes, CI/CD, Infrastructure as Code, Automation, Monitoring, Linux, Cloud Security, Container Orchestration</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Technical Interview Prep */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Technical Interview Preparation</h2>
            <div className="prose prose-lg max-w-none">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="border rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4">Coding Interview Topics</h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Data Structures (Arrays, Linked Lists, Trees, Graphs)</li>
                    <li>• Algorithms (Sorting, Searching, Dynamic Programming)</li>
                    <li>• Time & Space Complexity Analysis</li>
                    <li>• Object-Oriented Programming Principles</li>
                    <li>• System Design (for senior roles)</li>
                    <li>• Database Design & SQL Queries</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4">Behavioral Interview Prep</h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Challenging project you worked on</li>
                    <li>• How you handle tight deadlines</li>
                    <li>• Conflict resolution with team members</li>
                    <li>• Learning new technology quickly</li>
                    <li>• Debugging a complex issue</li>
                    <li>• Leading a technical initiative</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Interview Process Timeline</h3>
              <div className="bg-purple-50 rounded-lg p-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Phone/Video Screening</h4>
                      <p className="text-sm text-gray-600">HR or hiring manager discusses role, experience, and basic technical questions</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Technical Assessment</h4>
                      <p className="text-sm text-gray-600">Take-home project or online coding challenge (HackerRank, Codility)</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Technical Interview</h4>
                      <p className="text-sm text-gray-600">Live coding session with engineers, problem-solving and code review</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">System Design (Senior Roles)</h4>
                      <p className="text-sm text-gray-600">Design scalable systems, discuss architecture and trade-offs</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">5</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Final Interview</h4>
                      <p className="text-sm text-gray-600">Meet with team leads, cultural fit, and final decision</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Salary Negotiation */}
          <div className="bg-yellow-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Tech Salary Negotiation Tips</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Research Market Rates</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Use Glassdoor, Levels.fyi, Blind for salary data</li>
                  <li>• Consider total compensation (base + equity + bonus)</li>
                  <li>• Factor in location and cost of living</li>
                  <li>• Account for company size and funding stage</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Negotiation Strategy</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Always negotiate - most tech companies expect it</li>
                  <li>• Focus on total package, not just base salary</li>
                  <li>• Negotiate multiple offers simultaneously</li>
                  <li>• Be prepared to walk away if terms don't meet needs</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Land Your Dream Tech Job?</h3>
              <p className="text-blue-100 mb-6">Create a tech-optimized resume that showcases your technical skills and gets you noticed by top companies.</p>
              <Link href="/builder" className="bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold inline-block">
                Build Your Tech Resume
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
