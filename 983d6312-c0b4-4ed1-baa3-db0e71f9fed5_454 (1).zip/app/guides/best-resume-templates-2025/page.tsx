'use client';

import Header from '../../../components/Header';
import Link from 'next/link';

export default function BestResumeTemplates2025Page() {
  const templates = [
    {
      name: "Modern Professional",
      description: "Clean design with subtle color accents, perfect for corporate roles",
      bestFor: "Business, Finance, Consulting",
      features: ["ATS-Optimized", "Color Customizable", "Two-Column Layout"]
    },
    {
      name: "Creative Portfolio",
      description: "Eye-catching design for creative professionals",
      bestFor: "Design, Marketing, Media",
      features: ["Portfolio Section", "Creative Layout", "Visual Elements"]
    },
    {
      name: "Executive Leadership",
      description: "Sophisticated template for senior-level positions",
      bestFor: "C-Suite, VP, Director",
      features: ["Executive Summary", "Achievement Focus", "Premium Design"]
    },
    {
      name: "Tech Specialist",
      description: "Technical-focused layout for IT and engineering roles",
      bestFor: "Software, Engineering, IT",
      features: ["Skills Matrix", "Project Showcase", "Technical Focus"]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="pt-20">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Best Resume Templates for 2025
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover the most effective resume templates that will help you stand out 
              in today's competitive job market.
            </p>
          </div>

          <img 
            src="https://readdy.ai/api/search-image?query=Modern%20professional%20resume%20templates%20displayed%20on%20computer%20screen%20in%20elegant%20office%20workspace%2C%20multiple%20resume%20designs%20showing%20different%20styles%20and%20layouts%2C%20clean%20typography%20and%20professional%20formatting%2C%20contemporary%20business%20environment&width=1200&height=400&seq=templates-showcase&orientation=landscape"
            alt="Resume templates showcase"
            className="w-full h-80 object-cover object-top rounded-lg mb-12"
          />

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {templates.map((template, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm border p-8">
                <div className="mb-6">
                  <img 
                    src={`https://readdy.ai/api/search-image?query=Professional%20resume%20template%20design%20showing%20$%7Btemplate.name.toLowerCase%28%29%7D%20style%20layout%20with%20clean%20typography%2C%20modern%20formatting%2C%20and%20professional%20appearance%20suitable%20for%20$%7Btemplate.bestFor.toLowerCase%28%29%7D%20industry&width=400&height=500&seq=template-${index}&orientation=portrait`}
                    alt={template.name}
                    className="w-full h-64 object-cover object-top rounded-lg"
                  />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{template.name}</h3>
                <p className="text-gray-600 mb-4">{template.description}</p>
                
                <div className="mb-4">
                  <span className="text-sm font-semibold text-blue-600">Best for: </span>
                  <span className="text-sm text-gray-700">{template.bestFor}</span>
                </div>

                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Key Features:</h4>
                  <div className="flex flex-wrap gap-2">
                    {template.features.map((feature, featureIndex) => (
                      <span 
                        key={featureIndex}
                        className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  <Link 
                    href="/builder"
                    className="flex-1 bg-blue-600 text-white text-center py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap"
                  >
                    Use This Template
                  </Link>
                  <button className="px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <i className="ri-eye-line text-gray-600"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">How to Choose the Right Template</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Consider Your Industry</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <i className="ri-building-line text-blue-600 mr-3 mt-1"></i>
                    <div>
                      <h4 className="font-semibold text-gray-900">Corporate/Finance</h4>
                      <p className="text-gray-600 text-sm">Conservative, clean designs with traditional layouts</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <i className="ri-palette-line text-purple-600 mr-3 mt-1"></i>
                    <div>
                      <h4 className="font-semibold text-gray-900">Creative Industries</h4>
                      <p className="text-gray-600 text-sm">Bold designs with visual elements and creative layouts</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <i className="ri-code-line text-green-600 mr-3 mt-1"></i>
                    <div>
                      <h4 className="font-semibold text-gray-900">Technology</h4>
                      <p className="text-gray-600 text-sm">Modern, minimal designs with emphasis on skills and projects</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Experience Level Matters</h3>
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900">Entry Level</h4>
                    <p className="text-green-800 text-sm">Focus on education, skills, and internships</p>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900">Mid-Career</h4>
                    <p className="text-blue-800 text-sm">Emphasize achievements and career progression</p>
                  </div>
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h4 className="font-semibold text-purple-900">Executive</h4>
                    <p className="text-purple-800 text-sm">Highlight leadership and strategic impact</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-lg p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Ready to Create Your Perfect Resume?</h3>
            <p className="text-green-100 mb-6">
              Choose from our collection of professionally designed templates and create your resume in minutes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/templates"
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap"
              >
                Browse All Templates
              </Link>
              <Link 
                href="/builder"
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap"
              >
                Start Building Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}