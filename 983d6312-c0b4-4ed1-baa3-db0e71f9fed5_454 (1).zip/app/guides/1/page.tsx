
import Link from 'next/link';

export default function CompleteResumeWritingGuide() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/guides" className="text-emerald-600 hover:text-emerald-700 mb-4 inline-flex items-center">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Guides
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-medium">Resume Writing</span>
            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">Beginner</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Complete Resume Writing Guide for 2024</h1>
          <p className="text-xl text-gray-600 mb-6">Master the art of resume writing with our comprehensive step-by-step guide covering everything from formatting to content optimization.</p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <i className="ri-book-line"></i>
              12 Chapters
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-time-line"></i>
              25 min read
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-user-line"></i>
              Beginner Level
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Table of Contents */}
          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Table of Contents</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Part 1: Foundation</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>1. Understanding Modern Resumes</li>
                  <li>2. Resume Structure & Layout</li>
                  <li>3. Choosing the Right Format</li>
                  <li>4. Essential Sections</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Part 2: Content Creation</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>5. Writing Compelling Headlines</li>
                  <li>6. Professional Summary</li>
                  <li>7. Work Experience Section</li>
                  <li>8. Skills & Achievements</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Part 3: Optimization</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>9. ATS Optimization</li>
                  <li>10. Industry-Specific Tips</li>
                  <li>11. Common Mistakes</li>
                  <li>12. Final Review Checklist</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Chapter 1 */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Chapter 1: Understanding Modern Resumes</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                In today's competitive job market, your resume is more than just a list of your work history—it's your personal marketing document. Modern resumes have evolved significantly from the traditional formats of the past, and understanding these changes is crucial for success.
              </p>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What Makes a Modern Resume?</h3>
              <ul className="space-y-3 text-gray-700">
                <li><strong>ATS-Friendly Design:</strong> Your resume must be readable by Applicant Tracking Systems (ATS) that scan and filter resumes before they reach human eyes.</li>
                <li><strong>Results-Oriented Content:</strong> Modern resumes focus on achievements and quantifiable results rather than just job duties.</li>
                <li><strong>Clean, Professional Layout:</strong> Simple, elegant designs that are easy to scan and read quickly.</li>
                <li><strong>Strategic Keyword Usage:</strong> Incorporating relevant industry keywords to improve searchability and relevance.</li>
              </ul>
            </div>
          </div>

          {/* Chapter 2 */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Chapter 2: Resume Structure & Layout</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                The structure of your resume is the foundation upon which all your content builds. A well-organized resume guides the reader's eye naturally and ensures important information is easily found.
              </p>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Essential Resume Sections (In Order):</h3>
              <div className="bg-blue-50 rounded-lg p-6 mb-6">
                <ol className="space-y-3 text-gray-700">
                  <li><strong>1. Header with Contact Information</strong></li>
                  <li><strong>2. Professional Summary or Objective</strong></li>
                  <li><strong>3. Core Skills/Technical Skills</strong></li>
                  <li><strong>4. Professional Experience</strong></li>
                  <li><strong>5. Education</strong></li>
                  <li><strong>6. Additional Sections</strong> (Certifications, Languages, etc.)</li>
                </ol>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Layout Best Practices:</h3>
              <ul className="space-y-3 text-gray-700">
                <li>Use consistent formatting throughout</li>
                <li>Maintain adequate white space for readability</li>
                <li>Choose professional fonts (Arial, Calibri, or similar)</li>
                <li>Keep font size between 10-12 points</li>
                <li>Use bullet points for easy scanning</li>
              </ul>
            </div>
          </div>

          {/* Chapter 3 */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Chapter 3: Choosing the Right Format</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                There are three main resume formats, each suited for different career situations. Choosing the right format can make the difference between getting noticed and being overlooked.
              </p>
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Chronological</h4>
                  <p className="text-sm text-gray-600 mb-3">Lists work experience in reverse chronological order</p>
                  <div className="text-xs">
                    <p className="text-green-600 mb-1">✓ Best for: Traditional career paths</p>
                    <p className="text-red-600">✗ Avoid if: Career gaps or frequent job changes</p>
                  </div>
                </div>
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Functional</h4>
                  <p className="text-sm text-gray-600 mb-3">Focuses on skills and achievements rather than work history</p>
                  <div className="text-xs">
                    <p className="text-green-600 mb-1">✓ Best for: Career changers, gaps in employment</p>
                    <p className="text-red-600">✗ Avoid if: Traditional industries</p>
                  </div>
                </div>
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Hybrid</h4>
                  <p className="text-sm text-gray-600 mb-3">Combines skills focus with chronological work history</p>
                  <div className="text-xs">
                    <p className="text-green-600 mb-1">✓ Best for: Most situations</p>
                    <p className="text-red-600">✗ Avoid if: Very traditional companies</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Chapters Summary */}
          <div className="bg-emerald-50 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What You'll Learn in Remaining Chapters</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Content Writing Mastery</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Crafting compelling professional summaries</li>
                  <li>• Writing achievement-focused bullet points</li>
                  <li>• Quantifying your accomplishments</li>
                  <li>• Showcasing transferable skills</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Technical Optimization</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• ATS optimization strategies</li>
                  <li>• Industry-specific keyword research</li>
                  <li>• Common formatting mistakes to avoid</li>
                  <li>• Final review and proofreading checklist</li>
                </ul>
              </div>
            </div>
            <div className="mt-6 p-4 bg-white rounded-lg border-l-4 border-emerald-500">
              <p className="text-gray-700">
                <strong>Pro Tip:</strong> The most successful resumes tell a compelling story about your career progression while being optimized for both human readers and ATS systems. Focus on achievements, use action verbs, and always tailor your resume to the specific job you're applying for.
              </p>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <div className="bg-gray-900 text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Build Your Perfect Resume?</h3>
              <p className="text-gray-300 mb-6">Put these strategies into practice with our professional resume builder and templates.</p>
              <Link href="/builder" className="bg-emerald-600 text-white px-8 py-3 rounded-lg hover:bg-emerald-700 transition-colors font-semibold inline-block">
                Start Building Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
