
import Link from 'next/link';

export default function CoverLetterMastery() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/guides" className="text-emerald-600 hover:text-emerald-700 mb-4 inline-flex items-center">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Guides
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">Cover Letters</span>
            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">Beginner</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Cover Letter Mastery: From Generic to Compelling</h1>
          <p className="text-xl text-gray-600 mb-6">Transform your cover letter from a boring template into a powerful tool that gets you noticed by hiring managers.</p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <i className="ri-book-line"></i>
              10 Chapters
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-time-line"></i>
              20 min read
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-user-line"></i>
              Beginner Level
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Cover Letter Myths */}
          <div className="bg-red-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Cover Letter Myths Debunked</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">❌ Common Myths</h3>
                <ul className="space-y-2 text-red-700 text-sm">
                  <li>• "Nobody reads cover letters anymore"</li>
                  <li>• "Just repeat what's on your resume"</li>
                  <li>• "One generic cover letter works for all jobs"</li>
                  <li>• "Keep it as short as possible"</li>
                  <li>• "Focus only on what you want from the job"</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">✅ The Reality</h3>
                <ul className="space-y-2 text-green-700 text-sm">
                  <li>• 83% of hiring managers read cover letters</li>
                  <li>• Cover letters showcase personality and communication skills</li>
                  <li>• Customization increases response rates by 30%</li>
                  <li>• Optimal length is 250-400 words</li>
                  <li>• Focus on what you can offer the company</li>
                </ul>
              </div>
            </div>
          </div>

          {/* The AIDA Framework */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">The AIDA Framework for Cover Letters</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Use the proven AIDA (Attention, Interest, Desire, Action) marketing framework to structure your cover letter for maximum impact.
              </p>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="border-l-4 border-blue-500 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">📧 ATTENTION</h3>
                  <p className="text-gray-700 mb-3">Grab the hiring manager's attention with a compelling opening that shows you've done your research.</p>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-700 italic">
                      "When I saw that Spotify increased user engagement by 25% through personalized playlists, I knew your Product Manager role was perfect for someone with my background in data-driven user experience optimization."
                    </p>
                  </div>
                </div>
                <div className="border-l-4 border-green-500 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">🎯 INTEREST</h3>
                  <p className="text-gray-700 mb-3">Build interest by connecting your relevant experience to their specific needs.</p>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-700 italic">
                      "In my current role at TechStart, I led a team that increased user retention by 40% through A/B testing and user research, directly contributing to $2M in additional revenue."
                    </p>
                  </div>
                </div>
                <div className="border-l-4 border-purple-500 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">💝 DESIRE</h3>
                  <p className="text-gray-700 mb-3">Create desire by showing your passion and unique value proposition.</p>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-700 italic">
                      "I'm particularly excited about Spotify's mission to democratize music discovery. My experience building recommendation algorithms aligns perfectly with your goal of connecting artists with their ideal audiences."
                    </p>
                  </div>
                </div>
                <div className="border-l-4 border-orange-500 pl-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">🚀 ACTION</h3>
                  <p className="text-gray-700 mb-3">Close with a clear call to action that moves the process forward.</p>
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-700 italic">
                      "I'd love to discuss how my experience scaling user engagement at high-growth startups can contribute to Spotify's continued success. I'm available for a conversation at your convenience."
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Research Strategies */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Company Research That Makes You Stand Out</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Generic cover letters get ignored. Show hiring managers you've done your homework with targeted research that demonstrates genuine interest.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Research Checklist</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-emerald-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Company Intelligence</h4>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Recent news, press releases, product launches</li>
                    <li>• Company mission, values, and culture</li>
                    <li>• Growth metrics and achievements</li>
                    <li>• Industry challenges and opportunities</li>
                    <li>• Competitive positioning</li>
                  </ul>
                </div>
                <div className="bg-purple-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Role-Specific Research</h4>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Department goals and initiatives</li>
                    <li>• Team structure and reporting lines</li>
                    <li>• Key performance indicators for the role</li>
                    <li>• Skills gaps and pain points</li>
                    <li>• Career progression opportunities</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Where to Find Information</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300 mb-6">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Source</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">What to Look For</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">How to Use in Cover Letter</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Company Website</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Mission, values, recent achievements</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Reference specific company goals you can support</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">LinkedIn</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Team members, company updates, hiring manager info</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Mention shared connections or similar backgrounds</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Industry News</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Market trends, competitive moves, challenges</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Show industry knowledge and strategic thinking</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Glassdoor/Reviews</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Company culture, employee experiences</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Demonstrate cultural fit and shared values</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Industry-Specific Examples */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Industry-Specific Cover Letter Examples</h2>
            <div className="space-y-8">
              {/* Tech Industry */}
              <div className="border rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <i className="ri-code-line text-blue-600"></i>
                  Technology Industry
                </h3>
                <div className="bg-blue-50 rounded-lg p-4 mb-4">
                  <p className="text-sm text-gray-700 italic mb-3">
                    "Dear Hiring Manager,
                  </p>
                  <p className="text-sm text-gray-700 italic mb-3">
                    When Stripe processed over $640 billion in payments last year, it reinforced my belief that elegant, developer-focused solutions win in fintech. Your Senior Backend Engineer position excites me because it combines my passion for scalable architecture with the opportunity to impact millions of businesses globally.
                  </p>
                  <p className="text-sm text-gray-700 italic mb-3">
                    At PaymentTech, I architected a microservices platform that reduced transaction processing time by 60% while maintaining 99.99% uptime. This directly enabled our clients to handle Black Friday traffic spikes without disruption, generating $50M in additional revenue. Your focus on infrastructure reliability resonates with my experience building systems that scale.
                  </p>
                  <p className="text-sm text-gray-700 italic">
                    I'd welcome the opportunity to discuss how my experience optimizing high-throughput payment systems can contribute to Stripe's mission of increasing internet GDP..."
                  </p>
                </div>
                <div className="text-xs text-gray-600">
                  <strong>Key Elements:</strong> Specific company metrics, relevant technical achievements, industry knowledge, quantified impact
                </div>
              </div>

              {/* Healthcare */}
              <div className="border rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <i className="ri-heart-pulse-line text-red-600"></i>
                  Healthcare Industry
                </h3>
                <div className="bg-red-50 rounded-lg p-4 mb-4">
                  <p className="text-sm text-gray-700 italic mb-3">
                    "Dear Dr. Martinez,
                  </p>
                  <p className="text-sm text-gray-700 italic mb-3">
                    Your recent publication on reducing hospital readmission rates through predictive analytics aligns perfectly with my passion for data-driven healthcare improvements. The Clinical Data Analyst position at MedCenter represents an ideal opportunity to apply my biostatistics background to improve patient outcomes.
                  </p>
                  <p className="text-sm text-gray-700 italic mb-3">
                    In my current role at Regional Health System, I developed a predictive model that identified high-risk patients 72 hours before potential complications, resulting in a 23% reduction in ICU transfers and $1.2M in cost savings annually. Your commitment to evidence-based care matches my dedication to translating complex data into actionable clinical insights.
                  </p>
                  <p className="text-sm text-gray-700 italic">
                    I'm eager to discuss how my experience in healthcare analytics can support MedCenter's mission of providing exceptional patient care..."
                  </p>
                </div>
                <div className="text-xs text-gray-600">
                  <strong>Key Elements:</strong> Industry-specific language, clinical impact metrics, research awareness, patient-focused outcomes
                </div>
              </div>

              {/* Marketing */}
              <div className="border rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <i className="ri-megaphone-line text-purple-600"></i>
                  Marketing Industry
                </h3>
                <div className="bg-purple-50 rounded-lg p-4 mb-4">
                  <p className="text-sm text-gray-700 italic mb-3">
                    "Dear Sarah Chen,
                  </p>
                  <p className="text-sm text-gray-700 italic mb-3">
                    BrandCorp's '2024 Authenticity Campaign' didn't just win a Cannes Lion—it proved that purpose-driven marketing creates lasting brand loyalty. Your Digital Marketing Manager role excites me because it offers the chance to blend creative storytelling with performance marketing at a company that values both art and science.
                  </p>
                  <p className="text-sm text-gray-700 italic mb-3">
                    At CreativeAgency, I launched a multi-channel campaign that increased brand awareness by 45% while driving a 3x improvement in conversion rates. By combining compelling video content with precision targeting, we achieved a 250% ROAS across all channels. Your emphasis on data-driven creativity mirrors my approach to building campaigns that both inspire and convert.
                  </p>
                  <p className="text-sm text-gray-700 italic">
                    I'd love to discuss how my experience scaling performance marketing campaigns can help BrandCorp continue setting industry standards..."
                  </p>
                </div>
                <div className="text-xs text-gray-600">
                  <strong>Key Elements:</strong> Industry recognition, creative + analytical balance, specific marketing metrics, brand understanding
                </div>
              </div>
            </div>
          </div>

          {/* Common Mistakes */}
          <div className="bg-yellow-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Top 10 Cover Letter Mistakes to Avoid</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Content Mistakes</h3>
                <ul className="space-y-2 text-red-700 text-sm">
                  <li>• Using "To Whom It May Concern"</li>
                  <li>• Repeating your resume verbatim</li>
                  <li>• Focusing on what you want vs. what you offer</li>
                  <li>• Using generic templates without customization</li>
                  <li>• Making it all about yourself instead of the company</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Format & Technical Mistakes</h3>
                <ul className="space-y-2 text-red-700 text-sm">
                  <li>• Exceeding one page in length</li>
                  <li>• Using unprofessional email addresses</li>
                  <li>• Inconsistent formatting or fonts</li>
                  <li>• Typos and grammatical errors</li>
                  <li>• Forgetting to include contact information</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Cover Letter Templates */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Cover Letter Structure Templates</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Traditional Structure</h3>
                <div className="space-y-3 text-sm">
                  <div className="bg-gray-100 px-3 py-2 rounded">
                    <strong>Header:</strong> Your contact info + employer's info
                  </div>
                  <div className="bg-gray-100 px-3 py-2 rounded">
                    <strong>Greeting:</strong> "Dear [Specific Name]"
                  </div>
                  <div className="bg-gray-100 px-3 py-2 rounded">
                    <strong>Opening:</strong> Hook + position you're applying for
                  </div>
                  <div className="bg-gray-100 px-3 py-2 rounded">
                    <strong>Body:</strong> 2-3 paragraphs of relevant experience
                  </div>
                  <div className="bg-gray-100 px-3 py-2 rounded">
                    <strong>Closing:</strong> Call to action + thank you
                  </div>
                  <div className="bg-gray-100 px-3 py-2 rounded">
                    <strong>Signature:</strong> Professional sign-off
                  </div>
                </div>
              </div>
              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Modern AIDA Structure</h3>
                <div className="space-y-3 text-sm">
                  <div className="bg-blue-100 px-3 py-2 rounded">
                    <strong>Attention:</strong> Compelling hook with company research
                  </div>
                  <div className="bg-green-100 px-3 py-2 rounded">
                    <strong>Interest:</strong> Relevant experience + quantified achievements  
                  </div>
                  <div className="bg-purple-100 px-3 py-2 rounded">
                    <strong>Desire:</strong> Passion + unique value proposition
                  </div>
                  <div className="bg-orange-100 px-3 py-2 rounded">
                    <strong>Action:</strong> Clear next steps + professional closing
                  </div>
                </div>
                <p className="text-xs text-gray-600 mt-3">
                  <strong>Best for:</strong> Competitive roles, creative industries, career changes
                </p>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Write Compelling Cover Letters?</h3>
              <p className="text-purple-100 mb-6">Use our cover letter builder to create personalized, professional cover letters that get results.</p>
              <Link href="/cover-letter-builder" className="bg-white text-purple-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold inline-block">
                Build Your Cover Letter
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
