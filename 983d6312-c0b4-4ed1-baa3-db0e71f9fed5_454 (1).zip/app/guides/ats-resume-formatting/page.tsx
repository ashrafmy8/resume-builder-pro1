'use client';

import Header from '../../../components/Header';
import Link from 'next/link';

export default function ATSResumeFormattingPage() {
  const formatTips = [
    {
      icon: "ri-file-text-line",
      title: "Use Standard Fonts",
      description: "Stick to Arial, Calibri, or Times New Roman for maximum compatibility",
      example: "Arial 10-12pt, Calibri 11-12pt, Times New Roman 10-12pt"
    },
    {
      icon: "ri-layout-line",
      title: "Simple Layout",
      description: "Avoid complex formatting, tables, and graphics that confuse ATS",
      example: "Single column, clear sections, consistent spacing"
    },
    {
      icon: "ri-text",
      title: "Standard Headings",
      description: "Use conventional section headers that ATS systems recognize",
      example: "Experience, Education, Skills, Summary"
    },
    {
      icon: "ri-file-line",
      title: "File Format",
      description: "Submit as .docx or .pdf based on job posting requirements",
      example: "Most ATS prefer .docx, but always check posting"
    }
  ];

  const keywords = [
    { category: "Hard Skills", examples: ["Python", "Project Management", "SEO", "AutoCAD"] },
    { category: "Soft Skills", examples: ["Leadership", "Communication", "Problem-solving", "Teamwork"] },
    { category: "Certifications", examples: ["PMP", "Google Analytics", "AWS Certified", "CPA"] },
    { category: "Industry Terms", examples: ["Agile", "ROI", "KPI", "B2B Sales"] }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="pt-20">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              ATS-Friendly Resume Formatting Tips
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Learn how to format your resume to pass Applicant Tracking Systems 
              and get in front of human recruiters.
            </p>
          </div>

          <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-12">
            <div className="flex items-start">
              <i className="ri-alert-line text-red-600 mr-3 mt-1 text-xl"></i>
              <div>
                <h3 className="text-lg font-semibold text-red-900 mb-2">Why ATS Formatting Matters</h3>
                <p className="text-red-800">
                  Over 98% of Fortune 500 companies use ATS to filter resumes. If your resume isn't 
                  ATS-friendly, it may never reach human eyes, regardless of your qualifications.
                </p>
              </div>
            </div>
          </div>

          <img 
            src="https://readdy.ai/api/search-image?query=Professional%20recruiter%20reviewing%20ATS%20system%20on%20computer%20screen%20showing%20resume%20parsing%20and%20keyword%20matching%20technology%2C%20modern%20HR%20office%20environment%20with%20digital%20workflow%2C%20clean%20interface%20design&width=1200&height=400&seq=ats-system&orientation=landscape"
            alt="ATS system interface"
            className="w-full h-80 object-cover object-top rounded-lg mb-12"
          />

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {formatTips.map((tip, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm border p-6">
                <div className="flex items-center mb-4">
                  <i className={`${tip.icon} text-2xl text-blue-600 mr-3`}></i>
                  <h3 className="text-xl font-semibold text-gray-900">{tip.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{tip.description}</p>
                <div className="bg-gray-50 rounded-lg p-3">
                  <span className="text-sm font-semibold text-gray-700">Example: </span>
                  <span className="text-sm text-gray-600">{tip.example}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Keyword Optimization Strategy</h2>
            
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              {keywords.map((keywordGroup, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">{keywordGroup.category}</h3>
                  <div className="flex flex-wrap gap-2">
                    {keywordGroup.examples.map((keyword, keywordIndex) => (
                      <span 
                        key={keywordIndex}
                        className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                      >
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Keyword Research Process</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="bg-blue-600 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                    <span className="font-bold">1</span>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">Analyze Job Posting</h4>
                  <p className="text-gray-600 text-sm">Extract key terms from the job description</p>
                </div>
                <div className="text-center">
                  <div className="bg-purple-600 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                    <span className="font-bold">2</span>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">Match Your Experience</h4>
                  <p className="text-gray-600 text-sm">Align keywords with your actual skills</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-600 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                    <span className="font-bold">3</span>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">Natural Integration</h4>
                  <p className="text-gray-600 text-sm">Include keywords naturally in context</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Common ATS Mistakes to Avoid</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-red-600 mb-4">❌ Don't Do This</h3>
                <div className="space-y-4">
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h4 className="font-semibold text-red-900">Images and Graphics</h4>
                    <p className="text-red-800 text-sm">ATS cannot read images or extract text from graphics</p>
                  </div>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h4 className="font-semibold text-red-900">Complex Tables</h4>
                    <p className="text-red-800 text-sm">Information in tables may be parsed incorrectly</p>
                  </div>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h4 className="font-semibold text-red-900">Unusual Fonts</h4>
                    <p className="text-red-800 text-sm">Script or decorative fonts confuse ATS parsing</p>
                  </div>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h4 className="font-semibold text-red-900">Headers/Footers</h4>
                    <p className="text-red-800 text-sm">Contact info in headers may not be readable</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-green-600 mb-4">✅ Do This Instead</h3>
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900">Plain Text</h4>
                    <p className="text-green-800 text-sm">Use text-based formatting and descriptions</p>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900">Simple Lists</h4>
                    <p className="text-green-800 text-sm">Use bullet points and clear section breaks</p>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900">Standard Fonts</h4>
                    <p className="text-green-800 text-sm">Stick to Arial, Calibri, or Times New Roman</p>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900">Main Body Text</h4>
                    <p className="text-green-800 text-sm">Keep all important info in the main document body</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-lg p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Test Your Resume's ATS Compatibility</h3>
            <p className="text-orange-100 mb-6">
              Use our ATS checker to ensure your resume will pass through applicant tracking systems.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/ats-resume-checker"
                className="bg-white text-orange-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap"
              >
                Check My Resume
              </Link>
              <Link 
                href="/builder"
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-orange-600 transition-colors whitespace-nowrap"
              >
                Build ATS-Friendly Resume
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}