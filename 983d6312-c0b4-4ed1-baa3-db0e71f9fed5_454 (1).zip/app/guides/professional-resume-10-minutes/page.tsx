'use client';

import Header from '../../../components/Header';

export default function ProfessionalResume10MinutesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="pt-20">
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="bg-white rounded-lg shadow-sm border p-8">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                How to Create a Professional Resume in 10 Minutes
              </h1>
              <div className="flex items-center text-gray-600 text-sm mb-6">
                <i className="ri-time-line mr-2"></i>
                <span>Reading time: 8 minutes</span>
                <span className="mx-2">•</span>
                <i className="ri-calendar-line mr-2"></i>
                <span>Updated: January 2025</span>
              </div>
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20person%20creating%20resume%20on%20laptop%20computer%20in%20modern%20office%20workspace%20with%20clean%20desk%20setup%2C%20business%20documents%20and%20coffee%20cup%2C%20bright%20natural%20lighting%2C%20productivity%20focused%20atmosphere%2C%20modern%20minimalist%20design&width=800&height=400&seq=resume-guide-hero&orientation=landscape"
                alt="Creating professional resume"
                className="w-full h-64 object-cover object-top rounded-lg mb-8"
              />
            </div>

            <div className="prose max-w-none">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Quick Start Guide</h2>
              <p className="text-gray-700 mb-6">
                Creating a professional resume doesn't have to take hours. With the right approach and tools, 
                you can build an impressive resume in just 10 minutes. Follow this step-by-step guide to get started.
              </p>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-8">
                <div className="flex items-center mb-2">
                  <i className="ri-lightbulb-line text-blue-600 mr-2"></i>
                  <h3 className="text-lg font-semibold text-blue-900">Pro Tip</h3>
                </div>
                <p className="text-blue-800">
                  Use our resume builder to automatically format and optimize your resume for ATS systems.
                </p>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Step 1: Choose the Right Template (1 minute)</h3>
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start">
                    <i className="ri-check-line text-green-600 mr-2 mt-1"></i>
                    <span>Select a clean, professional template that matches your industry</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-green-600 mr-2 mt-1"></i>
                    <span>Ensure the template is ATS-friendly with clear sections</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-green-600 mr-2 mt-1"></i>
                    <span>Consider your experience level when choosing layout</span>
                  </li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Step 2: Add Personal Information (1 minute)</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Essential Contact Info:</h4>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Full name</li>
                    <li>• Professional email</li>
                    <li>• Phone number</li>
                    <li>• LinkedIn profile</li>
                    <li>• City, State</li>
                  </ul>
                </div>
                <div>
                  <img 
                    src="https://readdy.ai/api/search-image?query=Professional%20business%20contact%20information%20form%20being%20filled%20out%20on%20computer%20screen%2C%20modern%20interface%20design%2C%20clean%20typography%20and%20layout%2C%20office%20workspace%20background&width=400&height=300&seq=contact-info&orientation=landscape"
                    alt="Contact information form"
                    className="w-full h-48 object-cover object-top rounded-lg"
                  />
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Step 3: Write a Compelling Summary (2 minutes)</h3>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-6">
                <h4 className="font-semibold text-yellow-900 mb-2">Summary Formula:</h4>
                <p className="text-yellow-800 mb-4">
                  [Job Title] with [X years] of experience in [Industry/Field]. Proven track record of [Key Achievement]. 
                  Skilled in [Top 3 Skills]. Seeking to [Career Goal] at [Type of Company].
                </p>
                <div className="bg-white rounded p-4">
                  <p className="text-gray-700 italic">
                    "Marketing Manager with 5 years of experience in digital marketing. Proven track record of 
                    increasing ROI by 150%. Skilled in SEO, content strategy, and campaign management. 
                    Seeking to drive growth at a tech startup."
                  </p>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Step 4: List Work Experience (4 minutes)</h3>
              <div className="space-y-4 mb-6">
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">For Each Job, Include:</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <ul className="space-y-2 text-gray-700">
                      <li className="flex items-start">
                        <i className="ri-arrow-right-s-line text-blue-600 mr-1 mt-1"></i>
                        <span>Job title and company name</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-arrow-right-s-line text-blue-600 mr-1 mt-1"></i>
                        <span>Employment dates</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-arrow-right-s-line text-blue-600 mr-1 mt-1"></i>
                        <span>3-5 bullet points of achievements</span>
                      </li>
                    </ul>
                    <ul className="space-y-2 text-gray-700">
                      <li className="flex items-start">
                        <i className="ri-arrow-right-s-line text-blue-600 mr-1 mt-1"></i>
                        <span>Use action verbs (Led, Managed, Increased)</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-arrow-right-s-line text-blue-600 mr-1 mt-1"></i>
                        <span>Include numbers and percentages</span>
                      </li>
                      <li className="flex items-start">
                        <i className="ri-arrow-right-s-line text-blue-600 mr-1 mt-1"></i>
                        <span>Focus on results, not duties</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Step 5: Add Education & Skills (2 minutes)</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="bg-green-50 rounded-lg p-6">
                  <h4 className="font-semibold text-green-900 mb-3">Education Section:</h4>
                  <ul className="space-y-2 text-green-800">
                    <li>• Degree and major</li>
                    <li>• University name</li>
                    <li>• Graduation year</li>
                    <li>• GPA (if 3.5 or higher)</li>
                    <li>• Relevant coursework or honors</li>
                  </ul>
                </div>
                <div className="bg-purple-50 rounded-lg p-6">
                  <h4 className="font-semibold text-purple-900 mb-3">Skills Section:</h4>
                  <ul className="space-y-2 text-purple-800">
                    <li>• Technical skills</li>
                    <li>• Software proficiency</li>
                    <li>• Industry certifications</li>
                    <li>• Language skills</li>
                    <li>• Relevant soft skills</li>
                  </ul>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-8 text-white text-center">
                <h3 className="text-2xl font-bold mb-4">Ready to Build Your Resume?</h3>
                <p className="text-blue-100 mb-6">
                  Use our professional resume builder to create your perfect resume in minutes.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a 
                    href="/builder" 
                    className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap"
                  >
                    Start Building Now
                  </a>
                  <a 
                    href="/templates" 
                    className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors whitespace-nowrap"
                  >
                    Browse Templates
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}