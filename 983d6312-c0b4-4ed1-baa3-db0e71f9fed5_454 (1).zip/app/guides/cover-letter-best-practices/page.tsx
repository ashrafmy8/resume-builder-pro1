'use client';

import Header from '../../../components/Header';
import Link from 'next/link';

export default function CoverLetterBestPracticesPage() {
  const sections = [
    {
      title: "Header & Greeting",
      content: "Include your contact info and address the hiring manager by name when possible",
      tips: ["Research the hiring manager's name", "Use professional email", "Include date and company address"]
    },
    {
      title: "Opening Paragraph",
      content: "Hook the reader with your enthusiasm and briefly mention the specific role",
      tips: ["Mention how you found the position", "Show genuine interest", "State the role clearly"]
    },
    {
      title: "Body Paragraphs",
      content: "Demonstrate your qualifications with specific examples and achievements",
      tips: ["Use the STAR method", "Quantify achievements", "Connect skills to job requirements"]
    },
    {
      title: "Closing Paragraph",
      content: "Reiterate interest, mention next steps, and thank the reader",
      tips: ["Request an interview", "Mention follow-up plans", "Professional sign-off"]
    }
  ];

  const examples = [
    {
      type: "Strong Opening",
      example: "As a marketing professional with 5 years of experience driving 200% growth in digital campaigns, I was thrilled to discover the Marketing Manager position at [Company]. Your recent expansion into sustainable products aligns perfectly with my passion for purpose-driven marketing.",
      color: "green"
    },
    {
      type: "Weak Opening",
      example: "I am writing to apply for the marketing position I saw on your website. I think I would be a good fit for this role because I have marketing experience.",
      color: "red"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="pt-20">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Cover Letter Writing Best Practices
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Master the art of writing compelling cover letters that get you noticed 
              and help you land more interviews.
            </p>
          </div>

          <img 
            src="https://readdy.ai/api/search-image?query=Professional%20person%20writing%20cover%20letter%20on%20laptop%20in%20modern%20office%20workspace%2C%20business%20documents%20and%20resume%20on%20desk%2C%20focused%20work%20environment%20with%20clean%20design%20and%20natural%20lighting&width=1200&height=400&seq=cover-letter-writing&orientation=landscape"
            alt="Writing cover letter"
            className="w-full h-80 object-cover object-top rounded-lg mb-12"
          />

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {sections.map((section, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm border p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{section.title}</h3>
                <p className="text-gray-600 mb-4">{section.content}</p>
                <div className="space-y-2">
                  {section.tips.map((tip, tipIndex) => (
                    <div key={tipIndex} className="flex items-start">
                      <i className="ri-check-line text-green-600 mr-2 mt-1"></i>
                      <span className="text-gray-700 text-sm">{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Writing Examples: Good vs. Bad</h2>
            
            <div className="space-y-8">
              {examples.map((example, index) => (
                <div key={index} className={`border-l-4 ${example.color === 'green' ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'} p-6 rounded-r-lg`}>
                  <h3 className={`text-lg font-semibold mb-3 ${example.color === 'green' ? 'text-green-800' : 'text-red-800'}`}>
                    {example.color === 'green' ? '✅' : '❌'} {example.type}
                  </h3>
                  <p className={`${example.color === 'green' ? 'text-green-700' : 'text-red-700'} italic`}>
                    "{example.example}"
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Cover Letter Checklist</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Before You Submit</h3>
                <div className="space-y-3">
                  {[
                    "Customized for specific job and company",
                    "Addressed to specific person when possible",
                    "No spelling or grammar errors",
                    "Professional tone throughout",
                    "Quantified achievements included",
                    "Call to action in closing",
                    "Proper business letter format",
                    "Saved as PDF unless otherwise specified"
                  ].map((item, index) => (
                    <div key={index} className="flex items-start">
                      <input type="checkbox" className="mt-1 mr-3" />
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Length & Format Guidelines</h3>
                <div className="space-y-4">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900">Length</h4>
                    <p className="text-blue-800 text-sm">One page maximum, 3-4 paragraphs</p>
                  </div>
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h4 className="font-semibold text-purple-900">Font</h4>
                    <p className="text-purple-800 text-sm">Arial, Calibri, or Times New Roman, 10-12pt</p>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-900">Margins</h4>
                    <p className="text-green-800 text-sm">1 inch on all sides for proper formatting</p>
                  </div>
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h4 className="font-semibold text-orange-900">File Name</h4>
                    <p className="text-orange-800 text-sm">FirstName_LastName_CoverLetter.pdf</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-8 mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Industry-Specific Tips</h2>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-gray-50 rounded-lg p-6">
                <i className="ri-building-line text-2xl text-blue-600 mb-3"></i>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Corporate/Finance</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Conservative, professional tone</li>
                  <li>• Focus on numbers and results</li>
                  <li>• Mention relevant certifications</li>
                  <li>• Highlight analytical skills</li>
                </ul>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <i className="ri-palette-line text-2xl text-purple-600 mb-3"></i>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Creative Industries</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Show personality and creativity</li>
                  <li>• Mention portfolio or work samples</li>
                  <li>• Discuss creative process</li>
                  <li>• Reference company's creative work</li>
                </ul>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <i className="ri-code-line text-2xl text-green-600 mb-3"></i>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Technology</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Mention specific technologies</li>
                  <li>• Discuss problem-solving approach</li>
                  <li>• Reference GitHub or portfolio</li>
                  <li>• Show continuous learning</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Ready to Write Your Perfect Cover Letter?</h3>
            <p className="text-purple-100 mb-6">
              Use our cover letter builder to create a compelling cover letter that complements your resume.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                href="/cover-letter-builder"
                className="bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap"
              >
                Build Cover Letter
              </Link>
              <Link 
                href="/cover-letter-templates"
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-purple-600 transition-colors whitespace-nowrap"
              >
                Browse Templates
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}