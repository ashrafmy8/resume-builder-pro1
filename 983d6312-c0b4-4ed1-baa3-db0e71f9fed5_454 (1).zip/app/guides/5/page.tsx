
import Link from 'next/link';

export default function InterviewConfidenceBuilder() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/guides" className="text-emerald-600 hover:text-emerald-700 mb-4 inline-flex items-center">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Guides
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-medium">Interview Prep</span>
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">All Levels</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Interview Confidence Builder: From Nervous to Natural</h1>
          <p className="text-xl text-gray-600 mb-6">Build unshakeable interview confidence with psychology-backed techniques and practical preparation strategies.</p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <i className="ri-book-line"></i>
              14 Chapters
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-time-line"></i>
              28 min read
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-user-line"></i>
              All Levels
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Confidence Assessment */}
          <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Interview Anxiety Self-Assessment</h2>
            <p className="text-gray-700 mb-4">Rate each statement from 1 (never) to 5 (always) to understand your confidence level:</p>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Physical Symptoms</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>□ I experience sweating or trembling before interviews</li>
                  <li>□ My heart races when thinking about interviews</li>
                  <li>□ I have trouble sleeping before important interviews</li>
                  <li>□ I feel nauseous or lose appetite on interview days</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Mental & Emotional</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>□ I worry about making mistakes or saying the wrong thing</li>
                  <li>□ I assume I'm not qualified enough for positions</li>
                  <li>□ I have trouble remembering prepared answers</li>
                  <li>□ I compare myself negatively to other candidates</li>
                </ul>
              </div>
            </div>
            <div className="mt-4 p-4 bg-white rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>Scoring:</strong> 8-16 (Low anxiety), 17-28 (Moderate anxiety), 29-40 (High anxiety). 
                This guide will help regardless of your starting point!
              </p>
            </div>
          </div>

          {/* The Science of Interview Anxiety */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Understanding Interview Anxiety: The Science Behind the Nerves</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Interview anxiety is a normal psychological response to perceived evaluation. Understanding why it happens is the first step to overcoming it.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">The Fight-or-Flight Response</h3>
              <div className="bg-blue-50 rounded-lg p-6 mb-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">What Happens in Your Body</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Adrenaline and cortisol release</li>
                      <li>• Increased heart rate and blood pressure</li>
                      <li>• Heightened alertness and focus</li>
                      <li>• Reduced digestive activity</li>
                      <li>• Muscle tension and sweating</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Why This Happens</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Brain perceives interview as "threat"</li>
                      <li>• Fear of judgment and rejection</li>
                      <li>• Uncertainty about outcome</li>
                      <li>• High stakes for career/financial security</li>
                      <li>• Past negative experiences</li>
                    </ul>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Reframing Anxiety as Excitement</h3>
              <p className="text-gray-700 mb-4">
                Research shows that trying to calm down during high-stress situations is less effective than reframing anxiety as excitement. 
                This technique, called "anxiety reappraisal," helps you harness nervous energy positively.
              </p>
              
              <div className="border-l-4 border-green-500 pl-6 mb-6">
                <h4 className="font-semibold text-gray-900 mb-2">Reframing Techniques:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li><strong>Instead of:</strong> "I'm so nervous, I'm going to mess this up"</li>
                  <li><strong>Try:</strong> "I'm excited to show them what I can bring to this role"</li>
                  <li><strong>Instead of:</strong> "What if they ask something I don't know?"</li>
                  <li><strong>Try:</strong> "This is a great opportunity to learn and demonstrate my problem-solving skills"</li>
                </ul>
              </div>
            </div>
          </div>

          {/* The STAR Method Mastery */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Mastering the STAR Method for Behavioral Questions</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                The STAR method (Situation, Task, Action, Result) is your secret weapon for answering behavioral interview questions with confidence and structure.
              </p>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">STAR Framework Breakdown</h3>
                  <div className="space-y-4">
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h4 className="font-semibold text-gray-900">Situation (20%)</h4>
                      <p className="text-sm text-gray-600">Set the context with specific details</p>
                    </div>
                    <div className="border-l-4 border-green-500 pl-4">
                      <h4 className="font-semibold text-gray-900">Task (20%)</h4>
                      <p className="text-sm text-gray-600">Define your responsibility or goal</p>
                    </div>
                    <div className="border-l-4 border-purple-500 pl-4">
                      <h4 className="font-semibold text-gray-900">Action (40%)</h4>
                      <p className="text-sm text-gray-600">Describe what YOU did (most important part)</p>
                    </div>
                    <div className="border-l-4 border-orange-500 pl-4">
                      <h4 className="font-semibold text-gray-900">Result (20%)</h4>
                      <p className="text-sm text-gray-600">Share quantifiable outcomes and lessons learned</p>
                    </div>
                  </div>
                </div>
                <div className="bg-emerald-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Example STAR Response</h3>
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="font-semibold text-blue-600">Situation:</span>
                      <p className="text-gray-700">"During Q4 at my previous company, our team was 30% behind on quarterly sales targets with only 6 weeks remaining."</p>
                    </div>
                    <div>
                      <span className="font-semibold text-green-600">Task:</span>
                      <p className="text-gray-700">"As team lead, I needed to develop a strategy to close the gap without compromising quality or team morale."</p>
                    </div>
                    <div>
                      <span className="font-semibold text-purple-600">Action:</span>
                      <p className="text-gray-700">"I analyzed our pipeline, identified bottlenecks in the proposal process, and implemented daily check-ins with struggling team members. I also partnered with marketing to create targeted campaigns for warm leads."</p>
                    </div>
                    <div>
                      <span className="font-semibold text-orange-600">Result:</span>
                      <p className="text-gray-700">"We exceeded our quarterly target by 5%, and the new processes increased team efficiency by 25% ongoing."</p>
                    </div>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Building Your STAR Story Bank</h3>
              <p className="text-gray-700 mb-4">Prepare 8-10 versatile STAR stories that can answer multiple question types:</p>
              
              <div className="overflow-x-auto mb-6">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Theme</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Potential Questions</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Key Elements to Include</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Leadership</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Tell me about a time you led a team, had to motivate others</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Team size, challenge faced, leadership style, team results</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Problem-Solving</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Describe a complex problem you solved, overcame an obstacle</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Problem complexity, analytical approach, creative solutions</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Conflict Resolution</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Handle disagreement with colleague, difficult customer</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Diplomacy, listening, win-win solutions</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Achievement</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Biggest accomplishment, exceeded expectations</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Quantifiable results, strategic impact, recognition</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Pre-Interview Confidence Rituals */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Pre-Interview Confidence Rituals</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Develop a consistent pre-interview routine that puts you in the optimal mental and physical state for success.
              </p>

              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="bg-green-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <i className="ri-time-line text-green-600"></i>
                    24 Hours Before
                  </h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Review your STAR stories and practice out loud</li>
                    <li>• Research recent company news and interviewer backgrounds</li>
                    <li>• Prepare your interview outfit and materials</li>
                    <li>• Get a good night's sleep (7-8 hours)</li>
                    <li>• Avoid caffeine after 2 PM</li>
                  </ul>
                </div>
                <div className="bg-blue-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <i className="ri-sun-line text-blue-600"></i>
                    Morning Of
                  </h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Eat a balanced breakfast with protein</li>
                    <li>• Review key points but avoid cramming</li>
                    <li>• Practice power poses for 2 minutes</li>
                    <li>• Arrive 10-15 minutes early</li>
                    <li>• Listen to confident, upbeat music</li>
                  </ul>
                </div>
                <div className="bg-purple-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <i className="ri-door-open-line text-purple-600"></i>
                    Right Before
                  </h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Do breathing exercises (4-7-8 technique)</li>
                    <li>• Review your elevator pitch silently</li>
                    <li>• Visualize successful interview outcomes</li>
                    <li>• Turn off phone notifications</li>
                    <li>• Smile and stand tall before entering</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Power Poses and Body Language</h3>
              <div className="bg-yellow-50 rounded-lg p-6 mb-6">
                <p className="text-gray-700 mb-4">
                  Research by Amy Cuddy shows that "power posing" for 2 minutes can increase confidence hormones by 20% and decrease stress hormones by 25%.
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Confidence-Boosting Poses (practice privately)</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Wonder Woman: Hands on hips, feet shoulder-width apart</li>
                      <li>• Victory V: Arms raised in V shape above head</li>
                      <li>• CEO: Feet up on desk, hands behind head</li>
                      <li>• Starfish: Arms and legs spread wide, taking up space</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Interview Body Language</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Maintain 50-70% eye contact</li>
                      <li>• Keep shoulders back and down</li>
                      <li>• Use open gestures (palms visible)</li>
                      <li>• Mirror interviewer's energy level</li>
                      <li>• Lean slightly forward to show engagement</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Handling Difficult Questions */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Navigating Challenging Interview Questions</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Every interview includes curveball questions. Here's how to handle them with grace and confidence.
              </p>

              <div className="space-y-6">
                <div className="border rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-3 text-red-600">"What's your greatest weakness?"</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-red-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-red-700 mb-2">❌ Poor Answers</h4>
                      <ul className="text-sm text-red-600 space-y-1">
                        <li>• "I'm a perfectionist"</li>
                        <li>• "I work too hard"</li>
                        <li>• "I don't have any weaknesses"</li>
                        <li>• "I'm not good with people"</li>
                      </ul>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-green-700 mb-2">✅ Strong Approach</h4>
                      <p className="text-sm text-green-700 mb-2">
                        "Earlier in my career, I struggled with delegating tasks because I wanted to ensure quality. 
                        I've worked on this by developing clear processes and check-ins that allow me to delegate effectively 
                        while maintaining standards. Last quarter, this helped my team deliver 30% more projects."
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-3 text-blue-600">"Why did you leave your last job?"</h3>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-700 mb-3">Framework: Past + Present + Future</h4>
                    <div className="space-y-2 text-sm text-blue-700">
                      <p><strong>Past:</strong> "I learned a tremendous amount at [Company] and accomplished [specific achievement]..."</p>
                      <p><strong>Present:</strong> "However, I reached a point where I wanted to take on more strategic responsibilities..."</p>
                      <p><strong>Future:</strong> "This role at your company offers exactly the growth opportunity I'm seeking in [specific area]."</p>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-3 text-purple-600">"I don't think you have enough experience"</h3>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-purple-700 mb-3">The Pivot Technique</h4>
                    <div className="space-y-2 text-sm text-purple-700">
                      <p><strong>Acknowledge:</strong> "You're right that I have 3 years versus the 5 years you ideally want..."</p>
                      <p><strong>Redirect:</strong> "However, my experience is very relevant because..."</p>
                      <p><strong>Provide Evidence:</strong> "For example, in my current role I [specific achievement that demonstrates capability]..."</p>
                      <p><strong>Show Enthusiasm:</strong> "I'm excited about the opportunity to grow into this role and contribute immediately in areas like [specific skills]."</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Virtual Interview Mastery */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Virtual Interview Excellence</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Virtual interviews require additional preparation to ensure technical smooth sailing and maintain connection through the screen.
              </p>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-green-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4">Technical Setup</h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Test technology 24 hours before and 15 minutes before</li>
                    <li>• Use ethernet connection if possible</li>
                    <li>• Position camera at eye level</li>
                    <li>• Ensure good lighting (natural light or ring light)</li>
                    <li>• Use headphones to prevent echo</li>
                    <li>• Have phone backup plan ready</li>
                  </ul>
                </div>
                <div className="bg-blue-50 rounded-lg p-6">
                  <h3 className="font-semibold text-gray-900 mb-4">Environment & Presence</h3>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Choose professional, clutter-free background</li>
                    <li>• Eliminate distractions and noise</li>
                    <li>• Dress professionally (full outfit, not just top)</li>
                    <li>• Look directly at camera when speaking</li>
                    <li>• Use gestures but keep them in frame</li>
                    <li>• Speak 10% more slowly and energetically</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Virtual Interview Challenges & Solutions</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300 mb-6">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Challenge</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Solution</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Technical difficulties during interview</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Stay calm, communicate the issue, have phone number ready for backup call</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Losing connection or engagement</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Maintain eye contact with camera, use more animated expressions, ask engaging questions</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Awkward silences or delays</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Pause 1-2 seconds before responding, acknowledge delays professionally, stay patient</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Difficulty reading body language</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Ask for feedback, check understanding frequently, pay attention to vocal cues</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Post-Interview Confidence */}
          <div className="bg-emerald-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Post-Interview Confidence Maintenance</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Immediate Follow-Up (Within 24 Hours)</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Send personalized thank you email to each interviewer</li>
                  <li>• Reference specific conversation points</li>
                  <li>• Reiterate your interest and key qualifications</li>
                  <li>• Provide any additional information requested</li>
                  <li>• Connect on LinkedIn with appropriate message</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Managing the Waiting Period</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Continue your job search and applications</li>
                  <li>• Reflect on lessons learned and areas for improvement</li>
                  <li>• Avoid over-analyzing every interaction</li>
                  <li>• Follow up professionally if promised timeline passes</li>
                  <li>• Prepare for potential next round or offer negotiation</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Interview with Confidence?</h3>
              <p className="text-orange-100 mb-6">Practice your interview skills and build the confidence you need to land your dream job.</p>
              <Link href="/interview-tips" className="bg-white text-orange-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold inline-block">
                More Interview Resources
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
