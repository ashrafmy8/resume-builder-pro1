
import Link from 'next/link';

export default function CareerChangePlaybook() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/guides" className="text-emerald-600 hover:text-emerald-700 mb-4 inline-flex items-center">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Guides
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-sm font-medium">Career Change</span>
            <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">Intermediate</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Career Change Playbook: Pivot Successfully</h1>
          <p className="text-xl text-gray-600 mb-6">Navigate career transitions with confidence using proven strategies for switching industries, roles, or career paths.</p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <i className="ri-book-line"></i>
              15 Chapters
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-time-line"></i>
              30 min read
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-user-line"></i>
              Intermediate Level
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Career Change Assessment */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Career Change Readiness Assessment</h2>
            <p className="text-gray-700 mb-4">Before diving into your career transition, assess your readiness with these key questions:</p>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Financial Readiness</h3>
                <ul className="space-y-2 text-gray-600 text-sm">
                  <li>• Do you have 3-6 months of expenses saved?</li>
                  <li>• Can you afford potential salary reduction?</li>
                  <li>• Have you budgeted for training/certification costs?</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Personal Readiness</h3>
                <ul className="space-y-2 text-gray-600 text-sm">
                  <li>• Are you clear on your career goals?</li>
                  <li>• Do you have family support?</li>
                  <li>• Are you prepared for a learning curve?</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Phase 1: Self-Discovery */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Phase 1: Self-Discovery & Goal Setting</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Successful career changes start with deep self-reflection. Understanding your motivations, values, and transferable skills is crucial for making the right transition.
              </p>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Identify Your Why</h3>
              <div className="bg-yellow-50 rounded-lg p-6 mb-6">
                <h4 className="font-semibold text-gray-900 mb-3">Common Career Change Motivations:</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <ul className="space-y-2 text-gray-700">
                    <li>• Lack of growth opportunities</li>
                    <li>• Poor work-life balance</li>
                    <li>• Industry decline or automation</li>
                    <li>• Desire for more meaningful work</li>
                  </ul>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Better compensation potential</li>
                    <li>• Personal passion or interest</li>
                    <li>• Geographic relocation needs</li>
                    <li>• Life stage changes</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Skills Inventory</h3>
              <p className="text-gray-700 mb-4">
                Map out your transferable skills—these are your golden tickets to a new career. Focus on skills that translate across industries.
              </p>
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Technical Skills</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Software proficiency</li>
                    <li>• Data analysis</li>
                    <li>• Project management</li>
                    <li>• Digital marketing</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Soft Skills</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Leadership</li>
                    <li>• Communication</li>
                    <li>• Problem-solving</li>
                    <li>• Adaptability</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Industry Knowledge</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Regulatory understanding</li>
                    <li>• Market knowledge</li>
                    <li>• Customer insights</li>
                    <li>• Process expertise</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Phase 2: Research & Planning */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Phase 2: Market Research & Strategic Planning</h2>
            <div className="prose prose-lg max-w-none">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Industry Research Framework</h3>
              <div className="bg-emerald-50 rounded-lg p-6 mb-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Market Analysis</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Industry growth trends</li>
                      <li>• Job market demand</li>
                      <li>• Salary ranges and progression</li>
                      <li>• Geographic opportunities</li>
                      <li>• Future outlook and stability</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Role Requirements</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Required qualifications</li>
                      <li>• Preferred experience levels</li>
                      <li>• Key competencies needed</li>
                      <li>• Career progression paths</li>
                      <li>• Industry certifications</li>
                    </ul>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Creating Your Transition Timeline</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300 mb-6">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Phase</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Timeline</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Key Activities</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Preparation</td>
                      <td className="border border-gray-300 px-4 py-2">Months 1-3</td>
                      <td className="border border-gray-300 px-4 py-2">Skills assessment, research, networking</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Skill Building</td>
                      <td className="border border-gray-300 px-4 py-2">Months 3-9</td>
                      <td className="border border-gray-300 px-4 py-2">Training, certifications, portfolio building</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Job Search</td>
                      <td className="border border-gray-300 px-4 py-2">Months 9-12</td>
                      <td className="border border-gray-300 px-4 py-2">Applications, interviews, negotiations</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Phase 3: Building Bridge Skills */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Phase 3: Building Bridge Skills</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Bridge skills help you transition from your current field to your target industry. These are the skills that make you a viable candidate despite lacking direct experience.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Skill Development Strategies</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Formal Learning</h4>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Online courses and certifications</li>
                    <li>• Professional bootcamps</li>
                    <li>• Part-time degree programs</li>
                    <li>• Industry conferences and workshops</li>
                    <li>• Professional association memberships</li>
                  </ul>
                </div>
                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Experiential Learning</h4>
                  <ul className="space-y-2 text-gray-700 text-sm">
                    <li>• Volunteer work in target field</li>
                    <li>• Freelance or consulting projects</li>
                    <li>• Side projects and portfolios</li>
                    <li>• Job shadowing opportunities</li>
                    <li>• Informational interviews</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Resume Strategy for Career Changers */}
          <div className="bg-blue-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Resume Strategy for Career Changers</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Do's</h3>
                <ul className="space-y-2 text-green-700 text-sm">
                  <li>✓ Lead with a strong professional summary</li>
                  <li>✓ Highlight transferable skills prominently</li>
                  <li>✓ Use a functional or hybrid format</li>
                  <li>✓ Include relevant volunteer work</li>
                  <li>✓ Showcase continuous learning efforts</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Don'ts</h3>
                <ul className="space-y-2 text-red-700 text-sm">
                  <li>✗ Focus on irrelevant past experience</li>
                  <li>✗ Use outdated or industry-specific jargon</li>
                  <li>✗ Highlight employment gaps prominently</li>
                  <li>✗ Undersell your transferable skills</li>
                  <li>✗ Ignore industry keywords and trends</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Success Stories */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Real Career Change Success Stories</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://readdy.ai/api/search-image?query=Professional%20woman%20in%20business%20attire%20smiling%20confidently%20in%20modern%20office%2C%20successful%20career%20transition%2C%20professional%20headshot%20style&width=60&height=60&seq=sarah-success&orientation=squarish" 
                    alt="Sarah Chen" 
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900">Sarah Chen</h3>
                    <p className="text-sm text-gray-600">Teacher → UX Designer</p>
                  </div>
                </div>
                <p className="text-gray-700 text-sm mb-3">
                  "After 8 years in education, I transitioned to UX design by completing a bootcamp while teaching part-time. My experience in curriculum design translated perfectly to user experience work."
                </p>
                <div className="text-xs text-gray-500">
                  <span className="bg-green-100 text-green-700 px-2 py-1 rounded">6-month transition</span>
                  <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded ml-2">40% salary increase</span>
                </div>
              </div>
              <div className="border rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://readdy.ai/api/search-image?query=Professional%20man%20in%20suit%20smiling%20confidently%20in%20corporate%20office%20environment%2C%20successful%20career%20change%2C%20executive%20headshot%20style&width=60&height=60&seq=michael-success&orientation=squarish" 
                    alt="Michael Rodriguez" 
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900">Michael Rodriguez</h3>
                    <p className="text-sm text-gray-600">Engineer → Product Manager</p>
                  </div>
                </div>
                <p className="text-gray-700 text-sm mb-3">
                  "My technical background gave me credibility with development teams, while I developed business skills through an MBA program. The combination was perfect for product management."
                </p>
                <div className="text-xs text-gray-500">
                  <span className="bg-green-100 text-green-700 px-2 py-1 rounded">18-month transition</span>
                  <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded ml-2">25% salary increase</span>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Start Your Career Transition?</h3>
              <p className="text-purple-100 mb-6">Build a career-change optimized resume that highlights your transferable skills and positions you for success in your new field.</p>
              <Link href="/builder" className="bg-white text-purple-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold inline-block">
                Create Your Transition Resume
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
