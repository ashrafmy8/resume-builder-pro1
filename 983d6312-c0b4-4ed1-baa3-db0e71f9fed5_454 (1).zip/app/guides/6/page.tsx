
import Link from 'next/link';

export default function HealthcareProfessionalGuide() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/guides" className="text-emerald-600 hover:text-emerald-700 mb-4 inline-flex items-center">
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Guides
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">Industry Specific</span>
            <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">Intermediate</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Healthcare Professional's Career Guide</h1>
          <p className="text-xl text-gray-600 mb-6">Specialized career guidance for healthcare workers, including resume tips for medical fields and healthcare-specific interview strategies.</p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <span className="flex items-center gap-2">
              <i className="ri-book-line"></i>
              16 Chapters
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-time-line"></i>
              32 min read
            </span>
            <span className="flex items-center gap-2">
              <i className="ri-user-line"></i>
              Intermediate Level
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Healthcare Career Paths */}
          <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Healthcare Career Specializations</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <i className="ri-heart-pulse-line text-red-600"></i>
                  Clinical Roles
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Registered Nurse (RN)</li>
                  <li>• Nurse Practitioner</li>
                  <li>• Physician Assistant</li>
                  <li>• Medical Doctor (MD)</li>
                  <li>• Specialist Physician</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <i className="ri-microscope-line text-blue-600"></i>
                  Diagnostic & Tech
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Medical Technologist</li>
                  <li>• Radiologic Technologist</li>
                  <li>• Ultrasound Technician</li>
                  <li>• Pathologist</li>
                  <li>• Lab Technician</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <i className="ri-wheelchair-line text-green-600"></i>
                  Allied Health
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Physical Therapist</li>
                  <li>• Occupational Therapist</li>
                  <li>• Speech Pathologist</li>
                  <li>• Respiratory Therapist</li>
                  <li>• Pharmacist</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <i className="ri-mind-map text-purple-600"></i>
                  Mental Health
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Clinical Psychologist</li>
                  <li>• Psychiatrist</li>
                  <li>• Mental Health Counselor</li>
                  <li>• Social Worker</li>
                  <li>• Psychiatric Nurse</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <i className="ri-hospital-line text-orange-600"></i>
                  Healthcare Admin
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Healthcare Administrator</li>
                  <li>• Medical Office Manager</li>
                  <li>• Health Information Manager</li>
                  <li>• Quality Assurance Director</li>
                  <li>• Healthcare Consultant</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border">
                <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <i className="ri-test-tube-line text-teal-600"></i>
                  Research & Public Health
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Clinical Research Coordinator</li>
                  <li>• Epidemiologist</li>
                  <li>• Public Health Specialist</li>
                  <li>• Biostatistician</li>
                  <li>• Health Educator</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Healthcare Resume Structure */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Healthcare Resume Structure & Best Practices</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Healthcare resumes require specific formatting and content to meet industry standards and highlight clinical competencies effectively.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Essential Sections for Healthcare Resumes</h3>
              <div className="bg-blue-50 rounded-lg p-6 mb-6">
                <ol className="space-y-3 text-gray-700">
                  <li><strong>1. Professional Header</strong> - Include credentials and license numbers</li>
                  <li><strong>2. Professional Summary</strong> - Highlight clinical expertise and patient care philosophy</li>
                  <li><strong>3. Licenses & Certifications</strong> - List all current and relevant credentials</li>
                  <li><strong>4. Clinical Experience</strong> - Focus on patient outcomes and specialized skills</li>
                  <li><strong>5. Education</strong> - Include clinical rotations and relevant coursework</li>
                  <li><strong>6. Professional Skills</strong> - Technical, clinical, and soft skills</li>
                  <li><strong>7. Professional Affiliations</strong> - Medical associations and memberships</li>
                </ol>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Credentials and Licensing Section</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">❌ Poor Credentials Section</h4>
                  <div className="bg-red-50 p-3 rounded text-sm">
                    <p><strong>Certifications:</strong></p>
                    <p>RN License, BLS, ACLS</p>
                  </div>
                  <p className="text-xs text-red-600 mt-2">Problems: No license numbers, expiration dates, or issuing bodies</p>
                </div>
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">✅ Professional Credentials Section</h4>
                  <div className="bg-green-50 p-3 rounded text-sm space-y-1">
                    <p><strong>Professional Licenses:</strong></p>
                    <p>• Registered Nurse, California #RN123456 (Expires: 12/2025)</p>
                    <p>• DEA Registration #AB1234567 (Expires: 06/2024)</p>
                    <p><strong>Certifications:</strong></p>
                    <p>• BLS Provider, American Heart Association (Expires: 08/2024)</p>
                    <p>• ACLS Provider, American Heart Association (Expires: 10/2024)</p>
                    <p>• CCRN, American Association of Critical-Care Nurses (Expires: 03/2025)</p>
                  </div>
                  <p className="text-xs text-green-600 mt-2">Benefits: Complete details, easy verification, shows currency</p>
                </div>
              </div>
            </div>
          </div>

          {/* Patient Outcomes Focus */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Highlighting Patient Outcomes & Clinical Impact</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Healthcare employers want to see how your clinical skills translate into positive patient outcomes and operational improvements.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Quantifying Healthcare Achievements</h3>
              <div className="space-y-6">
                <div className="border-l-4 border-red-500 pl-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Patient Care Quality</h4>
                  <div className="bg-red-50 p-4 rounded-lg mb-3">
                    <p className="text-sm text-gray-700 mb-2"><strong>Instead of:</strong> "Provided excellent patient care in ICU setting"</p>
                    <p className="text-sm text-gray-700"><strong>Write:</strong> "Managed care for 8-12 critically ill patients per shift, achieving 98% patient satisfaction scores and zero medication errors over 18 months in 40-bed ICU"</p>
                  </div>
                </div>

                <div className="border-l-4 border-blue-500 pl-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Clinical Outcomes</h4>
                  <div className="bg-blue-50 p-4 rounded-lg mb-3">
                    <p className="text-sm text-gray-700 mb-2"><strong>Instead of:</strong> "Assisted with patient recovery"</p>
                    <p className="text-sm text-gray-700"><strong>Write:</strong> "Implemented evidence-based mobility protocols that reduced average patient length of stay by 1.2 days and decreased fall rates by 25% in orthopedic unit"</p>
                  </div>
                </div>

                <div className="border-l-4 border-green-500 pl-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Process Improvements</h4>
                  <div className="bg-green-50 p-4 rounded-lg mb-3">
                    <p className="text-sm text-gray-700 mb-2"><strong>Instead of:</strong> "Improved department efficiency"</p>
                    <p className="text-sm text-gray-700"><strong>Write:</strong> "Led initiative to streamline medication administration process, reducing medication preparation time by 30% and improving on-time medication delivery from 85% to 96%"</p>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Healthcare-Specific Action Verbs</h3>
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="bg-emerald-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Patient Care</h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• Assessed</li>
                    <li>• Monitored</li>
                    <li>• Administered</li>
                    <li>• Diagnosed</li>
                    <li>• Treated</li>
                    <li>• Rehabilitated</li>
                  </ul>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Clinical Leadership</h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• Supervised</li>
                    <li>• Mentored</li>
                    <li>• Coordinated</li>
                    <li>• Implemented</li>
                    <li>• Standardized</li>
                    <li>• Optimized</li>
                  </ul>
                </div>
                <div className="bg-orange-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Quality & Safety</h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• Reduced</li>
                    <li>• Prevented</li>
                    <li>• Improved</li>
                    <li>• Ensured</li>
                    <li>• Maintained</li>
                    <li>• Exceeded</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Healthcare Interview Preparation */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Healthcare Interview Strategies</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Healthcare interviews often include clinical scenarios, ethical dilemmas, and questions about patient safety and quality improvement.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Common Healthcare Interview Questions</h3>
              <div className="space-y-6">
                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3 text-red-600">"Describe a time you had to deal with a difficult patient or family member"</h4>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-700 mb-3">
                      <strong>STAR Example:</strong>
                    </p>
                    <p className="text-sm text-gray-700 mb-2">
                      <strong>Situation:</strong> "A patient's family member was upset about wait times and became verbally aggressive toward staff."
                    </p>
                    <p className="text-sm text-gray-700 mb-2">
                      <strong>Task:</strong> "I needed to de-escalate the situation while ensuring patient care continued smoothly."
                    </p>
                    <p className="text-sm text-gray-700 mb-2">
                      <strong>Action:</strong> "I listened actively to their concerns, acknowledged their frustration, explained the clinical priorities causing delays, and offered regular updates on their loved one's status."
                    </p>
                    <p className="text-sm text-gray-700">
                      <strong>Result:</strong> "The family member calmed down, apologized for their behavior, and later thanked me for my patience and communication."
                    </p>
                  </div>
                </div>

                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3 text-blue-600">"How do you handle ethical dilemmas in patient care?"</h4>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h5 className="font-semibold text-blue-700 mb-2">Framework for Ethical Decision-Making:</h5>
                    <ol className="text-sm text-blue-700 space-y-1">
                      <li>1. Identify the ethical issue and stakeholders involved</li>
                      <li>2. Consider relevant professional codes and institutional policies</li>
                      <li>3. Consult with colleagues, supervisors, or ethics committee</li>
                      <li>4. Weigh patient autonomy, beneficence, and non-maleficence</li>
                      <li>5. Document decision-making process and rationale</li>
                    </ol>
                  </div>
                </div>

                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3 text-green-600">"Tell me about a time you made a mistake and how you handled it"</h4>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-green-700 mb-3">
                      <strong>Key Elements to Include:</strong>
                    </p>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Immediate patient safety actions taken</li>
                      <li>• Transparent communication with team and patient/family</li>
                      <li>• Root cause analysis and lessons learned</li>
                      <li>• Systemic changes implemented to prevent recurrence</li>
                      <li>• Personal growth and improved practices</li>
                    </ul>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Clinical Scenario Questions</h3>
              <div className="bg-yellow-50 rounded-lg p-6 mb-6">
                <p className="text-gray-700 mb-4">
                  Many healthcare interviews include clinical scenarios to assess critical thinking and clinical judgment. Practice these steps:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Assessment Process</h4>
                    <ol className="space-y-2 text-gray-700 text-sm">
                      <li>1. Gather relevant information systematically</li>
                      <li>2. Identify priority problems and safety concerns</li>
                      <li>3. Consider differential diagnoses or interventions</li>
                      <li>4. Explain clinical reasoning and decision-making</li>
                    </ol>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Communication Focus</h4>
                    <ul className="space-y-2 text-gray-700 text-sm">
                      <li>• Patient safety and comfort considerations</li>
                      <li>• Interdisciplinary collaboration needs</li>
                      <li>• Family education and communication</li>
                      <li>• Documentation and follow-up plans</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Professional Development */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Continuing Education & Career Advancement</h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-gray-700 mb-6">
                Healthcare careers require ongoing education and professional development to maintain competency and advance in your field.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Career Advancement Pathways</h3>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Clinical Ladder</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                      <div>
                        <p className="font-semibold text-gray-900">Staff Level</p>
                        <p className="text-sm text-gray-600">Direct patient care, building core competencies</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                      <div>
                        <p className="font-semibold text-gray-900">Senior/Charge</p>
                        <p className="text-sm text-gray-600">Shift leadership, mentoring new staff</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                      <div>
                        <p className="font-semibold text-gray-900">Specialist/Educator</p>
                        <p className="text-sm text-gray-600">Clinical expertise, education responsibilities</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                      <div>
                        <p className="font-semibold text-gray-900">Management</p>
                        <p className="text-sm text-gray-600">Unit management, strategic planning</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="border rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Advanced Practice Options</h4>
                  <ul className="space-y-3 text-gray-700 text-sm">
                    <li><strong>Advanced Degrees:</strong> MSN, DNP, PhD programs</li>
                    <li><strong>Specialty Certifications:</strong> CCRN, CEN, CNOR, etc.</li>
                    <li><strong>Leadership Roles:</strong> Nurse Manager, Director, CNO</li>
                    <li><strong>Clinical Specialization:</strong> ICU, OR, ER, Oncology</li>
                    <li><strong>Non-Clinical Paths:</strong> Quality, Informatics, Education</li>
                    <li><strong>Entrepreneurship:</strong> Consulting, Private Practice</li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Professional Development Planning</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300 mb-6">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Career Stage</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Key Development Areas</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Recommended Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">New Graduate (0-2 years)</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Clinical competency, time management, confidence building</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Residency programs, mentorship, BLS/ACLS certification</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Experienced (2-5 years)</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Specialty focus, leadership skills, evidence-based practice</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Specialty certification, charge nurse training, BSN if needed</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Advanced (5-10 years)</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Management, education, quality improvement</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">MSN degree, leadership programs, committee involvement</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-4 py-2 font-semibold">Expert (10+ years)</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Strategic planning, system-level change, mentoring</td>
                      <td className="border border-gray-300 px-4 py-2 text-sm">Executive education, DNP/PhD, speaking/publishing</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Salary & Negotiation */}
          <div className="bg-green-50 rounded-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Healthcare Salary Negotiation Strategies</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Research & Preparation</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Use salary.com, glassdoor.com, and payscale.com</li>
                  <li>• Consider geographic location and cost of living</li>
                  <li>• Factor in shift differentials and specialty pay</li>
                  <li>• Research hospital system vs. private practice differences</li>
                  <li>• Understand union vs. non-union environments</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Total Compensation Package</h3>
                <ul className="space-y-2 text-gray-700 text-sm">
                  <li>• Base salary and shift differentials</li>
                  <li>• Health, dental, vision insurance</li>
                  <li>• Retirement plans and employer matching</li>
                  <li>• Continuing education funding and time off</li>
                  <li>• Certification maintenance reimbursement</li>
                  <li>• Flexible scheduling and PTO policies</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Healthcare Resume Examples */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Healthcare Resume Examples by Specialty</h2>
            <div className="space-y-6">
              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <i className="ri-heart-pulse-line text-red-600"></i>
                  Registered Nurse - ICU
                </h3>
                <div className="bg-red-50 rounded-lg p-4">
                  <div className="text-sm text-gray-700 space-y-2">
                    <p><strong>Professional Summary:</strong></p>
                    <p className="italic">
                      "Dedicated ICU Registered Nurse with 5+ years of experience in high-acuity patient care. 
                      Expert in hemodynamic monitoring, ventilator management, and critical care protocols. 
                      Proven track record of achieving 98% patient satisfaction scores while maintaining zero preventable complications. 
                      CCRN certified with leadership experience in code blue responses and new nurse mentoring."
                    </p>
                    <p className="mt-3"><strong>Key Achievement:</strong></p>
                    <p className="italic">
                      "• Led implementation of evidence-based mobility protocols that reduced ICU-acquired weakness by 35% 
                      and decreased average length of stay by 2.1 days, resulting in $2.3M annual cost savings"
                    </p>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <i className="ri-wheelchair-line text-green-600"></i>
                  Physical Therapist
                </h3>
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="text-sm text-gray-700 space-y-2">
                    <p><strong>Professional Summary:</strong></p>
                    <p className="italic">
                      "Licensed Physical Therapist specializing in orthopedic and sports medicine rehabilitation. 
                      7 years of experience treating diverse patient populations from post-surgical recovery to athletic performance optimization. 
                      Expertise in manual therapy techniques, therapeutic exercise prescription, and patient education. 
                      Consistently achieves 95%+ functional outcome scores and patient satisfaction ratings."
                    </p>
                    <p className="mt-3"><strong>Key Achievement:</strong></p>
                    <p className="italic">
                      "• Developed innovative post-ACL reconstruction protocol that reduced return-to-sport timeline by 3 weeks 
                      while maintaining 98% success rate, adopted as standard practice across 12-clinic system"
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <div className="bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">Ready to Advance Your Healthcare Career?</h3>
              <p className="text-red-100 mb-6">Create a healthcare-optimized resume that highlights your clinical expertise and patient care achievements.</p>
              <Link href="/builder" className="bg-white text-red-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold inline-block">
                Build Your Healthcare Resume
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
