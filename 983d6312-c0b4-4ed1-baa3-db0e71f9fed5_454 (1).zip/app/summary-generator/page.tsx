'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function SummaryGeneratorPage() {
  const [formData, setFormData] = useState({
    jobTitle: '',
    experience: '',
    industry: '',
    keySkills: '',
    achievements: ''
  });
  const [generatedSummary, setGeneratedSummary] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const industries = [
    'Technology', 'Healthcare', 'Finance', 'Marketing', 'Sales', 'Education', 
    'Manufacturing', 'Retail', 'Consulting', 'Non-profit', 'Government', 'Other'
  ];

  const experienceLevels = [
    'Entry Level (0-2 years)', 'Mid Level (3-5 years)', 'Senior Level (6-10 years)', 
    'Executive Level (10+ years)', 'Student/Recent Graduate'
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const generateSummary = () => {
    if (!formData.jobTitle || !formData.experience) {
      alert('Please fill in job title and experience level');
      return;
    }

    setIsGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      const summaries = [
        `Experienced ${formData.jobTitle} with ${formData.experience.toLowerCase()} of proven success in ${formData.industry || 'various industries'}. Expert in ${formData.keySkills || 'relevant technologies and methodologies'} with a strong track record of ${formData.achievements || 'delivering high-quality results and exceeding performance targets'}. Passionate about driving innovation and contributing to organizational growth through strategic thinking and collaborative leadership.`,
        
        `Dynamic ${formData.jobTitle} bringing ${formData.experience.toLowerCase()} of hands-on experience in ${formData.industry || 'fast-paced environments'}. Skilled in ${formData.keySkills || 'cutting-edge tools and best practices'} with demonstrated ability to ${formData.achievements || 'lead cross-functional teams and execute complex projects'}. Committed to continuous learning and delivering exceptional value to stakeholders while maintaining the highest standards of quality and efficiency.`,
        
        `Results-driven ${formData.jobTitle} with ${formData.experience.toLowerCase()} of comprehensive experience in ${formData.industry || 'competitive markets'}. Proficient in ${formData.keySkills || 'industry-leading technologies and frameworks'} and recognized for ${formData.achievements || 'innovative problem-solving and strategic decision-making'}. Seeking to leverage expertise and passion for excellence to contribute to organizational success and professional growth.`
      ];
      
      const randomSummary = summaries[Math.floor(Math.random() * summaries.length)];
      setGeneratedSummary(randomSummary);
      setIsGenerating(false);
    }, 2000);
  };

  const copySummary = () => {
    navigator.clipboard.writeText(generatedSummary);
    alert('Summary copied to clipboard!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center">
              <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center mr-3">
                <i className="ri-file-text-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">Resume teacher</span>
            </Link>
            <Link href="/builder" className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors whitespace-nowrap">
              Build Resume
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-red-600 to-pink-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className={`transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              AI Resume Summary Generator
            </h1>
            <p className="text-xl text-red-100 mb-8 max-w-3xl mx-auto">
              Create a compelling professional summary that captures your experience, skills, and career goals. 
              Let AI craft the perfect introduction to your resume.
            </p>
            <div className="flex items-center justify-center space-x-8 text-red-100">
              <div className="flex items-center">
                <i className="ri-magic-line mr-2"></i>
                <span>AI-Powered</span>
              </div>
              <div className="flex items-center">
                <i className="ri-time-line mr-2"></i>
                <span>Instant Results</span>
              </div>
              <div className="flex items-center">
                <i className="ri-edit-line mr-2"></i>
                <span>Customizable</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Generator Form */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Input Form */}
            <div className={`transition-all duration-1000 delay-300 ${isAnimated ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-pink-600 rounded-xl flex items-center justify-center mr-4">
                    <i className="ri-settings-3-line text-white text-xl"></i>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Generate Your Summary</h2>
                    <p className="text-gray-600">Fill in your details to create a personalized summary</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Job Title *
                    </label>
                    <input
                      type="text"
                      value={formData.jobTitle}
                      onChange={(e) => handleInputChange('jobTitle', e.target.value)}
                      placeholder="e.g., Software Engineer, Marketing Manager"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Experience Level *
                    </label>
                    <select
                      value={formData.experience}
                      onChange={(e) => handleInputChange('experience', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 pr-8"
                    >
                      <option value="">Select experience level</option>
                      {experienceLevels.map((level) => (
                        <option key={level} value={level}>{level}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Industry
                    </label>
                    <select
                      value={formData.industry}
                      onChange={(e) => handleInputChange('industry', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 pr-8"
                    >
                      <option value="">Select industry</option>
                      {industries.map((industry) => (
                        <option key={industry} value={industry}>{industry}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Key Skills (Optional)
                    </label>
                    <input
                      type="text"
                      value={formData.keySkills}
                      onChange={(e) => handleInputChange('keySkills', e.target.value)}
                      placeholder="e.g., Python, Project Management, Data Analysis"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Key Achievements (Optional)
                    </label>
                    <textarea
                      value={formData.achievements}
                      onChange={(e) => handleInputChange('achievements', e.target.value)}
                      placeholder="e.g., increased sales by 30%, led team of 10 developers"
                      rows={3}
                      maxLength={500}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 resize-none"
                    />
                    <div className="text-xs text-gray-500 mt-1 text-right">
                      {formData.achievements.length}/500
                    </div>
                  </div>

                  <button
                    onClick={generateSummary}
                    disabled={isGenerating || !formData.jobTitle || !formData.experience}
                    className="w-full bg-gradient-to-r from-red-600 to-pink-600 text-white py-4 rounded-lg hover:from-red-700 hover:to-pink-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                  >
                    {isGenerating ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                        Generating Summary...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <i className="ri-magic-line mr-2"></i>
                        Generate AI Summary
                      </div>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Generated Summary */}
            <div className={`transition-all duration-1000 delay-500 ${isAnimated ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mr-4">
                    <i className="ri-file-text-line text-white text-xl"></i>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Your Professional Summary</h2>
                    <p className="text-gray-600">AI-generated summary ready to use</p>
                  </div>
                </div>

                {generatedSummary ? (
                  <div className="space-y-6">
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
                      <p className="text-gray-800 leading-relaxed text-lg">{generatedSummary}</p>
                    </div>

                    <div className="flex space-x-4">
                      <button
                        onClick={copySummary}
                        className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold whitespace-nowrap"
                      >
                        <i className="ri-clipboard-line mr-2"></i>
                        Copy Summary
                      </button>
                      <button
                        onClick={generateSummary}
                        className="flex-1 bg-gray-600 text-white py-3 rounded-lg hover:bg-gray-700 transition-colors font-semibold whitespace-nowrap"
                      >
                        <i className="ri-refresh-line mr-2"></i>
                        Generate New
                      </button>
                    </div>

                    <Link
                      href="/builder"
                      className="w-full bg-gradient-to-r from-red-600 to-pink-600 text-white py-3 rounded-lg hover:from-red-700 hover:to-pink-700 transition-colors font-semibold text-center block whitespace-nowrap"
                    >
                      Use in Resume Builder
                    </Link>
                  </div>
                ) : (
                  <div className="text-center py-20">
                    <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center">
                      <i className="ri-file-text-line text-4xl text-gray-400 animate-pulse"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-3">Ready to Generate</h3>
                    <p className="text-gray-600 mb-2">Fill in your information and click generate</p>
                    <p className="text-sm text-gray-500">Your AI-powered summary will appear here</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tips Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Professional Summary Tips</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-focus-3-line text-red-600 text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Keep It Concise</h3>
              <p className="text-gray-600">
                Aim for 3-4 sentences that capture your most important qualifications and career goals.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-target-line text-red-600 text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Be Specific</h3>
              <p className="text-gray-600">
                Include specific skills, years of experience, and quantifiable achievements when possible.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-refresh-line text-red-600 text-3xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Tailor for Each Job</h3>
              <p className="text-gray-600">
                Customize your summary for each application to match the specific job requirements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-pink-600 to-red-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Build Your Complete Resume?</h2>
          <p className="text-xl text-pink-100 mb-8 max-w-2xl mx-auto">
            Take your generated summary and create a complete, professional resume that gets results
          </p>
          <Link
            href="/builder"
            className="inline-block bg-white text-red-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors text-lg font-semibold whitespace-nowrap"
          >
            Start Building Now
          </Link>
        </div>
      </section>
    </div>
  );
}