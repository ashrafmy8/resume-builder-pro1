
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function TemplatesPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    setIsAnimated(true);
  }, []);

  const categories = [
    { id: 'all', name: 'All Templates' },
    { id: 'professional', name: 'Professional' },
    { id: 'creative', name: 'Creative' },
    { id: 'modern', name: 'Modern' },
    { id: 'executive', name: 'Executive' },
    { id: 'entry-level', name: 'Entry Level' }
  ];

  const templates = [
    // Professional Templates
    {
      id: 1,
      name: 'Corporate Professional',
      category: 'professional',
      content: `JOHN ANDERSON
Senior Business Analyst
john.anderson@email.com | (555) 123-4567 | New York, NY 10001

PROFESSIONAL SUMMARY
Results-driven Senior Business Analyst with 8+ years of experience in financial services and technology consulting. Proven track record of leading cross-functional teams, implementing process improvements that increased operational efficiency by 35%, and managing projects worth $2M+. Expert in data analysis, stakeholder management, and strategic planning.

CORE COMPETENCIES
• Business Process Analysis & Optimization    • Financial Modeling & Forecasting
• Project Management (PMP Certified)         • Stakeholder Relationship Management
• Data Analytics (SQL, Python, Tableau)      • Strategic Planning & Implementation
• Risk Assessment & Mitigation               • Team Leadership & Development

PROFESSIONAL EXPERIENCE

Senior Business Analyst | Goldman Sachs | New York, NY | 2020 - Present
• Led digital transformation initiative resulting in 40% reduction in processing time
• Collaborated with IT teams to implement automated reporting system serving 500+ users
• Conducted comprehensive market analysis supporting $50M investment decisions
• Managed stakeholder relationships across 12 departments and external partners

Business Analyst | JPMorgan Chase | New York, NY | 2018 - 2020
• Developed financial models for credit risk assessment improving accuracy by 25%
• Created executive dashboards providing real-time insights to C-level management
• Facilitated requirements gathering sessions with business units and technical teams
• Streamlined workflows reducing manual processes by 60% across three departments

Junior Analyst | Deloitte Consulting | Boston, MA | 2016 - 2018
• Supported client engagements in healthcare and financial services sectors
• Performed data analysis and created presentations for senior leadership
• Assisted in process mapping and documentation for operational improvements

EDUCATION
Master of Business Administration (MBA) | Columbia Business School | 2016
Bachelor of Science in Finance | Boston University | 2014

CERTIFICATIONS
• Project Management Professional (PMP) - 2019
• Certified Business Analysis Professional (CBAP) - 2020
• Tableau Desktop Certified Professional - 2021`
    },
    {
      id: 2,
      name: 'Healthcare Professional',
      category: 'professional',
      content: `DR. SARAH MARTINEZ, MD
Internal Medicine Physician
sarah.martinez@hospital.com | (555) 987-6543 | Boston, MA 02115

PROFESSIONAL PROFILE
Board-certified Internal Medicine physician with 12+ years of clinical experience in hospital and outpatient settings. Expertise in complex medical case management, patient care coordination, and medical education. Committed to evidence-based medicine and improving patient outcomes through comprehensive care and collaborative treatment approaches.

MEDICAL EXPERTISE
• Internal Medicine & Primary Care          • Chronic Disease Management
• Acute Care & Emergency Medicine          • Preventive Medicine & Wellness
• Geriatric Medicine & Elder Care          • Medical Education & Training
• Clinical Research & Protocol Development  • Quality Improvement Initiatives

PROFESSIONAL EXPERIENCE

Attending Physician | Massachusetts General Hospital | Boston, MA | 2018 - Present
• Provide comprehensive medical care to 200+ patients monthly in inpatient setting
• Lead multidisciplinary rounds and coordinate care with specialists
• Mentor medical residents and students in clinical decision-making
• Participate in quality improvement initiatives reducing readmission rates by 15%

Staff Physician | Boston Medical Center | Boston, MA | 2015 - 2018
• Managed diverse patient population in busy urban medical center
• Collaborated with emergency department on complex case consultations
• Developed patient education programs improving medication compliance by 30%
• Served on medical staff committees for policy development and review

Resident Physician | Brigham and Women's Hospital | Boston, MA | 2012 - 2015
• Completed internal medicine residency with focus on hospital medicine
• Participated in clinical research studies on cardiovascular disease prevention
• Received teaching award for excellence in medical student education

EDUCATION & TRAINING
Doctor of Medicine (MD) | Harvard Medical School | Boston, MA | 2012
Bachelor of Science in Biology | MIT | Cambridge, MA | 2008

BOARD CERTIFICATIONS & LICENSES
• Board Certified in Internal Medicine - American Board of Internal Medicine
• Massachusetts Medical License (#MD-12345) - Active
• DEA Registration - Active
• ACLS, BLS, PALS Certified

RESEARCH & PUBLICATIONS
• "Improving Care Coordination in Hospital Medicine" - Journal of Hospital Medicine, 2021
• "Patient Safety Initiatives in Internal Medicine" - New England Journal of Medicine, 2020
• Multiple poster presentations at American College of Physicians Annual Meeting`
    },
    {
      id: 3,
      name: 'Technology Professional',
      category: 'modern',
      content: `ALEX CHEN
Senior Software Engineer
alex.chen@tech.com | (555) 456-7890 | San Francisco, CA 94102
LinkedIn: linkedin.com/in/alexchen | GitHub: github.com/alexchen

TECHNICAL PROFILE
Full-stack software engineer with 7+ years of experience building scalable web applications and microservices. Expert in modern JavaScript, Python, and cloud technologies. Passionate about clean code, system architecture, and mentoring junior developers. Led engineering teams that delivered products serving 1M+ users.

TECHNICAL SKILLS
Languages: JavaScript/TypeScript, Python, Java, Go, SQL
Frontend: React, Vue.js, Angular, Next.js, HTML5, CSS3, Tailwind CSS  
Backend: Node.js, Django, Flask, Express.js, RESTful APIs, GraphQL
Databases: PostgreSQL, MongoDB, Redis, Elasticsearch
Cloud & DevOps: AWS, Docker, Kubernetes, CI/CD, Terraform, Jenkins
Tools: Git, JIRA, Figma, VS Code, Postman, Slack

PROFESSIONAL EXPERIENCE

Senior Software Engineer | Meta | Menlo Park, CA | 2021 - Present
• Lead development of React-based dashboard serving 2M+ daily active users
• Architected microservices infrastructure reducing API response time by 45%
• Mentored 5 junior engineers and conducted technical interviews for new hires
• Collaborated with product managers and designers on user experience improvements

Software Engineer | Airbnb | San Francisco, CA | 2019 - 2021
• Built and maintained booking platform handling $100M+ in transactions annually
• Implemented real-time messaging system using WebSocket and Redis
• Optimized database queries reducing page load times by 60%
• Participated in on-call rotation ensuring 99.9% system uptime

Full Stack Developer | Stripe | San Francisco, CA | 2017 - 2019
• Developed payment processing features used by thousands of merchants
• Created automated testing framework increasing code coverage to 95%
• Built internal tools improving developer productivity by 30%
• Contributed to open-source projects and technical documentation

PROJECTS & ACHIEVEMENTS
• TaskMaster Pro: Built productivity app with 50K+ downloads on App Store
• Open Source Contributor: 500+ GitHub stars across multiple repositories
• Tech Speaker: Presented at React Conference 2022 and JavaScript meetups
• Hackathon Winner: First place at TechCrunch Disrupt Hackathon 2020

EDUCATION
Bachelor of Science in Computer Science | Stanford University | 2017
Relevant Coursework: Data Structures, Algorithms, Database Systems, Software Engineering

CERTIFICATIONS
• AWS Certified Solutions Architect - Associate (2022)
• Google Cloud Professional Developer (2021)
• Certified Kubernetes Administrator (2020)`
    },
    {
      id: 4,
      name: 'Creative Designer',
      category: 'creative',
      content: `EMMA WILLIAMS
Senior UI/UX Designer
emma.williams@creative.com | (555) 321-9876 | Los Angeles, CA 90210
Portfolio: emmawilliams.design | Dribbble: dribbble.com/emmaw

CREATIVE PROFILE
Passionate UI/UX designer with 6+ years of experience creating intuitive digital experiences for web and mobile applications. Expert in user research, interaction design, and visual storytelling. Led design projects for Fortune 500 companies resulting in 40% increase in user engagement and 25% improvement in conversion rates.

DESIGN EXPERTISE
• User Experience (UX) Design & Research    • User Interface (UI) Design & Prototyping
• Design Systems & Component Libraries     • Interaction Design & Animation
• Usability Testing & User Research        • Brand Identity & Visual Design
• Wireframing & Information Architecture   • Design Thinking & Strategy

DESIGN TOOLS
Figma, Sketch, Adobe Creative Suite (Photoshop, Illustrator, XD)
InVision, Principle, Framer, Miro, Notion, Slack, JIRA

PROFESSIONAL EXPERIENCE

Senior UI/UX Designer | Netflix | Los Angeles, CA | 2021 - Present
• Lead design for streaming platform features used by 200M+ global subscribers
• Collaborated with product managers and engineers on mobile app redesign
• Conducted user research sessions and usability testing with 500+ participants
• Created comprehensive design system adopted across 15+ product teams

UI/UX Designer | Spotify | New York, NY | 2019 - 2021
• Designed music discovery features resulting in 30% increase in user engagement
• Led cross-functional workshops to align stakeholders on product vision
• Developed interactive prototypes for new podcast listening experience
• Mentored junior designers and established design review processes

Product Designer | Uber | San Francisco, CA | 2018 - 2019
• Redesigned driver onboarding flow reducing completion time by 50%
• Created accessibility guidelines ensuring WCAG 2.1 compliance
• Collaborated with data science team on A/B testing framework
• Presented design concepts to executive leadership team

SELECTED PROJECTS
• Music Streaming App Redesign: Led complete UI overhaul increasing daily active users by 45%
• E-commerce Mobile Experience: Designed shopping app with 4.8 App Store rating
• Financial Dashboard: Created analytics platform for fintech startup (acquired by Goldman Sachs)
• Healthcare Patient Portal: Designed telemedicine interface improving patient satisfaction by 35%

EDUCATION
Bachelor of Fine Arts in Graphic Design | ArtCenter College of Design | 2018
Dean's List (3 semesters) | Graduated Magna Cum Laude

AWARDS & RECOGNITION
• Webby Award Winner - Best User Interface Design (2022)
• Adobe Design Achievement Award - Interactive Design (2021)
• Featured Designer - Awwwards Site of the Month (2020)
• Dribbble Popular Shot - 10K+ likes and 500+ comments`
    },
    {
      id: 5,
      name: 'Executive Leadership',
      category: 'executive',
      content: `MICHAEL THOMPSON
Chief Technology Officer
michael.thompson@executive.com | (555) 777-8888 | Seattle, WA 98101

EXECUTIVE SUMMARY
Visionary technology executive with 15+ years of leadership experience driving digital transformation and innovation at Fortune 500 companies. Proven track record of scaling engineering organizations from 50 to 500+ employees, leading M&A technology integrations worth $2B+, and delivering products that generate $100M+ annual revenue. Expert in strategic planning, team building, and emerging technologies.

CORE LEADERSHIP COMPETENCIES
• Strategic Technology Planning & Execution  • Digital Transformation Leadership
• Engineering Organization Scaling          • Product Strategy & Innovation
• Mergers & Acquisitions Integration       • Board-Level Communication
• Venture Capital & Startup Advisory       • Global Team Management

EXECUTIVE EXPERIENCE

Chief Technology Officer | Amazon Web Services | Seattle, WA | 2020 - Present
• Lead global engineering organization of 800+ engineers across 12 countries
• Drive technology strategy for cloud infrastructure serving millions of customers
• Oversee annual R&D budget of $500M+ focused on AI and machine learning initiatives
• Member of executive leadership team reporting directly to CEO
• Spearhead partnerships with major enterprise clients generating $2B+ in new revenue

Vice President of Engineering | Microsoft | Redmond, WA | 2017 - 2020
• Built and scaled Azure engineering teams from 100 to 400+ engineers
• Led cloud migration strategy helping enterprise customers reduce costs by 40%
• Managed technology integration for 3 major acquisitions totaling $1.2B
• Established engineering best practices adopted across entire Microsoft ecosystem

Senior Director of Technology | Google | Mountain View, CA | 2014 - 2017
• Launched Google Cloud Platform products used by Fortune 1000 companies
• Led international expansion into European and Asian markets
• Created innovation lab fostering breakthrough technologies in AI and automation
• Mentored 50+ engineering leaders now in senior roles at major tech companies

Director of Engineering | Facebook | Menlo Park, CA | 2011 - 2014
• Built infrastructure supporting 1B+ daily active users during hypergrowth phase
• Led mobile platform development during critical iOS and Android expansion
• Established data engineering practices processing petabytes of user data daily

BOARD POSITIONS & ADVISORY ROLES
• Board Member - TechStartup Accelerator (2019 - Present)
• Technical Advisor - 5 venture capital firms including Andreessen Horowitz
• Advisory Board - Stanford Computer Science Department

EDUCATION & CREDENTIALS
Master of Business Administration (MBA) | Stanford Graduate School of Business | 2011
Master of Science in Computer Science | MIT | 2009
Bachelor of Science in Electrical Engineering | UC Berkeley | 2007

THOUGHT LEADERSHIP
• Keynote Speaker at major technology conferences (CES, Web Summit, TechCrunch Disrupt)
• Published 25+ articles on technology leadership in Harvard Business Review and Forbes
• Podcast host "Future of Technology" with 100K+ monthly listeners
• Regular contributor to CNBC and Bloomberg on technology trends`
    },
    {
      id: 6,
      name: 'Recent Graduate',
      category: 'entry-level',
      content: `JESSICA RODRIGUEZ
Marketing Graduate
jessica.rodriguez@student.com | (555) 234-5678 | Austin, TX 78701
LinkedIn: linkedin.com/in/jessicarodriguez

PROFESSIONAL OBJECTIVE
Recent Marketing graduate with strong academic background and hands-on internship experience in digital marketing and brand management. Passionate about data-driven marketing strategies and consumer behavior analysis. Seeking entry-level marketing position to apply creative problem-solving skills and contribute to innovative marketing campaigns.

EDUCATION
Bachelor of Business Administration - Marketing | University of Texas at Austin | May 2024
GPA: 3.8/4.0 | Magna Cum Laude | Dean's List (6 semesters)

Relevant Coursework:
• Digital Marketing Strategy & Analytics     • Consumer Behavior & Psychology
• Brand Management & Positioning           • Marketing Research & Data Analysis
• Social Media Marketing                   • Integrated Marketing Communications
• International Business & Global Markets  • E-commerce & Online Marketing

INTERNSHIP EXPERIENCE

Marketing Intern | Dell Technologies | Austin, TX | Summer 2023
• Supported social media campaigns reaching 500K+ followers across platforms
• Conducted competitor analysis for new product launch in laptop market
• Created content calendar resulting in 25% increase in engagement rates
• Assisted with trade show planning and execution for South by Southwest
• Collaborated with cross-functional teams on email marketing campaigns

Digital Marketing Intern | Local Austin Startup | Austin, TX | Summer 2022
• Managed Instagram and TikTok accounts growing follower base by 200%
• Designed marketing materials using Canva and Adobe Creative Suite
• Conducted customer surveys and analyzed feedback for product improvements
• Wrote blog posts on industry trends published on company website
• Supported influencer outreach campaign connecting with 50+ local creators

ACADEMIC PROJECTS & ACHIEVEMENTS

Senior Capstone Project: "Social Media Marketing Strategy for Sustainable Fashion Brand"
• Developed comprehensive 6-month marketing plan with $50K budget allocation
• Conducted primary research with 300+ survey respondents on sustainable fashion
• Created detailed buyer personas and customer journey mapping
• Presented findings to panel of industry professionals receiving top marks

Marketing Research Project: "Gen Z Consumer Behavior in E-commerce"
• Led team of 5 students analyzing online shopping patterns of college students
• Utilized SPSS for statistical analysis of 1,000+ survey responses
• Presented research findings at University Business Student Conference
• Paper selected for publication in undergraduate business journal

TECHNICAL SKILLS
• Digital Marketing: Google Analytics, Google Ads, Facebook Ads Manager, Hootsuite
• Design: Canva, Adobe Photoshop, Adobe Illustrator, Figma
• Analytics: SPSS, Excel, Tableau, Google Data Studio
• Social Media: Instagram, TikTok, LinkedIn, Twitter, YouTube
• Content Management: WordPress, Mailchimp, Buffer

LEADERSHIP & ACTIVITIES
• President - Marketing Student Association (2023-2024)
• Vice President - Hispanic Business Student Association (2022-2023)
• Volunteer - Austin Food Bank (2021-2024): 100+ hours community service
• Study Abroad - International Business Program, London, UK (Fall 2022)

AWARDS & RECOGNITION
• Outstanding Marketing Student Award - University of Texas (2024)
• Scholarship Recipient - Hispanic Scholarship Fund (2021-2024)
• Marketing Plan Competition Winner - Texas Business Students Conference (2023)`
    }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="relative pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`text-center transition-all duration-1000 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-6">
              Professional Resume Templates
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Choose from our collection of A4-sized, professionally designed templates with complete English content. 
              Each template showcases real professional experience and achievements.
            </p>
            <div className="flex justify-center space-x-8 text-sm text-gray-600">
              <div className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                <span>A4 Format</span>
              </div>
              <div className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                <span>Complete Content</span>
              </div>
              <div className="flex items-center">
                <i className="ri-check-line text-green-500 mr-2"></i>
                <span>Professional English</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter Section */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className={`bg-white/70 backdrop-blur-lg rounded-2xl shadow-xl border border-white/20 p-6 transition-all duration-1000 delay-300 ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          {/* Search Bar */}
          <div className="flex flex-col lg:flex-row gap-6 mb-6">
            <div className="flex-1">
              <div className="relative">
                <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search templates by name or profession..."
                  className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white/80 backdrop-blur-sm transition-all duration-300 hover:border-gray-300 text-lg"
                />
              </div>
            </div>
            <Link 
              href="/builder"
              className="group bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-8 py-4 rounded-xl hover:from-indigo-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-indigo-200/50 hover:-translate-y-1 whitespace-nowrap text-lg font-semibold"
            >
              <div className="flex items-center">
                <i className="ri-add-line group-hover:scale-110 transition-transform duration-300 mr-2"></i>
                <span>Start Building Resume</span>
              </div>
            </Link>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-3">
            {categories.map((category, index) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-xl transition-all duration-300 hover:scale-105 ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-200/50'
                    : 'bg-white/80 text-gray-700 hover:bg-white border border-gray-200 hover:border-indigo-300'
                } ${isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                style={{ transitionDelay: `${300 + index * 50}ms` }}
              >
                <span className="font-medium whitespace-nowrap">{category.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Templates Grid */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {filteredTemplates.map((template, index) => (
            <div
              key={template.id}
              className={`group bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 ${
                isAnimated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${500 + index * 100}ms` }}
            >
              {/* Template Preview */}
              <div className="relative bg-white p-8 border-b border-gray-100">
                <div className="bg-gray-50 rounded-lg p-6 h-96 overflow-hidden relative shadow-inner">
                  <div className="text-xs leading-relaxed text-gray-700 font-mono">
                    <div className="whitespace-pre-wrap">{template.content}</div>
                  </div>
                  
                  {/* Gradient overlay at bottom */}
                  <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-gray-50 to-transparent"></div>
                </div>
              </div>

              {/* Template Info */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-bold text-gray-900 text-xl">{template.name}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    template.category === 'professional' ? 'bg-blue-100 text-blue-800' :
                    template.category === 'creative' ? 'bg-purple-100 text-purple-800' :
                    template.category === 'modern' ? 'bg-green-100 text-green-800' :
                    template.category === 'executive' ? 'bg-gray-100 text-gray-800' :
                    'bg-orange-100 text-orange-800'
                  }`}>
                    {template.category.replace('-', ' ').toUpperCase()}
                  </span>
                </div>

                {/* Use Template Button */}
                <Link
                  href={`/builder?template=${template.name.toLowerCase().replace(/\s+/g, '-')}`}
                  className="block w-full text-center py-4 rounded-xl font-semibold transition-all duration-300 hover:scale-105 whitespace-nowrap bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:from-indigo-600 hover:to-purple-700 shadow-lg hover:shadow-indigo-200/50"
                >
                  <i className="ri-edit-line mr-2"></i>
                  Use This Template
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* No Results */}
        {filteredTemplates.length === 0 && (
          <div className="text-center py-16">
            <div className="w-32 h-32 mx-auto mb-6 bg-gray-100 rounded-2xl flex items-center justify-center">
              <i className="ri-search-line text-4xl text-gray-400"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-3">No Templates Found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your search terms or filter criteria to find the perfect template.</p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
              className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-indigo-600 hover:to-purple-700 transition-all duration-300 font-semibold whitespace-nowrap"
            >
              <i className="ri-refresh-line mr-2"></i>
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Call to Action */}
      <div className="relative bg-gradient-to-r from-indigo-600 to-purple-700 py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Build Your Professional Resume?
          </h2>
          <p className="text-xl text-indigo-100 mb-8">
            Select any template above to start building your resume with our easy-to-use builder
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/builder"
              className="bg-white text-indigo-600 px-8 py-4 rounded-xl hover:bg-gray-50 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl hover:-translate-y-1 whitespace-nowrap"
            >
              <i className="ri-file-edit-line mr-2"></i>
              Start Building Now
            </Link>
            <Link
              href="/resume-examples"
              className="bg-green-500 text-white px-8 py-4 rounded-xl hover:bg-green-600 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl hover:-translate-y-1 whitespace-nowrap"
            >
              <i className="ri-eye-line mr-2"></i>
              View Examples
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
