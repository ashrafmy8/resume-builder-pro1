import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const formData = await req.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      return new Response(
        JSON.stringify({ error: 'No file provided' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Convert file to base64 for processing
    const arrayBuffer = await file.arrayBuffer()
    const uint8Array = new Uint8Array(arrayBuffer)
    let fileContent = ''

    // Simple text extraction for PDF/DOC files
    // In a real implementation, you would use a proper PDF/DOC parser
    try {
      const decoder = new TextDecoder('utf-8')
      fileContent = decoder.decode(uint8Array)
    } catch {
      // Fallback for binary files - extract readable text
      fileContent = Array.from(uint8Array)
        .map(byte => String.fromCharCode(byte))
        .join('')
        .replace(/[^\x20-\x7E\n\r\t]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
    }

    // AI-powered extraction using pattern matching and NLP
    const extractedData = await extractResumeData(fileContent, file.name)

    return new Response(
      JSON.stringify({
        success: true,
        data: extractedData,
        fileName: file.name
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )

  } catch (error) {
    console.error('Resume extraction error:', error)
    return new Response(
      JSON.stringify({ 
        error: 'Failed to extract resume data',
        details: error.message 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})

async function extractResumeData(content: string, fileName: string) {
  // Clean and normalize content
  const cleanContent = content
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s@.,()-]/g, ' ')
    .trim()

  // Extract personal information
  const personalInfo = extractPersonalInfo(cleanContent)
  
  // Extract professional summary
  const summary = extractSummary(cleanContent)
  
  // Extract work experience
  const experience = extractExperience(cleanContent)
  
  // Extract education
  const education = extractEducation(cleanContent)
  
  // Extract skills
  const skills = extractSkills(cleanContent)

  return {
    personalInfo,
    summary,
    experience,
    education,
    skills,
    extractedFrom: fileName,
    extractedAt: new Date().toISOString()
  }
}

function extractPersonalInfo(content: string) {
  const personalInfo: any = {}

  // Extract name (usually at the beginning)
  const namePatterns = [
    /^([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/,
    /(?:Name|NOME|NAME):\s*([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/i
  ]
  
  for (const pattern of namePatterns) {
    const nameMatch = content.match(pattern)
    if (nameMatch) {
      personalInfo.fullName = nameMatch[1].trim()
      break
    }
  }

  // Extract email
  const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/
  const emailMatch = content.match(emailPattern)
  if (emailMatch) {
    personalInfo.email = emailMatch[1]
  }

  // Extract phone
  const phonePatterns = [
    /(\+?1?[-.\s]?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4})/,
    /(\+?[0-9]{1,3}[-.\s]?[0-9]{3,4}[-.\s]?[0-9]{3,4}[-.\s]?[0-9]{3,4})/
  ]
  
  for (const pattern of phonePatterns) {
    const phoneMatch = content.match(pattern)
    if (phoneMatch) {
      personalInfo.phone = phoneMatch[1].trim()
      break
    }
  }

  // Extract location
  const locationPatterns = [
    /([A-Z][a-z]+,\s*[A-Z]{2})/,
    /([A-Z][a-z]+\s*[A-Z][a-z]*,\s*[A-Z]{2,3})/,
    /(?:Address|Location|City):\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*,?\s*[A-Z]{2,3})/i
  ]
  
  for (const pattern of locationPatterns) {
    const locationMatch = content.match(pattern)
    if (locationMatch) {
      personalInfo.location = locationMatch[1].trim()
      break
    }
  }

  // Extract LinkedIn
  const linkedinPattern = /(linkedin\.com\/in\/[a-zA-Z0-9-]+)/
  const linkedinMatch = content.match(linkedinPattern)
  if (linkedinMatch) {
    personalInfo.linkedin = `https://www.${linkedinMatch[1]}`
  }

  // Extract website
  const websitePattern = /((?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/
  const websiteMatch = content.match(websitePattern)
  if (websiteMatch && !websiteMatch[1].includes('linkedin') && !websiteMatch[1].includes('@')) {
    personalInfo.website = websiteMatch[1]
  }

  return personalInfo
}

function extractSummary(content: string) {
  const summaryKeywords = [
    'summary', 'profile', 'objective', 'about', 'overview', 'professional summary',
    'career objective', 'personal statement', 'professional profile'
  ]
  
  for (const keyword of summaryKeywords) {
    const pattern = new RegExp(`(?:${keyword})(?:\\s*:)?\\s*([^\\n\\r]{50,300})`, 'i')
    const match = content.match(pattern)
    if (match) {
      return match[1].trim().replace(/\s+/g, ' ')
    }
  }
  
  // Fallback: extract first substantial paragraph
  const paragraphs = content.split(/\n\s*\n/).filter(p => p.length > 50 && p.length < 400)
  if (paragraphs.length > 0) {
    return paragraphs[0].trim().replace(/\s+/g, ' ')
  }
  
  return ''
}

function extractExperience(content: string) {
  const experience = []
  const experienceKeywords = ['experience', 'employment', 'work history', 'professional experience', 'career']
  
  // Find experience section
  let experienceSection = ''
  for (const keyword of experienceKeywords) {
    const pattern = new RegExp(`(?:${keyword})(?:\\s*:)?\\s*([\\s\\S]*?)(?=(?:education|skills|projects|certifications)|$)`, 'i')
    const match = content.match(pattern)
    if (match) {
      experienceSection = match[1]
      break
    }
  }
  
  if (!experienceSection) {
    experienceSection = content
  }
  
  // Extract job entries
  const jobPattern = /([A-Z][a-zA-Z\s&,.-]+?)(?:\s+at\s+|\s+@\s+|\s+-\s+)([A-Z][a-zA-Z\s&,.-]+?)(?:\s+\|\s+|\s+-\s+|\s+\()([0-9]{4}(?:\s*-\s*(?:[0-9]{4}|Present|Current))?)/g
  
  let match
  while ((match = jobPattern.exec(experienceSection)) !== null) {
    const position = match[1].trim()
    const company = match[2].trim()
    const duration = match[3].trim()
    
    // Find description following this job
    const startIndex = match.index + match[0].length
    const nextJobIndex = experienceSection.slice(startIndex).search(/[A-Z][a-zA-Z\s&,.-]+?\s+(?:at|@|-)\s+[A-Z]/)
    const descriptionEnd = nextJobIndex !== -1 ? startIndex + nextJobIndex : experienceSection.length
    const description = experienceSection.slice(startIndex, descriptionEnd)
      .replace(/^\s*[-•]\s*/, '')
      .trim()
      .split(/\n\s*[-•]\s*/)
      .join('. ')
      .replace(/\s+/g, ' ')
      .substring(0, 300)
    
    experience.push({
      position,
      company,
      duration,
      description: description || `${position} at ${company}. Responsible for key duties and achievements in this role.`
    })
  }
  
  return experience
}

function extractEducation(content: string) {
  const education = []
  const educationKeywords = ['education', 'academic', 'qualifications', 'degrees']
  
  // Find education section
  let educationSection = ''
  for (const keyword of educationKeywords) {
    const pattern = new RegExp(`(?:${keyword})(?:\\s*:)?\\s*([\\s\\S]*?)(?=(?:experience|skills|projects|certifications)|$)`, 'i')
    const match = content.match(pattern)
    if (match) {
      educationSection = match[1]
      break
    }
  }
  
  if (!educationSection) {
    educationSection = content
  }
  
  // Extract degree patterns
  const degreePatterns = [
    /(Bachelor|Master|PhD|MBA|Associate|Doctorate)(?:\s+of)?(?:\s+(?:Science|Arts|Engineering|Business))?(?:\s+in)?(?:\s+([A-Z][a-zA-Z\s&,.-]+?))?(?:\s+from\s+|\s+at\s+|\s+-\s+)([A-Z][a-zA-Z\s&,.-]+?)(?:\s+\|\s+|\s+-\s+|\s+\()([0-9]{4})/gi,
    /([A-Z][a-zA-Z\s]+?)(?:\s+from\s+|\s+at\s+|\s+-\s+)([A-Z][a-zA-Z\s&,.-]+?)(?:\s+\|\s+|\s+-\s+|\s+\()([0-9]{4})/g
  ]
  
  for (const pattern of degreePatterns) {
    let match
    while ((match = pattern.exec(educationSection)) !== null) {
      let degree, field, school, year
      
      if (pattern === degreePatterns[0]) {
        degree = match[1]
        field = match[2] || ''
        school = match[3]
        year = match[4]
      } else {
        degree = match[1]
        school = match[2]
        year = match[3]
        field = ''
      }
      
      education.push({
        degree: `${degree}${field ? ` in ${field}` : ''}`.trim(),
        school: school.trim(),
        year: year.trim()
      })
    }
  }
  
  return education
}

function extractSkills(content: string) {
  const skills = []
  const skillsKeywords = ['skills', 'technologies', 'competencies', 'expertise', 'proficiencies']
  
  // Find skills section
  let skillsSection = ''
  for (const keyword of skillsKeywords) {
    const pattern = new RegExp(`(?:${keyword})(?:\\s*:)?\\s*([\\s\\S]*?)(?=(?:experience|education|projects|certifications)|$)`, 'i')
    const match = content.match(pattern)
    if (match) {
      skillsSection = match[1]
      break
    }
  }
  
  if (!skillsSection) {
    skillsSection = content
  }
  
  // Common technical skills
  const techSkills = [
    'JavaScript', 'Python', 'Java', 'React', 'Node.js', 'HTML', 'CSS', 'SQL',
    'MongoDB', 'PostgreSQL', 'AWS', 'Docker', 'Git', 'TypeScript', 'Vue.js',
    'Angular', 'PHP', 'Ruby', 'C++', 'C#', '.NET', 'Django', 'Flask',
    'Express.js', 'jQuery', 'Bootstrap', 'Sass', 'Webpack', 'REST API',
    'GraphQL', 'Redis', 'Kubernetes', 'Jenkins', 'CI/CD', 'Agile', 'Scrum'
  ]
  
  // Extract skills by patterns
  const skillPatterns = [
    /(?:^|\n)\s*[-•]\s*([A-Z][a-zA-Z\s&+#.-]+)/gm,
    /([A-Z][a-zA-Z\s&+#.-]+?)(?:\s*[,|]\s*)/g
  ]
  
  const foundSkills = new Set()
  
  // Check for known technical skills
  for (const skill of techSkills) {
    const pattern = new RegExp(`\\b${skill}\\b`, 'gi')
    if (pattern.test(skillsSection) || pattern.test(content)) {
      foundSkills.add(skill)
    }
  }
  
  // Extract skills from patterns
  for (const pattern of skillPatterns) {
    let match
    while ((match = pattern.exec(skillsSection)) !== null) {
      const skill = match[1].trim()
      if (skill.length > 2 && skill.length < 30 && /^[A-Z]/.test(skill)) {
        foundSkills.add(skill)
      }
    }
  }
  
  return Array.from(foundSkills).slice(0, 20)
}