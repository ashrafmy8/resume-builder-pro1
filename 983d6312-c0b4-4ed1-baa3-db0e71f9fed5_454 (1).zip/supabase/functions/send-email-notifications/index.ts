import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { type, email, firstName, resetUrl } = await req.json()
    console.log('Email notification request:', { type, email, firstName })

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
    if (!RESEND_API_KEY) {
      console.error('RESEND_API_KEY not found in environment variables')
      throw new Error('Email service not configured')
    }

    let subject = ''
    let htmlContent = ''

    if (type === 'password_reset') {
      subject = 'Reset Your ResumeTeacher.com Password'
      
      htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Reset Your Password - Resume Teacher</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f8fafc;">
          <div style="max-width: 600px; margin: 0 auto; background-color: white;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 20px; text-align: center;">
              <img src="https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/8c822e6d95d195d9ba734a18b3eef59c.png" alt="Resume Teacher" style="height: 60px; margin-bottom: 20px;">
              <h1 style="color: white; margin: 0; font-size: 28px; font-weight: 600;">Password Reset Request</h1>
            </div>
            
            <!-- Content -->
            <div style="padding: 40px 30px;">
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
                Hi ${firstName || 'there'},
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin-bottom: 25px;">
                We received a request to reset the password for your ResumeTeacher.com account. If you made this request, you can reset your password by clicking the button below:
              </p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${resetUrl}" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; padding: 15px 30px; border-radius: 8px; font-weight: 600; font-size: 16px; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);">
                  👉 Reset Password
                </a>
              </div>
              
              <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 25px 0;">
                Or copy and paste this link into your browser:<br>
                <a href="${resetUrl}" style="color: #667eea; word-break: break-all;">${resetUrl}</a>
              </p>
              
              <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 25px 0; border-radius: 4px;">
                <p style="color: #92400e; font-size: 14px; margin: 0; font-weight: 500;">
                  ⚠️ This link will expire in 1 hour for your security.
                </p>
              </div>
              
              <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin-top: 30px;">
                If you didn't request a password reset, you can safely ignore this email. Your account will remain secure.
              </p>
            </div>
            
            <!-- Footer -->
            <div style="background-color: #f8fafc; padding: 30px; text-align: center; border-top: 1px solid #e5e7eb;">
              <p style="color: #374151; font-size: 16px; font-weight: 600; margin: 0 0 10px 0;">
                Thank you,<br>
                The ResumeTeacher Team
              </p>
              <p style="color: #6b7280; font-size: 14px; margin: 15px 0;">
                <a href="mailto:support@resume-teacher.com" style="color: #667eea; text-decoration: none;">support@resume-teacher.com</a> | 
                <a href="https://resume-teacher.com" style="color: #667eea; text-decoration: none;">resume-teacher.com</a>
              </p>
              <p style="color: #9ca3af; font-size: 12px; margin: 20px 0 0 0; line-height: 1.4;">
                This is an automated message from ResumeTeacher.com. Please do not reply to this email.
                <br>If you need assistance, contact us at support@resume-teacher.com
              </p>
            </div>
          </div>
        </body>
        </html>
      `
    } else {
      throw new Error('Invalid email type')
    }

    const emailData = {
      from: 'noreply@auth.resume-teacher.com',
      to: [email],
      subject,
      html: htmlContent,
    }

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailData),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Resend API error:', response.status, errorText)
      throw new Error(`Failed to send email: ${response.status} ${errorText}`)
    }

    const result = await response.json()
    console.log('Email sent successfully:', result)

    return new Response(
      JSON.stringify({ success: true, messageId: result.id }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error sending email:', error)
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})