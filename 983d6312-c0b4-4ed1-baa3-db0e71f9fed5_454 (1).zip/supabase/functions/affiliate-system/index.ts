import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    )

    const authHeader = req.headers.get('Authorization')!
    const token = authHeader.replace('Bearer ', '')
    const { data: { user } } = await supabaseClient.auth.getUser(token)

    if (!user) {
      throw new Error('Unauthorized')
    }

    const { action, ...body } = await req.json()

    switch (action) {
      case 'generate_affiliate_code': {
        // Generate unique affiliate code
        const affiliateCode = generateUniqueCode()
        const referralLink = `${Deno.env.get('SITE_URL') || 'https://resumeteacher.com'}/signup?ref=${affiliateCode}`

        // Check if user already has an affiliate code
        const { data: existing } = await supabaseClient
          .from('affiliate_codes')
          .select('*')
          .eq('user_id', user.id)
          .single()

        if (existing) {
          return new Response(
            JSON.stringify({ 
              success: true, 
              affiliateCode: existing.affiliate_code,
              referralLink: existing.referral_link 
            }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          )
        }

        // Create new affiliate code
        const { data: newCode, error } = await supabaseClient
          .from('affiliate_codes')
          .insert({
            user_id: user.id,
            affiliate_code: affiliateCode,
            referral_link: referralLink
          })
          .select()
          .single()

        if (error) throw error

        // Initialize earnings record
        await supabaseClient
          .from('affiliate_earnings')
          .insert({
            user_id: user.id,
            total_earned: 0.00,
            total_paid: 0.00,
            pending_payout: 0.00
          })

        return new Response(
          JSON.stringify({ 
            success: true, 
            affiliateCode: newCode.affiliate_code,
            referralLink: newCode.referral_link 
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      case 'get_affiliate_stats': {
        // Get affiliate code and stats
        const { data: affiliateCode } = await supabaseClient
          .from('affiliate_codes')
          .select('*')
          .eq('user_id', user.id)
          .single()

        if (!affiliateCode) {
          return new Response(
            JSON.stringify({ success: false, message: 'No affiliate code found' }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          )
        }

        // Get referrals
        const { data: referrals } = await supabaseClient
          .from('affiliate_referrals')
          .select(`
            *,
            referred_user:users!affiliate_referrals_referred_user_id_fkey(email, first_name, last_name, created_at)
          `)
          .eq('referrer_user_id', user.id)
          .order('created_at', { ascending: false })

        // Get earnings
        const { data: earnings } = await supabaseClient
          .from('affiliate_earnings')
          .select('*')
          .eq('user_id', user.id)
          .single()

        return new Response(
          JSON.stringify({
            success: true,
            affiliateCode: affiliateCode.affiliate_code,
            referralLink: affiliateCode.referral_link,
            totalReferrals: affiliateCode.total_referrals,
            totalEarnings: affiliateCode.total_earnings,
            referrals: referrals || [],
            earnings: earnings || {
              total_earned: 0,
              total_paid: 0,
              pending_payout: 0
            }
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      case 'track_referral': {
        const { referredUserId, affiliateCode } = body

        // Find the affiliate code
        const { data: codeData } = await supabaseClient
          .from('affiliate_codes')
          .select('*')
          .eq('affiliate_code', affiliateCode)
          .single()

        if (!codeData) {
          throw new Error('Invalid affiliate code')
        }

        // Check if referral already exists
        const { data: existingReferral } = await supabaseClient
          .from('affiliate_referrals')
          .select('*')
          .eq('referred_user_id', referredUserId)
          .single()

        if (existingReferral) {
          return new Response(
            JSON.stringify({ success: false, message: 'User already referred' }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          )
        }

        // Create referral record
        await supabaseClient
          .from('affiliate_referrals')
          .insert({
            affiliate_code_id: codeData.id,
            referrer_user_id: codeData.user_id,
            referred_user_id: referredUserId,
            commission_amount: 3.00,
            status: 'confirmed',
            conversion_date: new Date().toISOString()
          })

        // Update affiliate code stats
        await supabaseClient
          .from('affiliate_codes')
          .update({
            total_referrals: codeData.total_referrals + 1,
            total_earnings: parseFloat(codeData.total_earnings) + 3.00,
            updated_at: new Date().toISOString()
          })
          .eq('id', codeData.id)

        // Update earnings
        const { data: currentEarnings } = await supabaseClient
          .from('affiliate_earnings')
          .select('*')
          .eq('user_id', codeData.user_id)
          .single()

        if (currentEarnings) {
          await supabaseClient
            .from('affiliate_earnings')
            .update({
              total_earned: parseFloat(currentEarnings.total_earned) + 3.00,
              pending_payout: parseFloat(currentEarnings.pending_payout) + 3.00,
              updated_at: new Date().toISOString()
            })
            .eq('user_id', codeData.user_id)
        }

        return new Response(
          JSON.stringify({ success: true, message: 'Referral tracked successfully' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      case 'update_payout_info': {
        const { payoutMethod, payoutEmail } = body

        const { error } = await supabaseClient
          .from('affiliate_earnings')
          .update({
            payout_method: payoutMethod,
            payout_email: payoutEmail,
            updated_at: new Date().toISOString()
          })
          .eq('user_id', user.id)

        if (error) throw error

        return new Response(
          JSON.stringify({ success: true, message: 'Payout info updated' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      default:
        throw new Error('Invalid action')
    }

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    )
  }
})

function generateUniqueCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = 'RT'
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}