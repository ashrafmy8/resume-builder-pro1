import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    const { email, verificationCode, userId } = await req.json();

    if (!email || !verificationCode || !userId) {
      throw new Error('Missing required fields: email, verificationCode, userId');
    }

    // Validate verification code format (6 digits only)
    if (!/^\d{6}$/.test(verificationCode.trim())) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Invalid verification code format. Please enter 6 digits.'
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    // Check verification code in our custom database
    const { data: verification, error: fetchError } = await supabaseClient
      .from('email_verifications')
      .select('*')
      .eq('user_id', userId)
      .eq('email', email)
      .eq('verification_code', verificationCode.trim())
      .eq('is_verified', false)
      .single();

    if (fetchError || !verification) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Invalid or expired verification code. Please check your email or request a new code.'
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    // Check if code has expired (15 minutes)
    const now = new Date();
    const expiresAt = new Date(verification.expires_at);
    
    if (now > expiresAt) {
      // Mark expired code as invalid
      await supabaseClient
        .from('email_verifications')
        .update({ is_verified: false, expired: true })
        .eq('id', verification.id);

      return new Response(
        JSON.stringify({
          success: false,
          error: 'Verification code has expired. Please request a new code.',
          expired: true
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    // Mark verification as complete in our database
    const { error: updateError } = await supabaseClient
      .from('email_verifications')
      .update({
        is_verified: true,
        verified_at: new Date().toISOString()
      })
      .eq('id', verification.id);

    if (updateError) {
      console.error('Verification update error:', updateError);
      throw new Error(`Failed to update verification status: ${updateError.message}`);
    }

    // Update user profile as email verified
    const { error: userUpdateError } = await supabaseClient
      .from('users')
      .update({
        email_verified: true,
        verified_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', userId);

    if (userUpdateError) {
      console.error('User profile update error:', userUpdateError);
    }

    // Update profiles table
    const { error: profileUpdateError } = await supabaseClient
      .from('profiles')
      .update({
        email_verified: true,
        verified_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', userId);

    if (profileUpdateError) {
      console.error('Profile update error:', profileUpdateError);
    }

    // Update Supabase Auth user - mark as email confirmed
    const { error: authUpdateError } = await supabaseClient.auth.admin.updateUserById(
      userId,
      { 
        email_confirm: true,
        user_metadata: { 
          email_verified: true,
          verification_method: 'custom_otp',
          verified_at: new Date().toISOString()
        }
      }
    );

    if (authUpdateError) {
      console.error('Auth user update error:', authUpdateError);
    }

    // Clean up old verification codes for this user
    await supabaseClient
      .from('email_verifications')
      .delete()
      .eq('user_id', userId)
      .eq('email', email)
      .neq('id', verification.id);

    console.log(`Email verification successful for user ${userId}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Email verified successfully! Redirecting to dashboard...',
        redirectUrl: '/dashboard',
        customVerification: true,
        verified: true
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Verification error:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Verification failed. Please try again.',
        customVerification: true
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});