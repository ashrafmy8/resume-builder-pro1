import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { email, resetToken } = await req.json()

    if (!email || !resetToken) {
      return new Response(
        JSON.stringify({ error: 'Email and reset token are required' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400 
        }
      )
    }

    // Use your actual ResumeTeacher domain for the reset URL
    const resetUrl = `https://resume-teacher.com/reset-password?token=${resetToken}&email=${encodeURIComponent(email)}`

    const emailHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reset Your ResumeTeacher.com Password</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f8fafc;
            }
            .container {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 20px;
                padding: 2px;
                margin: 20px 0;
            }
            .inner-container {
                background: white;
                border-radius: 18px;
                padding: 40px;
                text-align: center;
            }
            .logo {
                font-family: "Pacifico", serif;
                font-size: 32px;
                font-weight: bold;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                margin-bottom: 30px;
                display: block;
            }
            .greeting {
                font-size: 18px;
                color: #4a5568;
                margin-bottom: 20px;
            }
            .message {
                font-size: 16px;
                color: #4a5568;
                margin-bottom: 30px;
                line-height: 1.6;
            }
            .reset-button {
                display: inline-block;
                padding: 16px 32px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white !important;
                text-decoration: none;
                border-radius: 50px;
                font-weight: 600;
                font-size: 16px;
                margin: 20px 0;
                transition: transform 0.2s ease;
            }
            .reset-button:hover {
                transform: translateY(-2px);
            }
            .link-text {
                font-size: 14px;
                color: #718096;
                margin: 20px 0;
                word-break: break-all;
                background: #f7fafc;
                padding: 15px;
                border-radius: 8px;
                border-left: 4px solid #667eea;
            }
            .security-notice {
                background: #fef5e7;
                border: 1px solid #f6ad55;
                border-radius: 8px;
                padding: 15px;
                margin: 20px 0;
                font-size: 14px;
                color: #744210;
            }
            .footer {
                margin-top: 40px;
                padding-top: 20px;
                border-top: 1px solid #e2e8f0;
                font-size: 14px;
                color: #718096;
            }
            .team-signature {
                font-weight: 600;
                color: #4a5568;
                margin-bottom: 10px;
            }
            .contact-info {
                margin-top: 15px;
            }
            .contact-info a {
                color: #667eea;
                text-decoration: none;
            }
            .contact-info a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="inner-container">
                <div class="logo">ResumeTeacher</div>
                
                <div class="greeting">Hi there,</div>
                
                <div class="message">
                    We received a request to reset the password for your ResumeTeacher.com account. If you made this request, you can reset your password by clicking the button below:
                </div>
                
                <div style="margin: 30px 0;">
                    👉 <a href="${resetUrl}" class="reset-button">Reset Password</a>
                </div>
                
                <div class="message">
                    Or copy and paste this link into your browser:
                </div>
                
                <div class="link-text">
                    ${resetUrl}
                </div>
                
                <div class="security-notice">
                    <strong>⏰ This link will expire in 1 hour for your security.</strong>
                    <br><br>
                    If you didn't request a password reset, you can safely ignore this email. Your account will remain secure.
                </div>
                
                <div class="footer">
                    <div class="team-signature">
                        Thank you,<br>
                        The ResumeTeacher Team
                    </div>
                    
                    <div class="contact-info">
                        <a href="mailto:support@resume-teacher.com">support@resume-teacher.com</a> | 
                        <a href="https://resume-teacher.com">resume-teacher.com</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px; font-size: 12px; color: #a0aec0;">
            This email was sent to ${email}. If you no longer wish to receive these emails, please contact support.
        </div>
    </body>
    </html>
    `

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: 'ResumeTeacher <noreply@auth.resume-teacher.com>',
        to: [email],
        subject: 'Reset Your ResumeTeacher.com Password',
        html: emailHtml
      })
    })

    if (res.ok) {
      const data = await res.json()
      return new Response(JSON.stringify(data), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    } else {
      const error = await res.text()
      return new Response(JSON.stringify({ error }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})