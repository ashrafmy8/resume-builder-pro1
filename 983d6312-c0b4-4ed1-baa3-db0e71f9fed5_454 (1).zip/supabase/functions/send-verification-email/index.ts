import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { userId, email, firstName } = await req.json()
    
    if (!userId || !email || !firstName) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: userId, email, firstName' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    // Generate 6-digit verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString()
    
    // Delete any existing verification codes for this user
    await supabase
      .from('email_verifications')
      .delete()
      .eq('user_id', userId)
      .eq('email', email)
    
    // Store new verification code in database
    const { error: insertError } = await supabase
      .from('email_verifications')
      .insert({
        user_id: userId,
        email: email,
        verification_code: verificationCode,
        expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes from now
        is_verified: false,
        created_at: new Date().toISOString()
      })

    if (insertError) {
      console.error('Database error:', insertError)
      return new Response(
        JSON.stringify({ error: 'Failed to create verification record' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Create dashboard redirect URL
    const dashboardUrl = `${Deno.env.get('SITE_URL') || 'https://resume-teacher.com'}/dashboard`
    
    // Custom email content - NO Supabase default styling
    const emailContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Enter Your Verification Code - ResumeTeacher</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; 
            line-height: 1.6; 
            color: #333333; 
            background-color: #f8fafc; 
          }
          .email-container { 
            max-width: 600px; 
            margin: 20px auto; 
            background: #ffffff; 
            border-radius: 12px; 
            overflow: hidden; 
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07); 
          }
          .email-header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            padding: 40px 30px; 
            text-align: center; 
          }
          .logo { 
            color: #ffffff; 
            font-size: 28px; 
            font-weight: bold; 
            font-family: 'Pacifico', serif; 
            margin-bottom: 8px;
          }
          .header-subtitle {
            color: rgba(255, 255, 255, 0.9);
            font-size: 16px;
            font-weight: 500;
          }
          .email-body { 
            padding: 40px 30px; 
            background: #ffffff; 
          }
          .greeting { 
            font-size: 24px; 
            font-weight: 600; 
            color: #1a202c; 
            margin-bottom: 16px; 
            text-align: center;
          }
          .welcome-message { 
            font-size: 16px; 
            color: #4a5568; 
            text-align: center; 
            margin-bottom: 32px; 
            line-height: 1.5;
          }
          .code-section { 
            text-align: center; 
            margin: 40px 0; 
            padding: 32px 20px;
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            border-radius: 12px;
            border: 2px solid #e2e8f0;
          }
          .code-label {
            font-size: 14px;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .verification-code { 
            display: inline-block; 
            background: #ffffff; 
            border: 3px solid #4299e1; 
            border-radius: 12px; 
            padding: 20px 32px; 
            font-size: 36px; 
            font-weight: bold; 
            letter-spacing: 8px; 
            color: #2b6cb0; 
            font-family: 'Courier New', monospace; 
            box-shadow: 0 2px 4px rgba(66, 153, 225, 0.1);
          }
          .instructions {
            background: #ebf4ff;
            border: 1px solid #bee3f8;
            border-radius: 8px;
            padding: 20px;
            margin: 32px 0;
            text-align: center;
          }
          .instructions-title {
            color: #2c5282;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 8px;
          }
          .instructions-text {
            color: #2a69ac;
            font-size: 14px;
            line-height: 1.5;
          }
          .dashboard-section { 
            background: linear-gradient(135deg, #f0fff4 0%, #c6f6d5 100%); 
            border: 2px solid #9ae6b4; 
            border-radius: 12px; 
            padding: 24px; 
            margin: 32px 0; 
            text-align: center; 
          }
          .dashboard-title { 
            color: #22543d; 
            font-weight: 700;
            font-size: 18px; 
            margin-bottom: 8px; 
          }
          .dashboard-text { 
            color: #2f855a; 
            font-size: 14px; 
            margin-bottom: 16px; 
            line-height: 1.4;
          }
          .dashboard-button { 
            display: inline-block; 
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); 
            color: #ffffff; 
            text-decoration: none; 
            padding: 12px 24px; 
            border-radius: 8px; 
            font-weight: 600; 
            font-size: 14px; 
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(72, 187, 120, 0.2);
          }
          .dashboard-button:hover { 
            background: linear-gradient(135deg, #38a169 0%, #2f855a 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(72, 187, 120, 0.3);
          }
          .security-notice { 
            background: #fffbeb; 
            border-left: 4px solid #f6ad55; 
            border-radius: 6px;
            padding: 16px 20px; 
            margin: 24px 0; 
          }
          .security-text { 
            color: #c05621; 
            font-size: 14px; 
            font-weight: 500;
            display: flex;
            align-items: center;
          }
          .security-icon {
            margin-right: 8px;
            font-size: 16px;
          }
          .features-list {
            background: #f7fafc;
            border-radius: 8px;
            padding: 20px;
            margin: 24px 0;
          }
          .features-title {
            color: #2d3748;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 16px;
            text-align: center;
          }
          .features-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
          }
          .feature-item {
            display: flex;
            align-items: center;
            color: #4a5568;
            font-size: 14px;
          }
          .feature-icon {
            color: #4299e1;
            margin-right: 8px;
            font-size: 16px;
          }
          .email-footer { 
            background: #f8fafc; 
            padding: 30px; 
            text-align: center; 
            border-top: 1px solid #e2e8f0; 
          }
          .team-signature { 
            color: #2d3748; 
            font-weight: 600; 
            font-size: 16px;
            margin-bottom: 12px; 
          }
          .contact-info { 
            color: #718096; 
            font-size: 14px; 
            line-height: 1.4;
          }
          .contact-link { 
            color: #4299e1; 
            text-decoration: none; 
          }
          .contact-link:hover {
            color: #2b6cb0;
            text-decoration: underline;
          }
          
          @media (max-width: 600px) {
            .email-container { margin: 10px; }
            .email-header, .email-body, .email-footer { padding: 20px; }
            .verification-code { 
              font-size: 28px; 
              padding: 16px 24px; 
              letter-spacing: 4px; 
            }
            .features-grid { grid-template-columns: 1fr; }
          }
        </style>
      </head>
      <body>
        <div class="email-container">
          <div class="email-header">
            <div class="logo">ResumeTeacher</div>
            <div class="header-subtitle">Professional Resume Builder</div>
          </div>
          
          <div class="email-body">
            <div class="greeting">Welcome ${firstName}! 🎉</div>
            
            <div class="welcome-message">
              Thank you for joining ResumeTeacher! You're just one step away from creating your professional resume with our AI-powered tools.
            </div>
            
            <div class="instructions">
              <div class="instructions-title">📧 Verification Required</div>
              <div class="instructions-text">
                Please enter this 6-digit code in the verification form to complete your account setup and access your dashboard.
              </div>
            </div>
            
            <div class="code-section">
              <div class="code-label">Your Verification Code</div>
              <div class="verification-code">${verificationCode}</div>
            </div>
            
            <div class="dashboard-section">
              <div class="dashboard-title">🚀 Ready to Start Building?</div>
              <div class="dashboard-text">
                Once verified, you'll be redirected to your personal dashboard where you can start creating your professional resume immediately.
              </div>
              <a href="${dashboardUrl}" class="dashboard-button">Access Your Dashboard</a>
            </div>
            
            <div class="security-notice">
              <div class="security-text">
                <span class="security-icon">⏰</span>
                This verification code expires in 15 minutes for your security. If you didn't request this, please ignore this email.
              </div>
            </div>
            
            <div class="features-list">
              <div class="features-title">What's waiting for you:</div>
              <div class="features-grid">
                <div class="feature-item">
                  <span class="feature-icon">📄</span>
                  Professional Templates
                </div>
                <div class="feature-item">
                  <span class="feature-icon">🤖</span>
                  AI Content Suggestions
                </div>
                <div class="feature-item">
                  <span class="feature-icon">⚡</span>
                  ATS Optimization
                </div>
                <div class="feature-item">
                  <span class="feature-icon">💼</span>
                  Expert Career Advice
                </div>
              </div>
            </div>
          </div>
          
          <div class="email-footer">
            <div class="team-signature">Welcome to the ResumeTeacher family!</div>
            <div class="contact-info">
              Questions? Contact us at <a href="mailto:support@resume-teacher.com" class="contact-link">support@resume-teacher.com</a><br>
              Visit us at <a href="https://resume-teacher.com" class="contact-link">resume-teacher.com</a>
            </div>
          </div>
        </div>
      </body>
      </html>
    `

    // Send ONLY our custom email using Resend - NO Supabase auth emails
    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('RESEND_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'ResumeTeacher <noreply@auth.resume-teacher.com>',
        to: [email],
        subject: `${firstName}, enter your verification code - ResumeTeacher`,
        html: emailContent,
        // Add headers to prevent any auto-generated emails
        headers: {
          'X-Priority': '1',
          'X-MSMail-Priority': 'High',
          'Importance': 'high'
        }
      }),
    })

    if (!emailResponse.ok) {
      const errorData = await emailResponse.text()
      console.error('Error sending verification email:', errorData)
      return new Response(
        JSON.stringify({ error: 'Failed to send verification email' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const emailResult = await emailResponse.json()
    console.log('Custom verification email sent successfully:', emailResult)

    return new Response(
      JSON.stringify({ 
        message: 'Custom verification email sent successfully',
        emailId: emailResult.id,
        expiresIn: '15 minutes',
        customEmail: true
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Function error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})