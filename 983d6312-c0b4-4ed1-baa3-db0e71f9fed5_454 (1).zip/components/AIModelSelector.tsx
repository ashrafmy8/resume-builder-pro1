'use client';

import { useState, useEffect } from 'react';

interface AIModelSelectorProps {
  onModelChange: (model: 'standard' | 'deepseek') => void;
  currentModel?: 'standard' | 'deepseek';
}

export default function AIModelSelector({ onModelChange, currentModel = 'standard' }: AIModelSelectorProps) {
  const [selectedModel, setSelectedModel] = useState<'standard' | 'deepseek'>(currentModel);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Load saved preference from localStorage
    const savedModel = localStorage.getItem('ai-model-preference') as 'standard' | 'deepseek';
    if (savedModel) {
      setSelectedModel(savedModel);
      onModelChange(savedModel);
    }
  }, [onModelChange]);

  const handleModelChange = (model: 'standard' | 'deepseek') => {
    setSelectedModel(model);
    onModelChange(model);
    localStorage.setItem('ai-model-preference', model);
    setIsOpen(false);
  };

  const models = {
    standard: {
      name: 'Standard AI',
      description: 'Balanced performance for general use',
      icon: 'ri-brain-line',
      color: 'blue',
      features: ['Fast response', 'General purpose', 'Reliable results']
    },
    deepseek: {
      name: 'DeepSeek AI',
      description: 'Advanced AI for enhanced insights',
      icon: 'ri-search-eye-line',
      color: 'purple',
      features: ['Deep analysis', 'Advanced reasoning', 'Premium quality']
    }
  };

  const getColorClasses = (color: string, type: 'bg' | 'text' | 'border' | 'hover') => {
    const colorMap = {
      blue: {
        bg: 'bg-blue-500',
        text: 'text-blue-500',
        border: 'border-blue-500',
        hover: 'hover:bg-blue-50'
      },
      purple: {
        bg: 'bg-purple-500',
        text: 'text-purple-500',
        border: 'border-purple-500',
        hover: 'hover:bg-purple-50'
      }
    };
    return colorMap[color as keyof typeof colorMap]?.[type] || colorMap.blue[type];
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-3 px-4 py-2 bg-white border border-gray-200 rounded-xl hover:border-gray-300 transition-all shadow-sm hover:shadow-md"
      >
        <div className={`w-8 h-8 ${getColorClasses(models[selectedModel].color, 'bg')} rounded-lg flex items-center justify-center`}>
          <i className={`${models[selectedModel].icon} text-white text-sm`}></i>
        </div>
        <div className="text-left">
          <div className="font-semibold text-gray-900">{models[selectedModel].name}</div>
          <div className="text-xs text-gray-500">{models[selectedModel].description}</div>
        </div>
        <i className={`ri-arrow-down-s-line text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`}></i>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)}></div>
          <div className="absolute top-full left-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-bold text-gray-900 flex items-center">
                <i className="ri-settings-3-line text-gray-500 mr-2"></i>
                Choose AI Model
              </h3>
              <p className="text-sm text-gray-500 mt-1">Select your preferred AI model for assistance</p>
            </div>
            
            <div className="p-2">
              {Object.entries(models).map(([key, model]) => (
                <button
                  key={key}
                  onClick={() => handleModelChange(key as 'standard' | 'deepseek')}
                  className={`w-full p-4 rounded-xl transition-all ${
                    selectedModel === key 
                      ? `${getColorClasses(model.color, 'bg')}/10 ${getColorClasses(model.color, 'border')} border-2` 
                      : 'hover:bg-gray-50 border-2 border-transparent'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-10 h-10 ${getColorClasses(model.color, 'bg')} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <i className={`${model.icon} text-white text-lg`}></i>
                    </div>
                    <div className="flex-1 text-left">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-bold text-gray-900">{model.name}</h4>
                        {selectedModel === key && (
                          <div className={`w-5 h-5 ${getColorClasses(model.color, 'bg')} rounded-full flex items-center justify-center`}>
                            <i className="ri-check-line text-white text-xs"></i>
                          </div>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{model.description}</p>
                      <div className="flex flex-wrap gap-1">
                        {model.features.map((feature, index) => (
                          <span
                            key={index}
                            className={`px-2 py-1 ${getColorClasses(model.color, 'bg')}/10 ${getColorClasses(model.color, 'text')} text-xs rounded-full`}
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-100">
              <div className="flex items-center text-xs text-gray-500">
                <i className="ri-information-line mr-2"></i>
                Your preference will be saved for future sessions
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}