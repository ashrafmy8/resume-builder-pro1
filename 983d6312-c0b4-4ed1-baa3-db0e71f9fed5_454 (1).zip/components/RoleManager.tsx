'use client';

import { useState, useEffect } from 'react';
import { userService, UserProfile, UserPermission } from '@/lib/supabase';

interface RoleManagerProps {
  currentUserId: string;
  currentUserRole: string;
}

const AVAILABLE_PERMISSIONS = [
  { key: 'resume.create', label: 'Create Resumes', description: 'Can create new resumes' },
  { key: 'resume.edit', label: 'Edit Resumes', description: 'Can edit existing resumes' },
  { key: 'resume.delete', label: 'Delete Resumes', description: 'Can delete resumes' },
  { key: 'resume.export', label: 'Export Resumes', description: 'Can export resumes in PDF/Word' },
  { key: 'resume.share', label: 'Share Resumes', description: 'Can share resumes via email' },
  { key: 'templates.premium', label: 'Premium Templates', description: 'Access to premium templates' },
  { key: 'ai.assistant', label: 'AI Assistant', description: 'Use AI writing assistance' },
  { key: 'cover-letter.create', label: 'Create Cover Letters', description: 'Can create cover letters' },
  { key: 'profile.manage', label: 'Manage Profile', description: 'Update profile information' },
  { key: 'billing.view', label: 'View Billing', description: 'Access billing information' },
  { key: 'support.priority', label: 'Priority Support', description: 'Get priority customer support' }
];

const ROLE_PERMISSIONS = {
  user: ['resume.create', 'resume.edit', 'resume.export', 'profile.manage'],
  premium: [
    'resume.create', 'resume.edit', 'resume.delete', 'resume.export', 'resume.share',
    'templates.premium', 'ai.assistant', 'cover-letter.create', 'profile.manage',
    'billing.view', 'support.priority'
  ],
  admin: [...AVAILABLE_PERMISSIONS.map(p => p.key)]
};

export default function RoleManager({ currentUserId, currentUserRole }: RoleManagerProps) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [userPermissions, setUserPermissions] = useState<UserPermission[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    if (currentUserRole === 'admin') {
      loadUsers();
    }
  }, [currentUserRole]);

  const loadUsers = async () => {
    try {
      // In a real implementation, you'd fetch users from Supabase
      // For now, we'll simulate with current user data
      const currentUser = await userService.getProfile(currentUserId);
      if (currentUser) {
        setUsers([currentUser]);
      }
    } catch (error) {
      console.error('Error loading users:', error);
      setMessage({ type: 'error', text: 'Failed to load users' });
    } finally {
      setLoading(false);
    }
  };

  const loadUserPermissions = async (userId: string) => {
    try {
      const permissions = await userService.getUserPermissions(userId);
      setUserPermissions(permissions);
    } catch (error) {
      console.error('Error loading permissions:', error);
      setMessage({ type: 'error', text: 'Failed to load user permissions' });
    }
  };

  const handleUserSelect = async (user: UserProfile) => {
    setSelectedUser(user);
    await loadUserPermissions(user.id);
  };

  const handleRoleChange = async (userId: string, newRole: 'user' | 'premium' | 'admin') => {
    if (currentUserRole !== 'admin') return;

    setUpdating(true);
    try {
      await userService.updateProfile(userId, { role: newRole });
      
      // Update role-based permissions
      const currentPermissions = await userService.getUserPermissions(userId);
      const newPermissions = ROLE_PERMISSIONS[newRole];
      
      // Remove permissions not in new role
      for (const perm of currentPermissions) {
        if (!newPermissions.includes(perm.permission)) {
          await userService.revokePermission(userId, perm.permission);
        }
      }
      
      // Add new permissions
      for (const permission of newPermissions) {
        const hasPermission = currentPermissions.some(p => p.permission === permission);
        if (!hasPermission) {
          await userService.grantPermission(userId, permission, currentUserId);
        }
      }

      await loadUsers();
      if (selectedUser?.id === userId) {
        await loadUserPermissions(userId);
        setSelectedUser({ ...selectedUser, role: newRole });
      }
      
      setMessage({ type: 'success', text: `Role updated to ${newRole}` });
    } catch (error) {
      console.error('Error updating role:', error);
      setMessage({ type: 'error', text: 'Failed to update role' });
    } finally {
      setUpdating(false);
    }
  };

  const handlePermissionToggle = async (userId: string, permission: string, granted: boolean) => {
    if (currentUserRole !== 'admin') return;

    setUpdating(true);
    try {
      if (granted) {
        await userService.grantPermission(userId, permission, currentUserId);
      } else {
        await userService.revokePermission(userId, permission);
      }
      
      await loadUserPermissions(userId);
      setMessage({ 
        type: 'success', 
        text: `Permission ${granted ? 'granted' : 'revoked'} successfully` 
      });
    } catch (error) {
      console.error('Error updating permission:', error);
      setMessage({ type: 'error', text: 'Failed to update permission' });
    } finally {
      setUpdating(false);
    }
  };

  if (currentUserRole !== 'admin') {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center py-8">
          <i className="ri-shield-line text-6xl text-gray-300 mb-4"></i>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Access Restricted</h3>
          <p className="text-gray-600">You need admin privileges to manage user roles and permissions.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-center py-8">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Role & Permission Management</h3>
        <p className="text-gray-600">Manage user roles and permissions across the platform</p>
      </div>

      {/* Message */}
      {message && (
        <div className={`mb-6 p-4 rounded-lg ${
          message.type === 'success' 
            ? 'bg-green-50 border border-green-200 text-green-700' 
            : 'bg-red-50 border border-red-200 text-red-700'
        }`}>
          <div className="flex items-center">
            <i className={`mr-2 ${
              message.type === 'success' ? 'ri-check-circle-line' : 'ri-error-warning-line'
            }`}></i>
            {message.text}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Users List */}
        <div>
          <h4 className="font-semibold text-gray-900 mb-4">Users</h4>
          <div className="space-y-3">
            {users.map((user) => (
              <div
                key={user.id}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  selectedUser?.id === user.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => handleUserSelect(user)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {user.avatar_url ? (
                      <img 
                        src={user.avatar_url} 
                        alt={`${user.first_name} ${user.last_name}`}
                        className="w-10 h-10 rounded-full"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">
                          {(user.first_name || user.email[0]).toUpperCase()}
                        </span>
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-gray-900">
                        {user.first_name || user.last_name 
                          ? `${user.first_name} ${user.last_name}`.trim()
                          : user.email
                        }
                      </p>
                      <p className="text-sm text-gray-600">{user.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      user.role === 'admin'
                        ? 'bg-red-100 text-red-800'
                        : user.role === 'premium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.role}
                    </span>
                    
                    {updating ? (
                      <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <select
                        value={user.role}
                        onChange={(e) => handleRoleChange(user.id, e.target.value as any)}
                        onClick={(e) => e.stopPropagation()}
                        className="text-sm border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="user">User</option>
                        <option value="premium">Premium</option>
                        <option value="admin">Admin</option>
                      </select>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Permissions Panel */}
        <div>
          {selectedUser ? (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-gray-900">
                  Permissions for {selectedUser.first_name || selectedUser.email}
                </h4>
                <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                  selectedUser.role === 'admin'
                    ? 'bg-red-100 text-red-800'
                    : selectedUser.role === 'premium'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {selectedUser.role}
                </span>
              </div>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {AVAILABLE_PERMISSIONS.map((permission) => {
                  const hasPermission = userPermissions.some(p => p.permission === permission.key);
                  const isRoleDefault = ROLE_PERMISSIONS[selectedUser.role].includes(permission.key);
                  
                  return (
                    <div
                      key={permission.key}
                      className={`p-3 border rounded-lg ${
                        isRoleDefault ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h5 className="font-medium text-gray-900">{permission.label}</h5>
                            {isRoleDefault && (
                              <span className="px-2 py-0.5 text-xs bg-blue-100 text-blue-800 rounded">
                                Role Default
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mt-1">{permission.description}</p>
                        </div>
                        
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={hasPermission}
                            onChange={(e) => handlePermissionToggle(
                              selectedUser.id, 
                              permission.key, 
                              e.target.checked
                            )}
                            disabled={updating}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <i className="ri-user-settings-line text-6xl text-gray-300 mb-4"></i>
              <h4 className="font-semibold text-gray-900 mb-2">Select a User</h4>
              <p className="text-gray-600">Choose a user from the list to manage their permissions</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}