'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface UserProfile {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  phone?: string;
  company?: string;
  job_title?: string;
  bio?: string;
  location?: string;
  website?: string;
  linkedin?: string;
  twitter?: string;
  avatar_url?: string;
  email_notifications?: boolean;
  marketing_emails?: boolean;
  resume_tips?: boolean;
  job_alerts?: boolean;
}

interface ProfileManagerProps {
  user: UserProfile;
  onClose: () => void;
  onUpdate?: (profile: UserProfile) => void;
}

export default function ProfileManager({ user, onClose, onUpdate }: ProfileManagerProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [profile, setProfile] = useState<UserProfile>({
    id: user.id,
    email: user.email,
    first_name: user.first_name || '',
    last_name: user.last_name || '',
    phone: user.phone || '',
    company: user.company || '',
    job_title: user.job_title || '',
    bio: user.bio || '',
    location: user.location || '',
    website: user.website || '',
    linkedin: user.linkedin || '',
    twitter: user.twitter || '',
    avatar_url: user.avatar_url || '',
    email_notifications: user.email_notifications ?? true,
    marketing_emails: user.marketing_emails ?? false,
    resume_tips: user.resume_tips ?? true,
    job_alerts: user.job_alerts ?? false
  });
  const [passwords, setPasswords] = useState({
    current: '',
    new: '',
    confirm: ''
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState(user.avatar_url || '');

  const showMessage = (type: string, text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 5000);
  };

  const handleInputChange = (field: keyof UserProfile, value: string | boolean) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateProfile = () => {
    const errors = [];
    
    if (!profile.first_name?.trim()) {
      errors.push('First name is required');
    }
    
    if (!profile.last_name?.trim()) {
      errors.push('Last name is required');
    }
    
    if (profile.website && !profile.website.match(/^https?:\/\/.+/)) {
      errors.push('Website must start with http:// or https://');
    }
    
    if (profile.linkedin && !profile.linkedin.includes('linkedin.com')) {
      errors.push('LinkedIn must be a valid LinkedIn URL');
    }
    
    if (profile.twitter && !profile.twitter.includes('twitter.com') && !profile.twitter.includes('x.com')) {
      errors.push('Twitter must be a valid Twitter/X URL');
    }
    
    return errors;
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showMessage('error', 'Image must be smaller than 5MB');
      return;
    }

    if (!file.type.startsWith('image/')) {
      showMessage('error', 'Please select an image file');
      return;
    }

    setUploadingAvatar(true);

    try {
      const { data: { user: currentUser }, error: authError } = await supabase.auth.getUser();
      
      if (authError || !currentUser) {
        throw new Error('User not authenticated');
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${currentUser.id}-${Date.now()}.${fileExt}`;

      if (profile.avatar_url && profile.avatar_url.includes('/avatars/')) {
        try {
          const oldPath = profile.avatar_url.split('/avatars/')[1];
          if (oldPath) {
            await supabase.storage.from('avatars').remove([oldPath]);
          }
        } catch (error) {
          console.log('Old avatar cleanup failed (not critical):', error);
        }
      }

      const { data, error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: true
        });

      if (uploadError) {
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      setProfile(prev => ({ ...prev, avatar_url: publicUrl }));
      setAvatarPreview(publicUrl);
      
      showMessage('success', 'Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('Avatar upload error:', error);
      showMessage('error', error.message || 'Failed to upload image. Please try again.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleRemoveAvatar = async () => {
    if (!profile.avatar_url) return;

    try {
      if (profile.avatar_url.includes('/avatars/')) {
        const avatarPath = profile.avatar_url.split('/avatars/')[1];
        if (avatarPath) {
          await supabase.storage.from('avatars').remove([avatarPath]);
        }
      }

      setProfile(prev => ({ ...prev, avatar_url: '' }));
      setAvatarPreview('');
      showMessage('success', 'Profile picture removed successfully!');
    } catch (error) {
      console.error('Remove avatar error:', error);
      showMessage('error', 'Failed to remove image. Please try again.');
    }
  };

  const updateProfile = async () => {
    if (saving) return; // Prevent multiple simultaneous calls
    
    const errors = validateProfile();
    if (errors.length > 0) {
      showMessage('error', errors[0]);
      return;
    }

    setSaving(true);

    try {
      const { data: { user: currentUser }, error: authError } = await supabase.auth.getUser();
      
      if (authError || !currentUser) {
        throw new Error('Authentication required. Please sign in again.');
      }

      if (currentUser.id !== profile.id) {
        throw new Error('Permission denied: Cannot update another user\'s profile.');
      }

      // Check if profile exists in profiles table
      const { data: existingProfile, error: checkError } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', profile.id)
        .maybeSingle();

      if (checkError && checkError.code !== 'PGRST116') {
        throw new Error(`Database error: ${checkError.message}`);
      }

      const profileData = {
        first_name: profile.first_name?.trim() || null,
        last_name: profile.last_name?.trim() || null,
        phone: profile.phone?.trim() || null,
        company: profile.company?.trim() || null,
        job_title: profile.job_title?.trim() || null,
        bio: profile.bio?.trim() || null,
        location: profile.location?.trim() || null,
        website: profile.website?.trim() || null,
        linkedin: profile.linkedin?.trim() || null,
        twitter: profile.twitter?.trim() || null,
        avatar_url: profile.avatar_url || null,
        email_notifications: profile.email_notifications,
        marketing_emails: profile.marketing_emails,
        resume_tips: profile.resume_tips,
        job_alerts: profile.job_alerts,
        updated_at: new Date().toISOString()
      };

      let result;
      
      if (existingProfile) {
        result = await supabase
          .from('profiles')
          .update(profileData)
          .eq('id', profile.id)
          .select()
          .single();
      } else {
        result = await supabase
          .from('profiles')
          .insert({
            id: profile.id,
            email: profile.email,
            ...profileData,
            created_at: new Date().toISOString()
          })
          .select()
          .single();
      }

      if (result.error) {
        console.error('Profile save error:', result.error);
        
        if (result.error.code === 'PGRST116') {
          throw new Error('Profile not found or access denied.');
        } else if (result.error.message?.includes('row-level security')) {
          throw new Error('Permission denied. Please sign out and sign in again.');
        } else if (result.error.message?.includes('duplicate key')) {
          throw new Error('Profile already exists with this information.');
        } else {
          throw new Error(`Save failed: ${result.error.message}`);
        }
      }

      if (!result.data) {
        throw new Error('Profile update failed - no data returned.');
      }

      const updatedProfile = {
        ...profile,
        ...result.data
      };
      setProfile(updatedProfile);
      
      onUpdate?.(updatedProfile);
      
      showMessage('success', 'Profile updated successfully!');
      
    } catch (error: any) {
      console.error('Profile update error:', error);
      
      const errorMessage = error?.message || 'An unexpected error occurred. Please try again.';
      
      if (errorMessage.includes('not authenticated') || errorMessage.includes('Authentication required')) {
        showMessage('error', 'Session expired. Please sign in again.');
      } else if (errorMessage.includes('Permission denied')) {
        showMessage('error', 'Access denied. Please check your permissions.');
      } else if (errorMessage.includes('Network')) {
        showMessage('error', 'Network error. Please check your connection and try again.');
      } else {
        showMessage('error', errorMessage);
      }
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwords.new !== passwords.confirm) {
      showMessage('error', 'New passwords do not match');
      return;
    }

    if (passwords.new.length < 8) {
      showMessage('error', 'Password must be at least 8 characters');
      return;
    }

    setSaving(true);

    try {
      const { error } = await supabase.auth.updateUser({
        password: passwords.new
      });

      if (error) throw error;

      setPasswords({ current: '', new: '', confirm: '' });
      showMessage('success', 'Password updated successfully!');
    } catch (error: any) {
      console.error('Password change error:', error);
      showMessage('error', error.message || 'Failed to change password');
    } finally {
      setSaving(false);
    }
  };

  const getInitials = () => {
    if (profile.first_name && profile.last_name) {
      return `${profile.first_name.charAt(0)}${profile.last_name.charAt(0)}`.toUpperCase();
    }
    return profile.first_name?.charAt(0)?.toUpperCase() || 'U';
  };

  const tabs = [
    { id: 'profile', label: 'Personal Info', icon: 'user-line' },
    { id: 'professional', label: 'Professional', icon: 'briefcase-line' },
    { id: 'social', label: 'Social Links', icon: 'links-line' },
    { id: 'security', label: 'Security', icon: 'shield-line' },
    { id: 'preferences', label: 'Email Settings', icon: 'mail-line' }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Profile Settings</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="ri-close-line text-gray-600 text-xl"></i>
          </button>
        </div>

        {/* Message Display */}
        {message.text && (
          <div className={`mx-6 mt-4 p-4 rounded-lg ${
            message.type === 'success' 
              ? 'bg-green-100 text-green-800 border border-green-200' 
              : 'bg-red-100 text-red-800 border border-red-200'
          } animate-in slide-in-from-top-2 duration-300`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <i className={`ri-${message.type === 'success' ? 'check-circle' : 'error-warning'}-line text-lg mr-2`}></i>
                {message.text}
              </div>
              <button
                onClick={() => setMessage({ type: '', text: '' })}
                className="text-current hover:opacity-70 transition-opacity"
              >
                <i className="ri-close-line"></i>
              </button>
            </div>
          </div>
        )}

        <div className="flex">
          {/* Sidebar Navigation */}
          <div className="w-64 bg-gray-50 p-6">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <i className={`ri-${tab.icon} text-lg w-5 h-5 flex items-center justify-center`}></i>
                  <span className="font-medium">{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Content Area */}
          <div className="flex-1 p-6 overflow-y-auto max-h-[calc(90vh-88px)]">
            {/* Personal Info Tab */}
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Personal Information</h3>
                  
                  {/* Avatar Section */}
                  <div className="flex items-center space-x-6 mb-8">
                    <div className="relative">
                      {avatarPreview ? (
                        <img 
                          src={avatarPreview} 
                          alt="Profile" 
                          className="w-24 h-24 rounded-full object-cover border-4 border-blue-200"
                        />
                      ) : (
                        <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-2xl font-bold">
                            {getInitials()}
                          </span>
                        </div>
                      )}
                      {uploadingAvatar && (
                        <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center">
                          <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 mb-2">Profile Picture</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Upload a professional photo. JPG, PNG or GIF. Max 5MB.
                      </p>
                      <div className="flex space-x-3">
                        <label className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer transition-colors whitespace-nowrap">
                          <i className="ri-upload-line mr-2"></i>
                          Upload Photo
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleAvatarUpload}
                            disabled={uploadingAvatar}
                            className="hidden"
                          />
                        </label>
                        {avatarPreview && (
                          <button
                            onClick={handleRemoveAvatar}
                            className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap"
                          >
                            <i className="ri-delete-bin-line mr-2"></i>
                            Remove
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          First Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={profile.first_name}
                          onChange={(e) => handleInputChange('first_name', e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                          placeholder="Enter your first name"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Last Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={profile.last_name}
                          onChange={(e) => handleInputChange('last_name', e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                          placeholder="Enter your last name"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email Address
                        </label>
                        <input
                          type="email"
                          value={profile.email}
                          disabled
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 text-sm"
                        />
                        <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          value={profile.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                          placeholder="+1 (555) 123-4567"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location
                      </label>
                      <input
                        type="text"
                        value={profile.location}
                        onChange={(e) => handleInputChange('location', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="City, State, Country"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Professional Bio
                      </label>
                      <textarea
                        value={profile.bio}
                        onChange={(e) => handleInputChange('bio', e.target.value)}
                        rows={4}
                        maxLength={500}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none"
                        placeholder="Tell us about yourself, your experience, and career goals..."
                      />
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-xs text-gray-500">Brief professional summary</p>
                        <span className="text-xs text-gray-400">{profile.bio?.length || 0}/500</span>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={updateProfile}
                        disabled={saving}
                        className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white px-8 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
                      >
                        {saving ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2 inline-block"></div>
                            Saving...
                          </>
                        ) : (
                          <>
                            <i className="ri-save-line mr-2"></i>
                            Save Changes
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Professional Tab */}
            {activeTab === 'professional' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Professional Information</h3>
                  
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Current Company
                        </label>
                        <input
                          type="text"
                          value={profile.company}
                          onChange={(e) => handleInputChange('company', e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                          placeholder="Your current company"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Job Title
                        </label>
                        <input
                          type="text"
                          value={profile.job_title}
                          onChange={(e) => handleInputChange('job_title', e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                          placeholder="Your current position"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Professional Website
                      </label>
                      <input
                        type="url"
                        value={profile.website}
                        onChange={(e) => handleInputChange('website', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="https://yourwebsite.com"
                      />
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={updateProfile}
                        disabled={saving}
                        className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white px-8 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
                      >
                        {saving ? 'Saving...' : 'Save Changes'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Social Links Tab */}
            {activeTab === 'social' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Social Media Links</h3>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <i className="ri-linkedin-fill text-blue-600 mr-2"></i>
                        LinkedIn Profile
                      </label>
                      <input
                        type="url"
                        value={profile.linkedin}
                        onChange={(e) => handleInputChange('linkedin', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="https://linkedin.com/in/yourprofile"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <i className="ri-twitter-fill text-blue-400 mr-2"></i>
                        Twitter Profile
                      </label>
                      <input
                        type="url"
                        value={profile.twitter}
                        onChange={(e) => handleInputChange('twitter', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="https://twitter.com/yourusername"
                      />
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={updateProfile}
                        disabled={saving}
                        className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white px-8 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
                      >
                        {saving ? 'Saving...' : 'Save Changes'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Security Settings</h3>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                    <div className="flex items-center">
                      <i className="ri-shield-check-line text-yellow-600 text-lg mr-2 w-5 h-5 flex items-center justify-center"></i>
                      <p className="text-yellow-800 text-sm">
                        Keep your account secure by using a strong password and updating it regularly.
                      </p>
                    </div>
                  </div>

                  <form onSubmit={changePassword} className="space-y-6 max-w-md">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Current Password *
                      </label>
                      <input
                        type="password"
                        required
                        value={passwords.current}
                        onChange={(e) => setPasswords(prev => ({ ...prev, current: e.target.value }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="Enter current password"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        New Password *
                      </label>
                      <input
                        type="password"
                        required
                        value={passwords.new}
                        onChange={(e) => setPasswords(prev => ({ ...prev, new: e.target.value }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="Enter new password"
                      />
                      <p className="text-xs text-gray-500 mt-1">Password must be at least 8 characters</p>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Confirm New Password *
                      </label>
                      <input
                        type="password"
                        required
                        value={passwords.confirm}
                        onChange={(e) => setPasswords(prev => ({ ...prev, confirm: e.target.value }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="Confirm new password"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={saving}
                      className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white px-8 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {saving ? 'Updating...' : 'Update Password'}
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* Email Preferences Tab */}
            {activeTab === 'preferences' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Email Preferences</h3>
                  
                  <p className="text-gray-600 mb-6">
                    Choose which emails you'd like to receive from Resume Teacher.
                  </p>

                  <div className="space-y-4">
                    {[
                      {
                        id: 'email_notifications',
                        title: 'Account Notifications',
                        description: 'Receive emails about account activity and security',
                        checked: profile.email_notifications
                      },
                      {
                        id: 'resume_tips',
                        title: 'Resume Tips & Advice',
                        description: 'Weekly tips to improve your resume and career prospects',
                        checked: profile.resume_tips
                      },
                      {
                        id: 'job_alerts',
                        title: 'Job Alerts',
                        description: 'Notifications about relevant job opportunities',
                        checked: profile.job_alerts
                      },
                      {
                        id: 'marketing_emails',
                        title: 'Product Updates',
                        description: 'Announcements about new features and improvements',
                        checked: profile.marketing_emails
                      }
                    ].map((pref) => (
                      <div key={pref.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{pref.title}</h4>
                          <p className="text-sm text-gray-600">{pref.description}</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={pref.checked}
                            onChange={(e) => handleInputChange(pref.id as keyof UserProfile, e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-end mt-6">
                    <button
                      type="button"
                      onClick={updateProfile}
                      disabled={saving}
                      className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white px-8 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {saving ? 'Saving...' : 'Save Preferences'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}