
'use client';

import { useState } from 'react';
import AIModelSelector from './AIModelSelector';

interface AIAssistantProps {
  section: string;
  context?: any;
  onSuggestion: (suggestion: string) => void;
}

export default function AIAssistant({ section, context, onSuggestion }: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [selectedModel, setSelectedModel] = useState<'standard' | 'deepseek'>('standard');
  const [inputText, setInputText] = useState('');
  const [error, setError] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const sectionTips = {
    personalinfo: [
      "Use a professional email address with your name",
      "Include your city and state, but full address isn't necessary",
      "Add LinkedIn profile URL if it's professional and updated",
      "Consider adding a professional portfolio website",
      "Phone number should include area code"
    ],
    workexperience: [
      "Start each bullet point with an action verb",
      "Quantify achievements with numbers and percentages", 
      "Focus on accomplishments, not just responsibilities",
      "Use the STAR method (Situation, Task, Action, Result)",
      "Tailor experience to match job requirements"
    ],
    education: [
      "List education in reverse chronological order",
      "Include GPA if it's 3.5 or higher",
      "Add relevant coursework for entry-level positions",
      "Include academic honors and achievements",
      "Mention thesis or capstone projects if relevant"
    ],
    skills: [
      "Separate technical and soft skills into categories",
      "Only include skills you can confidently discuss",
      "Prioritize skills mentioned in job descriptions",
      "Use industry-standard terminology",
      "Consider adding skill proficiency levels"
    ],
    summary: [
      "Keep it concise - 3-4 sentences maximum",
      "Start with years of experience and key expertise",
      "Include 2-3 major achievements with numbers",
      "Mention skills that match the job requirements",
      "End with your career goals or value proposition"
    ]
  };

  const generateBulletPoints = async (jobTitle: string, company: string) => {
    setIsGenerating(true);
    setError('');
    
    try {
      setTimeout(() => {
        const modelData = {
          standard: {
            'Software Engineer': [
              "Developed and maintained full-stack web applications using React, Node.js, and PostgreSQL, serving 10,000+ daily active users",
              "Implemented automated testing procedures that reduced bug reports by 40% and improved code quality",
              "Collaborated with cross-functional teams to deliver 15+ features on schedule, improving user engagement by 25%",
              "Optimized database queries and API performance, reducing page load times by 60%"
            ],
            'Marketing Manager': [
              "Led digital marketing campaigns that increased brand awareness by 150% and generated $2M+ in revenue",
              "Managed social media strategy across 5 platforms, growing follower base by 300% in 12 months",
              "Developed and executed content marketing strategy that improved organic traffic by 200%",
              "Coordinated with design and development teams to launch 10+ successful product campaigns"
            ],
            'Sales Representative': [
              "Exceeded quarterly sales targets by 25% through strategic client relationship management",
              "Generated $500K+ in new business revenue by identifying and pursuing qualified leads",
              "Maintained 95% client retention rate through exceptional customer service and follow-up",
              "Collaborated with marketing team to develop targeted sales materials and presentations"
            ]
          },
          deepseek: {
            'Software Engineer': [
              "Architected and deployed scalable microservices infrastructure using Docker and Kubernetes, supporting 50,000+ concurrent users with 99.9% uptime",
              "Pioneered implementation of machine learning algorithms that enhanced user experience personalization, resulting in 45% increase in user retention",
              "Established comprehensive CI/CD pipelines with automated testing and security scanning, reducing deployment time by 80% while maintaining zero-defect releases",
              "Led cross-functional technical innovation initiatives, mentoring 8 junior developers and driving adoption of modern development practices across 3 teams"
            ],
            'Marketing Manager': [
              "Orchestrated data-driven marketing ecosystem leveraging advanced analytics and customer segmentation, driving 280% ROI improvement across multi-channel campaigns",
              "Spearheaded innovative brand positioning strategy incorporating emerging market trends and competitive intelligence, capturing 15% additional market share",
              "Engineered comprehensive customer journey optimization through behavioral analysis and personalization, increasing conversion rates by 65% and customer lifetime value by 40%",
              "Established strategic partnerships and influencer networks that expanded brand reach to 2M+ new prospects while reducing customer acquisition costs by 35%"
            ],
            'Sales Representative': [
              "Orchestrated sophisticated sales methodology incorporating advanced CRM analytics and predictive modeling, consistently exceeding quotas by 45% while maintaining 98% client satisfaction",
              "Cultivated high-value strategic partnerships through consultative selling approach, generating $2.5M+ in enterprise-level contracts and establishing recurring revenue streams",
              "Pioneered innovative prospecting techniques utilizing social selling and data-driven insights, expanding territory by 60% and reducing sales cycle duration by 30%",
              "Demonstrated exceptional relationship management skills by transforming challenging accounts into brand advocates, resulting in 85% upsell success rate and $1.8M additional revenue"
            ]
          }
        };

        const role = jobTitle || 'Software Engineer';
        const suggestions = modelData[selectedModel][role as keyof typeof modelData[typeof selectedModel]] || [
          selectedModel === 'deepseek' 
            ? "Orchestrated transformative initiatives that revolutionized operational efficiency by 45% through strategic implementation of cutting-edge methodologies and cross-functional collaboration excellence"
            : "Led key initiatives that improved operational efficiency by 30% through process optimization and team collaboration",
          selectedModel === 'deepseek'
            ? "Cultivated high-performance cross-functional partnerships, leveraging synergistic collaboration to exceed ambitious business objectives while delivering measurable results ahead of critical deadlines"
            : "Collaborated with cross-functional teams to achieve business objectives and deliver projects on time",
          selectedModel === 'deepseek'
            ? "Pioneered innovative best practices and quality optimization frameworks, resulting in measurable cost reduction of 25% and enhanced operational excellence across multiple departments"
            : "Implemented best practices that enhanced quality and reduced costs by 15%",
          selectedModel === 'deepseek'
            ? "Demonstrated exceptional leadership managing complex, multi-stakeholder initiatives while consistently delivering transformational results that exceeded performance benchmarks by 35%"
            : "Managed multiple projects simultaneously while meeting tight deadlines and quality standards"
        ];
        
        setSuggestions(suggestions);
        setIsGenerating(false);
      }, selectedModel === 'deepseek' ? 3000 : 2000);
    } catch (error) {
      console.error('AI Generation Error:', error);
      setError('Failed to generate content. Please try again.');
      setIsGenerating(false);
    }
  };

  const handleGenerate = async () => {
    if (!inputText || typeof inputText !== 'string' || inputText.trim().length === 0) {
      setError('Please provide some input to generate content');
      return;
    }

    setIsGenerating(true);
    setError('');
    
    try {
      const safeContext = {
        jobTitle: context?.jobTitle || '',
        company: context?.company || '',
        currentText: context?.currentText || '',
        ...context
      };

      const role = safeContext.jobTitle || inputText || 'Software Engineer';
      await generateBulletPoints(role, safeContext.company || '');
    } catch (error) {
      console.error('AI Generation Error:', error);
      setError('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const enhanceText = async (text: string, type: 'summary' | 'skill' | 'experience') => {
    if (!text.trim()) return;
    
    setIsGenerating(true);
    
    setTimeout(() => {
      let enhanced = text;
      
      if (selectedModel === 'deepseek') {
        if (type === 'summary') {
          enhanced = `Visionary ${text.toLowerCase()} professional with distinguished track record of driving transformational business outcomes through strategic expertise, innovative leadership, and data-driven decision making. Consistently delivers exceptional results while fostering collaborative excellence and sustainable competitive advantages across diverse organizational environments.`;
        } else if (type === 'experience') {
          enhanced = `Strategically orchestrated ${text.toLowerCase()}, delivering exceptional results through innovative problem-solving, cross-functional collaboration, and implementation of cutting-edge methodologies that consistently exceeded performance benchmarks and organizational objectives while maintaining operational excellence.`;
        }
      } else {
        if (type === 'summary') {
          enhanced = `Experienced ${text.toLowerCase()} professional with proven track record of delivering results and leading successful initiatives. Demonstrated expertise in driving business impact through strategic thinking and collaborative leadership across various projects and teams.`;
        } else if (type === 'experience') {
          enhanced = `Successfully ${text.toLowerCase()}, resulting in improved efficiency and positive business outcomes through strategic implementation, collaborative leadership, and focus on measurable results and continuous improvement.`;
        }
      }
      
      onSuggestion(enhanced);
      setIsGenerating(false);
      setIsOpen(false);
      setInputText('');
    }, selectedModel === 'deepseek' ? 2500 : 1500);
  };

  return (
    <div className="relative">
      <div className="flex items-center justify-center space-x-4 mb-6">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center space-x-3 px-6 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 ${
            isOpen 
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-500/25' 
              : 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:from-purple-600 hover:to-indigo-600 shadow-lg hover:shadow-xl'
          }`}
        >
          <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
            <i className="ri-magic-line text-xl"></i>
          </div>
          <span className="text-lg">AI Writing Assistant</span>
          {isGenerating && (
            <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
          )}
          <i className={`ri-arrow-${isOpen ? 'up' : 'down'}-s-line text-xl transition-transform`}></i>
        </button>
        
        <AIModelSelector 
          onModelChange={setSelectedModel}
          currentModel={selectedModel}
        />
      </div>

      {isOpen && (
        <>
          <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40" onClick={() => setIsOpen(false)}></div>
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-4 w-[500px] bg-white rounded-3xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
            <div className="bg-gradient-to-r from-purple-500 to-indigo-500 p-6 text-white">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold flex items-center">
                  <i className="ri-robot-line mr-3"></i>
                  AI Writing Assistant
                </h3>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 text-sm rounded-full font-medium ${
                    selectedModel === 'deepseek' 
                      ? 'bg-purple-400/30 text-purple-100' 
                      : 'bg-blue-400/30 text-blue-100'
                  }`}>
                    {selectedModel === 'deepseek' ? 'DeepSeek AI' : 'Standard AI'}
                  </span>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="w-8 h-8 bg-white/20 text-white rounded-lg hover:bg-white/30 transition-colors flex items-center justify-center"
                  >
                    <i className="ri-close-line"></i>
                  </button>
                </div>
              </div>
              <p className="text-purple-100 mt-2">
                {selectedModel === 'deepseek' 
                  ? 'Advanced AI for sophisticated, professional content'
                  : 'Smart AI assistance for clear, effective writing'
                }
              </p>
            </div>

            <div className="p-6 space-y-6">
              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-4">
                {section === 'workexperience' && (
                  <button
                    onClick={() => generateBulletPoints('Software Engineer', 'Tech Company')}
                    disabled={isGenerating}
                    className={`p-4 rounded-2xl border-2 border-dashed transition-all disabled:opacity-50 ${
                      selectedModel === 'deepseek'
                        ? 'border-purple-300 bg-purple-50 hover:border-purple-400 hover:bg-purple-100'
                        : 'border-blue-300 bg-blue-50 hover:border-blue-400 hover:bg-blue-100'
                    }`}
                  >
                    <i className="ri-list-check text-2xl text-gray-600 mb-2"></i>
                    <div className="text-sm font-medium text-gray-800">Generate Bullet Points</div>
                    <div className="text-xs text-gray-500 mt-1">Professional achievements</div>
                  </button>
                )}

                {section === 'summary' && (
                  <div className="space-y-3">
                    <textarea
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder="Enter your basic summary or job title..."
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm resize-none focus:border-blue-400 focus:outline-none"
                      rows={3}
                    />
                    <button
                      onClick={() => enhanceText(inputText, 'summary')}
                      disabled={isGenerating || !inputText.trim()}
                      className={`w-full p-3 rounded-xl text-white font-medium transition-all disabled:opacity-50 ${
                        selectedModel === 'deepseek'
                          ? 'bg-purple-500 hover:bg-purple-600'
                          : 'bg-blue-500 hover:bg-blue-600'
                      }`}
                    >
                      {isGenerating ? 'Enhancing...' : `Enhance with ${selectedModel === 'deepseek' ? 'DeepSeek' : 'Standard'}`}
                    </button>
                  </div>
                )}
              </div>

              {/* AI Suggestions */}
              {suggestions.length > 0 && (
                <div className="space-y-4">
                  <h4 className="font-bold text-gray-900 flex items-center">
                    <i className="ri-lightbulb-line text-yellow-500 mr-2"></i>
                    AI Generated Content
                    <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                      selectedModel === 'deepseek' 
                        ? 'bg-purple-100 text-purple-600' 
                        : 'bg-blue-100 text-blue-600'
                    }`}>
                      {selectedModel === 'deepseek' ? 'Advanced' : 'Standard'}
                    </span>
                  </h4>
                  <div className="max-h-64 overflow-y-auto space-y-3">
                    {suggestions.map((suggestion, index) => (
                      <div
                        key={index}
                        className={`p-4 rounded-2xl border-2 cursor-pointer transition-all group ${
                          selectedModel === 'deepseek'
                            ? 'border-purple-200 bg-purple-50/50 hover:border-purple-300 hover:bg-purple-100/50'
                            : 'border-blue-200 bg-blue-50/50 hover:border-blue-300 hover:bg-blue-100/50'
                        }`}
                        onClick={() => {
                          onSuggestion(suggestion);
                          setIsOpen(false);
                        }}
                      >
                        <div className="flex items-start space-x-3">
                          <i className={`ri-arrow-right-circle-line text-xl mt-0.5 ${
                            selectedModel === 'deepseek' ? 'text-purple-500' : 'text-blue-500'
                          } group-hover:scale-110 transition-transform`}></i>
                          <p className="text-sm text-gray-700 leading-relaxed">{suggestion}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Tips */}
              <div className="border-t border-gray-200 pt-6">
                <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                  <i className="ri-lightbulb-flash-line text-yellow-500 mr-2"></i>
                  Smart Tips for {section.charAt(0).toUpperCase() + section.slice(1)}
                </h4>
                <div className="grid gap-3">
                  {(sectionTips[section as keyof typeof sectionTips] || []).slice(0, 3).map((tip, index) => (
                    <div key={index} className="flex items-start text-sm text-gray-600 p-3 bg-gray-50 rounded-xl">
                      <i className="ri-check-line text-green-500 mr-3 mt-0.5 flex-shrink-0"></i>
                      <span className="leading-relaxed">{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
