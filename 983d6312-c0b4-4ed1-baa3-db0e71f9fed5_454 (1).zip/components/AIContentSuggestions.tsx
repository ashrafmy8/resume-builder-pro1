
'use client';

import { useState } from 'react';

interface AIContentSuggestionsProps {
  jobPosition: string;
  company: string;
  currentContent: string;
  contentType: 'opening' | 'body' | 'closing';
  onApplySuggestion: (content: string) => void;
  onClose: () => void;
}

export default function AIContentSuggestions({ 
  jobPosition, 
  company, 
  currentContent,
  contentType,
  onApplySuggestion,
  onClose
}: AIContentSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasGenerated, setHasGenerated] = useState(false);

  const generateSuggestions = async () => {
    if (!jobPosition || !company) {
      return;
    }

    setIsGenerating(true);
    
    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    const suggestions = getSuggestionsBySection(contentType, jobPosition, company);
    setSuggestions(suggestions);
    setIsGenerating(false);
    setHasGenerated(true);
  };

  const getSuggestionsBySection = (section: string, job: string, comp: string): string[] => {
    const jobLower = job.toLowerCase();
    const isMarketing = jobLower.includes('marketing') || jobLower.includes('brand') || jobLower.includes('digital');
    const isTech = jobLower.includes('developer') || jobLower.includes('engineer') || jobLower.includes('software') || jobLower.includes('tech');
    const isSales = jobLower.includes('sales') || jobLower.includes('business development') || jobLower.includes('account');
    const isManagement = jobLower.includes('manager') || jobLower.includes('director') || jobLower.includes('lead') || jobLower.includes('supervisor');

    switch (section) {
      case 'opening':
        return [
          `Dear Hiring Manager,\n\nI am writing to express my strong interest in the ${job} position at ${comp}. With my proven track record in ${isMarketing ? 'driving brand awareness and customer engagement' : isTech ? 'developing scalable software solutions' : isSales ? 'exceeding sales targets and building client relationships' : isManagement ? 'leading high-performing teams and strategic initiatives' : 'delivering exceptional results'}, I am excited about the opportunity to contribute to your team's continued success.`,
          
          `Dear ${comp} Hiring Team,\n\nI was thrilled to discover the ${job} opening at ${comp}, as it perfectly aligns with my passion for ${isMarketing ? 'creative marketing strategies and data-driven campaigns' : isTech ? 'innovative technology solutions and clean code architecture' : isSales ? 'relationship building and revenue generation' : isManagement ? 'organizational leadership and process optimization' : 'professional excellence and continuous improvement'}. Your company's reputation for ${isMarketing ? 'brand innovation' : isTech ? 'cutting-edge technology' : isSales ? 'customer satisfaction' : isManagement ? 'industry leadership' : 'excellence'} makes this an ideal next step in my career.`,
          
          `Dear Hiring Manager,\n\nAs a dedicated professional with extensive experience in ${isMarketing ? 'multi-channel marketing and brand development' : isTech ? 'full-stack development and system architecture' : isSales ? 'consultative sales and account management' : isManagement ? 'team leadership and strategic planning' : 'my field'}, I am excited to apply for the ${job} position at ${comp}. I am particularly drawn to your company's commitment to ${isMarketing ? 'innovative marketing approaches' : isTech ? 'technological advancement' : isSales ? 'customer success' : isManagement ? 'operational excellence' : 'quality and innovation'}.`,

          `Dear Hiring Team,\n\nYour posting for the ${job} position at ${comp} immediately caught my attention, as it represents the perfect intersection of my ${isMarketing ? 'marketing expertise and creative vision' : isTech ? 'technical skills and problem-solving abilities' : isSales ? 'sales experience and relationship-building strengths' : isManagement ? 'leadership experience and strategic mindset' : 'professional background and career aspirations'}. I am excited to bring my ${isMarketing ? 'campaign development and analytics expertise' : isTech ? 'coding proficiency and system design experience' : isSales ? 'proven sales track record and client management skills' : isManagement ? 'team leadership and project management capabilities' : 'professional skills'} to your dynamic team.`
        ];

      case 'body':
        return [
          `In my previous role, I successfully ${isMarketing ? 'increased brand engagement by 40% through targeted digital campaigns and social media strategies' : isTech ? 'reduced system downtime by 60% while implementing scalable microservices architecture' : isSales ? 'exceeded quarterly sales targets by 25% and maintained a 95% client retention rate' : isManagement ? 'led a team of 15+ professionals and improved operational efficiency by 30%' : 'delivered outstanding results that exceeded expectations'}. This experience has equipped me with the skills necessary to excel in the ${job} role at ${comp}.\n\nI am particularly excited about ${comp}'s ${isMarketing ? 'innovative approach to customer engagement and brand storytelling' : isTech ? 'commitment to using cutting-edge technologies and agile methodologies' : isSales ? 'customer-centric approach and focus on long-term relationships' : isManagement ? 'emphasis on leadership development and strategic growth' : 'vision and company culture'}. My expertise in ${isMarketing ? 'content creation, campaign optimization, and analytics' : isTech ? 'programming languages, database management, and cloud platforms' : isSales ? 'CRM systems, pipeline management, and negotiation' : isManagement ? 'project management, team building, and strategic planning' : 'relevant skills'} would enable me to make an immediate impact on your team.`,
          
          `Throughout my career, I have demonstrated a consistent ability to ${isMarketing ? 'develop compelling marketing campaigns that drive customer acquisition and brand loyalty' : isTech ? 'architect robust solutions that scale efficiently and maintain high performance standards' : isSales ? 'build strong client relationships and consistently deliver revenue growth' : isManagement ? 'inspire teams to achieve ambitious goals while maintaining high morale and productivity' : 'achieve exceptional results'}. For example, ${isMarketing ? 'I launched a multi-platform campaign that generated 200% ROI and increased market share by 15%' : isTech ? 'I developed a system that processed 1M+ transactions daily with 99.9% uptime' : isSales ? 'I closed deals worth $2M+ annually and expanded territory coverage by 40%' : isManagement ? 'I restructured operations that saved $500K annually while improving team satisfaction by 35%' : 'I delivered a project that significantly impacted business outcomes'}.\n\nWhat particularly attracts me to ${comp} is your ${isMarketing ? 'data-driven approach to marketing and commitment to creative excellence' : isTech ? 'focus on innovation and investment in emerging technologies' : isSales ? 'reputation for putting customers first and building lasting partnerships' : isManagement ? 'culture of continuous improvement and employee development' : 'strong market position and growth trajectory'}. I am confident that my experience and passion for ${isMarketing ? 'marketing excellence' : isTech ? 'technical innovation' : isSales ? 'sales success' : isManagement ? 'leadership' : 'professional growth'} make me an ideal candidate for this position.`,
          
          `My professional journey has been marked by ${isMarketing ? 'creating integrated marketing strategies that consistently exceed KPIs and drive measurable business growth' : isTech ? 'delivering complex technical projects on time and within budget while maintaining code quality standards' : isSales ? 'developing strategic partnerships and consistently ranking among top performers in competitive markets' : isManagement ? 'transforming underperforming teams into high-achievers through effective leadership and mentoring' : 'consistent achievement and professional growth'}. Most recently, I ${isMarketing ? 'spearheaded a rebranding initiative that increased customer engagement by 50% across all touchpoints' : isTech ? 'led the migration of legacy systems to cloud infrastructure, improving performance by 300%' : isSales ? 'expanded into new markets and achieved 120% of annual quota for three consecutive years' : isManagement ? 'implemented new processes that reduced project delivery time by 25% while improving quality metrics' : 'achieved significant professional milestones'}.\n\nI am drawn to ${comp} because of your ${isMarketing ? 'innovative marketing philosophy and commitment to customer experience excellence' : isTech ? 'reputation for technical excellence and collaborative engineering culture' : isSales ? 'customer-first approach and strong track record of market leadership' : isManagement ? 'focus on sustainable growth and investment in human capital' : 'industry leadership and company values'}. I believe my skills in ${isMarketing ? 'digital marketing, brand management, and performance analytics' : isTech ? 'software development, system design, and technical leadership' : isSales ? 'relationship building, strategic selling, and market analysis' : isManagement ? 'strategic planning, team development, and operational optimization' : 'key professional areas'} would contribute significantly to your continued success.`,

          `My expertise in ${isMarketing ? 'digital marketing and customer acquisition' : isTech ? 'software engineering and system optimization' : isSales ? 'sales strategy and client relationship management' : isManagement ? 'team leadership and operational management' : 'my professional field'} has been consistently recognized through ${isMarketing ? 'campaigns that achieved 300% higher engagement rates than industry benchmarks' : isTech ? 'technical solutions that improved system efficiency by 45% while reducing costs' : isSales ? 'sales performance that consistently ranked in the top 10% company-wide' : isManagement ? 'leadership initiatives that improved team productivity by 35% and reduced turnover by 50%' : 'exceptional performance metrics'}. At my current company, I ${isMarketing ? 'developed an omnichannel strategy that increased customer lifetime value by 60%' : isTech ? 'architected a distributed system that handles 10M+ requests per hour with zero downtime' : isSales ? 'built a client portfolio worth $5M+ while maintaining 98% customer satisfaction' : isManagement ? 'transformed a struggling department into the most profitable division within 18 months' : 'led initiatives that significantly improved business outcomes'}.\n\nWhat excites me most about joining ${comp} is the opportunity to ${isMarketing ? 'leverage cutting-edge marketing technologies and data analytics to drive unprecedented growth' : isTech ? 'work with innovative technologies and contribute to products that impact millions of users' : isSales ? 'apply my proven sales methodologies to expand market reach and drive revenue growth' : isManagement ? 'lead strategic initiatives that will shape the future direction of the organization' : 'contribute to meaningful projects that drive business success'}. I am confident that my ${isMarketing ? 'creative problem-solving abilities and analytical mindset' : isTech ? 'technical expertise and collaborative approach' : isSales ? 'relationship-building skills and results-driven mentality' : isManagement ? 'strategic vision and people-first leadership style' : 'professional experience and dedication'} would make me a valuable addition to your team.`
        ];

      case 'closing':
        return [
          `I would welcome the opportunity to discuss how my experience in ${isMarketing ? 'marketing strategy and campaign execution' : isTech ? 'software development and technical innovation' : isSales ? 'sales performance and client relationship management' : isManagement ? 'leadership and operational excellence' : 'my field'} can contribute to ${comp}'s continued growth and success. Thank you for considering my application. I look forward to hearing from you soon and discussing how I can make an immediate impact on your team.`,
          
          `I am excited about the possibility of joining the ${comp} team and contributing to your ${isMarketing ? 'marketing objectives and brand growth initiatives' : isTech ? 'technical innovation and product development goals' : isSales ? 'revenue targets and market expansion plans' : isManagement ? 'strategic objectives and organizational development' : 'company objectives'}. I would appreciate the opportunity to discuss my qualifications in more detail during an interview. Thank you for your time and consideration, and I look forward to the next steps in the process.`,
          
          `Thank you for considering my application for the ${job} position. I am enthusiastic about the opportunity to bring my expertise in ${isMarketing ? 'marketing excellence and creative problem-solving' : isTech ? 'technical development and innovative solutions' : isSales ? 'sales achievement and customer success' : isManagement ? 'leadership and strategic execution' : 'professional excellence'} to ${comp}. I am available at your convenience for an interview and look forward to discussing how I can contribute to your team's continued success.`,

          `I am genuinely excited about the prospect of joining ${comp} and contributing to your continued success in the ${isMarketing ? 'marketing and brand development space' : isTech ? 'technology and innovation sector' : isSales ? 'sales and business development arena' : isManagement ? 'strategic management and operational excellence area' : 'industry'}. I would be delighted to discuss how my ${isMarketing ? 'marketing expertise and creative vision' : isTech ? 'technical skills and problem-solving abilities' : isSales ? 'sales experience and relationship-building capabilities' : isManagement ? 'leadership experience and strategic mindset' : 'professional background'} align with your team's needs. Thank you for your consideration, and I eagerly await the opportunity to speak with you further.`,

          `The ${job} position at ${comp} represents exactly the kind of opportunity I have been seeking to ${isMarketing ? 'leverage my marketing expertise in a dynamic, growth-oriented environment' : isTech ? 'apply my technical skills to solve complex challenges and drive innovation' : isSales ? 'utilize my sales experience to build lasting relationships and drive revenue growth' : isManagement ? 'use my leadership abilities to guide teams toward achieving ambitious goals' : 'advance my career while making meaningful contributions'}. I would be honored to discuss how my background and enthusiasm can benefit your organization. Thank you for your time and consideration, and I look forward to the opportunity to meet with you soon.`
        ];

      default:
        return [];
    }
  };

  const handleSuggestionSelect = (suggestion: string) => {
    onApplySuggestion(suggestion);
  };

  // Auto-generate suggestions when component mounts
  useState(() => {
    if (!hasGenerated && jobPosition && company) {
      generateSuggestions();
    }
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white/95 backdrop-blur-lg rounded-3xl max-w-4xl w-full max-h-[85vh] overflow-hidden shadow-2xl border border-white/20">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center">
                <i className="ri-magic-line text-white text-lg"></i>
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  AI Suggestions for {contentType.charAt(0).toUpperCase() + contentType.slice(1)} Paragraph
                </h2>
                <p className="text-sm text-gray-600">
                  {jobPosition} at {company}
                </p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center text-gray-500 hover:text-gray-700 transition-all duration-300"
            >
              <i className="ri-close-line text-lg"></i>
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto">
            {isGenerating ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-pulse">
                    <i className="ri-magic-line text-white text-xl"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Generating AI Suggestions</h3>
                  <p className="text-gray-600">Creating personalized content for your {contentType} paragraph...</p>
                  <div className="flex items-center justify-center mt-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-2 border-purple-600 border-t-transparent"></div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {suggestions.map((suggestion, index) => (
                  <div key={index} className="border border-gray-200 rounded-xl p-6 hover:bg-gray-50 transition-all duration-300">
                    <div className="flex items-start justify-between mb-4">
                      <h4 className="font-semibold text-gray-900">Option {index + 1}</h4>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <i className="ri-magic-line text-purple-600"></i>
                        <span>AI Generated</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-700 mb-4 whitespace-pre-line leading-relaxed">
                      {suggestion}
                    </p>
                    
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => handleSuggestionSelect(suggestion)}
                        className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 font-medium text-sm whitespace-nowrap"
                      >
                        Use This Content
                      </button>
                      <button
                        onClick={() => {
                          handleSuggestionSelect(currentContent + '\n\n' + suggestion);
                        }}
                        className="px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-all duration-300 font-medium text-sm whitespace-nowrap"
                      >
                        Add to Existing
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {!isGenerating && suggestions.length === 0 && (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full flex items-center justify-center">
                <i className="ri-magic-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Ready to Generate Suggestions</h3>
              <p className="text-gray-600 mb-4">Click the button below to generate AI-powered content suggestions.</p>
              <button
                onClick={generateSuggestions}
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 font-medium whitespace-nowrap"
              >
                Generate Suggestions
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
