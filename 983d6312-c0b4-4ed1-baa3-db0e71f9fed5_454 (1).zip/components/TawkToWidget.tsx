
'use client';

import { useEffect } from 'react';

export default function TawkToWidget() {
  useEffect(() => {
    // Initialize Tawk.to
    (window as any).Tawk_API = (window as any).Tawk_API || {};
    (window as any).Tawk_LoadStart = new Date();
    
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://embed.tawk.to/68c34b9fc8761f19250bb362/1j4tduqis';
    script.charset = 'UTF-8';
    script.setAttribute('crossorigin', '*');
    
    const firstScript = document.getElementsByTagName('script')[0];
    if (firstScript && firstScript.parentNode) {
      firstScript.parentNode.insertBefore(script, firstScript);
    }
  }, []);

  return null;
}
