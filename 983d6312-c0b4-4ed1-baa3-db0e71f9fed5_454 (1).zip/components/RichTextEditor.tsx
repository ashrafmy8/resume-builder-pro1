'use client';

import { useState, useRef, useEffect } from 'react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows?: number;
  className?: string;
}

export default function RichTextEditor({ 
  value, 
  onChange, 
  placeholder = "Start typing...", 
  rows = 4,
  className = ""
}: RichTextEditorProps) {
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showBgColorPicker, setShowBgColorPicker] = useState(false);
  const [currentTextColor, setCurrentTextColor] = useState('#000000');
  const [currentBgColor, setCurrentBgColor] = useState('#ffffff');
  const editorRef = useRef<HTMLDivElement>(null);
  const colorPickerRef = useRef<HTMLDivElement>(null);
  const bgColorPickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editorRef.current && value !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (colorPickerRef.current && !colorPickerRef.current.contains(event.target as Node)) {
        setShowColorPicker(false);
      }
      if (bgColorPickerRef.current && !bgColorPickerRef.current.contains(event.target as Node)) {
        setShowBgColorPicker(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    handleInput();
  };

  const handleFontSize = (size: string) => {
    execCommand('fontSize', '3');
    // Then apply custom size via style
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      if (!range.collapsed) {
        const span = document.createElement('span');
        span.style.fontSize = size;
        try {
          range.surroundContents(span);
        } catch (e) {
          span.appendChild(range.extractContents());
          range.insertNode(span);
        }
        handleInput();
      }
    }
  };

  const handleTextColor = (color: string) => {
    setCurrentTextColor(color);
    execCommand('foreColor', color);
    setShowColorPicker(false);
  };

  const handleBgColor = (color: string) => {
    setCurrentBgColor(color);
    execCommand('backColor', color);
    setShowBgColorPicker(false);
  };

  const insertList = (type: 'ul' | 'ol') => {
    if (type === 'ul') {
      execCommand('insertUnorderedList');
    } else {
      execCommand('insertOrderedList');
    }
  };

  const colors = [
    '#000000', '#333333', '#666666', '#999999', '#cccccc', '#ffffff',
    '#ff0000', '#ff6600', '#ffcc00', '#33cc00', '#0066cc', '#6600cc',
    '#ff3366', '#ff9933', '#ccff33', '#33ffcc', '#3366ff', '#cc33ff',
    '#990000', '#cc6600', '#999900', '#006600', '#003399', '#330099'
  ];

  const fontSizes = [
    { label: 'Small', value: '12px' },
    { label: 'Normal', value: '14px' },
    { label: 'Medium', value: '16px' },
    { label: 'Large', value: '18px' },
    { label: 'X-Large', value: '24px' },
    { label: 'XX-Large', value: '32px' }
  ];

  return (
    <div className={`border-2 border-gray-200 rounded-xl focus-within:border-purple-500 transition-colors ${className}`}>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-1 p-3 border-b border-gray-200 bg-gray-50 rounded-t-xl">
        {/* Text Formatting */}
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => execCommand('bold')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Bold"
          >
            <i className="ri-bold text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('italic')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Italic"
          >
            <i className="ri-italic text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('underline')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Underline"
          >
            <i className="ri-underline text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('strikeThrough')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Strike Through"
          >
            <i className="ri-strikethrough text-lg"></i>
          </button>
        </div>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        {/* Font Size */}
        <div className="relative">
          <select
            onChange={(e) => handleFontSize(e.target.value)}
            className="px-3 py-1 bg-white border border-gray-300 rounded-lg text-sm cursor-pointer pr-8"
            title="Font Size"
          >
            <option value="">Size</option>
            {fontSizes.map((size) => (
              <option key={size.value} value={size.value}>
                {size.label}
              </option>
            ))}
          </select>
        </div>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        {/* Colors */}
        <div className="flex items-center space-x-1">
          <div className="relative" ref={colorPickerRef}>
            <button
              type="button"
              onClick={() => setShowColorPicker(!showColorPicker)}
              className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer flex items-center"
              title="Text Color"
            >
              <i className="ri-font-color text-lg"></i>
              <div 
                className="w-3 h-1 ml-1 rounded"
                style={{ backgroundColor: currentTextColor }}
              ></div>
            </button>
            {showColorPicker && (
              <div className="absolute top-full left-0 mt-1 p-3 bg-white border border-gray-300 rounded-lg shadow-lg z-50">
                <div className="grid grid-cols-6 gap-1">
                  {colors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => handleTextColor(color)}
                      className="w-6 h-6 rounded border border-gray-300 hover:scale-110 transition-transform cursor-pointer"
                      style={{ backgroundColor: color }}
                      title={color}
                    ></button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="relative" ref={bgColorPickerRef}>
            <button
              type="button"
              onClick={() => setShowBgColorPicker(!showBgColorPicker)}
              className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer flex items-center"
              title="Background Color"
            >
              <i className="ri-paint-fill text-lg"></i>
              <div 
                className="w-3 h-1 ml-1 rounded border border-gray-300"
                style={{ backgroundColor: currentBgColor }}
              ></div>
            </button>
            {showBgColorPicker && (
              <div className="absolute top-full left-0 mt-1 p-3 bg-white border border-gray-300 rounded-lg shadow-lg z-50">
                <div className="grid grid-cols-6 gap-1">
                  {colors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => handleBgColor(color)}
                      className="w-6 h-6 rounded border border-gray-300 hover:scale-110 transition-transform cursor-pointer"
                      style={{ backgroundColor: color }}
                      title={color}
                    ></button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        {/* Alignment */}
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => execCommand('justifyLeft')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Align Left"
          >
            <i className="ri-align-left text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('justifyCenter')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Align Center"
          >
            <i className="ri-align-center text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('justifyRight')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Align Right"
          >
            <i className="ri-align-right text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('justifyFull')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Justify"
          >
            <i className="ri-align-justify text-lg"></i>
          </button>
        </div>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        {/* Lists */}
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => insertList('ul')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Bullet List"
          >
            <i className="ri-list-unordered text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => insertList('ol')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Numbered List"
          >
            <i className="ri-list-ordered text-lg"></i>
          </button>
        </div>

        <div className="w-px h-6 bg-gray-300 mx-1"></div>

        {/* Utility Actions */}
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => execCommand('undo')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Undo"
          >
            <i className="ri-arrow-go-back-line text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('redo')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Redo"
          >
            <i className="ri-arrow-go-forward-line text-lg"></i>
          </button>
          <button
            type="button"
            onClick={() => execCommand('removeFormat')}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Clear Formatting"
          >
            <i className="ri-format-clear text-lg"></i>
          </button>
        </div>
      </div>

      {/* Editor */}
      <div
        ref={editorRef}
        contentEditable
        onInput={handleInput}
        className="w-full px-4 py-3 focus:outline-none resize-none leading-relaxed text-gray-900"
        style={{ 
          minHeight: `${rows * 1.5}rem`,
          maxHeight: '400px',
          overflowY: 'auto'
        }}
        suppressContentEditableWarning={true}
        data-placeholder={placeholder}
      />

      <style jsx>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: #9ca3af;
          pointer-events: none;
        }
      `}</style>
    </div>
  );
}