'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface AffiliateStats {
  affiliateCode: string;
  referralLink: string;
  totalReferrals: number;
  totalEarnings: number;
  referrals: any[];
  earnings: {
    total_earned: number;
    total_paid: number;
    pending_payout: number;
  };
}

export default function AffiliateManager() {
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [payoutMethod, setPayoutMethod] = useState('paypal');
  const [payoutEmail, setPayoutEmail] = useState('');
  const [showPayoutForm, setShowPayoutForm] = useState(false);

  useEffect(() => {
    loadAffiliateStats();
  }, []);

  const loadAffiliateStats = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch('/api/supabase/functions/affiliate-system', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'get_affiliate_stats' })
      });

      const result = await response.json();
      if (result.success) {
        setStats(result);
        setPayoutEmail(result.earnings?.payout_email || '');
        setPayoutMethod(result.earnings?.payout_method || 'paypal');
      } else {
        // Generate affiliate code if not found
        await generateAffiliateCode();
      }
    } catch (error) {
      console.error('Error loading affiliate stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateAffiliateCode = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch('/api/supabase/functions/affiliate-system', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'generate_affiliate_code' })
      });

      const result = await response.json();
      if (result.success) {
        await loadAffiliateStats();
      }
    } catch (error) {
      console.error('Error generating affiliate code:', error);
    }
  };

  const copyReferralLink = async () => {
    if (stats?.referralLink) {
      await navigator.clipboard.writeText(stats.referralLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const updatePayoutInfo = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch('/api/supabase/functions/affiliate-system', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          action: 'update_payout_info',
          payoutMethod,
          payoutEmail
        })
      });

      const result = await response.json();
      if (result.success) {
        setShowPayoutForm(false);
        await loadAffiliateStats();
      }
    } catch (error) {
      console.error('Error updating payout info:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center p-8">
        <p className="text-gray-600 mb-4">Unable to load affiliate data</p>
        <button 
          onClick={generateAffiliateCode}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Generate Affiliate Code
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Referrals</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalReferrals}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <i className="ri-group-line text-blue-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Earnings</p>
              <p className="text-2xl font-bold text-green-600">${stats.earnings.total_earned.toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-money-dollar-circle-line text-green-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Payout</p>
              <p className="text-2xl font-bold text-orange-600">${stats.earnings.pending_payout.toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <i className="ri-wallet-line text-orange-600 text-xl"></i>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Link */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Referral Link</h3>
        <div className="flex items-center space-x-3">
          <div className="flex-1">
            <input
              type="text"
              value={stats.referralLink}
              readOnly
              className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
            />
          </div>
          <button
            onClick={copyReferralLink}
            className={`px-6 py-3 rounded-lg transition-colors whitespace-nowrap ${
              copied 
                ? 'bg-green-600 text-white' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {copied ? (
              <>
                <i className="ri-check-line mr-2"></i>
                Copied!
              </>
            ) : (
              <>
                <i className="ri-file-copy-line mr-2"></i>
                Copy Link
              </>
            )}
          </button>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          Share this link with friends to earn $3 for each person who signs up!
        </p>
      </div>

      {/* Affiliate Code */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border border-blue-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Affiliate Code</h3>
        <div className="text-3xl font-bold text-blue-600 mb-2">{stats.affiliateCode}</div>
        <p className="text-gray-600">Use this code in your marketing materials and social media posts</p>
      </div>

      {/* Payout Settings */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Payout Settings</h3>
          <button
            onClick={() => setShowPayoutForm(!showPayoutForm)}
            className="text-blue-600 hover:text-blue-700 font-medium"
          >
            <i className="ri-edit-line mr-1"></i>
            Edit
          </button>
        </div>

        {showPayoutForm ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Payout Method
              </label>
              <select
                value={payoutMethod}
                onChange={(e) => setPayoutMethod(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="paypal">PayPal</option>
                <option value="bank">Bank Transfer</option>
                <option value="stripe">Stripe</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Payout Email
              </label>
              <input
                type="email"
                value={payoutEmail}
                onChange={(e) => setPayoutEmail(e.target.value)}
                placeholder="Enter your payout email"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div className="flex space-x-3">
              <button
                onClick={updatePayoutInfo}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Save Changes
              </button>
              <button
                onClick={() => setShowPayoutForm(false)}
                className="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="text-gray-600">
            <p><strong>Method:</strong> {payoutMethod.charAt(0).toUpperCase() + payoutMethod.slice(1)}</p>
            <p><strong>Email:</strong> {payoutEmail || 'Not set'}</p>
          </div>
        )}
      </div>

      {/* Recent Referrals */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Referrals</h3>
        {stats.referrals.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">User</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Commission</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                </tr>
              </thead>
              <tbody>
                {stats.referrals.slice(0, 10).map((referral, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-3 px-4">
                      {referral.referred_user?.first_name && referral.referred_user?.last_name
                        ? `${referral.referred_user.first_name} ${referral.referred_user.last_name}`
                        : referral.referred_user?.email || 'Anonymous'
                      }
                    </td>
                    <td className="py-3 px-4 text-gray-600">
                      {new Date(referral.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-green-600 font-medium">
                      ${referral.commission_amount.toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        referral.status === 'confirmed' 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {referral.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <i className="ri-group-line text-4xl mb-4"></i>
            <p>No referrals yet. Start sharing your link to earn commissions!</p>
          </div>
        )}
      </div>

      {/* Marketing Tips */}
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-lg border border-purple-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Marketing Tips</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <i className="ri-social-media-line text-purple-600"></i>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Share on Social Media</h4>
              <p className="text-sm text-gray-600">Post about ResumeTeacher on LinkedIn, Twitter, and Facebook</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <i className="ri-mail-line text-blue-600"></i>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Email Your Network</h4>
              <p className="text-sm text-gray-600">Send personalized emails to friends and colleagues</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <i className="ri-article-line text-green-600"></i>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Write Blog Posts</h4>
              <p className="text-sm text-gray-600">Create content about resume writing and include your link</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <i className="ri-community-line text-orange-600"></i>
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Join Communities</h4>
              <p className="text-sm text-gray-600">Participate in career-focused forums and groups</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}