'use client';

import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';

interface UserActivity {
  id: string;
  user_id: string;
  activity_type: 'page_view' | 'resume_edit' | 'template_select' | 'section_complete' | 'form_interaction' | 'download' | 'share';
  activity_data: any;
  page_url: string;
  session_id: string;
  timestamp: string;
  duration?: number;
}

interface ActivityTrackerProps {
  userId: string;
  onActivityUpdate?: (activity: UserActivity) => void;
}

export default function ActivityTracker({ userId, onActivityUpdate }: ActivityTrackerProps) {
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [isActive, setIsActive] = useState(true);
  const [currentPage, setCurrentPage] = useState('');
  const pageStartTime = useRef(Date.now());
  const activityQueue = useRef<UserActivity[]>([]);
  const flushInterval = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentPage(window.location.pathname);
      
      // Track page changes
      const handlePageChange = () => {
        trackActivity('page_view', {
          previous_page: currentPage,
          page_title: document.title,
          referrer: document.referrer
        });
        setCurrentPage(window.location.pathname);
        pageStartTime.current = Date.now();
      };

      // Track user interactions
      const handleClick = (event: MouseEvent) => {
        const target = event.target as HTMLElement;
        if (target.tagName === 'BUTTON' || target.tagName === 'A' || target.closest('button') || target.closest('a')) {
          trackActivity('form_interaction', {
            element_type: target.tagName.toLowerCase(),
            element_text: target.textContent?.slice(0, 100),
            element_id: target.id,
            element_class: target.className,
            position: { x: event.clientX, y: event.clientY }
          });
        }
      };

      // Track form interactions
      const handleFormInteraction = (event: Event) => {
        const target = event.target as HTMLElement;
        trackActivity('form_interaction', {
          form_field: target.getAttribute('name') || target.id,
          field_type: target.getAttribute('type') || target.tagName.toLowerCase(),
          action: event.type
        });
      };

      // Track scroll behavior
      let scrollTimer: NodeJS.Timeout;
      const handleScroll = () => {
        clearTimeout(scrollTimer);
        scrollTimer = setTimeout(() => {
          const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
          if (scrollPercent > 0) {
            trackActivity('page_view', {
              scroll_depth: scrollPercent,
              scroll_position: window.scrollY,
              page_height: document.body.scrollHeight
            });
          }
        }, 1000);
      };

      // Track visibility changes
      const handleVisibilityChange = () => {
        setIsActive(!document.hidden);
        if (document.hidden) {
          trackActivity('page_view', {
            action: 'page_blur',
            time_spent: Date.now() - pageStartTime.current
          });
        } else {
          trackActivity('page_view', {
            action: 'page_focus'
          });
          pageStartTime.current = Date.now();
        }
      };

      // Set up event listeners
      window.addEventListener('popstate', handlePageChange);
      document.addEventListener('click', handleClick);
      document.addEventListener('input', handleFormInteraction);
      document.addEventListener('change', handleFormInteraction);
      document.addEventListener('scroll', handleScroll);
      document.addEventListener('visibilitychange', handleVisibilityChange);

      // Initial page view
      trackActivity('page_view', {
        page_title: document.title,
        user_agent: navigator.userAgent,
        screen_resolution: `${screen.width}x${screen.height}`,
        viewport: `${window.innerWidth}x${window.innerHeight}`
      });

      return () => {
        window.removeEventListener('popstate', handlePageChange);
        document.removeEventListener('click', handleClick);
        document.removeEventListener('input', handleFormInteraction);
        document.removeEventListener('change', handleFormInteraction);
        document.removeEventListener('scroll', handleScroll);
        document.removeEventListener('visibilitychange', handleVisibilityChange);
        clearTimeout(scrollTimer);
      };
    }
  }, []);

  useEffect(() => {
    // Flush activity queue every 5 seconds
    flushInterval.current = setInterval(() => {
      flushActivityQueue();
    }, 5000);

    return () => {
      if (flushInterval.current) {
        clearInterval(flushInterval.current);
      }
      flushActivityQueue(); // Final flush on unmount
    };
  }, []);

  const trackActivity = (type: UserActivity['activity_type'], data: any = {}) => {
    if (!userId || !isActive) return;

    const activity: UserActivity = {
      id: `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      user_id: userId,
      activity_type: type,
      activity_data: data,
      page_url: typeof window !== 'undefined' ? window.location.pathname : '',
      session_id: sessionId,
      timestamp: new Date().toISOString(),
      duration: type === 'page_view' && data.time_spent ? data.time_spent : undefined
    };

    activityQueue.current.push(activity);
    
    // Notify parent component immediately
    if (onActivityUpdate) {
      onActivityUpdate(activity);
    }

    // Flush immediately for critical activities
    if (['resume_edit', 'section_complete', 'download'].includes(type)) {
      flushActivityQueue();
    }
  };

  const flushActivityQueue = async () => {
    if (activityQueue.current.length === 0) return;

    const activitiesToFlush = [...activityQueue.current];
    activityQueue.current = [];

    try {
      // Try to save to Supabase first
      const { error } = await supabase
        .from('user_activities')
        .insert(activitiesToFlush);

      if (error) {
        console.warn('Failed to save activities to database:', error);
        // Fallback to localStorage
        saveActivitiesLocally(activitiesToFlush);
      }
    } catch (error) {
      console.warn('Activity tracking error:', error);
      saveActivitiesLocally(activitiesToFlush);
    }
  };

  const saveActivitiesLocally = (activities: UserActivity[]) => {
    try {
      const existingActivities = JSON.parse(localStorage.getItem(`activities_${userId}`) || '[]');
      const updatedActivities = [...existingActivities, ...activities];
      // Keep only last 1000 activities to prevent storage bloat
      const trimmedActivities = updatedActivities.slice(-1000);
      localStorage.setItem(`activities_${userId}`, JSON.stringify(trimmedActivities));
    } catch (error) {
      console.warn('Failed to save activities locally:', error);
    }
  };

  // Expose tracking functions for manual usage
  const trackResumeEdit = (resumeId: string, section: string, data: any) => {
    trackActivity('resume_edit', {
      resume_id: resumeId,
      section,
      changes: data,
      timestamp: new Date().toISOString()
    });
  };

  const trackSectionComplete = (resumeId: string, section: string) => {
    trackActivity('section_complete', {
      resume_id: resumeId,
      section,
      completion_time: Date.now() - pageStartTime.current
    });
  };

  const trackTemplateSelect = (templateId: string, templateName: string) => {
    trackActivity('template_select', {
      template_id: templateId,
      template_name: templateName
    });
  };

  const trackDownload = (resumeId: string, format: string) => {
    trackActivity('download', {
      resume_id: resumeId,
      format,
      download_timestamp: new Date().toISOString()
    });
  };

  // Make tracking functions available globally
  useEffect(() => {
    if (typeof window !== 'undefined') {
      (window as any).resumeTracker = {
        trackResumeEdit,
        trackSectionComplete,
        trackTemplateSelect,
        trackDownload
      };
    }
  }, []);

  return null; // This is an invisible tracking component
}