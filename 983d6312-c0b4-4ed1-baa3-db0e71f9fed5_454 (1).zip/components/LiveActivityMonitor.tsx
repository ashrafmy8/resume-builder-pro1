'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface UserActivity {
  id: string;
  user_id: string;
  activity_type: 'page_view' | 'resume_edit' | 'template_select' | 'section_complete' | 'form_interaction' | 'download' | 'share';
  activity_data: any;
  page_url: string;
  session_id: string;
  timestamp: string;
  duration?: number;
}

interface LiveActivityMonitorProps {
  userId: string;
  maxActivities?: number;
}

export default function LiveActivityMonitor({ userId, maxActivities = 20 }: LiveActivityMonitorProps) {
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [isLive, setIsLive] = useState(false);
  const [stats, setStats] = useState({
    totalTime: 0,
    pagesVisited: 0,
    actionsPerformed: 0,
    resumesWorkedOn: new Set(),
    currentSession: 0
  });

  useEffect(() => {
    loadRecentActivities();
    setupRealtimeSubscription();
    
    return () => {
      if (typeof window !== 'undefined') {
        // Clean up any existing subscriptions
      }
    };
  }, [userId]);

  useEffect(() => {
    calculateStats();
  }, [activities]);

  const loadRecentActivities = async () => {
    try {
      // Try loading from Supabase first
      const { data, error } = await supabase
        .from('user_activities')
        .select('*')
        .eq('user_id', userId)
        .order('timestamp', { ascending: false })
        .limit(maxActivities);

      if (error) {
        console.warn('Failed to load activities from database:', error);
        loadActivitiesFromLocalStorage();
        return;
      }

      if (data) {
        setActivities(data);
        setIsLive(true);
      } else {
        loadActivitiesFromLocalStorage();
      }
    } catch (error) {
      console.warn('Activity loading error:', error);
      loadActivitiesFromLocalStorage();
    }
  };

  const loadActivitiesFromLocalStorage = () => {
    try {
      const localActivities = JSON.parse(localStorage.getItem(`activities_${userId}`) || '[]');
      const recentActivities = localActivities
        .sort((a: UserActivity, b: UserActivity) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, maxActivities);
      setActivities(recentActivities);
      setIsLive(false);
    } catch (error) {
      console.warn('Failed to load local activities:', error);
      setActivities([]);
    }
  };

  const setupRealtimeSubscription = () => {
    try {
      const subscription = supabase
        .channel('user_activities')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'user_activities',
            filter: `user_id=eq.${userId}`
          },
          (payload) => {
            const newActivity = payload.new as UserActivity;
            setActivities(prev => [newActivity, ...prev.slice(0, maxActivities - 1)]);
            setIsLive(true);
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    } catch (error) {
      console.warn('Failed to setup realtime subscription:', error);
      setIsLive(false);
    }
  };

  const calculateStats = () => {
    const now = Date.now();
    const sessionStart = now - (24 * 60 * 60 * 1000); // Last 24 hours
    
    const sessionActivities = activities.filter(
      activity => new Date(activity.timestamp).getTime() > sessionStart
    );

    const totalTime = sessionActivities
      .filter(activity => activity.duration)
      .reduce((sum, activity) => sum + (activity.duration || 0), 0);

    const pagesVisited = new Set(
      sessionActivities
        .filter(activity => activity.activity_type === 'page_view')
        .map(activity => activity.page_url)
    ).size;

    const actionsPerformed = sessionActivities
      .filter(activity => ['form_interaction', 'resume_edit', 'template_select'].includes(activity.activity_type))
      .length;

    const resumesWorkedOn = new Set(
      sessionActivities
        .filter(activity => activity.activity_data?.resume_id)
        .map(activity => activity.activity_data.resume_id)
    );

    setStats({
      totalTime: Math.round(totalTime / 1000), // Convert to seconds
      pagesVisited,
      actionsPerformed,
      resumesWorkedOn,
      currentSession: sessionActivities.length
    });
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'page_view': return 'ri-eye-line';
      case 'resume_edit': return 'ri-edit-line';
      case 'template_select': return 'ri-layout-line';
      case 'section_complete': return 'ri-check-line';
      case 'form_interaction': return 'ri-cursor-line';
      case 'download': return 'ri-download-line';
      case 'share': return 'ri-share-line';
      default: return 'ri-information-line';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'page_view': return 'text-blue-600 bg-blue-100';
      case 'resume_edit': return 'text-green-600 bg-green-100';
      case 'template_select': return 'text-purple-600 bg-purple-100';
      case 'section_complete': return 'text-emerald-600 bg-emerald-100';
      case 'form_interaction': return 'text-orange-600 bg-orange-100';
      case 'download': return 'text-indigo-600 bg-indigo-100';
      case 'share': return 'text-pink-600 bg-pink-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getActivityDescription = (activity: UserActivity) => {
    const data = activity.activity_data || {};
    
    switch (activity.activity_type) {
      case 'page_view':
        if (data.action === 'page_blur') return `Left page after ${Math.round(data.time_spent / 1000)}s`;
        if (data.scroll_depth) return `Scrolled ${data.scroll_depth}% of page`;
        return `Viewed ${activity.page_url}`;
      
      case 'resume_edit':
        return `Edited ${data.section} section ${data.resume_id ? `in resume ${data.resume_id.slice(-8)}` : ''}`;
      
      case 'template_select':
        return `Selected template: ${data.template_name || data.template_id}`;
      
      case 'section_complete':
        return `Completed ${data.section} section`;
      
      case 'form_interaction':
        if (data.element_text) return `Clicked: ${data.element_text.slice(0, 30)}...`;
        if (data.form_field) return `Interacted with ${data.form_field} field`;
        return 'Form interaction';
      
      case 'download':
        return `Downloaded resume as ${data.format?.toUpperCase() || 'file'}`;
      
      case 'share':
        return `Shared resume ${data.resume_id ? data.resume_id.slice(-8) : ''}`;
      
      default:
        return activity.activity_type.replace('_', ' ');
    }
  };

  const formatTime = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
    return `${Math.round(seconds / 3600)}h`;
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.round(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.round(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border">
      <div className="p-6 border-b">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Live Activity Monitor</h3>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-500' : 'bg-gray-400'}`}></div>
            <span className="text-sm text-gray-600">
              {isLive ? 'Live' : 'Offline'}
            </span>
          </div>
        </div>

        {/* Real-time Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{formatTime(stats.totalTime)}</div>
            <div className="text-sm text-gray-600">Time Spent</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.pagesVisited}</div>
            <div className="text-sm text-gray-600">Pages Visited</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.actionsPerformed}</div>
            <div className="text-sm text-gray-600">Actions</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.resumesWorkedOn.size}</div>
            <div className="text-sm text-gray-600">Resumes</div>
          </div>
        </div>
      </div>

      {/* Activity Feed */}
      <div className="p-6">
        <h4 className="font-medium text-gray-900 mb-4">Recent Activity</h4>
        
        {activities.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <i className="ri-time-line text-xl text-gray-400"></i>
            </div>
            <p className="text-gray-600">No recent activity to display</p>
            <p className="text-sm text-gray-500 mt-1">Start using the app to see your activity here</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getActivityColor(activity.activity_type)}`}>
                  <i className={`${getActivityIcon(activity.activity_type)} text-sm`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900 font-medium">
                    {getActivityDescription(activity)}
                  </p>
                  <div className="flex items-center space-x-2 mt-1">
                    <p className="text-xs text-gray-500">{formatTimestamp(activity.timestamp)}</p>
                    {activity.page_url && (
                      <span className="text-xs text-gray-400">•</span>
                    )}
                    {activity.page_url && (
                      <p className="text-xs text-gray-500">{activity.page_url}</p>
                    )}
                  </div>
                </div>
                {activity.activity_type === 'resume_edit' && (
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}