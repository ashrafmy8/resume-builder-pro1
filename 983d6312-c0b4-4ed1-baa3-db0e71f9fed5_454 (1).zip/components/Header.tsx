
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Header() {
  const [showResumeDropdown, setShowResumeDropdown] = useState(false);
  const [showCVDropdown, setShowCVDropdown] = useState(false);
  const [showCoverLetterDropdown, setShowCoverLetterDropdown] = useState(false);
  const [showAdviceDropdown, setShowAdviceDropdown] = useState(false);
  const [showResourcesDropdown, setShowResourcesDropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Check authentication status only on client side
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const checkAuth = () => {
      try {
        const authStatus = localStorage.getItem('isAuthenticated');
        const userData = localStorage.getItem('user');
        
        if (authStatus === 'true' && userData) {
          setIsAuthenticated(true);
          setUser(JSON.parse(userData));
        } else {
          setIsAuthenticated(false);
          setUser(null);
        }
      } catch (error) {
        console.error('Auth check error:', error);
        setIsAuthenticated(false);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    // Initial check
    checkAuth();

    // Listen for auth changes
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'isAuthenticated' || e.key === 'user') {
        checkAuth();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const handleLogout = () => {
    if (typeof window === 'undefined') return;
    
    try {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('user');
      localStorage.removeItem('googleAuthToken');
      setIsAuthenticated(false);
      setUser(null);
      setShowProfileDropdown(false);
      window.location.href = '/';
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <>
      {/* WhatsApp Floating Button - Mobile Optimized */}
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50">
        <a
          href="https://wa.me/256750625684"
          target="_blank"
          rel="noopener noreferrer"
          className="group relative bg-green-500 hover:bg-green-600 text-white w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 animate-pulse hover:animate-none"
        >
          <i className="ri-whatsapp-line text-lg md:text-2xl"></i>
          
          {/* Tooltip - Hidden on mobile */}
          <div className="hidden md:block absolute right-full mr-4 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white text-sm px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
            Need Help? Chat with us!
            <div className="absolute left-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-l-gray-900"></div>
          </div>
          
          {/* Ripple Effect */}
          <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-20"></div>
        </a>
      </div>

      {/* Magic Wand Icon with Animation */}
      <div className="relative group">
        <div className="relative">
          {/* Wand Image */}
          <img 
            src="https://static.readdy.ai/image/466f3553021a9445150292a8336276fc/c60b31656d7a61f006c5aa48c9e8a889.png" 
            alt="Magic Wand" 
            className="w-8 h-8 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12"
          />
        </div>
      </div>

      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-xl font-['Pacifico'] font-bold text-gray-800">Resume Teacher</span>
            </Link>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2 rounded-lg text-gray-600 hover:text-blue-600 hover:bg-gray-100 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <i className={`ri-${mobileMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-4 lg:space-x-8">
              <Link href="/pricing" className="px-3 lg:px-4 py-2 text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap text-sm lg:text-base font-medium">
                Pricing
              </Link>

              {/* Resume Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setShowResumeDropdown(true)}
                onMouseLeave={() => setShowResumeDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap text-sm lg:text-base">
                  Resume
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>
                
                {showResumeDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-80 z-50">
                    <div className="grid grid-cols-1 gap-4">
                      <Link href="/resume-templates" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-file-copy-line text-orange-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Resume Templates</h3>
                          <p className="text-sm text-gray-600">Browse customizable templates to create a resume quickly and easily.</p>
                        </div>
                      </Link>

                      <Link href="/formats" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-layout-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Resume Formats</h3>
                          <p className="text-sm text-gray-600">Learn different formats and choose the best one for you based on your background.</p>
                        </div>
                      </Link>

                      <Link href="/resume-examples" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-award-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Resume Examples</h3>
                          <p className="text-sm text-gray-600">Use examples for various job titles and industries as a source of inspiration.</p>
                        </div>
                      </Link>

                      <Link href="/ai-resume-skills-generator" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-settings-3-line text-purple-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">AI Resume Skills Generator</h3>
                          <p className="text-sm text-gray-600">Use our resume skills generator for a quick solution to a job-winning skills section.</p>
                        </div>
                      </Link>

                      <Link href="/how-to-make-resume" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-question-line text-indigo-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">How to Make a Resume</h3>
                          <p className="text-sm text-gray-600">Learn step-by-step tips for writing a resume that gets noticed.</p>
                        </div>
                      </Link>

                      <Link href="/ats-resume-checker" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-shield-check-line text-yellow-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">ATS Resume Checker</h3>
                          <p className="text-sm text-gray-600">Ensure your resume can be easily read by Applicant Tracking Systems (ATS).</p>
                        </div>
                      </Link>

                      <Link href="/summary-generator" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-magic-line text-red-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">AI Summary Generator</h3>
                          <p className="text-sm text-gray-600">Create a professional resume summary that highlights your essential qualifications and career goals.</p>
                        </div>
                      </Link>

                      <Link href="/ai-review" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-search-eye-line text-teal-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">AI Resume Review</h3>
                          <p className="text-sm text-gray-600">Get instant expert feedback with clear steps for improvement.</p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* CV Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setShowCVDropdown(true)}
                onMouseLeave={() => setShowCVDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap text-sm lg:text-base">
                  CV
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>
                
                {showCVDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link href="/cv-templates" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-file-list-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">CV Templates</h3>
                          <p className="text-sm text-gray-600">Professional CV templates for academic and research positions.</p>
                        </div>
                      </Link>

                      <Link href="/cv-examples" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-bookmark-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">CV Examples</h3>
                          <p className="text-sm text-gray-600">Browse CV examples across different industries and experience levels.</p>
                        </div>
                      </Link>

                      <Link href="/how-to-write-cv" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-edit-line text-purple-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">How to Write a CV</h3>
                          <p className="text-sm text-gray-600">Complete guide to writing a compelling CV that stands out.</p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Cover Letter Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setShowCoverLetterDropdown(true)}
                onMouseLeave={() => setShowCoverLetterDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap text-sm lg:text-base">
                  Cover Letter
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>
                
                {showCoverLetterDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link href="/cover-letter-builder" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-file-text-line text-indigo-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Cover Letter Builder</h3>
                          <p className="text-sm text-gray-600">Create professional cover letters with our easy-to-use builder.</p>
                        </div>
                      </Link>

                      <Link href="/cover-letter-templates" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-layout-2-line text-orange-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Cover Letter Templates</h3>
                          <p className="text-sm text-gray-600">Choose from professionally designed cover letter templates.</p>
                        </div>
                      </Link>

                      <Link href="/cover-letter-examples" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-newspaper-line text-teal-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Cover Letter Examples</h3>
                          <p className="text-sm text-gray-600">Get inspired by cover letter examples for various job roles.</p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Advice Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setShowAdviceDropdown(true)}
                onMouseLeave={() => setShowAdviceDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap text-sm lg:text-base">
                  Advice
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>
                
                {showAdviceDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link href="/career-advice" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-lightbulb-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Career Advice</h3>
                          <p className="text-sm text-gray-600">Expert tips for advancing your career and landing your dream job.</p>
                        </div>
                      </Link>

                      <Link href="/interview-tips" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-discuss-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Interview Tips</h3>
                          <p className="text-sm text-gray-600">Prepare for interviews with our comprehensive guides and tips.</p>
                        </div>
                      </Link>

                      <Link href="/job-search-tips" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-search-line text-purple-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Job Search Tips</h3>
                          <p className="text-sm text-gray-600">Strategies and tips for finding and applying to the right jobs.</p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Resources Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setShowResourcesDropdown(true)}
                onMouseLeave={() => setShowResourcesDropdown(false)}
              >
                <button className="flex items-center text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap text-sm lg:text-base">
                  Resources
                  <i className="ri-arrow-down-s-line ml-1"></i>
                </button>
                
                {showResourcesDropdown && (
                  <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-4 px-6 w-72 z-50">
                    <div className="space-y-3">
                      <Link href="/blog" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-article-line text-orange-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Blog</h3>
                          <p className="text-sm text-gray-600">Latest articles on career development and job search strategies.</p>
                        </div>
                      </Link>

                      <Link href="/guides" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-book-line text-blue-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Career Guides</h3>
                          <p className="text-sm text-gray-600">Comprehensive guides for different career paths and industries.</p>
                        </div>
                      </Link>

                      <Link href="/tools" className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="ri-tools-line text-green-600"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">Career Tools</h3>
                          <p className="text-sm text-gray-600">Useful tools and calculators for career planning and development.</p>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Desktop Auth Buttons / Profile */}
            <div className="hidden md:flex items-center space-x-2 lg:space-x-3">
              {!isLoading && (
                <>
                  {isAuthenticated && user ? (
                    // Profile dropdown for authenticated users
                    <div className="flex items-center space-x-4">
                      <button 
                        onClick={handleLogout}
                        className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer rounded-lg"
                        title="Logout"
                      >
                        <i className="ri-logout-circle-line text-xl"></i>
                      </button>
                      
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                        <i className="ri-settings-3-line text-xl"></i>
                      </button>
                      
                      <div 
                        className="relative"
                        onMouseEnter={() => setShowProfileDropdown(true)}
                        onMouseLeave={() => setShowProfileDropdown(false)}
                      >
                        <button className="flex items-center space-x-2 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                          {user.picture ? (
                            <img 
                              src={user.picture} 
                              alt={user.name || user.firstName} 
                              className="w-8 h-8 rounded-full"
                            />
                          ) : (
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-blue-600 font-medium text-sm">
                                {(user.firstName || user.name || 'U')[0].toUpperCase()}
                              </span>
                            </div>
                          )}
                          <span className="text-sm font-medium">
                            {user.firstName || user.name?.split(' ')[0] || 'User'}
                          </span>
                          <i className="ri-arrow-down-s-line text-sm"></i>
                        </button>

                        {showProfileDropdown && (
                          <div className="absolute top-full right-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-200 py-2 w-64 z-50">
                            <div className="px-4 py-3 border-b border-gray-100">
                              <p className="text-sm font-semibold text-gray-900">
                                {user.name || `${user.firstName} ${user.lastName}`}
                              </p>
                              <p className="text-sm text-gray-600">{user.email}</p>
                            </div>
                            
                            <div className="py-2">
                              <Link href="/dashboard" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <i className="ri-dashboard-line mr-3"></i>
                                Dashboard
                              </Link>
                              <Link href="/profile" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <i className="ri-user-line mr-3"></i>
                                Profile Settings
                              </Link>
                              <Link href="/my-resumes" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <i className="ri-file-list-line mr-3"></i>
                                My Resumes
                              </Link>
                              <Link href="/billing" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <i className="ri-credit-card-line mr-3"></i>
                                Billing
                              </Link>
                            </div>
                            
                            <div className="border-t border-gray-100 pt-2">
                              <button 
                                onClick={handleLogout}
                                className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-50 transition-colors"
                              >
                                <i className="ri-logout-circle-line mr-3"></i>
                                Sign Out
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    // Login/Signup buttons for non-authenticated users
                    <>
                      <Link href="/login" className="px-3 lg:px-6 py-2 text-gray-700 hover:text-blue-600 transition-colors border border-gray-300 rounded-lg hover:border-blue-300 whitespace-nowrap text-sm lg:text-base">
                        Login
                      </Link>
                      <Link href="/signup" className="px-3 lg:px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap text-sm lg:text-base">
                        Free Account
                      </Link>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation Menu - Updated to match image */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-lg z-50">
            <div className="px-4 py-4 space-y-3">
              
              {/* Resume Builder - Blue Button */}
              <Link 
                href="/builder" 
                className="block w-full px-4 py-3 text-center text-white bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Resume Builder
              </Link>

              {/* Simple Menu Items */}
              <Link 
                href="/resume-templates" 
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors text-left"
                onClick={() => setMobileMenuOpen(false)}
              >
                Resume Templates
              </Link>
              
              <Link 
                href="/cv-templates" 
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors text-left"
                onClick={() => setMobileMenuOpen(false)}
              >
                CV Templates
              </Link>
              
              <Link 
                href="/cover-letter-builder" 
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors text-left"
                onClick={() => setMobileMenuOpen(false)}
              >
                Cover Letter Builder
              </Link>
              
              <Link 
                href="/interview-tips" 
                className="block px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors text-left"
                onClick={() => setMobileMenuOpen(false)}
              >
                Interview Tips
              </Link>

              {/* Auth Section at Bottom */}
              <div className="pt-4 border-t border-gray-200 space-y-2">
                {isAuthenticated && user ? (
                  <div className="space-y-2">
                    <div className="px-4 py-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        {user.picture ? (
                          <img src={user.picture} alt={user.name} className="w-8 h-8 rounded-full" />
                        ) : (
                          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                            <span className="text-white font-medium text-sm">
                              {(user.firstName || user.name || 'U')[0].toUpperCase()}
                            </span>
                          </div>
                        )}
                        <div>
                          <p className="font-medium text-gray-900 text-sm">
                            {user.name || `${user.firstName} ${user.lastName}`}
                          </p>
                          <p className="text-xs text-gray-600">{user.email}</p>
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        handleLogout();
                        setMobileMenuOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      Sign Out
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Link 
                      href="/login" 
                      className="block px-4 py-2 text-center text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Login
                    </Link>
                    <Link 
                      href="/signup" 
                      className="block px-4 py-2 text-center bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Free Account
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

      </header>
    </>
  );
}
